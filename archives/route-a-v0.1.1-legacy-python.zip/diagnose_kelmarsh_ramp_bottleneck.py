"""Read-only attribution counts on already-inspected development forecasts."""
from pathlib import Path
import json

import numpy as np
import pandas as pd

from diagnose_gefcom2012_data_attribution import match_truth
from revision_common import write

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'out_kelmarsh_ramp_probability'/'expanded_development'
OUT=ROOT/'out_kelmarsh_ramp_probability'/'bottleneck_diagnosis'


def nearby(mask,k):
    return np.stack([mask[:,max(0,j-k):min(24,j+k+1)].any(axis=1) for j in range(24)],axis=1)


def main():
    z=np.load(SOURCE/'scores.npz')
    y=z['actual'];gate=z['gate'];up=y>.1
    result=dict(scope='already-inspected Kelmarsh February–December2024 development only; no fitting or independent evaluation',
        days=len(y),events=int(up.sum()),same_hour_nwp_gate_events=int((up&gate).sum()),first_lead_events=int(up[:,0].sum()))
    for k in (1,2,3):
        result[f'nwp_gate_within_{k}h_events']=int((up&nearby(gate,k)).sum())
    cut=json.loads((SOURCE/'diagnostic_cutoffs.json').read_text())
    for name,field in [('qrf','qrf'),('annual_q90','q90'),('ramp_probability','probability')]:
        if name=='qrf':
            al=z[field]>.1
        else:
            c=cut[name];s=z[field]
            al=np.where(gate,(s>c['value'])|((s==c['value'])&(z['tie']>=c['tie'])),z['qrf']>.1)
        hit=match_truth(up,al)
        result[name]=dict(total_hits=int((up&hit).sum()),gated_hits=int((up&hit&gate).sum()),nongated_hits=int((up&hit&~gate).sum()))
    sc=pd.read_csv(ROOT/'out_kelmarsh_gfs'/'scada_hourly_2024.csv',parse_dates=['target']).set_index('target')
    origins=pd.to_datetime(z['origins'],utc=True)
    wind=np.asarray([sc.reindex(pd.date_range(o,o+pd.Timedelta(hours=24),freq='h')).wind_speed.to_numpy() for o in origins])
    dw=np.diff(wind,axis=1)
    for threshold in (.25,.5,1.):
        sig=dw>=threshold
        result[f'observed_wind_rise_{threshold}']=dict(valid_ramps=int((up&np.isfinite(dw)).sum()),
            same_hour_ramps=int((up&sig).sum()),within1h_ramps=int((up&nearby(sig,1)).sum()),
            same_hour_ramps_missing_nwp_gate=int((up&sig&~gate).sum()))
    result['cautions']=[
        'Signal occurrence around true events is not alarm recall at controlled false rate or a predictive upper bound.',
        'Expanding the neighborhood automatically increases chance matches; include quiet negatives and keep identical event denominators in a prospective comparison.',
        'Observed future SCADA wind is explanatory only, never a deployable input; sensor height/location and turbine-operation dependence prevent clean causal NWP-error attribution.',
        'NWP gate at first lead is unavailable;31 true events are at first lead. Windows stay inside one issued24h forecast.',
        'Current correction branches train only on gate>=0.5; outside it alarms remain QRF, although nearby alarms can match an outside-gate event.',
    ]
    write(OUT/'counts.json',result)
    (OUT/'RESULTS.md').write_text('\n'.join([
        '# 已有开发期的爬坡瓶颈诊断','',
        '不重训、不改阈值、不打开独立样本。读取已保存的逐小时评分及同一批SCADA风速。','',
        '| 描述性条件 | 覆盖真实爬坡 | 占625个事件 |','|---|---:|---:|',
        f'| 同小时NWP风速增幅≥0.5m/s | {result["same_hour_nwp_gate_events"]} | 34.88% |',
        f'| 同批NWP前后1小时存在上述信号 | {result["nwp_gate_within_1h_events"]} | 61.76% |',
        f'| 同批NWP前后2小时存在上述信号 | {result["nwp_gate_within_2h_events"]} | 75.04% |',
        f'| 同小时实测风速增幅≥0.5m/s | {result["observed_wind_rise_0.5"]["same_hour_ramps"]} | 98.08% |','',
        '上述比例不能当作可部署命中率。邻域更大也会增加平稳误标；实测风不等同于100m格点风，并可能受机组运行影响。NWP有邻域信号不证明只有相位误差，仍可能有幅度、风向或偶然匹配问题。','',
        '625个事件中407个不满足同小时门控，其中31个是无法计算同批差分的首时效。原QRF/q90/概率分支全小时命中110/124/125，门控组70/73/70，门控外40/51/55。门控外的变化来自邻近门控报警的一对一匹配，并非分支主动修正了所有门控外小时。','',
        '已有证据首先支持检验“局部时间结构及同小时硬门控”，不支持直接认定NWP毫无信息。NWP实际精度仍是上游限制，阈值跨期漂移亦已存在，但单独重定标不能消除同误报排序收益不足。',
        '下一项建议为局部NWP轨迹特征×门控范围的2×2开发对照。两种特征模型统一用同一年度、相同完整发报日和相同训练小时池拟合；固定分类目标、树配置与QRF，分开比较同小时门控和邻域门控。所有策略在同一批全部真实事件、同一个全小时平稳误报预算下评分，避免更换分母制造收益。既有门控训练模型作为附加冻结参照，不能把重新训练的2×2基线当作旧权重精确复现。','',
        '复现：`python diagnose_kelmarsh_ramp_bottleneck.py`。完整计数与解释边界见counts.json。','']),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
