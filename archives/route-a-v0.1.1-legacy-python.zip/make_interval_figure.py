"""Generate the final prediction-interval figure (actual vs C0 vs Final bounds)."""
from __future__ import annotations

import json
import time
from pathlib import Path

import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.multioutput import MultiOutputRegressor
from threadpoolctl import threadpool_limits

from data import build_situations, load_dataframe
from execute_x01 import cfg_for
from online_calibration import simulate
from run_c3 import build_cells, fit_head
from run_calibration import cache_predictions, indices_for
from run_c1 import signed_change

ROOT = Path(__file__).parent
MODEL = ROOT / 'out_v3/x01/tasks/NH_H0'
OUT = ROOT / 'out_final'
H0 = dict(max_iter=50, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, random_state=0)
CAP = 12300.0


def recompute():
    cfg = cfg_for()
    d = build_situations(load_dataframe(cfg), cfg)
    X_all = np.hstack([d['feat'], d['cond']])
    y_all = d['target']
    origins = d['origin_ts']
    valid = d['target_valid']
    mmore = (origins >= '2019-01-01') & (origins < '2020-07-01') & valid
    scaler = joblib.load(MODEL / 'scaler.joblib')
    Xs_all = scaler.transform(X_all)
    lower_head = MultiOutputRegressor(HistGradientBoostingRegressor(loss='quantile', quantile=0.05, **H0))
    lower_head.fit(Xs_all[mmore], y_all[mmore])
    X_cells, sL, sU, cvalid, corigins = build_cells()
    data = cache_predictions()
    upper_frozen = data['raw_upper_original']
    pred_idx = data['global_indices']
    lp = lower_head.predict(Xs_all[pred_idx])
    raw_lo = np.minimum(lp, upper_frozen)
    raw_hi = np.maximum(lp, upper_frozen)
    N, H = sU.shape
    rfit = (corigins >= np.datetime64('2020-01-01')) & (corigins < np.datetime64('2020-07-01'))
    train_mask = np.broadcast_to((rfit & cvalid)[:, None], (N, H))
    head_u = fit_head(X_cells.reshape(N * H, -1), sU.reshape(-1), train_mask.reshape(-1))
    bU = head_u.predict(X_cells.reshape(N * H, -1)).reshape(N, H)
    intervals = {}
    for year in ('2021', '2022'):
        seed, score = indices_for(data, year)
        c0 = simulate(data['origins'], data['target_end'], data['y'], raw_lo, raw_hi,
                      data['valid'], seed, score, 'rolling', 84)
        hy_lo = raw_lo[score] - c0['q_signed']
        hy_hi = raw_hi[score] + bU[score]
        empty = hy_lo > hy_hi
        center = (raw_lo[score] + raw_hi[score]) / 2
        hy_lo = np.where(empty, center, hy_lo); hy_hi = np.where(empty, center, hy_hi)
        intervals[year] = {
            'y': data['y'][score], 'valid': data['valid'][score],
            'last_hour': data['last_hour'][score],
            'origins': data['origins'][score],
            'C0': (c0['lo'], c0['hi']), 'Final': (hy_lo, hy_hi),
        }
    np.savez_compressed(OUT / 'intervals.npz',
                        **{f'{y}_{k}': v for y, iv in intervals.items() for k, v in iv.items()
                           if k in ('y', 'valid', 'last_hour', 'origins')})
    return intervals


def plot_day(ax, year, day_idx, intervals):
    iv = intervals[year]
    y = iv['y'][day_idx]
    lo_c, hi_c = iv['C0'][0][day_idx], iv['C0'][1][day_idx]
    lo_f, hi_f = iv['Final'][0][day_idx], iv['Final'][1][day_idx]
    x = np.arange(1, len(y) + 1)
    ax.fill_between(x, lo_c, hi_c, color='tab:gray', alpha=0.30, label='C0 interval')
    ax.fill_between(x, lo_f, hi_f, color='tab:blue', alpha=0.35, label='Final interval')
    ax.plot(x, y, color='k', lw=1.4, label='actual')
    ax.set_xticks([1, 6, 12, 18, 24])
    ax.set_ylabel('power (kW)')
    ax.grid(alpha=0.3)


def find_days(intervals):
    picked = {}
    for year in ('2021', '2022'):
        iv = intervals[year]
        y, valid = iv['y'], iv['valid']
        chg = signed_change(y, iv['last_hour'])
        up = chg > 1230.0
        c0 = iv['C0']; fn = iv['Final']
        # day with >=1 up-ramp cell where C0 upper misses but Final covers
        miss_c0 = (y > c0[1]) & up
        miss_fn = (y > fn[1]) & up
        fixed = miss_c0 & ~miss_fn
        cand = np.where((fixed.sum(axis=1) >= 1) & valid)[0]
        picked[year] = int(cand[0]) if len(cand) else int(np.where(valid)[0][len(np.where(valid)[0]) // 2])
    return picked


def main():
    began = time.perf_counter()
    intervals = recompute()
    picked = find_days(intervals)
    fig, axes = plt.subplots(2, 1, figsize=(10, 7))
    for i, year in enumerate(('2021', '2022')):
        di = picked[year]
        plot_day(axes[i], year, di, intervals)
        axes[i].set_title(f'{year} · origin {intervals[year]["origins"][di]} (hourly blocks)')
    axes[0].legend(fontsize=8, ncol=3, loc='upper right')
    plt.tight_layout()
    plt.savefig(OUT / 'interval_example.png', dpi=110)
    plt.close(fig)
    print(f'picked days: {picked}')
    print(f'[done] -> out_final/interval_example.png ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
