"""Config sweep for the R2 shared-head quantile model (2014 validation only).

Pre-fixed candidate configs (vs frozen A). A = frozen; B/C = stronger but more
regularized. Select on 2014 Apr-Jun validation, then freeze before evaluation.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from gefcom2014_experiment import metrics
from gefcom_protocol_v2 import index, prepare
from online_calibration import simulate
from strong_baselines import build_shared

OUT = Path('out_gefcom_config_sweep')
CONFIGS = {
    'A_frozen(50/31/20/0)': dict(max_iter=50, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, random_state=0),
    'B_reg(200/15/40/1)': dict(max_iter=200, max_leaf_nodes=15, min_samples_leaf=40, l2_regularization=1.0, random_state=0),
    'C_mid(100/23/30/0.5)': dict(max_iter=100, max_leaf_nodes=23, min_samples_leaf=30, l2_regularization=0.5, random_state=0),
}


def fit_shared(X, y, tr_unf, q, pkg):
    sc = StandardScaler().fit(X[tr_unf])
    xs = sc.transform(X)
    m = HistGradientBoostingRegressor(loss='quantile', quantile=q, **pkg)
    m.fit(xs[tr_unf], y[tr_unf])
    return m.predict(xs).reshape(-1, 24)


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    farms, _ = prepare(2014)
    rows = []
    for farm, d in farms.items():
        tr = index(d, 'train', True); vs = index(d, 'validation_seed'); vi = index(d, 'validation')
        tr_unf = np.repeat(np.isin(np.arange(len(d['origins'])), tr), 24)
        X, y, S = build_shared(d, 'R2')
        for name, pkg in CONFIGS.items():
            lo = fit_shared(X, y, tr_unf, 0.05, pkg)
            hi = fit_shared(X, y, tr_unf, 0.95, pkg)
            q05, q95 = lo, hi
            lo = np.minimum(q05, q95); hi = np.maximum(q05, q95)
            res = simulate(d['origins'], d['ends'], d['y'], lo, hi, d['valid'], vs, vi, 'rolling', 84)
            L = np.clip(res['lo'], 0, 1); U = np.clip(res['hi'], 0, 1)
            met = metrics(d['y'][vi], L, U, d['valid'][vi], d['history'][vi, -1])
            for g, v in met.items():
                rows.append(dict(farm=farm, config=name, group=g, **v))
        print(f'  farm{farm:02d} done', flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(OUT / 'validation_per_farm.csv', index=False)
    macro = df.groupby(['config', 'group'])[['coverage', 'width', 'IS', 'lower_miss', 'upper_miss']].mean().reset_index()
    macro.to_csv(OUT / 'validation_macro.csv', index=False)
    print('\n===== 2014 validation (clipped CQR, macro 10 farms) =====')
    for g in ('all', 'up_ramp', 'near_zero'):
        line = f'  {g:9s}'
        for name in CONFIGS:
            r = macro[(macro.config == name) & (macro.group == g)].iloc[0]
            line += f"  {name.split('(')[0]}: cov={r['coverage']*100:5.1f}% w={r['width']*100:5.2f}% IS={r['IS']:.4f}"
        print(line)
    print(f'\n[done] ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
