"""Full-response QRF without the dense (trees,nodes,max_leaf_size) padding.

Same bootstrap trees, inverse leaf-size weights, and quantile-forest 1.4.2
weighted-linear quantile kernel as the existing baseline. No response truncation.
Only the currently used single-output/bootstrap/full-sample setting is exposed.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'.aris/qrf-packages'))
import numpy as np
from scipy.sparse import csr_matrix,vstack
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble._forest import _generate_sample_indices
from quantile_forest._quantile_forest_fast import calc_weighted_quantile


class SparseLeafQRF:
    def __init__(self,n_estimators=500,min_samples_leaf=10,random_state=0,n_jobs=8):
        self.n_estimators=n_estimators;self.min_samples_leaf=min_samples_leaf
        self.random_state=random_state;self.n_jobs=n_jobs

    def fit(self,X,y):
        X=np.asarray(X,dtype='float32');y=np.asarray(y,dtype='float64')
        self.forest=RandomForestRegressor(n_estimators=self.n_estimators,min_samples_leaf=self.min_samples_leaf,
            max_features=1.,bootstrap=True,random_state=self.random_state,n_jobs=self.n_jobs).fit(X,y)
        return self.build_responses(X,y)

    def build_responses(self,X,y):
        """Can also attach an existing forest for deterministic equivalence checks."""
        n=len(y);sorter=np.argsort(y);rank=np.argsort(sorter)
        self.sorted_y=np.asarray(y[sorter],dtype='float64')
        matrices=[];self.lookups=[];sizes=[];offset=0
        for tree in self.forest.estimators_:
            bootstrap=_generate_sample_indices(tree.random_state,n,n)
            leaves=tree.apply(X)[bootstrap]
            node_ids,inverse,counts=np.unique(leaves,return_inverse=True,return_counts=True)
            lookup=np.full(tree.tree_.node_count,-1,dtype='int32');lookup[node_ids]=offset+np.arange(len(node_ids))
            self.lookups.append(lookup);offset+=len(node_ids);sizes.append(counts)
            # Duplicate bootstrap occurrences are summed into the same sorted-training column.
            weights=1./counts[inverse]
            mat=csr_matrix((weights,(inverse,rank[bootstrap])),shape=(len(node_ids),n))
            mat.sum_duplicates();mat.sort_indices();matrices.append(mat)
        self.responses=vstack(matrices,format='csr');self.leaf_sizes=np.concatenate(sizes)
        self.n_trees=len(self.forest.estimators_)
        return self

    def predict(self,X,quantiles=(.05,.95),batch_size=128):
        X=np.asarray(X,dtype='float32');out=np.empty((len(X),len(quantiles)))
        for start in range(0,len(X),batch_size):
            xx=X[start:start+batch_size];nodes=self.forest.apply(xx)
            rows=np.column_stack([self.lookups[t][nodes[:,t]] for t in range(self.n_trees)])
            assert (rows>=0).all()
            selector=csr_matrix((np.ones(rows.size),
                (np.repeat(np.arange(len(xx)),self.n_trees),rows.ravel())),shape=(len(xx),self.responses.shape[0]))
            weights=selector@self.responses;weights.sort_indices()
            # Preserve the baseline kernel's total-frequency normalization, not merely its CDF.
            multipliers=self.leaf_sizes[rows].sum(axis=1)/self.n_trees
            for j in range(len(xx)):
                begin,end=weights.indptr[j:j+2];idx=weights.indices[begin:end]
                w=weights.data[begin:end]*multipliers[j]
                out[start+j]=calc_weighted_quantile(self.sorted_y[idx],w,list(quantiles),b'linear',True)
        return out

    def storage_bytes(self):
        r=self.responses
        return int(r.data.nbytes+r.indices.nbytes+r.indptr.nbytes+self.leaf_sizes.nbytes+
            self.sorted_y.nbytes+sum(a.nbytes for a in self.lookups))
