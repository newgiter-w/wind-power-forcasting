"""Deep-learning baseline: shared-lead quantile MLP on the SAME 122-dim R2 features.

Compares a neural network (pinball-loss MLP) against the frozen GBM (R2) under
the identical protocol (features, train 2012, rolling-84 CQR, clip[0,1]).
Early stopping on 2013 Q1 (validation_seed); selection on 2013 Q2; eval 2013 H2.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from gefcom2014_experiment import metrics
from gefcom_protocol_v2 import index, prepare
from online_calibration import simulate
from strong_baselines import build_shared

OUT = Path('out_gefcom_dl_baseline')


def pinball_loss(pred, y, q):
    diff = y - pred
    return torch.mean(torch.maximum(q * diff, (q - 1) * diff))


class QuantileMLP(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 256), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(256, 128), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(128, 64), nn.ReLU(),
            nn.Linear(64, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


def train_model(Xtr, ytr, Xev, yev, q, seed=0):
    torch.manual_seed(seed)
    model = QuantileMLP(Xtr.shape[1])
    opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    Xtr_t = torch.tensor(Xtr, dtype=torch.float32)
    ytr_t = torch.tensor(ytr, dtype=torch.float32)
    Xev_t = torch.tensor(Xev, dtype=torch.float32)
    yev_t = torch.tensor(yev, dtype=torch.float32)
    best_loss = float('inf'); best_state = None; patience = 20; bad = 0
    trace = []
    for epoch in range(200):
        model.train()
        perm = torch.randperm(len(Xtr_t))
        for i in range(0, len(Xtr_t), 256):
            idx = perm[i:i + 256]
            opt.zero_grad()
            loss = pinball_loss(model(Xtr_t[idx]), ytr_t[idx], q)
            loss.backward(); opt.step()
        model.eval()
        with torch.no_grad():
            vloss = pinball_loss(model(Xev_t), yev_t, q).item()
        trace.append({'epoch': epoch + 1, 'validation_pinball': vloss})
        if vloss < best_loss - 1e-6:
            best_loss = vloss; best_state = {k: v.clone() for k, v in model.state_dict().items()}; bad = 0
        else:
            bad += 1
            if bad >= patience:
                break
    model.load_state_dict(best_state)
    model.eval()
    model.fit_summary = dict(epochs=len(trace), best_validation_pinball=best_loss, trace=trace)
    return model


def main():
    # Versioned restoration/diagnostic pipeline; never overwrite legacy CSVs.
    from run_revision_mlp import main as revised_main
    revised_main()


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
