"""Fixed-weight global/rolling/ACI comparison with predeclared chronological tuning."""
from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from threadpoolctl import threadpool_limits

import evaluate as ev
from data import build_situations,load_dataframe
from execute_x01 import cfg_for
from online_calibration import simulate

ROOT=Path(__file__).parent
OUT=ROOT/'out_calibration_v1'
MODEL=ROOT/'out_v3/x01/tasks/NH_H0'
PERIODS={
    'tuning':{'seed':['2020-01-01','2020-04-01'],'score':['2020-04-01','2020-07-01']},
    '2021':{'seed':['2020-10-01','2021-01-01'],'score':['2021-01-01','2022-01-01']},
    '2022':{'seed':['2021-10-01','2022-01-01'],'score':['2022-01-01','2023-01-01']},
}
WINDOWS=[28,56,84]
GAMMAS=[.002,.005,.01]
STAT_SPEC=importlib.util.spec_from_file_location('calibration_statistics',ROOT/'statistics.py')
STAT=importlib.util.module_from_spec(STAT_SPEC);STAT_SPEC.loader.exec_module(STAT)


def write_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def cache_predictions():
    path=OUT/'raw_predictions.npz'
    if path.exists():
        with np.load(path) as p:
            return {k:p[k] for k in p.files}
    d=build_situations(load_dataframe(cfg_for()),cfg_for())
    indices=np.flatnonzero((d['origin_ts']>='2020-01-01')&(d['origin_ts']<'2023-01-01'))
    X=np.hstack([d['feat'][indices],d['cond'][indices]])
    if not np.isfinite(X).all():raise ValueError('Nonfinite historical features')
    spec=json.loads((MODEL/'effective_spec.json').read_text(encoding='utf-8'))
    train_dates=pd.to_datetime(spec['origins_by_phase']['T'])
    assert train_dates.min().year==2019 and train_dates.max().year==2019
    models=joblib.load(MODEL/'models.joblib');scaler=joblib.load(MODEL/'scaler.joblib')
    assert X.shape[1]==167==scaler.n_features_in_
    for head in ('lower','upper'):
        for estimator in models[head].estimators_:
            for key,value in spec['package'].items():assert estimator.get_params()[key]==value
    began=time.perf_counter();scaled=scaler.transform(X)
    lower=models['lower'].predict(scaled);upper=models['upper'].predict(scaled)
    elapsed=time.perf_counter()-began
    data={'global_indices':indices,'origins':d['origin_ts'].iloc[indices].to_numpy(dtype='datetime64[ns]'),
          'target_start':d['target_start_ts'].iloc[indices].to_numpy(dtype='datetime64[ns]'),
          'target_end':d['target_end_ts'].iloc[indices].to_numpy(dtype='datetime64[ns]'),
          'y':d['target'][indices],'valid':d['target_valid'][indices],
          'raw_lower_original':lower,'raw_upper_original':upper,
          'raw_lo':np.minimum(lower,upper),'raw_hi':np.maximum(lower,upper),
          'last_hour':d['cond'][indices,-6:].mean(axis=1)}
    np.savez_compressed(path,**data)
    # The earlier X01 forecaster and raw predictions must be reproduced exactly.
    with np.load(MODEL/'predictions.npz') as old:
        old_dates=pd.to_datetime(json.loads((MODEL/'result.json').read_text(encoding='utf-8'))['origin_ids'])
        rows=pd.DatetimeIndex(data['origins']).get_indexer(old_dates)
        np.testing.assert_allclose(lower[rows],old['lo_raw_score'],rtol=0,atol=1e-12)
        np.testing.assert_allclose(upper[rows],old['hi_raw_score'],rtol=0,atol=1e-12)
    write_json(OUT/'model_identity.json',{'model_file':str(MODEL/'models.joblib'),
                'scaler_file':str(MODEL/'scaler.joblib'),'training_origin_min':str(train_dates.min()),
                'training_origin_max':str(train_dates.max()),'package':spec['package'],
                'features':167,'prediction_seconds':elapsed,'model_training_tasks':0,
                'X01_raw_prediction_reproduction':'PASS','raw_quantile_crossings':int((lower>upper).sum()),
                'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
                'platform':platform.platform(),'executable':sys.executable})
    return data


def indices_for(data,period):
    t=data['origins']
    a,b=PERIODS[period]['seed'];c,d=PERIODS[period]['score']
    seed=np.flatnonzero((t>=np.datetime64(a))&(t<np.datetime64(b)))
    score=np.flatnonzero((t>=np.datetime64(c))&(t<np.datetime64(d)))
    assert data['target_end'][seed].max()<=data['origins'][score[0]]
    return seed,score


def assess(data,result):
    idx=result['indices'];valid=data['valid'][idx];y=data['y'][idx]
    lo,hi=result['lo'],result['hi']
    inside=(y>=lo)&(y<=hi)
    empty=lo>hi;nonfinite=~np.isfinite(lo)|~np.isfinite(hi)
    usable=valid[:,None]&~empty&~nonfinite
    exceptional=bool(np.any((empty|nonfinite)[valid]))
    width=np.maximum(hi-lo,0)/12300.
    values=np.zeros_like(y)
    if usable.any():
        values[usable]=ev.interval_score_values(y[usable],lo[usable],hi[usable],.1)/12300.
    ramp=ev.ramp_mask(y,12300.,.1,prev=data['last_hour'][idx])
    vmask=np.broadcast_to(valid[:,None],y.shape)
    def group(mask):
        m=mask&vmask;count=int(m.sum())
        if not count:return {'cells':0,'coverage':None,'width':None,'score':None,'origins':0}
        finite_good=bool(np.all(usable[m]))
        return {'cells':count,'origins':int(m.any(axis=1).sum()),'coverage':float(inside[m].mean()),
                'width':float(width[m].mean()) if finite_good else None,
                'score':float(values[m].mean()) if finite_good else None}
    overall=group(np.ones_like(y,dtype=bool))
    overall.update(coverage_error=abs(overall['coverage']-.9),
                   nonfinite_cells=int((nonfinite&vmask).sum()),empty_cells=int((empty&vmask).sum()),
                   forecast_origins=len(idx),excluded_origins=int((~valid).sum()),
                   min_calibration_days=int(result['n_cal'].min()),max_calibration_days=int(result['n_cal'].max()),
                   state_projection_count=result['state_projection_count'],
                   support_projection_count=result['support_projection_count'],
                   midpoint_expansion_count=result['midpoint_expansion_count'])
    metrics={'all':overall,'ramp':group(ramp),'non_ramp':group(~ramp),'monthly':{},'lead':{}}
    months=pd.DatetimeIndex(data['origins'][idx]).month
    for month in np.unique(months):
        metrics['monthly'][str(month)]=group(np.broadcast_to((months==month)[:,None],y.shape))
    for lead in range(y.shape[1]):
        mask=np.zeros_like(y,dtype=bool);mask[:,lead]=True
        metrics['lead'][str(lead+1)]=group(mask)
    # Daily sums preserve varying ramp counts and missing complete days.
    counts=vmask.sum(axis=1).astype(float);ramp_valid=ramp&vmask
    daily=np.column_stack([counts,(inside&vmask).sum(axis=1),
                           np.where(vmask,width,0).sum(axis=1),
                           np.where(vmask,values,0).sum(axis=1),
                           ramp_valid.sum(axis=1),(inside&ramp_valid).sum(axis=1),
                           np.where(ramp_valid,width,0).sum(axis=1),
                           np.where(ramp_valid,values,0).sum(axis=1)])
    if exceptional:daily=None
    return metrics,daily


def execute(data,period,name,method,window=84,gamma=0.):
    directory=OUT/period/name
    seed,score=indices_for(data,period)
    began=time.perf_counter()
    result=simulate(data['origins'],data['target_end'],data['y'],data['raw_lo'],data['raw_hi'],
                    data['valid'],seed,score,method,window,gamma)
    elapsed=time.perf_counter()-began
    metrics,daily=assess(data,result)
    directory.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(directory/'state.npz',**{k:v for k,v in result.items() if isinstance(v,np.ndarray)})
    if daily is not None:np.savez_compressed(directory/'daily.npz',values=daily,origins=data['origins'][score])
    pd.DataFrame(result['feedback']).to_csv(directory/'feedback.csv',index=False)
    h=data['y'].shape[1]
    y=data['y'][score]
    ramp=ev.ramp_mask(y,12300.,.1,prev=data['last_hour'][score])
    start=np.repeat(data['target_start'][score],h)+np.tile(np.arange(h)*np.timedelta64(60,'m'),len(score))
    pd.DataFrame({'origin':np.repeat(data['origins'][score],h),'timezone':'UTC','lead_block':np.tile(np.arange(1,h+1),len(score)),
                  'target_block_start':start,'target_block_end':start+np.timedelta64(50,'m'),
                  'target_valid':np.repeat(data['valid'][score],h),'y':y.ravel(),
                  'raw_lo':data['raw_lo'][score].ravel(),'raw_hi':data['raw_hi'][score].ravel(),
                  'lo':result['lo'].ravel(),'hi':result['hi'].ravel(),'q_signed':result['q_signed'].ravel(),
                  'q_used':result['q_used'].ravel(),'alpha_requested':result['alpha_requested'].ravel(),
                  'alpha_used':result['alpha_used'].ravel(),'n_cal':np.repeat(result['n_cal'],h),
                  'max_label_end_used':np.repeat(result['max_label_end_used'],h),'ramp':ramp.ravel()
                  }).to_csv(directory/'forecasts.csv',index=False)
    payload={'name':name,'method':method,'window':window,'gamma':gamma,'metrics':metrics,
             'elapsed_calibration_seconds':elapsed,'initial_seed_days':int(data['valid'][seed].sum()),
             'score_period_UTC':PERIODS[period]['score']}
    write_json(directory/'metrics.json',payload)
    print(f"[{period}/{name}] coverage={metrics['all']['coverage']:.3%} "
          f"width={metrics['all']['width']} IS={metrics['all']['score']} "
          f"ramp_cov={metrics['ramp']['coverage']}",flush=True)
    return payload,result,daily


def select_candidate(candidates,global_metrics):
    ramp_guard=global_metrics['ramp']['origins']>=20
    feasible=[]
    for name,payload in candidates.items():
        metrics=payload['metrics']
        okay=.88<=metrics['all']['coverage']<=.92 and metrics['all']['score'] is not None
        if ramp_guard:okay=okay and metrics['ramp']['coverage']>=global_metrics['ramp']['coverage']-.02
        if okay:feasible.append(name)
    if feasible:
        selected=min(feasible,key=lambda k:candidates[k]['metrics']['all']['score'])
    else:
        selected=min(candidates,key=lambda k:(candidates[k]['metrics']['all']['coverage_error'],
                                              candidates[k]['metrics']['all']['score']))
    return selected,{'feasible_candidates':feasible,'coverage_ramp_guard_passed':bool(feasible),
                     'fallback':'nearest_to_90_then_IS' if not feasible else None,
                     'ramp_guard_used':ramp_guard}


def aggregate(totals):
    c=np.maximum(totals[...,0],1);r=np.maximum(totals[...,4],1)
    return {'coverage':totals[...,1]/c,'width':totals[...,2]/c,'IS':totals[...,3]/c,
            'ramp_coverage':totals[...,5]/r,'ramp_width':totals[...,6]/r,'ramp_IS':totals[...,7]/r}


def paired_calibration(data,period,candidate,baseline,length):
    _,score=indices_for(data,period)
    start,end=PERIODS[period]['score']
    full=pd.date_range(start,pd.Timestamp(end)-pd.Timedelta(days=1),freq='D')
    days=pd.DatetimeIndex(data['origins'][score]).normalize()
    pos=full.get_indexer(days)
    def grid(values):
        a=np.zeros((len(full),8));a[pos]=values;return a
    cg,bg=grid(candidate),grid(baseline)
    rng=np.random.default_rng(0)
    starts=rng.integers(0,len(full)-length+1,size=(5000,int(np.ceil(len(full)/length))))
    sampled=(starts[:,:,None]+np.arange(length)).reshape(5000,-1)[:,:len(full)]
    def sums(values):return np.column_stack([values[sampled,k].sum(axis=1) for k in range(8)])
    c,b=aggregate(sums(cg)),aggregate(sums(bg))
    cp,bp=aggregate(cg.sum(axis=0)),aggregate(bg.sum(axis=0))
    comparisons={
        'coverage_change':(cp['coverage']-bp['coverage'],c['coverage']-b['coverage']),
        'coverage_error_reduction':(abs(bp['coverage']-.9)-abs(cp['coverage']-.9),abs(b['coverage']-.9)-abs(c['coverage']-.9)),
        'width_relative_reduction':(1-cp['width']/bp['width'],1-c['width']/b['width']),
        'IS_relative_gain':(1-cp['IS']/bp['IS'],1-c['IS']/b['IS']),
        'ramp_coverage_change':(cp['ramp_coverage']-bp['ramp_coverage'],c['ramp_coverage']-b['ramp_coverage']),
        'ramp_coverage_error_reduction':(abs(bp['ramp_coverage']-.9)-abs(cp['ramp_coverage']-.9),abs(b['ramp_coverage']-.9)-abs(c['ramp_coverage']-.9)),
        'ramp_IS_relative_gain':(1-cp['ramp_IS']/bp['ramp_IS'],1-c['ramp_IS']/b['ramp_IS'])}
    return {'block_days':length,'calendar_days':len(full),'resamples':5000,'seed':0,
            'metrics':{k:{'estimate':float(p),'ci95':np.quantile(v,[.025,.975]).tolist()} for k,(p,v) in comparisons.items()}}


def write_protocol():
    protocol={'date_local':'2026-11-01','time_basis':'UTC','model':str(MODEL),'model_training_tasks':0,
              'periods':PERIODS,'window_candidates_days':WINDOWS,'gamma_candidates':GAMMAS,
              'nominal_alpha':.1,'feedback':'whole_day_after_target_end; issue_before_future_quality_known',
              'score':'signed CQR; ceil((n+1)*(1-alpha))','annual_reset':True,
              'projected_ACI_state_bounds':[.02,.5],'projected_ACI_quantile_support':'alpha_effective>=1/(n+1)',
              'common_main_empty_set_policy':'expand_empty_to_raw_midpoint_singleton',
              'unprojected_diagnostic':'extended scores and raw empty sets retained; nonfinite IS marked unavailable',
              'selection':'2020 only; coverage/ramp constraints then IS; fallback nearest coverage then IS',
              'success_thresholds':{'coverage':[.88,.92],'width_reduction':.02,'max_IS_degradation':.02,'max_ramp_coverage_drop':.02},
              'bootstrap':{'days':[7,14],'resamples':5000,'seed':0},
              'source_references':['https://arxiv.org/html/2106.00170v3','https://github.com/isgibbs/AdaptiveConformal/blob/main/ACCode.R'],
              'inference_scope':'historical backtest; 2021/2022 not untouched new project datasets'}
    if (OUT/'protocol.json').exists():
        assert json.loads((OUT/'protocol.json').read_text(encoding='utf-8'))==protocol,'Frozen protocol mismatch'
    else:write_json(OUT/'protocol.json',protocol)
    snapshot=OUT/'source_executed';snapshot.mkdir(exist_ok=True)
    for name in ('online_calibration.py','run_calibration.py','models.py','data.py','evaluate.py','config.py','kelmarsh.py'):
        if not (snapshot/name).exists():shutil.copy2(ROOT/name,snapshot/name)


def main():
    started=time.perf_counter();OUT.mkdir(exist_ok=True);write_protocol()
    data=cache_predictions()
    tuning={}
    baseline,_,_=execute(data,'tuning','global_cqr','global')
    for w in WINDOWS:
        name=f'rolling_{w}'
        tuning[name]=execute(data,'tuning',name,'rolling',w)[0]
    selected_roll,roll_rule=select_candidate(tuning,baseline['metrics'])
    w=tuning[selected_roll]['window']
    aci={}
    for gamma in GAMMAS:
        name=f'aci_projected_{gamma:g}'
        aci[name]=execute(data,'tuning',name,'aci_projected',w,gamma)[0]
    selected_aci,aci_rule=select_candidate(aci,baseline['metrics'])
    gamma=aci[selected_aci]['gamma']
    stable=lambda payload:{k:v for k,v in payload.items() if k!='elapsed_calibration_seconds'}
    selection={'selected_window':w,'selected_gamma':gamma,'rolling_rule':roll_rule,'aci_rule':aci_rule,
               'tuning_period_UTC':PERIODS['tuning'],'frozen_before_yearly_evaluation':True,
               'candidate_metrics':{k:stable(v) for k,v in {**tuning,**aci}.items()},'baseline':stable(baseline)}
    if (OUT/'selection.json').exists():
        assert json.loads((OUT/'selection.json').read_text(encoding='utf-8'))==selection,'Selection changed'
    else:write_json(OUT/'selection.json',selection)
    results={}
    for year in ('2021','2022'):
        results[year]={};daily={}
        for name,method in (('global_cqr','global'),('rolling_cqr','rolling'),
                            ('aci_projected','aci_projected'),('aci_unprojected','aci_unprojected')):
            payload,state,day=execute(data,year,name,method,w,gamma)
            results[year][name]=payload
            if day is not None:daily[name]=day
        comparisons={}
        for name in ('rolling_cqr','aci_projected'):
            comparisons[name+'_vs_global']={str(length):paired_calibration(data,year,daily[name],daily['global_cqr'],length) for length in (7,14)}
        comparisons['aci_vs_rolling']={str(length):paired_calibration(data,year,daily['aci_projected'],daily['rolling_cqr'],length) for length in (7,14)}
        write_json(OUT/year/'comparisons.json',comparisons)
        _,score=indices_for(data,year)
        raw_state={'indices':score,'lo':data['raw_lo'][score],'hi':data['raw_hi'][score],
                   'n_cal':np.zeros(len(score),dtype=int),'state_projection_count':0,
                   'support_projection_count':0,'midpoint_expansion_count':0}
        raw_metrics,_=assess(data,raw_state)
        results[year]['raw_reference']={'name':'raw_reference','method':'raw','metrics':raw_metrics}
        write_json(OUT/year/'raw_reference_metrics.json',results[year]['raw_reference'])
    write_json(OUT/'results.json',{'selection':selection,'years':results,'elapsed_seconds':time.perf_counter()-started})
    print(f'[complete] window={w} gamma={gamma} no training; elapsed={time.perf_counter()-started:.2f}s',flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
