"""Independently recompute metrics/calibration and reload the eight fitted tasks."""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

ROOT=Path(__file__).parent


def verify_directory(path, check_model):
    result=json.loads((path/'result.json').read_text(encoding='utf-8'))
    table=pd.read_csv(path/'forecasts.csv')
    with np.load(path/'predictions.npz') as p:
        y=p['y_score'];lo=p['lo_cqr'];hi=p['hi_cqr']
        assert np.isfinite(y).all() and np.isfinite(lo).all() and np.isfinite(hi).all()
        assert np.all(lo<=hi)
        n=len(p['y_cal']);rank=int(np.ceil((n+1)*.9))
        scores=np.maximum(p['lo_cal']-p['y_cal'],p['y_cal']-p['hi_cal'])
        expected_q=np.sort(scores,axis=0)[rank-1]
        np.testing.assert_allclose(expected_q,p['q_signed'],rtol=0,atol=1e-12)
        # Independent pinball expression of interval score, no use of evaluate.py.
        a=.1
        dl=y-lo;dh=y-hi
        matrix=(2/a)*(np.maximum(a/2*dl,(a/2-1)*dl)+np.maximum((1-a/2)*dh,(-a/2)*dh))/12300.
        np.testing.assert_allclose(matrix.ravel(),table.cqr_IS.to_numpy(),rtol=1e-12,atol=1e-12)
        np.testing.assert_allclose(matrix.mean(axis=1),result['cqr_per_origin'],rtol=1e-12,atol=1e-12)
        assert abs(matrix.mean()-result['cqr']['score'])<1e-12
        assert abs(((y>=lo)&(y<=hi)).mean()-result['cqr']['coverage'])<1e-12
        assert abs((hi-lo).mean()/12300.-result['cqr']['width'])<1e-12
        origins=pd.to_datetime(table.origin).drop_duplicates().reset_index(drop=True)
        expected=pd.Series(pd.to_datetime(result['origin_ids']))
        pd.testing.assert_series_equal(origins,expected,check_names=False)
        if check_model:
            models=joblib.load(path/'models.joblib')
            scaler=joblib.load(path/'scaler.joblib')
            spec=json.loads((path/'effective_spec.json').read_text(encoding='utf-8'))
            with np.load(path/'inputs.npz') as inputs:
                sample=scaler.transform(inputs['X_Score'][:5])
                np.testing.assert_allclose(models['lower'].predict(sample),p['lo_raw_score'][:5],rtol=0,atol=1e-12)
                np.testing.assert_allclose(models['upper'].predict(sample),p['hi_raw_score'][:5],rtol=0,atol=1e-12)
                assert len(inputs['y_T'])==(684 if 'repair' in path.parts else 351)
            for head in ('lower','upper'):
                assert len(models[head].estimators_)==24
                for estimator in models[head].estimators_:
                    for key,value in spec['package'].items():
                        assert estimator.get_params()[key]==value
    return {'path':str(path),'origins':len(result['origin_ids']),
            'calibration_count':n,'calibration_rank':rank,'metric_reconstruction':True,
            'model_reload_verified':check_model,'q_negative_steps':int((expected_q<0).sum())}


def main():
    verified=[]
    for phase in ('repair','x01'):
        folder=ROOT/'out_v3'/phase
        assert (folder/'analysis.json').exists(),f'Missing completed analysis: {phase}'
        for path in sorted((folder/'tasks').iterdir()):
            verified.append(verify_directory(path,True))
        for path in sorted((folder/'baselines').iterdir()):
            verified.append(verify_directory(path,False))
    assert sum(v['model_reload_verified'] for v in verified)==8
    report={'status':'PASS','new_model_tasks':8,'artifact_groups':len(verified),'verified':verified,
            'scope':'new repair/X01 artifacts; legacy twelve-model step predictions unavailable'}
    (ROOT/'out_v3'/'repair'/'artifact_verification.json').write_text(
        json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
