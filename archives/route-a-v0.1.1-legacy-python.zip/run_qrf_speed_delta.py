"""Paired fixed-QRF comparison with same-issue NWP speed differences."""
from run_point_residual import (ROOT, OUT as BASE, cells, load_farms, feature_array,
                                index, calibration, frozen_spec, write, SparseLeafQRF)
from concurrent.futures import ProcessPoolExecutor
import joblib
import numpy as np
from sklearn.impute import SimpleImputer

OUT = ROOT/'out_gefcom_qrf_speed_delta_20261106'

def added_features(x):
    speed = x[:, -12].reshape(-1,24)
    cols = []
    for lag in (1,2,3):
        difference = np.full_like(speed,np.nan)
        difference[:,lag:] = speed[:,lag:]-speed[:,:-lag]
        cols.append(difference.ravel())
    return np.column_stack(cols)

def fit_farm(job):
    year,farm = job
    folder = OUT/f'gefcom{year}/farm_{farm:02}'
    folder.mkdir(parents=True,exist_ok=True)
    if (folder/'complete.json').exists():
        return
    d = load_farms(year)[farm]
    tr = index(d,'train',True)
    dev = index(d,'validation')
    ev = index(d,'evaluation')
    assert d['ends'][tr].max() <= d['origins'][index(d,'validation_seed')].min()
    extra = added_features(feature_array(year,farm,'GBM'))
    tm = cells(tr)
    imputer = SimpleImputer(strategy='median',add_indicator=True).fit(extra[tm])
    x = np.column_stack([feature_array(year,farm,'QRF'),imputer.transform(extra)]).astype('float32')
    model = SparseLeafQRF(500,10,0,n_jobs=2).fit(x[tm],d['y'][tr].ravel())
    query = np.r_[index(d,'validation_seed'),dev,ev]
    estimates = model.predict(x[cells(query)],(.05,.5,.95)).reshape(-1,24,3)
    assert (np.diff(estimates,axis=2)>=0).all()
    heads = np.full((*d['y'].shape,3),np.nan)
    heads[query] = estimates
    joblib.dump(dict(model=model,imputer=imputer),folder/'model.joblib',compress=1)
    np.savez_compressed(folder/'heads.npz',origins=d['origins'],train_days=tr,heads=heads)
    for stage in ('validation','evaluation'):
        ids,res = calibration(d,heads[:,:,0],heads[:,:,2],stage)
        np.savez_compressed(folder/f'{stage}.npz',ids=ids,lo=np.clip(res['lo'],0,1),
                            hi=np.clip(res['hi'],0,1),max_label_end=res['max_label_end_used'])
    write(folder/'complete.json',dict(farm=farm,year=year,train_days=len(tr)))
    print('SAVED',year,farm,flush=True)

def main():
    frozen_spec(OUT/'protocol.json',dict(seed=0,farms=17,model='QRF500 leaf10 max_features=1.0, seed0',
      features='original imputed R2 QRF inputs plus signed same-batch speed changes t minus t-k for k=1,2,3 and missing indicators',
      edge='earliest unavailable differences filled with proper-training median plus indicator',
      calibration='original per-farm per-lead signed rolling84 CQR',
      groups='same-hour >=0.5m/s, nearby only +/-2 leads, no nearby, lead1 unclassified; quiet actual absolute delta <=.05; forecast quiet proxy absolute NWP delta <.25',
      gates='2014 Q2 overall coverage>=.90 and drop<=.5pp, width increase<=1 capacity pp, IS no worse, all up upper miss lower, near-zero and down-ramp coverage drop<=1pp, quiet false alarms increase<=1pp',
      evaluation='report both datasets regardless of 2014 Q2 gates; retrospective'))
    for year in (2014,2012):
        with ProcessPoolExecutor(max_workers=6) as pool:
            list(pool.map(fit_farm,[(year,farm) for farm in load_farms(year)]))
        if year==2014:
            from report_qrf_speed_delta import compare, select
            select(compare(2014,'validation'))
    from report_qrf_speed_delta import report
    report()

if __name__=='__main__':
    main()
