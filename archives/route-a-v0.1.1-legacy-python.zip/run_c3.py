"""C3: conditioned upper/lower residual tails (quantile heads) + rolling signed CQR.

Two lightweight quantile regressors (quantile=.95) fit on R_fit = 2020 H1 using
the frozen NH_H0 raw predictions. Features are forecast-time-available only:
lead, raw L, raw U, last-hour power, past-6h mean/volatility/trend.
Then [L0=raw_lo-bL, U0=raw_hi+bU] get the same rolling-84 signed CQR as C0.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits

from data import build_situations, load_dataframe
from execute_x01 import cfg_for
from online_calibration import simulate
from run_calibration import cache_predictions, indices_for

ROOT = Path(__file__).parent
OUT = ROOT / 'out_c3'
HEAD_PKG = dict(max_iter=50, max_leaf_nodes=7, min_samples_leaf=40, l2_regularization=1.0, random_state=0)


def build_cells():
    """Return X (n_cells, 7), sL, sU (n_cells,), and per-cell origin timestamps + valid."""
    cfg = cfg_for()
    d = build_situations(load_dataframe(cfg), cfg)
    idx = np.flatnonzero((d['origin_ts'] >= '2020-01-01') & (d['origin_ts'] < '2023-01-01'))
    cond = d['cond'][idx]
    data = cache_predictions()
    assert np.array_equal(data['global_indices'], idx), 'cache index mismatch'
    raw_lo, raw_hi, y = data['raw_lo'], data['raw_hi'], data['y']
    valid = data['valid']
    N, H = y.shape
    last_hour = data['last_hour']                       # (N,)
    past6 = cond[:, -36:]                                # last 6 hours = 36 x 10min
    p6_mean = past6.mean(axis=1)
    p6_std = past6.std(axis=1)
    p6_trend = cond[:, -1] - cond[:, -36]
    lead = np.tile(np.arange(1, H + 1), (N, 1)).astype(float)
    day_feat = np.stack([last_hour, p6_mean, p6_std, p6_trend], axis=1)  # (N,4)
    X = np.concatenate([
        lead[:, :, None],
        raw_lo[:, :, None],
        raw_hi[:, :, None],
        np.repeat(day_feat, H, axis=1).reshape(N, H, 4),
    ], axis=2)                                          # (N,H,7)
    sL = raw_lo - y
    sU = y - raw_hi
    return X, sL, sU, valid, d['origin_ts'].iloc[idx].to_numpy(dtype='datetime64[ns]')


def fit_head(X, s, train_mask):
    Xtr = X[train_mask]
    s = s[train_mask]
    if not np.isfinite(Xtr).all() or not np.isfinite(s).all():
        raise ValueError('Nonfinite training data for residual head')
    m = HistGradientBoostingRegressor(loss='quantile', quantile=0.95, **HEAD_PKG)
    m.fit(Xtr, s)
    return m


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    X, sL, sU, valid, origins = build_cells()
    N, H = sL.shape
    # train mask: R_fit = 2020 H1, valid target days only (head trained on raw residual)
    o = origins
    rfit = (o >= np.datetime64('2020-01-01')) & (o < np.datetime64('2020-07-01'))
    train_mask = np.broadcast_to((rfit & valid)[:, None], (N, H))
    head_l = fit_head(X.reshape(N * H, -1), sL.reshape(-1), train_mask.reshape(-1))
    head_u = fit_head(X.reshape(N * H, -1), sU.reshape(-1), train_mask.reshape(-1))
    bL = head_l.predict(X.reshape(N * H, -1)).reshape(N, H)
    bU = head_u.predict(X.reshape(N * H, -1)).reshape(N, H)
    print(f'[heads] trained on {int(train_mask.any(axis=1).sum())} origins '
          f'({int(train_mask.sum())} cells); fit {time.perf_counter()-began:.1f}s', flush=True)

    data = cache_predictions()
    # C3 adjusted base intervals (replacing raw_lo/raw_hi)
    L0 = data['raw_lo'] - bL
    U0 = data['raw_hi'] + bU
    out = {}
    for year in ('2021', '2022'):
        seed, score = indices_for(data, year)
        c0 = simulate(data['origins'], data['target_end'], data['y'], data['raw_lo'], data['raw_hi'],
                      data['valid'], seed, score, 'rolling', 84)
        c3 = simulate(data['origins'], data['target_end'], data['y'], L0, U0,
                      data['valid'], seed, score, 'rolling', 84)
        # report: reuse the group metrics from run_c1
        from run_c1 import masks_for, group
        masks = masks_for(data, c0)
        print(f'\n===== {year} =====')
        for g in ('all', 'ramp', 'up_ramp', 'down_ramp', 'near_zero'):
            m = masks[g]
            r0 = group(data, c0, m); r3 = group(data, c3, m)
            def f(r): return ('n/a' if r is None else
                              f"{r['coverage']*100:5.1f}% w={r['width']*100:5.1f}% Lo={r['lower_miss']*100:4.1f}% Hi={r['upper_miss']*100:4.1f}%")
            print(f"  {g:11s} C0: {f(r0)}")
            print(f"  {'':11s} C3: {f(r3)}")
        out[year] = {'C0': {g: group(data, c0, masks[g]) for g in masks},
                     'C3': {g: group(data, c3, masks[g]) for g in masks}}
    (OUT / 'results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> out_c3/results.json ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
