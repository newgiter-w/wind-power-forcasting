"""Framework configuration.

All tunable parameters live here so the rest of the pipeline stays declarative.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import List, Optional


@dataclass
class Config:
    # ---- data ----------------------------------------------------------------
    # When empty, synthetic data is generated (smoke test). Otherwise a CSV path.
    data_path: str = ""
    timestamp_col: str = "timestamp"
    target_col: str = "power"
    weather_cols: List[str] = field(default_factory=lambda: ["wind_speed", "temperature", "pressure"])

    points_per_day: int = 96           # 15-min resolution -> 96 points/day
    synthetic_days: int = 365          # length of synthetic series

    # Kelmarsh real data (when set, overrides synthetic/CSV path)
    kelmarsh_root: str = ""            # e.g. D:/Study/wind_datasets/kelmarsh
    kelmarsh_years: Optional[List[int]] = None   # None = all available years
    kelmarsh_cache: str = ""           # optional slim farm-cache CSV (fast reload)

    # ---- horizon -------------------------------------------------------------
    horizon_days: int = 1              # 1..3 = short term, 7 = medium term
    condition_days: int = 1            # lookback window used for retrieval + features
    stride_points: int = 96            # step between consecutive forecast origins

    # ---- splits (chronological, never shuffled) ------------------------------
    train_frac: float = 0.60
    cal_frac: float = 0.20             # test frac = 1 - train - cal

    # ---- retrieval -----------------------------------------------------------
    top_k: int = 20                    # analog neighbors fed to the point/quantile model
    use_dtw: bool = True               # re-rank NN candidates with DTW on the z-scored window
    dtw_band: int = 24                 # Sakoe-Chiba band (points)
    nn_candidates: int = 100           # NN shortlist size before DTW re-ranking
    conformal_k: int = 30              # neighbors used as the LOCAL calibration set
    # Control: which neighbors condition the model. "similar" = real retrieval,
    # "random" = k random corpus members (isolates retrieval QUALITY vs extra signal),
    # "none" = no analog features at all (isolates whether retrieval helps).
    retrieval_mode: str = "similar"
    # Train-time retrieval-noise augmentation: fraction of the top-k similar
    # neighbors replaced by random ones (anti "copy-the-neighbor" overfitting).
    analog_noise_frac: float = 0.0

    # ---- analog conditioning -------------------------------------------------
    # Downsample the retrieved neighbor target windows to `analog_bins` values
    # (None = keep full horizon). Useful for medium-term to bound feature size.
    analog_bins: Optional[int] = None

    # ---- target granularity --------------------------------------------------
    # Aggregate the target (forecast) window into `horizon_bins` blocks (mean per
    # block). Medium-term (7 days) at 15-min = 672 points is intractable
    # per-step; use e.g. 7 (daily) or 48 (3.5-hour blocks). None = full resolution.
    horizon_bins: Optional[int] = None

    # ---- point / quantile model ---------------------------------------------
    point_model: str = "hist_gbr"      # hist_gbr (fast, recommended)
    quantile_model: str = "hist_gbr"   # hist_gbr with loss='quantile'
    n_estimators: int = 200
    max_depth: int = None

    # ---- intervals -----------------------------------------------------------
    confidence_levels: List[float] = field(default_factory=lambda: [0.90])
    interval_methods: List[str] = field(
        default_factory=lambda: ["quantile", "conformal", "cqr", "local_conformal"]
    )

    # ---- evaluation regimes --------------------------------------------------
    ramp_threshold_frac: float = 0.10   # |delta power|/capacity defining a ramp point
    capacity: Optional[float] = None    # MW; inferred from data when None

    # ---- misc ----------------------------------------------------------------
    out_dir: str = "out"
    seed: int = 0
    quiet: bool = False

    # ---- derived -------------------------------------------------------------
    @property
    def horizon_points(self) -> int:
        return self.horizon_days * self.points_per_day

    @property
    def condition_points(self) -> int:
        return self.condition_days * self.points_per_day

    def as_dict(self) -> dict:
        return asdict(self)


def default_config(**overrides) -> Config:
    cfg = Config()
    for k, v in overrides.items():
        if not hasattr(cfg, k):
            raise KeyError(f"unknown config key: {k}")
        setattr(cfg, k, v)
    return cfg
