"""GEFCom2014 A/B/C with ROLLING CQR (84-day window) instead of fixed CQR.

Re-trains the same q=.05/.95 models, predicts on all samples, then applies the
existing event-ordered rolling CQR (seed=2013 Q2, score=July-November). Reports rolling
vs fixed CQR coverage/width/IS per zone + macro.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

import gefcom_data as gd
from online_calibration import simulate
from run_gefcom_abc import build_X, conformal_quantile, fit_q, metrics, split

ROOT = Path(__file__).parent
OUT = ROOT / 'out_gefcom_rolling_corrected'


def run_zone(zone):
    s = gd.build_samples(gd.load_zone(zone))
    train, cal, test = split(s)
    tv = s['target_valid']
    inputs = s['history_valid'] & s['nwp_valid']
    train = train & tv & inputs; cal = cal & tv & inputs; test = test & inputs
    origins = s['origin_ts']
    target_end = origins + np.timedelta64(24, 'h')
    y = s['target']
    valid = s['target_valid']
    out = {}
    for c in ('A', 'B', 'C'):
        X = build_X(s, c)
        sc = StandardScaler().fit(X[train])
        Xs = sc.transform(X)
        lo_m = fit_q(Xs[train], y[train], 0.05)
        hi_m = fit_q(Xs[train], y[train], 0.95)
        lo_raw = lo_m.predict(Xs); hi_raw = hi_m.predict(Xs)
        lo = np.minimum(lo_raw, hi_raw); hi = np.maximum(lo_raw, hi_raw)
        # rolling CQR
        res = simulate(origins, target_end, y, lo, hi, valid,
                       np.where(cal)[0], np.where(test)[0], 'rolling', 84)
        # fixed CQR (for reference)
        lo_c = lo[cal]; hi_c = hi[cal]
        y_c = y[cal]
        q = np.array([conformal_quantile(np.maximum(lo_c[:, h] - y_c[:, h], y_c[:, h] - hi_c[:, h]), 0.9)
                      for h in range(24)])
        lo_fixed = lo[test] - q[None, :]; hi_fixed = hi[test] + q[None, :]
        out[c] = {
            'rolling': metrics(y[test], res['lo'], res['hi'], last_power=s['history'][test, -1], target_valid=tv[test]),
            'fixed': metrics(y[test], lo_fixed, hi_fixed, last_power=s['history'][test, -1], target_valid=tv[test]),
        }
    return out


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    results = {}
    for z in gd.ZONES:
        results[f'Zone{z}'] = run_zone(z)
        print(f'[done] Zone{z} ({time.perf_counter()-began:.1f}s)', flush=True)
    print('\n===== macro-average (10 zones) =====')
    for g in ('all', 'up_ramp', 'near_zero'):
        for m in ('fixed', 'rolling'):
            line = f'  {g:9s} {m:7s}'
            for c in ('A', 'B', 'C'):
                vals = [results[f'Zone{z}'][c][m][g] for z in range(1, 11)]
                cov = np.mean([v['coverage'] for v in vals if v])
                w = np.mean([v['width'] for v in vals if v])
                is_ = np.mean([v['IS'] for v in vals if v])
                line += f"  {c}: cov={cov*100:5.1f}% w={w*100:5.1f}% IS={is_:.3f}"
            print(line)
    (OUT / 'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> {OUT / "results.json"} ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
