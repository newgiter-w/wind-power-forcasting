"""Reproduce R2 without editing submitted sources; compare crossing fix and bootstrap."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
from pathlib import Path
import json,time,hashlib
import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from gefcom_protocol_v2 import prepare,index
from gefcom2014_experiment import metrics,masks
from strong_baselines import build_shared,fit_predict
from run_p2_2012 import build_shared_2012
from online_calibration import simulate

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'review_strong_baselines_20261103'
OUT.mkdir(exist_ok=True)

def write(name,x):
    (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def main():
    checks=[];rows=[];started=time.perf_counter();bootstrap=[]
    for year in [2014,2012]:
        farms,_=prepare(year)
        reference=pd.read_csv(ROOT/f'out_gefcom_strong_baselines_v1/p2_{year}_eval_per_farm.csv')
        dates=pd.date_range('2013-07-01' if year==2014 else '2011-07-01',max(pd.to_datetime(d['calendar'].origin).max() for d in farms.values()),freq='D')
        daily=np.zeros((3,len(farms),len(dates),5,4))
        for f,d in farms.items():
            folder=OUT/f'{year}_farm{f:02d}';folder.mkdir(exist_ok=True)
            X,y,S=(build_shared if year==2014 else build_shared_2012)(d,'R2')
            # Mechanical (sample, hour) ordering and native wind-curve witnesses.
            np.testing.assert_equal(y.reshape(S,24),d['y'])
            np.testing.assert_equal(X[:,107 if year==2014 else 108],np.tile(np.arange(1,25),S))
            extra=X[:,-14:].reshape(S,24,14)
            u=d['nwp'][:,:,-2];v=d['nwp'][:,:,-1]
            np.testing.assert_equal(extra[:,:,0],u);np.testing.assert_equal(extra[:,:,1],v)
            np.testing.assert_equal(extra[:,:,8][:,1:],u[:,:-1])
            np.testing.assert_equal(extra[:,:,10][:,:-1],u[:,1:])
            np.testing.assert_equal(extra[:,:,9][:,2:],u[:,:-2])
            np.testing.assert_equal(extra[:,:,11][:,:-2],u[:,2:])
            assert np.isnan(extra[:,0,8]).all() and np.isnan(extra[:,-1,10]).all()
            tr=index(d,'train',True);seed=index(d,'validation');score=index(d,'evaluation')
            tm=np.repeat(np.isin(np.arange(S),tr),24)
            assert d['ends'][tr].max()<=d['origins'][index(d,'validation_seed')].min()
            assert d['ends'][seed].max()<=d['origins'][score].min()
            pred=folder/'raw_heads.npz'
            if pred.exists():
                with np.load(pred) as z:ql=z['ql'];qu=z['qu']
            else:
                with threadpool_limits(limits=2):
                    ql,ml,sl=fit_predict(X,y,tm,.05);qu,mu,su=fit_predict(X,y,tm,.95)
                np.savez_compressed(pred,ql=ql,qu=qu)
                joblib.dump((ml,sl,mu,su),folder/'models_scalers.joblib',compress=3)
            crossed=ql>qu
            buggylo=np.minimum(ql,qu);buggyhi=np.maximum(buggylo,qu)
            fixedlo=np.minimum(ql,qu);fixedhi=np.maximum(ql,qu)
            stages={}
            for method,lo,hi in [('R2_submitted',buggylo,buggyhi),('R2_crossing_fixed',fixedlo,fixedhi)]:
                result=simulate(d['origins'],d['ends'],d['y'],lo,hi,d['valid'],seed,score,'rolling',84)
                assert (result['max_label_end_used']<=d['origins'][score]).all()
                stages[method]=(np.clip(result['lo'],0,1),np.clip(result['hi'],0,1))
                pd.DataFrame(result['feedback']).to_csv(folder/f'{method}_feedback.csv',index=False)
            src=ROOT/f'out_gefcom_protocol_v2/gefcom{year}/farm_{f:02d}/B_speed/evaluation_intervals.npz'
            with np.load(src) as z:
                np.testing.assert_equal(z['indices'],score)
                stages['R0']=(np.clip(z['lo'],0,1),np.clip(z['hi'],0,1))
            yy=d['y'][score];vv=d['valid'][score];last=d['history'][score,-1]
            gs=masks(yy,last)
            for j,method in enumerate(['R0','R2_submitted','R2_crossing_fixed']):
                L,U=stages[method];m=metrics(yy,L,U,vv,last)
                for g,values in m.items():
                    rows.append(dict(year=year,farm=f,method=method,group=g,**values))
                    if method in ['R0','R2_submitted']:
                        original=reference[(reference.farm==f)&(reference.method==('R2' if method.startswith('R2') else method))&(reference.group==g)].iloc[0]
                        for metric in ['coverage','width','IS','cells']:
                            assert np.isclose(values[metric],original[metric],atol=1e-10,rtol=1e-8),(year,f,g,metric,values[metric],original[metric])
                hit=(yy>=L)&(yy<=U);width=U-L
                IS=width+20*np.maximum(L-yy,0)+20*np.maximum(yy-U,0)
                for k,o in enumerate(d['origins'][score]):
                    pos=dates.get_indexer([pd.Timestamp(o)])[0]
                    for g,group in enumerate(['all','ramp','up_ramp','down_ramp','near_zero']):
                        mask=gs[group][k]&vv[k]
                        daily[j,f-1,pos,g]=[mask.sum(),hit[k,mask].sum(),width[k,mask].sum(),IS[k,mask].sum()]
                np.savez_compressed(folder/f'{method}.npz',lo=L,hi=U,y=yy,valid=vv,origins=d['origins'][score],last=last)
            checks.append(dict(year=year,farm=f,feature_dim=X.shape[1],training_rows=int(tm.sum()),
                      reshape_and_lag_order=True,feedback_time=True,submitted_metrics_reproduced=True,
                      crossed_all_cells=int(crossed.sum()),crossed_train_cells=int(crossed[tr].sum()),
                      crossed_seed_cells=int(crossed[seed].sum()),crossed_eval_cells=int(crossed[score][vv].sum())))
            pd.DataFrame(rows).to_csv(OUT/'metrics_per_farm.csv',index=False);write('checks.json',checks)
            print(f'{year} farm{f:02d} reproduced; crossings={int(crossed.sum())}; elapsed={time.perf_counter()-started:.1f}s',flush=True)
        def agg(a):
            t=a.sum(axis=2)
            return np.nanmean(np.divide(t[:,:,:,1:],t[:,:,:,0,None],out=np.full(t[:,:,:,1:].shape,np.nan),where=t[:,:,:,0,None]>0),axis=1)
        point=agg(daily)
        for block in [7,14]:
            rng=np.random.default_rng(20261103+block);boots=[]
            for _ in range(2000):
                starts=rng.integers(0,len(dates)-block+1,size=int(np.ceil(len(dates)/block)))
                idx=np.concatenate([np.arange(s,s+block) for s in starts])[:len(dates)]
                boots.append(agg(daily[:,:,idx]))
            boots=np.array(boots)
            for a,b in [(1,0),(2,0),(2,1)]:
                for g,group in enumerate(['all','ramp','up_ramp','down_ramp','near_zero']):
                    for k,metric in enumerate(['coverage','width','IS']):
                        delta=boots[:,a,g,k]-boots[:,b,g,k]
                        bootstrap.append(dict(year=year,method=['R0','R2_submitted','R2_crossing_fixed'][a],baseline=['R0','R2_submitted','R2_crossing_fixed'][b],
                            group=group,metric=metric,block_days=block,resamples=2000,delta=float(point[a,g,k]-point[b,g,k]),
                            low95=float(np.quantile(delta,.025)),high95=float(np.quantile(delta,.975))))
            pd.DataFrame(bootstrap).to_csv(OUT/'paired_bootstrap.csv',index=False)
    pd.DataFrame(rows).groupby(['year','method','group'])[['coverage','width','IS','lower_miss','upper_miss']].mean().reset_index().to_csv(OUT/'metrics_macro.csv',index=False)
    write('completion.json',dict(status='complete',reproduced_R2_farms=17,paired_bootstrap='7/14-day, common calendar draw across farms/methods, 2000 resamples',elapsed_seconds=time.perf_counter()-started))

if __name__=='__main__':main()
