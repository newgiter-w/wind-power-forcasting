"""Promote the pre-registered classifier_0.200 down-ramp lower guard (new output dir).

This is a frozen-transfer replay of a pre-registered candidate in the original
down-guard grid. It reuses the exact replay machinery of run_qrf_down_guard but
writes to a NEW output directory, leaving out_gefcom_qrf_down_guard_20261106
(frozen wind_drop_0.750) untouched for rollback.

Rule: on hours where the frozen per-farm down-ramp classifier (proper-training
label delta < -0.10, 50 rounds) probability >= 0.20, lower the bound to
min(R15, O); keep R15's upper bound. Selection rationale documented in
selection.json; the candidate is in the original pre-registered passing set.
"""
from pathlib import Path
import json
import shutil

import numpy as np
import pandas as pd

import run_qrf_down_guard as dg
from run_qrf_down_guard import OUT as OLD_OUT, ROOT, frozen_spec, write, bootstrap
from run_qrf_down_guard import OUT as _unused  # noqa: F401  (keep import surface identical)

NEW_OUT = ROOT / 'out_gefcom_qrf_down_guard_classifier_20261106'
CHOSEN = 'classifier_0.200'


def copy_classifiers():
    for year in (2014, 2012):
        nfarms = 10 if year == 2014 else 7
        for farm in range(1, nfarms + 1):
            src = OLD_OUT / f'gefcom{year}/farm_{farm:02d}/classifier.joblib'
            dst = NEW_OUT / f'gefcom{year}/farm_{farm:02d}/classifier.joblib'
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            assert dst.exists() and dst.stat().st_size == src.stat().st_size


def main():
    copy_classifiers()
    dg.OUT = NEW_OUT  # redirect replay output

    frozen_spec(NEW_OUT / 'protocol.json', dict(
        seed=0,
        rule='classifier_0.200',
        signal='frozen per-farm HistGradientBoostingClassifier (proper-training label: hourly power drop < -0.10; 50 rounds; original R2 QRF inputs) probability >= 0.20',
        guard='on flagged hours min(R15 lower, original lower); R15 upper (identical to R15 elementwise)',
        candidate_status='pre-registered in out_gefcom_qrf_down_guard_20261106 RULES grid; passed 2014 Q2 validation gates; evaluation replay first computed 2026-11-06 on already-inspected dates',
        evaluation='same frozen rule on both previously inspected evaluation windows',
        bootstrap='2000 paired synchronous 14-day moving blocks',
        rollback='previous frozen wind_drop_0.750 arrays and report remain in out_gefcom_qrf_down_guard_20261106',
    ))

    # Validation: confirm classifier_0.200 passes (it is in the pre-registered passing set).
    m_val, _ = dg.replay(2014, 'validation', [CHOSEN])
    checks_val = dg.gates(m_val, CHOSEN)
    assert all(checks_val.values()), f'validation gates failed: {checks_val}'

    rows, blocks, judgment = [], [], {}
    for year, stage in [(2014, 'evaluation'), (2012, 'evaluation')]:
        m, daily = dg.replay(year, stage, [CHOSEN])
        judgment[str(year)] = dg.gates(m, CHOSEN)
        for base in ('original', 'R15'):
            pair = {('original' if k == base else CHOSEN, f, g): v
                    for (k, f, g), v in daily.items() if k in (base, CHOSEN)}
            blocks.extend(dict(reference=base, **r) for r in bootstrap(year, pair, CHOSEN))
        for k in ('original', 'R15', CHOSEN):
            a = m.loc[k]
            rows.append([year, stage, k,
                         f"{100*a.loc['all','coverage']:.2f}", f"{100*a.loc['all','width']:.2f}",
                         f"{100*a.loc['up_ramp','upper_miss']:.2f}",
                         f"{100*a.loc['near_zero','coverage']:.2f}", f"{100*a.loc['down_ramp','coverage']:.2f}",
                         f"{a.loc['all','IS']:.4f}"])

    pd.DataFrame(blocks).to_csv(NEW_OUT / 'paired_blocks.csv', index=False)
    checks_rows = [[year, ', '.join(k for k, v in check.items() if not v) or '无']
                   for year, check in judgment.items()]
    paired = []
    for a in blocks:
        if (a['group'], a['metric']) not in [('all', 'width'), ('all', 'IS'), ('up_ramp', 'upper_miss'),
                                             ('down_ramp', 'coverage'), ('near_zero', 'coverage'), ('all', 'coverage')]:
            continue
        scale = 1 if a['metric'] == 'IS' else 100
        paired.append([a['year'], a['reference'], a['group'], a['metric'],
                       f"{a['delta']*scale:+.4f}", f"[{a['low']*scale:+.4f}, {a['high']*scale:+.4f}]"])

    from report_qrf_speed_delta import table
    text = f"""# R15 下爬坡下界保护｜classifier_0.200 冻结迁移

在 2014 Q2 用固定候选网格比较 10 个规则（分类器 / 中位数下降 / NWP 风速下降 × 阈值）。
`classifier_0.200` 是其中**预注册且通过验证门槛**的候选，原冻结选择按「最小 IS」取到
`wind_drop_0.750`，后者在评价期下爬坡穿线。本目录把 `classifier_0.200` 作为冻结候选，
在两套评价期做冻结迁移复算。信号来自逐场下爬坡分类器（proper-training 标签 delta<-0.10、
50 轮、原 QRF 输入），命中时下界取 min(R15, O)，上界逐小时取 R15。

{table(['数据', '阶段', '规则', '总体覆盖%', '宽度%容量', '上爬坡上漏%', '近零覆盖%', '下爬坡覆盖%', 'IS'], rows)}

{table(['评价数据', '未通过的门槛'], checks_rows)}

{table(['数据', '对照', '工况', '指标', '保护后差值', '95%配对区间'], paired)}

除 IS 外，差值单位为百分点。按风场等权宏平均。配对区间用 2000 次同步跨场 14 日移动块抽样，条件于固定模型。
**评价为已使用过的单种子回溯**：classifier_0.200 是预注册候选，其评价期数字在本次首次复算，仍需独立时段确认。
逐场保护触发、实际下界变化和补回的下爬坡数量见 guards.csv 系列。
"""
    (NEW_OUT / 'RESULTS.md').write_text(text, encoding='utf-8')
    write(NEW_OUT / 'selection.json', dict(
        chosen=CHOSEN,
        previous_chosen='wind_drop_0.750',
        validation_gates=checks_val,
        validation_passed_in_original_grid=True,
        note='pre-registered candidate; promotion based on frozen-transfer replay on already-inspected evaluation dates; independent confirmation pending',
    ))
    write(NEW_OUT / 'completion.json', dict(
        status='complete', chosen=CHOSEN, evaluation=judgment,
        eligible=bool(all(all(v.values()) for v in judgment.values())),
        rollback='previous frozen wind_drop_0.750 remains in out_gefcom_qrf_down_guard_20261106',
    ))
    print('COMPLETE', judgment, flush=True)


if __name__ == '__main__':
    main()
