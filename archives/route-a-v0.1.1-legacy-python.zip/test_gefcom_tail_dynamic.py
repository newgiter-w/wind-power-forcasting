import copy
import unittest
import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression
from run_gefcom_tail_dynamic import dynamic_features,base_matrix,risk_matrix,oof_splits,fit,PKG
from online_calibration import simulate_independent

def fixture():
    rng=np.random.default_rng(913)
    return dict(history=rng.uniform(0,1,(4,24)),nwp=rng.normal(size=(4,24,4)),
        origins=pd.date_range('2012-01-01',periods=4,freq='D').to_numpy(),y=rng.uniform(0,1,(4,24)))

class TailDynamicWitness(unittest.TestCase):
    def test_features_ignore_target_and_later_origins(self):
        d=fixture();X=base_matrix(d,2014);D,names=dynamic_features(d)
        altered=copy.deepcopy(d);altered['y'][:]=.999
        np.testing.assert_equal(X,base_matrix(altered,2014));np.testing.assert_equal(D,dynamic_features(altered)[0])
        altered['history'][1:]=.1;altered['nwp'][1:]=99
        np.testing.assert_equal(X[:24],base_matrix(altered,2014)[:24])
        np.testing.assert_equal(D[:1],dynamic_features(altered)[0][:1])
        self.assertEqual(len(names),17)
        vdelta=D[:,:,names.index('v_delta6')]
        self.assertTrue(np.isnan(vdelta[:,:6]).all())
        np.testing.assert_equal(vdelta[:,6:],d['nwp'][:,6:,-1]-d['nwp'][:,:-6,-1])
        np.testing.assert_equal(X[:,107].reshape(4,24),np.broadcast_to(np.arange(1,25),(4,24)))
        proxy=IsotonicRegression(out_of_bounds='clip').fit([0,1,2,3],[0,.1,.5,1])
        lo=np.full((4,24),.1);hi=np.full((4,24),.8)
        A,_=risk_matrix(d,proxy,lo,hi)
        np.testing.assert_equal(A,risk_matrix({**d,'y':np.zeros_like(d['y'])},proxy,lo,hi)[0])

    def test_tail_feedback_and_signed_shrinkage(self):
        orig=pd.date_range('2012-01-01',periods=110,freq='D').to_numpy();ends=orig+np.timedelta64(1,'D')
        y=np.full((110,24),.4);lo=np.full_like(y,.1);hi=np.full_like(y,.8);valid=np.ones(110,bool)
        a=simulate_independent(orig,ends,y,lo,hi,valid,np.arange(90),np.arange(90,110))
        changed=y.copy();changed[90:]=.99;vv=valid.copy();vv[90:]=False
        b=simulate_independent(orig,ends,changed,lo,hi,vv,np.arange(90),np.arange(90,110))
        np.testing.assert_equal(a['lo'][0],b['lo'][0]);np.testing.assert_equal(a['hi'][0],b['hi'][0])
        self.assertTrue((a['q_lower']<0).all() and (a['q_upper']<0).all())
        np.testing.assert_allclose(a['lo'],.4);np.testing.assert_allclose(a['hi'],.4)
        self.assertTrue((a['max_label_end_used']<=orig[a['indices']]).all())

    def test_oof_prefix_obeys_label_arrival(self):
        origins=pd.date_range('2012-01-01','2013-03-31',freq='D').to_numpy()
        d=dict(origins=origins,ends=origins+np.timedelta64(1,'D'),valid=np.ones(len(origins),bool),
            meta=pd.DataFrame({'phase':['train' if t<np.datetime64('2013-01-01') else 'validation_seed' for t in origins]}))
        for _,tr,held in oof_splits(d,2014):
            self.assertLessEqual(d['ends'][tr].max(),origins[held].min())
            self.assertFalse(np.intersect1d(tr,held).size)
            self.assertTrue((origins[held]<np.datetime64('2013-01-01')).all())

    def test_seeded_quantile_kernel_uses_train_scaling(self):
        rng=np.random.default_rng(42);X=rng.normal(size=(160,4));y=X[:,0]+rng.normal(size=160)*.1
        tr=np.arange(100);a,pack=fit(X,y,tr,.95,dict(PKG,max_iter=5,min_samples_leaf=5))
        other=X.copy();other[100:]+=100
        b,pack2=fit(other,y,tr,.95,dict(PKG,max_iter=5,min_samples_leaf=5))
        np.testing.assert_equal(pack['scaler'].mean_,pack2['scaler'].mean_)
        np.testing.assert_equal(a[:100],b[:100]);self.assertTrue(np.isfinite(a).all())

if __name__=='__main__':unittest.main()
