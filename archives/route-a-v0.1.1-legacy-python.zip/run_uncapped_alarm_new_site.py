"""Validate uncapped alarm ranking at a held-out site using frozen Kelmarsh models."""
import argparse
import hashlib
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

import run_kelmarsh_gfs_q90 as prior
from run_kelmarsh_gfs_q90_expand import OUT as EXPANDED,read_months,paired
from pair_penmanshiel_frozen_transfer import OUT as SITE,MONTHS,CAPACITY
from run_gefcom2012_local_increment import score,summarize
from diagnose_gefcom2012_data_attribution import match_truth
from revision_common import frozen_spec,write

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_uncapped_alarm_new_site'
COLS=('events','hits','signed','absolute','quiet','false','hours','all_absolute')
MODELS=('original','capped','uncapped')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def models():
    check=json.loads((EXPANDED/'reconstruction_check.json').read_text())
    assert sha(prior.DEST/'q90.joblib')==check['q90_sha256']
    assert sha(prior.DEST/'selection.json')==check['selection_sha256']
    bundle=joblib.load(EXPANDED/'frozen_baseline.joblib')
    return bundle['forest'],bundle['imputer'],joblib.load(prior.DEST/'q90.joblib')


def add_scores(d,forest,imp,model):
    with threadpool_limits(limits=2):
        base=prior.record(d,forest,imp)
        records=score(model,base,1.)
        for r in records:
            raw=r['base'].copy()
            raw[r['gate']]+=model.predict(r['features'][r['gate']])
            r['uncapped']=raw
            r['capped']=r['candidate']
            # Stable tie order is the same for a date across any subset/method.
            r['tie']=np.stack([np.random.default_rng(20261107+int(o.astype('datetime64[D]').astype(int))).random(24)
                               for o in r['origins']])
    return records


def calibrate(records,field):
    pairs=[]
    target=0
    for r in records:
        q=r['gate']&(np.abs(r['actual'])<=.05)
        target+=int((r['base'][q]>.10).sum())
        pairs.extend(zip(r[field][q],r['tie'][q]))
    pairs.sort(reverse=True)
    assert pairs
    if target==0:
        value,tie=pairs[0][0],1.
    elif target==len(pairs):
        value,tie=pairs[-1][0],0.
    else:
        value,tie=pairs[target-1]
    cutoff=dict(value=float(value),tie=float(tie),quiet_false_target=target,quiet_hours=len(pairs))
    assert sum(alarm(r,field,cutoff)[r['gate']&(np.abs(r['actual'])<=.05)].sum() for r in records)==target
    return cutoff


def alarm(r,field,cutoff):
    s=r[field]
    chosen=(s>cutoff['value'])|((s==cutoff['value'])&(r['tie']>=cutoff['tie']))
    return np.where(r['gate'],chosen,r['base']>.10)


def daily(records,cutoffs,operation):
    rows=[]
    for r in records:
        y=r['actual']
        for name in MODELS:
            pred=r['base'] if name=='original' else r['candidate']
            al=(r['base']>.10) if name=='original' else alarm(r,name,cutoffs[name])
            hit=match_truth(y>.10,al)
            e=pred-y
            for scope,keep in [('gated',r['gate']),('all',np.ones_like(r['gate']))]:
                u=keep&(y>.10)
                q=keep&(np.abs(y)<=.05)
                arrays=[u,u&hit,np.where(u,e,0),np.where(u,np.abs(e),0),q,q&al,keep,np.where(keep,np.abs(e),0)]
                values=np.column_stack([a.sum(axis=1) for a in arrays])
                rows.append(pd.DataFrame(values,columns=COLS).assign(
                    origin=r['origins'],farm=1,model=name,scope=scope,operation=operation))
    return pd.concat(rows,ignore_index=True)


def protocol():
    frozen_spec(OUT/'protocol.json',dict(site='Penmanshiel turbines11–15, 10.25MW, fixed new-site cohort',
        dates=list(MONTHS),weights='frozen Kelmarsh QRF, preprocessing and q90, zero-shot site transfer; no training',
        intervention='only alarm field changes to original increment+raw predicted q90 residual; no correction or physical clipping in alarm score',
        amplitudes='same old clipped increments reported for capped/uncapped; changes isolated to alarm ranking',
        calibration='Kelmarsh December2023 only: raw score threshold matches baseline quiet alarms; old capped threshold retained',
        evaluation='new site never used for model or threshold fit; whole period and quarters; fixed alarms and retrospective same quiet false count',
        tie='fixed per-day pseudo-random tie ordering, independent of observations; calibration labels select one cutoff',
        inference='2000 paired calendar moving blocks;14d primary and7/28d sensitivity, thresholds conditional',
        decision='same-FPR hit gain CI above zero against both original and capped at14d; fixed-threshold quiet FPR<=original; ramp MAE no worse'))


def prepare():
    protocol()
    forest,imp,model=models()
    records=add_scores(read_months(('2023-12',)),forest,imp,model)
    raw_cutoff=calibrate(records,'uncapped')
    old=json.loads((prior.DEST/'selection.json').read_text())['threshold']
    cutoff=dict(uncapped=raw_cutoff,capped=dict(value=old,tie=1.))
    frozen_spec(OUT/'thresholds.json',cutoff)
    frozen_spec(OUT/'weights.json',dict(q90_sha256=sha(prior.DEST/'q90.joblib'),
        qrf_bundle_sha256=sha(EXPANDED/'frozen_baseline.joblib'),old_threshold_sha256=sha(prior.DEST/'selection.json')))
    summarize(daily(records,cutoff,'frozen')).to_csv(OUT/'development_summary.csv')
    print('THRESHOLDS FROZEN',cutoff,flush=True)


def site_data():
    w=pd.concat([pd.read_csv(SITE/m/'paired_hourly.csv',parse_dates=['origin','target','cycle','archive_time'])
                 for m in MONTHS],ignore_index=True)
    sc=pd.read_csv(SITE/'scada_hourly_2024.csv',parse_dates=['target']).set_index('target')
    rows=[]
    for o,g in w.groupby('origin',sort=True):
        h=sc.reindex(pd.date_range(o-pd.Timedelta(hours=23),o,freq='h'))
        if len(g)!=24 or not g.paired.all() or not h.power_valid.eq(True).all():
            continue
        assert (g.archive_time<=o).all()
        np.testing.assert_array_equal(g.lead,np.arange(1,25))
        rows.append((o,h.power_pu.to_numpy(),g.power_pu.to_numpy(),g[['u100','v100']].to_numpy()))
    assert rows
    origins,h,y,wind=zip(*rows)
    y=np.asarray(y)
    assert y.min()>=-.01 and y.max()<=1.05, 'Extreme target values require a separate quality audit'
    data=dict(history=np.clip(h,0,1),y=np.clip(y,0,1),nwp=np.asarray(wind),
        origins=pd.DatetimeIndex(origins).tz_convert(None).to_numpy(),meta=pd.DataFrame(dict(nwp_age_hours=np.full(len(rows),6))))
    write(OUT/'sample_counts.json',dict(issued=w.origin.nunique(),days=len(rows),outside_power=int(((y<0)|(y>1)).sum()),
                                      capacity_kw=CAPACITY,min_power=float(y.min()),max_power=float(y.max())))
    return data


def evaluate():
    protocol()
    assert (SITE/'data_complete.json').exists()
    cutoffs=json.loads((OUT/'thresholds.json').read_text())
    weights=json.loads((OUT/'weights.json').read_text())
    assert weights['q90_sha256']==sha(prior.DEST/'q90.joblib')
    assert weights['qrf_bundle_sha256']==sha(EXPANDED/'frozen_baseline.joblib')
    forest,imp,model=models()
    data=site_data()
    records=add_scores(data,forest,imp,model)
    outcomes={}
    for period,months in [('all',tuple(range(2,13))),('apr_jun',(4,5,6)),('jul_sep',(7,8,9)),('oct_dec',(10,11,12))]:
        rec=[]
        for r in records:
            keep=np.isin(pd.DatetimeIndex(r['origins']).month,months)
            rec.append({k:(v[keep] if k!='farm' else v) for k,v in r.items()})
        if not any(len(r['origins']) for r in rec):
            continue
        exact={k:calibrate(rec,k) for k in ('capped','uncapped')}
        folder=OUT/period
        folder.mkdir(exist_ok=True)
        write(folder/'retrospective_cutoffs.json',exact)
        frame=pd.concat([daily(rec,cutoffs,'frozen'),daily(rec,exact,'exact_fpr')])
        frame.to_csv(folder/'daily.csv',index=False)
        summary=summarize(frame)
        summary.to_csv(folder/'summary.csv')
        intervals=[]
        for ref in ('original','capped'):
            pair=frame[frame.model.isin((ref,'uncapped'))].copy()
            pair['model']=pair.model.map({ref:'original','uncapped':'corrected'})
            intervals.extend(paired(pair,b).assign(reference=ref) for b in (7,14,28))
        ci=pd.concat(intervals,ignore_index=True)
        ci.to_csv(folder/'paired_blocks.csv',index=False)
        print(period,summary.xs('gated',level='scope')[['events','hits','false','recall','bias','mae','quiet_fpr']].round(6).to_string(),flush=True)
        if period=='all':
            gain=ci.query("block==14 and operation=='exact_fpr' and scope=='gated' and metric=='recall'")
            assert len(gain)==2
            a,b=(summary.loc[('frozen','gated',k)] for k in ('original','uncapped'))
            outcomes=dict(ci_positive=bool((gain.low>0).all()),frozen_fpr=bool(b.quiet_fpr<=a.quiet_fpr),
                mae=bool(b.mae<=a.mae))
    write(OUT/'completion.json',dict(status='complete',checks=outcomes,
                                     advance_to_interval=bool(all(outcomes.values()))))
    print('COMPLETE',outcomes,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--prepare',action='store_true')
    args=parser.parse_args()
    if args.prepare:
        prepare()
    else:
        evaluate()

