"""Recompute factorial metrics and synchronous calendar-block paired uncertainty."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from gefcom2014_experiment import metrics, masks
from run_gefcom_factorial import OUT, ROOT, METHODS, sha, write

GROUPS=['all','ramp','up_ramp','down_ramp','near_zero']
METRICS=['coverage','width','IS']
# Cell order: independent/base, independent/aug, shared/base, shared/aug.
CONTRASTS={
    'sharing_without_extra':[-1,0,1,0],
    'extra_with_independent':[-1,1,0,0],
    'extra_with_shared':[0,0,-1,1],
    'sharing_with_extra':[0,-1,0,1],
    'interaction':[1,-1,-1,1],
    'average_sharing':[-.5,-.5,.5,.5],
    'average_extra':[-.5,.5,-.5,.5],
    'combined':[-1,0,0,1],
}

def aggregate(daily):
    total=daily.sum(axis=2)
    return np.nanmean(np.divide(total[:,:,:,1:],total[:,:,:,0,None],
        out=np.full(total[:,:,:,1:].shape,np.nan),where=total[:,:,:,0,None]>0),axis=1)

def main():
    assert json.loads((OUT/'completion.json').read_text())['status']=='complete'
    table=pd.read_csv(OUT/'metrics_per_farm.csv')
    expected=table.query("stage=='evaluation' and kind=='cqr' and support=='clipped'")
    rows=[];checks=[];leads=[];bootrows=[]
    for year in [2014,2012]:
        folders=sorted((OUT/f'gefcom{year}').glob('farm_*'))
        dates=pd.date_range('2013-07-01' if year==2014 else '2011-07-01',
            '2013-12-31' if year==2014 else '2012-06-27',freq='D')
        daily=np.zeros((4,len(folders),len(dates),5,4))
        for f,folder in enumerate(folders):
            farm=int(folder.name.split('_')[-1])
            with np.load(folder/'samples.npz') as z:
                y=z['y'];valid=z['valid'];history=z['history'];origins=z['origins']
            common=None
            for j,method in enumerate(METHODS):
                dest=folder/method
                with np.load(dest/'heads.npz') as z:
                    q05=z['q05'];q95=z['q95']
                    np.testing.assert_array_equal(z['origins'],origins)
                for stage in ['validation','evaluation']:
                    with np.load(dest/f'{stage}.npz') as z:
                        idx=z['indices'];L=z['lo'];U=z['hi']
                        assert (z['max_label_end']<=origins[idx]).all()
                        assert np.isfinite(L).all() and np.isfinite(U).all() and (L<=U).all()
                    if stage=='evaluation':
                        score=idx.copy();lo=np.clip(L,0,1);hi=np.clip(U,0,1)
                if common is None:common=score.copy()
                else:np.testing.assert_array_equal(common,score)
                yy=y[score];vv=valid[score];last=history[score,-1]
                assert ((yy[vv]>=0)&(yy[vv]<=1)).all()
                mm=metrics(yy,lo,hi,vv,last)
                for group,v in mm.items():
                    ref=expected.query('year==@year and farm==@farm and method==@method and group==@group').iloc[0]
                    for k in ['coverage','width','IS','cells','origins','lower_miss','upper_miss']:
                        assert np.isclose(v[k],ref[k],atol=1e-12,rtol=1e-10),(year,farm,method,group,k)
                    rows.append(dict(year=year,farm=farm,method=method,group=group,**v))
                hit=(yy>=lo)&(yy<=hi);width=hi-lo
                IS=width+20*np.maximum(lo-yy,0)+20*np.maximum(yy-hi,0)
                pos=dates.get_indexer(pd.to_datetime(origins[score]));assert (pos>=0).all()
                for g,group in enumerate(GROUPS):
                    mask=masks(yy,last)[group]&vv[:,None]
                    daily[j,f,pos,g,0]=mask.sum(axis=1)
                    daily[j,f,pos,g,1]=(hit&mask).sum(axis=1)
                    daily[j,f,pos,g,2]=np.where(mask,width,0).sum(axis=1)
                    daily[j,f,pos,g,3]=np.where(mask,IS,0).sum(axis=1)
                for h in range(24):
                    leads.append(dict(year=year,farm=farm,method=method,lead=h+1,
                        cells=int(vv.sum()),coverage=hit[vv,h].mean(),width=width[vv,h].mean(),IS=IS[vv,h].mean()))
                old_diff=None
                if method=='R0_ind_base':
                    old=ROOT/f'out_gefcom_protocol_v2/gefcom{year}/farm_{farm:02d}/B_speed/evaluation_intervals.npz'
                    with np.load(old) as z:
                        np.testing.assert_array_equal(z['indices'],score)
                        old_diff=float(max(np.abs(lo-np.clip(z['lo'],0,1)).max(),np.abs(hi-np.clip(z['hi'],0,1)).max()))
                    assert old_diff<1e-10,('baseline changed',year,farm,old_diff)
                checks.append(dict(year=year,farm=farm,method=method,scored_days=int(vv.sum()),
                    issued_days=len(score),paired_origins=True,causal_feedback=True,metrics_recomputed=True,
                    crossing_all=int((q05>q95).sum()),crossing_eval=int((q05[score][vv]>q95[score][vv]).sum()),
                    baseline_max_abs_diff=old_diff))
        point=aggregate(daily)
        for j,method in enumerate(METHODS):
            for g,group in enumerate(GROUPS):
                ref=expected.query('year==@year and method==@method and group==@group')[METRICS].mean().to_numpy()
                np.testing.assert_allclose(point[j,g],ref,rtol=1e-10,atol=1e-12)
        np.savez_compressed(OUT/f'gefcom{year}_daily_stats.npz',daily=daily,dates=dates.to_numpy(),methods=METHODS,groups=GROUPS)
        for block in [7,14]:
            rng=np.random.default_rng(20261103+block);B=2000;D=len(dates)
            weights=np.zeros((B,D))
            for b in range(B):
                starts=rng.integers(0,D-block+1,size=int(np.ceil(D/block)))
                idx=np.concatenate([np.arange(s,s+block) for s in starts])[:D]
                weights[b]=np.bincount(idx,minlength=D)
            totals=np.einsum('bd,mfdgs->bmfgs',weights,daily,optimize=True)
            boots=np.nanmean(np.divide(totals[:,:,:,:,1:],totals[:,:,:,:,0,None],
                out=np.full(totals[:,:,:,:,1:].shape,np.nan),where=totals[:,:,:,:,0,None]>0),axis=2)
            for name,c in CONTRASTS.items():
                delta=np.einsum('m,mgk->gk',c,point)
                bs=np.einsum('m,bmgk->bgk',c,boots)
                for g,group in enumerate(GROUPS):
                    for k,metric in enumerate(METRICS):
                        bootrows.append(dict(year=year,contrast=name,group=group,metric=metric,
                            block_days=block,resamples=B,delta=delta[g,k],
                            low95=np.quantile(bs[:,g,k],.025),high95=np.quantile(bs[:,g,k],.975)))
            print(f'{year} paired bootstrap {block}d complete',flush=True)
    pd.DataFrame(rows).to_csv(OUT/'recomputed_metrics_per_farm.csv',index=False)
    pd.DataFrame(rows).groupby(['year','method','group'])[METRICS+['lower_miss','upper_miss']].mean().reset_index().to_csv(OUT/'evaluation_macro.csv',index=False)
    pd.DataFrame(leads).to_csv(OUT/'evaluation_per_lead.csv',index=False)
    pd.DataFrame(bootrows).to_csv(OUT/'paired_bootstrap.csv',index=False)
    write(OUT/'verification.json',dict(status='passed',farm_method_groups=68,scalar_quantile_models=1700,datasets=2,
        checks=checks,bootstrap='2000 moving 7/14-day blocks; common calendar draw across all methods and farms; farm-macro ratios',
        analysis_sha256=sha(Path(__file__)),multiple_comparisons='unadjusted exploratory 95% percentile intervals; no familywise claim',
        inference='temporal variability conditional on these fixed farms/seed and historical dates; not new-farm or seed uncertainty'))

if __name__=='__main__':main()
