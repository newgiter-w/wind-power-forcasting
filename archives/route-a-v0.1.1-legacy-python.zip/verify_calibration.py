"""Independent full-year score/history/ACI replay and metric reconstruction."""
import json
from pathlib import Path
import numpy as np
import pandas as pd

from run_calibration import PERIODS,indices_for,OUT


def verify_one(data,period,name):
    directory=OUT/period/name
    meta=json.loads((directory/'metrics.json').read_text(encoding='utf-8'))
    with np.load(directory/'state.npz') as loaded:state={k:loaded[k] for k in loaded.files}
    seed,score=indices_for(data,period)
    np.testing.assert_array_equal(score,state['indices'])
    origins,ends=data['origins'],data['target_end']
    alpha=np.full(24,.1);pointer=0;feedback_count=0
    all_ids=np.concatenate([seed,score])
    for position,idx in enumerate(score):
        now=origins[idx]
        if meta['method'].startswith('aci_'):
            while pointer<position and ends[score[pointer]]<=now:
                past=score[pointer]
                if data['valid'][past]:
                    miss=~((data['y'][past]>=state['lo'][pointer])&(data['y'][past]<=state['hi'][pointer]))
                    alpha=alpha+meta['gamma']*(.1-miss.astype(float))
                    if meta['method']=='aci_projected':alpha=np.maximum(.02,np.minimum(alpha,.5))
                    feedback_count+=1
                pointer+=1
        if meta['method']=='global':
            available=seed[data['valid'][seed]]
            desired=np.full(24,.1)
        else:
            arrived=(ends[all_ids]<=now)&(ends[all_ids]>now-np.timedelta64(meta['window'],'D'))
            available=all_ids[arrived&data['valid'][all_ids]]
            desired=alpha.copy() if meta['method'].startswith('aci_') else np.full(24,.1)
        assert np.all(ends[available]<=now) and idx not in available
        assert len(available)==state['n_cal'][position]
        assert ends[available].max()==state['max_label_end_used'][position]
        np.testing.assert_allclose(desired,state['alpha_requested'][position],rtol=0,atol=1e-12)
        effective=np.maximum(desired,1/(len(available)+1)) if meta['method']=='aci_projected' else desired
        np.testing.assert_allclose(effective,state['alpha_used'][position],rtol=0,atol=1e-12)
        scores=np.maximum(data['raw_lo'][available]-data['y'][available],data['y'][available]-data['raw_hi'][available])
        ordered=np.sort(scores,axis=0)
        ranks=np.ceil((len(available)+1)*(1-effective)-1e-12).astype(int)
        expected=[]
        for h,rank in enumerate(ranks):
            if effective[h]<=0 or rank>len(available):value=np.inf
            elif effective[h]>=1 or rank<1:value=-np.inf
            else:value=ordered[rank-1,h]
            expected.append(value)
        np.testing.assert_allclose(expected,state['q_signed'][position],rtol=0,atol=1e-12)
        lower=data['raw_lo'][idx]-expected;upper=data['raw_hi'][idx]+expected
        if meta['method']!='aci_unprojected':
            bad=lower>upper;center=(data['raw_lo'][idx]+data['raw_hi'][idx])/2
            lower=np.where(bad,center,lower);upper=np.where(bad,center,upper)
        np.testing.assert_allclose(lower,state['lo'][position],rtol=0,atol=1e-12)
        np.testing.assert_allclose(upper,state['hi'][position],rtol=0,atol=1e-12)
    valid=data['valid'][score]
    y=data['y'][score][valid];lo=state['lo'][valid];hi=state['hi'][valid]
    assert np.isfinite(lo).all() and np.isfinite(hi).all() and np.all(lo<=hi)
    # Recompute via the pinball identity, independent of the scoring implementation.
    dl=y-lo;du=y-hi
    interval_values=20*(np.maximum(.05*dl,-.95*dl)+np.maximum(.95*du,-.05*du))/12300.
    assert abs(interval_values.mean()-meta['metrics']['all']['score'])<1e-12
    assert abs(((y>=lo)&(y<=hi)).mean()-meta['metrics']['all']['coverage'])<1e-12
    assert abs((hi-lo).mean()/12300.-meta['metrics']['all']['width'])<1e-12
    ramp=np.abs(np.diff(y,axis=1,prepend=data['last_hour'][score][valid,None]))>.1*12300.
    assert int(ramp.sum())==meta['metrics']['ramp']['cells']
    assert abs(((y>=lo)&(y<=hi))[ramp].mean()-meta['metrics']['ramp']['coverage'])<1e-12
    assert abs(interval_values[ramp].mean()-meta['metrics']['ramp']['score'])<1e-12
    trace=pd.read_csv(directory/'feedback.csv')
    assert (pd.to_datetime(trace.source_target_end)<=pd.to_datetime(trace.processed_at)).all()
    assert len(trace)==len(score)-1
    assert trace.source_index.is_unique
    assert np.array_equal(trace.valid_feedback.to_numpy(),data['valid'][trace.source_index.to_numpy()])
    # Forecasts were emitted on incomplete-target days as well.
    assert len(state['indices'])==len(score)>int(valid.sum())
    return {'period':period,'method':name,'forecast_days':len(score),'scored_days':int(valid.sum()),
            'all_quantiles_replayed':True,'all_feedback_arrived':True,'independent_metrics':'PASS',
            'state_projection_count':meta['metrics']['all']['state_projection_count'],
            'support_projection_count':meta['metrics']['all']['support_projection_count'],
            'midpoint_expansion_count':meta['metrics']['all']['midpoint_expansion_count']}


def main():
    with np.load(OUT/'raw_predictions.npz') as p:data={k:p[k] for k in p.files}
    cases=[]
    for year in ('2021','2022'):
        for method in ('global_cqr','rolling_cqr','aci_projected','aci_unprojected'):
            cases.append(verify_one(data,year,method))
        with np.load(OUT/year/'aci_projected/state.npz') as a,np.load(OUT/year/'aci_unprojected/state.npz') as b:
            np.testing.assert_array_equal(a['lo'],b['lo']);np.testing.assert_array_equal(a['hi'],b['hi'])
    selection=OUT/'selection.json'
    assert selection.stat().st_mtime_ns<min((OUT/year/'global_cqr/metrics.json').stat().st_mtime_ns for year in ('2021','2022'))
    report={'status':'PASS','year_method_cases':len(cases),'cases':cases,
            'model_training_tasks':0,'selection_frozen_before_evaluation':True,
            'projected_and_unprojected_identical_on_both_years':True,
            'scope':'Cached raw forecasts from the existing 2019 NH_H0; whole-day feedback and complete-target evaluation'}
    (OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
