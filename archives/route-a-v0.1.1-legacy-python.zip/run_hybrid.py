"""Hybrid (direction B): lower bound = C0 symmetric q, upper bound = C3 conditioned bU.

[raw_lo - q_C0, raw_hi + bU]  (no additional CQR). The symmetric q (dominated by
upper misses) pushes the lower bound down and covers near-zero; the conditioned
upper head widens the upper bound only where ramp risk is present.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from online_calibration import simulate
from run_c1 import group, masks_for
from run_c3 import build_cells, fit_head
from run_calibration import cache_predictions, indices_for

ROOT = Path(__file__).parent
OUT = ROOT / 'out_hybrid'


def empty_safe(lo, hi, raw_lo, raw_hi):
    """Apply the same midpoint-singleton empty-set protection as simulate."""
    if not np.isfinite(lo).all() or not np.isfinite(hi).all():
        raise ValueError('nonfinite hybrid interval')
    empty = lo > hi
    center = (raw_lo + raw_hi) / 2
    lo = np.where(empty, center, lo)
    hi = np.where(empty, center, hi)
    return lo, hi, int(empty.sum())


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    X, sL, sU, valid, origins = build_cells()
    N, H = sL.shape
    o = origins
    rfit = (o >= np.datetime64('2020-01-01')) & (o < np.datetime64('2020-07-01'))
    train_mask = np.broadcast_to((rfit & valid)[:, None], (N, H))
    head_l = fit_head(X.reshape(N * H, -1), sL.reshape(-1), train_mask.reshape(-1))
    head_u = fit_head(X.reshape(N * H, -1), sU.reshape(-1), train_mask.reshape(-1))
    bL = head_l.predict(X.reshape(N * H, -1)).reshape(N, H)
    bU = head_u.predict(X.reshape(N * H, -1)).reshape(N, H)

    data = cache_predictions()
    out = {}
    for year in ('2021', '2022'):
        seed, score = indices_for(data, year)
        c0 = simulate(data['origins'], data['target_end'], data['y'], data['raw_lo'], data['raw_hi'],
                      data['valid'], seed, score, 'rolling', 84)
        # hybrid (dir B): C0 symmetric lower + C3 conditioned upper
        hyb_lo = data['raw_lo'][score] - c0['q_signed']
        hyb_hi = data['raw_hi'][score] + bU[score]
        hyb_lo, hyb_hi, empties = empty_safe(hyb_lo, hyb_hi, data['raw_lo'][score], data['raw_hi'][score])
        hybrid = {'indices': score, 'lo': hyb_lo, 'hi': hyb_hi, 'n_cal': c0['n_cal'],
                  'midpoint_expansion_count': empties,
                  'state_projection_count': 0, 'support_projection_count': 0}
        # hybrid_v2: base [raw_lo, raw_hi + bU] then ONE rolling symmetric CQR
        base_lo = data['raw_lo'].copy()
        base_hi = data['raw_hi'] + bU
        v2 = simulate(data['origins'], data['target_end'], data['y'], base_lo, base_hi,
                      data['valid'], seed, score, 'rolling', 84)
        masks = masks_for(data, c0)
        print(f'\n===== {year} =====')
        for g in ('all', 'ramp', 'up_ramp', 'down_ramp', 'near_zero'):
            r0 = group(data, c0, masks[g])
            rh = group(data, hybrid, masks[g])
            r2 = group(data, v2, masks[g])
            def f(r): return ('n/a' if r is None else
                              f"{r['coverage']*100:5.1f}% w={r['width']*100:5.1f}% Lo={r['lower_miss']*100:4.1f}% Hi={r['upper_miss']*100:4.1f}%")
            print(f"  {g:11s} C0 : {f(r0)}")
            print(f"  {'':11s} Hy : {f(rh)}")
            print(f"  {'':11s} Hy2: {f(r2)}")
        out[year] = {'C0': {g: group(data, c0, masks[g]) for g in masks},
                     'Hybrid': {g: group(data, hybrid, masks[g]) for g in masks},
                     'Hybrid_v2': {g: group(data, v2, masks[g]) for g in masks}}
    (OUT / 'results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> out_hybrid/results.json ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
