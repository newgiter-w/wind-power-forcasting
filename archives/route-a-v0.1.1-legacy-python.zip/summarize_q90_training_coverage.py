"""Render the locked training-coverage comparison without selecting a new model."""
import json
import pandas as pd

from prepare_q90_training_coverage import OUT
from revision_common import write

GROUPS={
    'independent_penmanshiel_jan':'独立时间留出：Penmanshiel 1月2–31日',
    'retrospective_kelmarsh_year':'回顾：Kelmarsh 2–12月',
    'retrospective_feb_mar':'回顾：2–3月（非完整冬季）',
    'retrospective_apr_jun':'回顾：4–6月',
    'retrospective_jul_sep':'回顾：7–9月',
    'retrospective_oct_dec':'回顾：10–12月',
}
ARMS={'old_short':'原11月短窗','latest_short':'同终点7月短窗','annual':'完整年度窗'}


def summary(group,arm,op='exact_fpr',scope='gated',model='corrected'):
    d=pd.read_csv(OUT/group/arm/'summary.csv')
    return d[(d.operation==op)&(d.scope==scope)&(d.model==model)].iloc[0]


def contrast(group,ref='old_short',op='exact_fpr',metric='recall',block=14,scope='gated'):
    d=pd.read_csv(OUT/group/'annual_vs_short_paired.csv')
    selected=d[(d.reference==ref)&(d.operation==op)&(d.scope==scope)&(d.metric==metric)&(d.block==block)]
    return None if selected.empty else selected.iloc[0]


def ci(row):
    if row is None:
        return '不可计算（有效日期跨度不足）'
    return f'{100*row.delta:+.2f} [{100*row.low:+.2f}, {100*row.high:+.2f}]'


def main():
    assert (OUT/'completion.json').exists()
    counts=json.loads((OUT/'sample_counts.json').read_text())
    train=pd.read_csv(OUT/'training_counts.csv')
    fresh='independent_penmanshiel_jan'
    retro='retrospective_kelmarsh_year'
    a=summary(fresh,'annual');old=summary(fresh,'old_short')
    af=summary(fresh,'annual','frozen');q=summary(fresh,'annual','frozen',model='original')
    ar=summary(retro,'annual','frozen');qr=summary(retro,'annual','frozen',model='original')
    checks=dict(
        independent_equal_fpr_recall_ci_above_zero=bool(contrast(fresh).low>0),
        independent_ramp_mae_not_worse=bool(a.mae<=old.mae),
        retrospective_equal_fpr_recall_ci_above_zero=bool(contrast(retro).low>0),
        no_significant_negative_retrospective_season=all(contrast(g).high>=0 for g in list(GROUPS)[2:]),
        independent_frozen_quiet_fpr_not_above_qrf=bool(af.quiet_fpr<=q.quiet_fpr),
        retrospective_frozen_quiet_fpr_not_above_qrf=bool(ar.quiet_fpr<=qr.quiet_fpr),
    )
    passed=all(checks.values())
    decision=dict(status='complete',checks=checks,upper_integration_eligible=passed,
        action='仍需另行验证区间端点及覆盖/宽度/IS' if passed else '未通过全部门槛；维持原QRF和区间，不接入上界',
        independent_scope='Previously unscored January at a previously inspected five-turbine cohort; fixed thresholds are independent deployment results; exact-FPR cutoffs use evaluation labels retrospectively.')
    write(OUT/'decision.json',decision)
    lines=['# q90 训练样本覆盖对照｜2026-11-07','',
        f'执行完成。决定：{decision["action"]}。全部预设门槛通过：{passed}。','',
        '本轮支持“原短窗限制了模型复杂度，扩大覆盖可进一步降低增幅MAE”；不支持“只扩大q90训练就能稳定提高同误报爬坡命中”。年度窗在全年回顾期仅比原短窗多命中2次，独立1月少命中1次；两组召回差区间均跨零，季度方向也不一致。',
        '年度窗真实爬坡MAE虽改善，平均低估偏差相对原短窗反而略增；全部触发小时MAE仍高于不做修正的QRF。不能把选择性真实爬坡MAE下降写成整体精度普遍提高。',
        '冻结阈值下命中和误报同时明显下降，说明开发期的报警工作点未稳定迁移。未限幅分数的排序和阈值迁移均没有完成所需确认；本轮不再回调阈值。','',
        '## 设计与可支持范围','',
        '- 冻结原 Kelmarsh QRF、输入、预处理、q90 残差目标和模型配置。只改变 q90 训练覆盖。原11月模型直接复用；另拟合7月短窗与12个月年度窗，三组全部报告，不用评价期挑模型。',
        '- 年度窗为2022-08至2023-07。QRF proper training为2023-09至10，年度残差由冻结QRF离线生成，训练目标不重叠；这不是对2022年的真实历史上线回测。所有模型与标签在2023-12开发前可用。',
        '- 三组均只在Kelmarsh 2023-12匹配原QRF的平稳误报数，冻结未限幅报警阈值。报警分数不裁剪，增幅误差仍沿用既有±10pp残差及物理支撑限幅。',
        '- 同终点7月短窗用于控制训练终点；年度与原11月之差同时包含季节覆盖、样本量、近期性等因素，不能单独归因为样本量。',
        '- 独立时间留出为Penmanshiel固定11–15号五机组群2024-01-02至31日。该站其他月份以前已看过，故不是全新独立站点；1月未参与本轮拟合或阈值选择。Kelmarsh 2024年2–12月已多次查看，本轮全部记为回顾诊断。',
        '- exact_fpr在评价期事后选取相同平稳误报数，只是排序诊断，不是部署验证；部署表现必须看frozen。独立1月也遵守这一划分。',
        '- NWP门控为同小时预报风速增加≥0.5m/s；真实上爬坡为实际小时增幅>10pp；平稳为绝对增幅≤5pp。±1小时命中采用每个发报日内一对一匹配，并按真实事件是否在门控内归组。',
        '- MAE和偏差以装机容量百分点计，召回和误报率以百分点或百分比计。模型是增幅残差q90，不能把报警命中当作90%功率区间覆盖。','',
        '## 样本覆盖','',
        '| 训练组 | 有效发报日 | 门控小时 | 真爬坡 | 平稳小时 | 首次发报 | 最后目标 | 树平均叶数 |',
        '|---|---:|---:|---:|---:|---|---|---:|']
    for _,r in train.iterrows():
        lines.append(f'| {ARMS[r.arm]} | {int(r.days)} | {int(r.gated_hours)} | {int(r.true_ramps)} | {int(r.quiet)} | {r.first_origin} | {r.last_label} | {r.mean_leaves:.2f} |')
    lines.extend(['',f'纳入天数：{json.dumps(counts,ensure_ascii=False)}。完整年度指连续12个日历月，不代表365个无缺测有效日。筛选只按完整逐时预报、归档可用性和SCADA质量；不按预测结果选择。',
        '同终点7月短窗只有13个有效日、67个触发小时；min_samples_leaf=50使其实际为单叶常数模型。这是固定配置与可用样本共同导致，不能当作一个充分训练的短窗强基线。年度与该组对比只能补充解释，不能独自证明季节覆盖机制。',
        '', '## 事后同误报数：主组内结果','',
        '| 评价集 | 方案 | ±1h命中/真爬坡 | 召回% | 平稳误报/小时 | 真爬坡偏差pp | 真爬坡MAE pp | 全部门控小时MAE pp |',
        '|---|---|---:|---:|---:|---:|---:|---:|'])
    for g,label in list(GROUPS.items())[:2]:
        for arm in ('qrf',*ARMS):
            r=summary(g,'annual',model='original') if arm=='qrf' else summary(g,arm)
            label_arm='原QRF' if arm=='qrf' else ARMS[arm]
            lines.append(f'| {label} | {label_arm} | {int(r.hits)}/{int(r.events)} | {100*r.recall:.2f} | {int(r["false"])}/{int(r.quiet)} | {100*r.bias:.2f} | {100*r.mae:.2f} | {100*r.all_mae:.2f} |')
    lines.extend(['','## 年度窗相对短窗：配对95%区间','',
        '14日历日移动区块为主，2000次重采样；相同日期配对。以下是年度减短窗；召回正值较好，MAE负值较好。每个回顾子组单独匹配误报数，因此季度命中不必加总为全年工作点命中；冻结阈值始终只来自同一开发期。','',
        '| 评价集 | 短窗参照 | 召回差pp [95%CI] | 真爬坡MAE差pp [95%CI] | 全部门控MAE差pp [95%CI] |',
        '|---|---|---:|---:|---:|'])
    for g,label in GROUPS.items():
        for ref in ('old_short','latest_short'):
            lines.append(f'| {label} | {ARMS[ref]} | {ci(contrast(g,ref))} | {ci(contrast(g,ref,metric="mae"))} | {ci(contrast(g,ref,metric="all_mae"))} |')
    lines.extend(['','## 开发期冻结阈值：可部署规则的验证','',
        '| 评价集 | 方案 | ±1h命中/真爬坡 | 平稳误报/小时 | 平稳误报率% |',
        '|---|---|---:|---:|---:|'])
    for g,label in list(GROUPS.items())[:2]:
        for arm in ('qrf',*ARMS):
            r=summary(g,'annual','frozen',model='original') if arm=='qrf' else summary(g,arm,'frozen')
            label_arm='原QRF' if arm=='qrf' else ARMS[arm]
            lines.append(f'| {label} | {label_arm} | {int(r.hits)}/{int(r.events)} | {int(r["false"])}/{int(r.quiet)} | {100*r.quiet_fpr:.2f} |')
    lines.extend(['','| 评价集 | 年度相对原短窗冻结召回差pp [CI] | 冻结误报率差pp [CI] |',
                  '|---|---:|---:|'])
    for g,label in list(GROUPS.items())[:2]:
        lines.append(f'| {label} | {ci(contrast(g,op="frozen"))} | {ci(contrast(g,op="frozen",metric="quiet_fpr"))} |')
    lines.extend(['','开发冻结阈值（含固定并列顺序）：','',
        '```json',(OUT/'thresholds.json').read_text(encoding='utf-8'),'```','',
        '## 区块长度敏感性与限制','',
        '| 评价集 | 短窗参照 | 7日召回差pp [CI] | 14日召回差pp [CI] | 28日召回差pp [CI] |',
        '|---|---|---:|---:|---:|'])
    for g,label in list(GROUPS.items())[:2]:
        for ref in ('old_short','latest_short'):
            cells=' | '.join(ci(contrast(g,ref,block=b)) for b in (7,14,28))
            lines.append(f'| {label} | {ARMS[ref]} | {cells} |')
    lines.extend(['',
        '- 区间条件于已经拟合的权重和阈值，不包含重复训练的不确定性；exact_fpr的阈值也不在每次重采样中重新估计。相同误报数在原评价集成立，重采样后不强制相等。',
        '- 独立1月仅23个有效日，实际日期跨度27天，14日区块有效独立信息很少，28日区块不可计算；未为计算区间而延长留出或填造日期。首次执行在这一长度检查处停止，仅修复统计输出以跳过不可用区块，未改变模型或阈值。季节分组是描述性回顾比较，未做多重比较修正。',
        '- 非循环移动区块会使短窗口中间日期更常被抽到；独立1月个别误差区间甚至未覆盖原点估计，反映端点权重和小样本敏感性。保留原输出，不据其很窄的误差CI作强确认。',
        '- 早期机制诊断中的78/218来自“取消残差10pp限幅、仍保留物理功率支撑”的不同报警分数。本轮遵守上轮新站点规则，报警完全不裁剪；同一旧q90模型在本轮全年为71/218，不能将78与本轮73直接比较。',
        '- 固定QRF仅用2023年9–10月训练。本实验检验增加q90残差训练覆盖，不能据此断言完整年度基础QRF、其他场站或整体区间的效果。',
        '- 本轮没有改变任何区间端点，未重新声称覆盖率、宽度或IS改善。即使事件诊断通过，仍需另留时段验证接入上界的完整区间指标。',
        '', '## 门槛与后续决策','',
        '```json',json.dumps(decision,ensure_ascii=False,indent=2),'```','',
        '应先依据同终点对照判断“覆盖不足”解释是否得到支持；不因训练样本变多就继续扩大同配方。若全年窗仍不能稳健提高同误报事件命中，应把下一轮改为独立立项的事件排序目标对照，而不是根据本轮留出结果回调q90配置或阈值。','',
        '## 复现与文件','',
        '```powershell','python -u prepare_q90_training_coverage.py','python -u run_q90_training_coverage.py','python summarize_q90_training_coverage.py','```','',
        '- protocol.json / decision_protocol.json：拟合前锁定设计与门槛；weights.json：冻结权重哈希。',
        '- training_counts.csv / sample_counts.json / thresholds.json：训练规模、纳入天数、开发冻结阈值。',
        '- 每个评价目录下，三组各有daily.csv、summary.csv、paired_blocks.csv、retrospective_cutoff.json；annual_vs_short_paired.csv为年度减短窗的直接配对对照。',
        '- decision.json为门槛判定；completion.json只代表执行完成，不代表方法有效。',''])
    if (OUT/'verification.json').exists():
        lines.extend(['完整性检查通过：冻结权重哈希未变、三组模型参数一致、开发期误报数均为8、各组逐日QRF基线完全相同、事后误报计数匹配、报警工作点不改变幅度误差。检查记录见verification.json。年度原始功率范围为−0.003301至1.000645，没有超出[−0.01,1.05]的极端值；沿用原处理裁剪到[0,1]，纳入目标的裁剪小时数见sample_counts.json。',''])
    (OUT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(decision,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
