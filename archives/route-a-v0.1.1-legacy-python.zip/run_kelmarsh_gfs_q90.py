"""Independent Kelmarsh holdout for the locked GEFCom q90 increment recipe."""
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from threadpoolctl import threadpool_limits

from pair_kelmarsh_gfs import OUT, PILOT, month
from revision_common import frozen_spec, write
from run_gefcom_tail_dynamic import base_matrix
from run_point_residual import cells
from sparse_leaf_qrf import SparseLeafQRF
from run_gefcom2012_local_increment import score,threshold,daily,summarize,paired

PERIODS={
    'qrf_train':('2023-09','2023-10'),
    'q90_train':('2023-11',),
    'threshold_dev':('2023-12',),
    'holdout':('2024-02','2024-03'),
}
DEST=OUT/'q90_independent'


def read(stage):
    months=PERIODS[stage]
    w=pd.concat([pd.read_csv(OUT/m/'paired_hourly.csv',parse_dates=['origin','target','cycle','archive_time'])
                 for m in months],ignore_index=True)
    years={int(m[:4]) for m in months}
    sc=pd.concat([pd.read_csv(OUT/f'scada_hourly_{y}.csv',parse_dates=['target']) for y in sorted(years)])
    sc=sc.set_index('target')
    histories,targets,wind,origins=[],[],[],[]
    for origin,g in w.groupby('origin',sort=True):
        idx=pd.date_range(origin-pd.Timedelta(hours=23),origin,freq='h')
        h=sc.reindex(idx)
        if len(g)!=24 or not g.paired.all() or not h.power_valid.eq(True).all():
            continue
        np.testing.assert_array_equal(g.lead,np.arange(1,25))
        assert (g.archive_time<=origin).all() and (g.cycle<origin).all()
        histories.append(h.power_pu.to_numpy())
        targets.append(g.power_pu.to_numpy())
        wind.append(g[['u100','v100']].to_numpy())
        origins.append(origin)
    assert origins
    y=np.asarray(targets)
    h=np.asarray(histories)
    outside=int(((y<0)|(y>1)).sum())
    return dict(history=np.clip(h,0,1),y=np.clip(y,0,1),nwp=np.asarray(wind),
        origins=pd.DatetimeIndex(origins).tz_convert(None).to_numpy(),
        meta=pd.DataFrame(dict(nwp_age_hours=np.full(len(origins),6))),
        total_origins=w.origin.nunique(),outside_target_hours=outside)


def record(d,forest,imputer):
    x=imputer.transform(base_matrix(d,2012))
    med=forest.predict(x,(.50,)).reshape(-1,24)
    y=d['y']
    last=d['history'][:,-1,None]
    before=np.concatenate([last,med[:,:-1]],axis=1)
    base=med-before
    actual=np.diff(y,axis=1,prepend=last)
    wind=d['nwp']
    speed=np.linalg.norm(wind,axis=2)
    dw=np.diff(speed,axis=1,prepend=np.full((len(speed),1),np.nan))
    turn=wind/np.maximum(speed[...,None],1.)
    turn_delta=np.diff(turn,axis=1,prepend=turn[:,:1])
    direction_change=np.linalg.norm(turn_delta,axis=2)
    lead=np.broadcast_to(np.arange(1,25),base.shape)
    features=np.stack([base,before,med,speed,dw,direction_change,turn[:,:,0],turn[:,:,1],lead],axis=-1)
    gate=dw>=.5
    assert np.isfinite(features[gate]).all()
    return [dict(farm=1,origins=d['origins'],ends=d['origins']+np.timedelta64(24,'h'),
                actual=actual,base=base,before=before,gate=gate,features=features)]


def main():
    pilot=json.loads((OUT/PILOT/'completion.json').read_text())
    if not pilot['pass']:
        print('STOP: pilot did not pass',flush=True)
        return
    frozen_spec(DEST/'protocol.json',dict(periods={k:list(v) for k,v in PERIODS.items()},pilot_excluded=PILOT,
        site='Kelmarsh only; same source as pilot, one daily 00 UTC issuance, complete forecast and observation days',
        base='new site-specific QRF500 leaf10, identical GEFCom2012 R2 feature builder, proper-train median imputation',
        model='locked q90 residual HistGBR from GEFCom recipe refitted locally, cap ±10pp, original point baseline retained',
        gate='NWP speed increase >=0.5m/s, actual ramp >10pp; ±1h one-to-one, quiet change within 5pp',
        thresholds='fit one alarm threshold by December quiet false count; report retrospective equal-false count separately',
        timing='holdout months strictly later than all training, threshold development, and pilot; January excluded; no refitting',
        inference='14-calendar-day moving paired blocks; conditional on trained forecasts; single-site short holdout'))
    for months in PERIODS.values():
        for m in months:
            if not (OUT/m/'completion.json').exists():
                month(m)
    train,fit,dev,test=(read(k) for k in PERIODS)
    assert all((left['origins']+np.timedelta64(24,'h')).max()<=right['origins'].min()
               for left,right in zip((train,fit,dev),(fit,dev,test)))
    counts={k:dict(days=len(v['origins']),issued=v['total_origins'],outside_target_hours=v['outside_target_hours'])
            for k,v in zip(PERIODS,(train,fit,dev,test))}
    write(DEST/'sample_counts.json',counts)
    tx=base_matrix(train,2012)
    imp=SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True).fit(tx)
    forest=SparseLeafQRF(500,10,0,n_jobs=4).fit(imp.transform(tx),train['y'].ravel())
    f=record(fit,forest,imp)[0]
    gate=f['gate']
    assert gate.sum()>=50
    model=HistGradientBoostingRegressor(loss='quantile',quantile=.90,max_iter=40,max_leaf_nodes=7,
        min_samples_leaf=50,l2_regularization=1,early_stopping=False,random_state=0)
    with threadpool_limits(limits=2):
        model.fit(f['features'][gate],(f['actual']-f['base'])[gate])
        development=score(model,record(dev,forest,imp),1.)
    frozen=threshold(development)
    frozen_spec(DEST/'selection.json',dict(quantile=.90,threshold=frozen,fit_hours=int(gate.sum())))
    joblib.dump(model,DEST/'q90.joblib')
    summarize(daily(development,frozen,'frozen')).to_csv(DEST/'development_summary.csv')
    with threadpool_limits(limits=2):
        evaluation=score(model,record(test,forest,imp),1.)
    exact=threshold(evaluation)
    frame=pd.concat([daily(evaluation,frozen,'frozen'),daily(evaluation,exact,'exact_fpr')])
    frame.to_csv(DEST/'evaluation_daily.csv',index=False)
    results=summarize(frame)
    results.to_csv(DEST/'evaluation_summary.csv')
    ci=paired(frame)
    ci.to_csv(DEST/'evaluation_paired_blocks.csv',index=False)
    write(DEST/'completion.json',dict(status='complete',samples=counts,threshold=frozen,exact_threshold=exact))
    print(results.xs('gated',level='scope').to_string(),flush=True)
    print(ci.query("scope=='gated'").to_string(index=False),flush=True)


if __name__=='__main__':
    main()
