"""Generate a retrospective monthly-refit report strictly from verified artifacts."""
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from retraining_common import OUT,ROOT,METHODS,load_farms,write
from analyze_retraining import load_stage


def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+
        ['| '+' | '.join(map(str,row))+' |' for row in rows])


def main():
    verification=json.loads((OUT/'verification.json').read_text());assert verification['status']=='passed'
    tests=json.loads((OUT/'test_result.json').read_text());assert tests['status']=='passed'
    macro=pd.read_csv(OUT/'metrics_macro.csv');per=pd.read_csv(OUT/'seed_mean_per_farm.csv')
    monthly=pd.read_csv(OUT/'monthly_macro.csv');diag=pd.read_csv(OUT/'raw_calibration_diagnostics.csv')
    bootstrap=pd.read_csv(OUT/'paired_bootstrap.csv');decision=json.loads((OUT/'development_decision.json').read_text())
    mainrows=[];grouprows=[];cirows=[];diagnosticrows=[];worst=[];targets=[]
    for year in [2014,2012]:
        m=macro[(macro.year==year)&(macro.stage=='evaluation')&(macro.variant=='signed')].set_index(['method','group'])
        base=m.loc[('frozen','all')]
        for method in METHODS:
            row=m.loc[(method,'all')];f=per[(per.year==year)&(per.stage=='evaluation')&(per.variant=='signed')&(per.method==method)&(per.group=='all')]
            mainrows.append([year,method,f'{row.coverage*100:.2f}',f'{row.width*100:.2f}',f'{(row.width/base.width-1)*100:+.2f}%',f'{row.IS:.4f}',f'{int((f.coverage>=.9).sum())}/{len(f)}'])
            for group in ['near_zero','up_ramp','down_ramp']:
                a=m.loc[(method,group)];b=m.loc[('frozen',group)]
                grouprows.append([year,method,group,f'{a.coverage*100:.2f}',f'{(a.coverage-b.coverage)*100:+.2f}',f'{a.width*100:.2f}',f'{a.IS:.4f}'])
            mm=monthly[(monthly.year==year)&(monthly.stage=='evaluation')&(monthly.method==method)&(monthly.group=='all')]
            w=mm.loc[mm.coverage.idxmin()];worst.append([year,method,w.month,f'{w.coverage*100:.2f}'])
            dd=diag[(diag.year==year)&(diag.stage=='evaluation')&(diag.method==method)].mean(numeric_only=True)
            diagnosticrows.append([year,method,f'{dd.raw_mean_pinball:.5f}',f'{dd.raw_clipped_width*100:.2f}',f'{dd.final_width*100:.2f}',f'{dd.mean_signed_correction*100:+.2f}',f'{dd.negative_correction_fraction*100:.1f}'])
            if method!='frozen':
                groups=all(m.loc[(method,g),'coverage']>=m.loc[('frozen',g),'coverage']-.01 for g in ['near_zero','up_ramp','down_ramp'])
                target=dict(year=year,method=method,coverage=float(row.coverage),width=float(row.width),IS=float(row.IS),
                    relative_width_change=float(row.width/base.width-1),literal_90_and_narrow=bool(row.coverage>=.9 and row.width<base.width),
                    practical_gate=bool(row.coverage>=max(.9,base.coverage-.005) and row.width<=.97*base.width and row.IS<=base.IS and groups),
                    conditional_within_1pp=groups,farms_ge90=int((f.coverage>=.9).sum()),farms=len(f))
                targets.append(target)
                for metric in ['coverage','width','IS']:
                    a=bootstrap[(bootstrap.year==year)&(bootstrap.method==method)&(bootstrap.group=='all')&(bootstrap.metric==metric)&(bootstrap.block_days==14)].iloc[0]
                    scale=100 if metric!='IS' else 1
                    cirows.append([year,method,metric+(' (pp)' if metric!='IS' else ''),f'{a.difference*scale:+.4f}',f'[{a.low*scale:+.4f}, {a.high*scale:+.4f}]',f'[{a.absolute_low*scale:.4f}, {a.absolute_high*scale:.4f}]'])
    pd.DataFrame(targets).to_csv(OUT/'target_checks.csv',index=False)
    summary=[]
    for year in [2014,2012]:
        matching=[a['method'] for a in targets if a['year']==year and a['literal_90_and_narrow']]
        passing=[a['method'] for a in targets if a['year']==year and a['practical_gate']]
        summary.append(f'- {year}：总体覆盖点估计≥90%且宽度小于冻结模型的候选为 **{", ".join(matching) if matching else "无"}**；同时通过缩宽≥3%、IS不增和三个工况覆盖下降≤1pp门槛的为 **{", ".join(passing) if passing else "无"}**。')
    figdir=OUT/'figures';figdir.mkdir(exist_ok=True)
    for year in [2014,2012]:
        mm=monthly[(monthly.year==year)&(monthly.stage=='evaluation')&(monthly.group=='all')]
        fig,axes=plt.subplots(3,1,figsize=(11,8),sharex=True)
        for method,color in zip(METHODS,['#555555','#2478a5','#c9823b']):
            a=mm[mm.method==method].sort_values('month')
            for ax,metric,scale in zip(axes,['coverage','width','IS'],[100,100,1]):ax.plot(a.month,a[metric]*scale,'o-',label=method,color=color)
        for ax,label in zip(axes,['Coverage (%)','Width (% capacity)','Interval score']):ax.set_ylabel(label);ax.grid(alpha=.2)
        axes[0].axhline(90,ls='--',color='gray');axes[0].set_ylim(0,100);axes[1].set_ylim(bottom=0)
        axes[0].legend(ncol=3);axes[-1].tick_params(axis='x',rotation=35);fig.suptitle(f'GEFCom{year}; monthly macro; seed0; retrospective')
        fig.tight_layout();fig.savefig(figdir/f'monthly_{year}.png',dpi=170);plt.close(fig)
        d=load_farms(year)[1];_,a,_=load_stage(year,1,'frozen',0,'evaluation');k=int(np.flatnonzero(d['valid'][a['indices']])[0])
        fig,axes=plt.subplots(3,1,figsize=(11,8),sharex=True,sharey=True)
        for ax,method in zip(axes,METHODS):
            _,b,_=load_stage(year,1,method,0,'evaluation');np.testing.assert_equal(a['indices'],b['indices'])
            ax.fill_between(np.arange(1,25),a['lo'][k],a['hi'][k],color='#888888',alpha=.25,label='Frozen')
            ax.fill_between(np.arange(1,25),b['lo'][k],b['hi'][k],color='#2478a5',alpha=.3,label=method)
            ax.plot(np.arange(1,25),d['y'][a['indices'][k]],color='black',lw=1.3,label='Observed')
            ax.set_ylim(0,1);ax.set_title(method);ax.set_ylabel('Power / capacity');ax.grid(alpha=.2);ax.legend(loc='upper right',fontsize=8)
        origin=str(d['origins'][a['indices'][k]])[:10];axes[-1].set_xlabel('Lead (h)');fig.suptitle(f'GEFCom{year} farm1; first valid evaluation origin {origin}; seed0')
        fig.tight_layout();fig.savefig(figdir/f'intervals_{year}_farm01.png',dpi=170);plt.close(fig)
        write(figdir/f'intervals_{year}_sources.json',dict(farm=1,seed=0,origin=origin,selection='first valid evaluation origin, no error-based selection',axis=[0,1]))
    text=f'''# 基础模型每月重训：完整回溯对照

启动：2026-11-05；完成：2026-11-06，Asia/Shanghai。训练、逐模型校准重算、权重重放、时间区块统计与回归检查全部完成。

## 1. 结果结论

{chr(10).join(summary)}

这里只支持固定种子0、这些已知风场和日期的回溯比较。总体90%不等于每场、近零、爬坡或每个月都达到90%，也不等于24小时整条路径同时覆盖。

## 2. 本轮只改什么

- 仍然逐场训练，不跨数据集混合；GEFCom2014为10场，2012为7场。
- 固定原有canonical R2特征与QRF500树、leaf10、max_features=1、bootstrap、完整叶响应、q05/q95；种子0。稀疏叶响应后端已与原QRF约1e−15一致。
- frozen：原模型不变，原训练段为2014的2012年、2012的2009H2+2010年。原始预测和最终校准区间与旧结果逐元素核对。
- expanding：每月1日重新拟合，使用所有更早且满足独立校准隔离的完整目标。
- rolling365：每月1日重新拟合，仅用相同截止点之前365个日历日；缺失日期不补齐为365个有效样本。
- 在月初t，训练标签结束时间≤t−84日；独立校准标签结束时间位于(t−84日,t]。训练与校准日不重叠；最近84天没有被新基础模型训练。
- 每个新模型重新预测自己未训练过的校准段。月内按完整目标到达更新逐时效rolling84 CQR。切换模型后不混用旧模型的误差，不使用新模型训练集内残差冒充校准。
- 每次中位数填补和缺失指示器只在该版本proper training拟合。基础模型每月固定；每天仍只发一次未来1–24小时区间。输入历史24小时和发报时可用NWP保持不变。
- 没有新增低功率风险保护、场间共享、阈值搜索或网络结构。

**重要限制：**这个干净实现有意保留84天训练隔离，检验的是“月度重新学习较新的历史”，不是每天立刻把昨天的数据加入基础模型。若无收益，不能推出所有在线学习都无效。若要同时利用最新标签并保持样本外校准，需要另行验证严格的滚动样本外误差方案。

expanding同时改变训练样本量与所覆盖的时间；QRF没有固定最大深度，更多样本也可能产生更多节点。因此即使有收益，也不能仅凭这一对照把原因唯一归为概念漂移。rolling365提供固定日历跨度的补充，但有效样本数仍受缺失影响。

## 3. 开发规则与范围

2014Q2作开发诊断，Q3/Q4作评价；2012评价为2011-07至2012-06-27。所有既有有效原点、目标、工况定义不变，不把评价期改成新的独立测试。

这里是逐月在线回放：例如2013年7月的功率到11月已经成为更早的已知历史，并离开84天校准隔离，可以进入11月训练；11月模型只能评分11月，不能回头重新评分7月。因此它改变了原先“整个评价期权重冻结”的训练政策，并非把整个H2永久排除于所有后续训练之外。

2014Q2预先固定门槛：总体覆盖≥max(90%,frozen−0.5pp)、宽度相对降低≥3%、IS不增，且近零/上升/下降覆盖各自不下降超过1pp。开发期偏好：**{decision['prefer']}**。所有候选无论通过与否都报告，无2012重选。

种子0是考虑实际计时成本后的固定筛查选择，未按表现挑种子。最终保留348个新500树森林和174个冻结月区间重建。计时pilot先拟合了2014场1七月expanding，但未查看预测质量；该权重复用，不能写成严格从未接触的测试。

原QRF的leaf10本就由2014Q2选择；本轮开发诊断仍是回顾性开发，不声称完全嵌套模型选择或新的外部确认。

“训练外校准”只表示这些标签没有进入该版本的基础模型拟合，不代表时间序列样本在统计上独立。2014Q2参与过原超参数选择，也可能参与校准；因此这里不声称标准split-conformal的独立校准条件或严格有限样本覆盖保证。

## 4. 评价期总体结果

{table(['数据','方法','覆盖%','宽度%容量','宽度相对冻结变化','IS','达到90%的场数'],mainrows)}

宽度变化为相对百分比，覆盖差值为百分点，不能混淆。逐场、原始区间、逐月与逐时效结果均保留。

## 5. 条件工况与最弱月份

{table(['数据','方法','工况','覆盖%','相对冻结pp','宽度%容量','IS'],grouprows)}

未来工况仅事后评价使用，不用于发报时读取真实未来状态。

{table(['数据','方法','最弱月份','覆盖%'],worst)}

## 6. 原始模型与校准修正的分离

{table(['数据','方法','原始双头平均pinball','原始clip宽度%','最终宽度%','平均signed修正pp','负修正%'],diagnosticrows)}

pinball用原始未clip预测的q05/q95损失求均值；其余宽度按clip后区间。signed修正可能为负，表示收缩；clip使修正和最终宽度变化并非简单加法。若原始损失未改善，仅最终区间变窄，不应宣称基础预测关系改善。

## 7. 不确定性

{table(['数据','方法','指标','相对冻结差值','差值95%区间','候选绝对指标95%区间'],cirows)}

主表14日移动块，另存7日敏感性；每种2000次，同时抽取全部风场与全部候选的相同日历块。区间条件于固定训练策略和种子0，没有包括训练随机性、策略再选择或多比较校正。覆盖绝对区间跨90%时不能称统计保证90%；时间序列也不满足标准split-conformal交换性假设。

## 8. 图与复现

![2014月份](figures/monthly_2014.png)

![2012月份](figures/monthly_2012.png)

![2014区间](figures/intervals_2014_farm01.png)

![2012区间](figures/intervals_2012_farm01.png)

区间图固定选择场1首个有效评价原点，所有方法同一天、seed0，纵轴统一[0,1]，不按预测效果挑图。

- protocol.json与development_decision.json：冻结规则和开发阶段偏好。
- metrics_per_farm.csv、metrics_macro.csv、monthly_per_farm.csv、per_lead.csv：全结果。
- raw_calibration_diagnostics.csv、paired_bootstrap.csv、target_checks.csv：机制诊断与配对统计。
- 每月model.joblib、predictions.npz、feedback.csv、complete.json：所有权重、拟合日、样本外预测与到达见证。
- verification.json：{verification['monthly_combinations']}个月/场/策略组合全量重算；每个重训模型核对完整训练标签、训练预处理，并重放首个校准日与首个预测日的全部24时效。
- test_result.json：{tests['count']}项相关回归测试通过。原有模型、报告与评价数组均未改写。

运行资源：初始6个进程，曾按22逻辑CPU与内存余量改为10个进程，实际吞吐未改善后恢复6个，每个森林2线程。已完成权重复用，未完成拟合按原种子重跑；没有改变模型参数或按分数选择重跑。详见execution_resource_note.json。复现入口为 `python prepare_retraining.py`、`python -u run_retraining.py --workers 6`，训练完成后执行analyze_retraining.py、相关测试及report_retraining.py。
'''
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')
    snapshot=OUT/'source_snapshot'
    for name in ['retraining_common.py','run_retraining.py','prepare_retraining.py','analyze_retraining.py','report_retraining.py','finish_retraining.py','test_retraining.py']:
        shutil.copy2(ROOT/name,snapshot/name)
    status=ROOT/'COMPLETE_STATUS.md';backup=OUT/'source_before';backup.mkdir(exist_ok=True)
    if not (backup/status.name).exists():shutil.copy2(status,backup/status.name)
    content=status.read_text(encoding='utf-8');marker='## 2026-11-06 基础模型每月重训对照'
    if marker in content:content=content.split(marker)[0].rstrip()+'\n'
    status.write_text(content+'\n'+marker+'\n\n已完成逐场QRF冻结、月度扩展、月度最近365天对照；种子0，保留84天独立校准。详见[重训完整报告](out_gefcom_retraining_20261105/RESULTS.md)。\n\n'+'\n'.join(summary)+'\n\n结果属于已查看日期的回溯筛查，未覆盖多种子或新数据确认。\n',encoding='utf-8')
    write(OUT/'completion.json',dict(status='complete',verification='passed',seeds=[0],report=str(OUT/'RESULTS.md'),scope='monthly local QRF retrospective screening',targets=targets))
    print('RETRAINING REPORT COMPLETE',OUT/'RESULTS.md',flush=True)


if __name__=='__main__':main()
