"""End-to-end pipeline: data -> retrieval -> point/quantile models -> intervals -> evaluation.

Usage:
    python run.py                                        # synthetic smoke test, 1-day, similar retrieval
    python run.py --ablation                             # compare none / random / similar retrieval
    python run.py --horizon-days 7 --horizon-bins 48 --analog-bins 48
    python run.py --data your_wind.csv --horizon-days 1
    python run.py --retrieval-mode random --noise-frac 0.3
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

import evaluate as ev
import intervals as iv
import models as md
import baselines as bm
from config import Config, default_config
from data import build_situations, chronological_split, load_dataframe
from retrieval import Retriever, analog_features

BASELINE_METHODS = ["climatology", "persistence", "analog"]


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Retrieval-augmented wind interval forecasting")
    p.add_argument("--data", type=str, default="", help="CSV path; empty -> synthetic")
    p.add_argument("--kelmarsh", type=str, default="", help="Kelmarsh data root (uses real farm data)")
    p.add_argument("--kelmarsh-years", type=int, nargs="+", default=None,
                   help="years to load, e.g. 2019 2020")
    p.add_argument("--kelmarsh-cache", type=str, default="",
                   help="slim farm-cache CSV path (built once, fast reload)")
    p.add_argument("--horizon-days", type=int, default=1)
    p.add_argument("--condition-days", type=int, default=1)
    p.add_argument("--points-per-day", type=int, default=96)
    p.add_argument("--days", type=int, default=365, help="synthetic length in days")
    p.add_argument("--conf", type=float, nargs="+", default=[0.90])
    p.add_argument("--methods", type=str, nargs="+",
                   default=["quantile", "conformal", "cqr", "local_conformal"])
    p.add_argument("--top-k", type=int, default=20)
    p.add_argument("--nn-candidates", type=int, default=100,
                   help="shortlist size before DTW re-rank (lower = faster DTW)")
    p.add_argument("--dtw-band", type=int, default=24,
                   help="Sakoe-Chiba band width in points (2h=12, 4h=24)")
    p.add_argument("--analog-bins", type=int, default=None)
    p.add_argument("--horizon-bins", type=int, default=None)
    p.add_argument("--retrieval-mode", type=str, default="similar",
                   choices=["similar", "random", "none"])
    p.add_argument("--noise-frac", type=float, default=0.0)
    p.add_argument("--n-estimators", type=int, default=200)
    p.add_argument("--ablation", action="store_true",
                   help="compare retrieval modes none/random/similar")
    p.add_argument("--no-dtw", action="store_true")
    p.add_argument("--out", type=str, default="out")
    p.add_argument("--seed", type=int, default=0)
    return p.parse_args()


def build_x(feat, mean_block, top1_block):
    return np.hstack([feat, mean_block, top1_block])


def run_once(cfg: Config, retrieval_mode: str, make_plot: bool):
    """Run the full chain under one retrieval mode. Returns (results, vis)."""
    df = load_dataframe(cfg)
    d = build_situations(df, cfg)
    cond, target, feat = d["cond"], d["target"], d["feat"]
    capacity = d["capacity"]
    n = len(cond)
    train_idx, cal_idx, test_idx = chronological_split(n, cfg)
    rng = np.random.default_rng(cfg.seed)

    # retrievers (frozen train memory; cal corpus only for local conformal)
    ret_train = Retriever(cond[train_idx], feat[train_idx], target[train_idx], train_idx, cfg)
    ret_cal = Retriever(cond[cal_idx], feat[cal_idx], target[cal_idx], cal_idx, cfg)

    # analog features
    excl_train = np.arange(len(train_idx))
    if retrieval_mode == "none":
        X_train, X_cal, X_test = feat[train_idx], feat[cal_idx], feat[test_idx]
    else:
        m_tr, t1_tr = analog_features(ret_train, cond[train_idx], feat[train_idx], excl_train, cfg,
                                      mode=retrieval_mode, noise_frac=cfg.analog_noise_frac, rng=rng)
        m_ca, t1_ca = analog_features(ret_train, cond[cal_idx], feat[cal_idx],
                                      np.full(len(cal_idx), -1), cfg, mode=retrieval_mode, rng=rng)
        m_te, t1_te = analog_features(ret_train, cond[test_idx], feat[test_idx],
                                      np.full(len(test_idx), -1), cfg, mode=retrieval_mode, rng=rng)
        X_train = build_x(feat[train_idx], m_tr, t1_tr)
        X_cal = build_x(feat[cal_idx], m_ca, t1_ca)
        X_test = build_x(feat[test_idx], m_te, t1_te)

    scaler = StandardScaler().fit(X_train)
    X_train = scaler.transform(X_train)
    X_cal = scaler.transform(X_cal)
    X_test = scaler.transform(X_test)
    y_train, y_cal, y_test = target[train_idx], target[cal_idx], target[test_idx]

    # point model
    point = md.fit_point(X_train, y_train, cfg)
    yhat_cal = md.predict(point, X_cal)
    yhat_test = md.predict(point, X_test)
    resid_cal = yhat_cal - y_cal

    # intervals
    results = {mth: {regime: {} for regime in ["all", "ramp", "calm"]} for mth in cfg.interval_methods}
    bounds = {}
    rmask = ev.ramp_mask(y_test, capacity, cfg.ramp_threshold_frac)
    masks = {"all": np.ones_like(y_test, dtype=bool), "ramp": rmask, "calm": ~rmask}

    for conf in cfg.confidence_levels:
        alpha = 1.0 - conf
        q_lo, q_hi = alpha / 2.0, 1.0 - alpha / 2.0

        need_quantile = ("quantile" in cfg.interval_methods) or ("cqr" in cfg.interval_methods)
        if need_quantile:
            qm_lo = md.fit_quantile(X_train, y_train, q_lo, cfg)
            qm_hi = md.fit_quantile(X_train, y_train, q_hi, cfg)
            lo_q_test = md.predict(qm_lo, X_test)
            hi_q_test = md.predict(qm_hi, X_test)
            lo_q_cal = md.predict(qm_lo, X_cal)
            hi_q_cal = md.predict(qm_hi, X_cal)

            if "quantile" in cfg.interval_methods:
                for regime, mask in masks.items():
                    results["quantile"][regime][conf] = ev.evaluate_intervals(
                        y_test, lo_q_test, hi_q_test, capacity, alpha, mask)
                bounds[("quantile", conf)] = (lo_q_test, hi_q_test)

        if "conformal" in cfg.interval_methods:
            q_h = iv.fit_conformal(y_cal, yhat_cal, conf)
            lo, hi = iv.predict_conformal(yhat_test, q_h)
            for regime, mask in masks.items():
                results["conformal"][regime][conf] = ev.evaluate_intervals(
                    y_test, lo, hi, capacity, alpha, mask)
            bounds[("conformal", conf)] = (lo, hi)

        if "cqr" in cfg.interval_methods:
            q_h = iv.fit_cqr(y_cal, lo_q_cal, hi_q_cal, conf)
            lo, hi = iv.predict_cqr(lo_q_test, hi_q_test, q_h)
            for regime, mask in masks.items():
                results["cqr"][regime][conf] = ev.evaluate_intervals(
                    y_test, lo, hi, capacity, alpha, mask)
            bounds[("cqr", conf)] = (lo, hi)

        if "local_conformal" in cfg.interval_methods:
            state = iv.fit_local_conformal(ret_cal, cond[cal_idx], feat[cal_idx], resid_cal, cfg)
            lo, hi = iv.predict_local_conformal(state, cond[test_idx], feat[test_idx], yhat_test, conf)
            for regime, mask in masks.items():
                results["local_conformal"][regime][conf] = ev.evaluate_intervals(
                    y_test, lo, hi, capacity, alpha, mask)
            bounds[("local_conformal", conf)] = (lo, hi)

    vis = (df, test_idx, d["origin_ts"], y_test, yhat_test, bounds, capacity) if make_plot else None
    return results, vis


def segment_split(origin_ts: pd.Series) -> dict:
    """Protocol D: 6 segments by last-observed time (left-closed, right-open).

    V_cal calibrates the frozen predictor for V_score scoring; C_old/E_old are
    already-seen segments reserved for back-test, NOT used for development.
    """
    ts = origin_ts
    return {
        "M": (ts >= "2018-01-01") & (ts < "2019-01-01"),       # fixed memory bank
        "T": (ts >= "2019-01-01") & (ts < "2021-01-01"),       # train predictors
        "V_cal": (ts >= "2021-01-01") & (ts < "2021-04-01"),   # internal calibration
        "V_score": (ts >= "2021-04-01") & (ts < "2021-07-01"), # candidate scoring
        "C_old": (ts >= "2021-07-01") & (ts < "2022-01-01"),   # old-protocol calibration
        "E_old": (ts >= "2022-01-01") & (ts < "2023-01-01"),   # old-protocol test
    }


def assert_time_boundaries(d: dict, seg: dict) -> None:
    """Every adjacent segment's labels must be fully observed before the next origin."""
    order = ["M", "T", "V_cal", "V_score", "C_old", "E_old"]
    for a, b in zip(order, order[1:]):
        if seg[a].any() and seg[b].any():
            a_end = d["target_end_ts"][seg[a]].max()
            b_start = d["origin_ts"][seg[b]].min()
            assert a_end <= b_start, f"boundary {a}->{b} violated: {a_end} > {b_start}"


def run_kelmarsh(cfg: Config, retrieval_mode: str, make_plot: bool):
    """Protocol D: train T, calibrate V_cal, score V_score (development only)."""
    df = load_dataframe(cfg)
    d = build_situations(df, cfg)
    cond, target, feat = d["cond"], d["target"], d["feat"]
    tvalid = d["target_valid"]
    origin_ts = d["origin_ts"]
    capacity = d["capacity"]

    seg = segment_split(origin_ts)
    assert_time_boundaries(d, seg)

    M_idx = np.where(seg["M"] & tvalid)[0]
    T_idx = np.where(seg["T"] & tvalid)[0]
    Vcal_idx = np.where(seg["V_cal"] & tvalid)[0]
    Vscore_idx = np.where(seg["V_score"] & tvalid)[0]
    print(f"[segments] M={len(M_idx)} T={len(T_idx)} V_cal={len(Vcal_idx)} V_score={len(Vscore_idx)} "
          f"| invalid discarded={int((~tvalid).sum())}")

    ret_M = Retriever(cond[M_idx], feat[M_idx], target[M_idx], M_idx, cfg)
    ret_Vcal = Retriever(cond[Vcal_idx], feat[Vcal_idx], target[Vcal_idx], Vcal_idx, cfg)

    rng = np.random.default_rng(cfg.seed)
    if retrieval_mode == "none":
        X_T, X_Vcal, X_Vscore = feat[T_idx], feat[Vcal_idx], feat[Vscore_idx]
    else:
        mT, t1T = analog_features(ret_M, cond[T_idx], feat[T_idx], np.full(len(T_idx), -1), cfg,
                                  mode=retrieval_mode, noise_frac=cfg.analog_noise_frac, rng=rng)
        mVc, t1Vc = analog_features(ret_M, cond[Vcal_idx], feat[Vcal_idx], np.full(len(Vcal_idx), -1), cfg,
                                    mode=retrieval_mode, rng=rng)
        mVs, t1Vs = analog_features(ret_M, cond[Vscore_idx], feat[Vscore_idx], np.full(len(Vscore_idx), -1), cfg,
                                    mode=retrieval_mode, rng=rng)
        X_T = build_x(feat[T_idx], mT, t1T)
        X_Vcal = build_x(feat[Vcal_idx], mVc, t1Vc)
        X_Vscore = build_x(feat[Vscore_idx], mVs, t1Vs)

    scaler = StandardScaler().fit(X_T)
    X_T = scaler.transform(X_T)
    X_Vcal = scaler.transform(X_Vcal)
    X_Vscore = scaler.transform(X_Vscore)
    y_T, y_Vcal, y_Vscore = target[T_idx], target[Vcal_idx], target[Vscore_idx]

    point = md.fit_point(X_T, y_T, cfg)
    yhat_Vcal = md.predict(point, X_Vcal)
    yhat_Vscore = md.predict(point, X_Vscore)
    resid_Vcal = yhat_Vcal - y_Vcal

    results = {mth: {regime: {} for regime in ["all", "ramp", "calm"]}
               for mth in (cfg.interval_methods + BASELINE_METHODS)}
    bounds = {}
    # first-step ramp uses "last observed hour mean -> first predicted hour mean"
    prev_Vscore = cond[Vscore_idx, -6:].mean(axis=1)
    rmask = ev.ramp_mask(y_Vscore, capacity, cfg.ramp_threshold_frac, prev=prev_Vscore)
    masks = {"all": np.ones_like(y_Vscore, dtype=bool), "ramp": rmask, "calm": ~rmask}

    for conf in cfg.confidence_levels:
        alpha = 1.0 - conf
        q_lo, q_hi = alpha / 2.0, 1.0 - alpha / 2.0
        need_q = ("quantile" in cfg.interval_methods) or ("cqr" in cfg.interval_methods)
        if need_q:
            qm_lo = md.fit_quantile(X_T, y_T, q_lo, cfg)
            qm_hi = md.fit_quantile(X_T, y_T, q_hi, cfg)
            lo_raw_s = md.predict(qm_lo, X_Vscore); hi_raw_s = md.predict(qm_hi, X_Vscore)
            lo_raw_c = md.predict(qm_lo, X_Vcal); hi_raw_c = md.predict(qm_hi, X_Vcal)
            # ordered quantiles (L=min, U=max); record crossing rate
            lo_Vscore = np.minimum(lo_raw_s, hi_raw_s); hi_Vscore = np.maximum(lo_raw_s, hi_raw_s)
            lo_Vcal = np.minimum(lo_raw_c, hi_raw_c); hi_Vcal = np.maximum(lo_raw_c, hi_raw_c)
            cross_rate = float((lo_raw_s > hi_raw_s).mean())
            print(f"[crossing] conf={conf:.2f} quantile-crossing rate={cross_rate*100:.2f}%")
            if "quantile" in cfg.interval_methods:
                for regime, mask in masks.items():
                    results["quantile"][regime][conf] = ev.evaluate_intervals(
                        y_Vscore, lo_Vscore, hi_Vscore, capacity, alpha, mask)
                bounds[("quantile", conf)] = (lo_Vscore, hi_Vscore)
        if "conformal" in cfg.interval_methods:
            q_h = iv.fit_conformal(y_Vcal, yhat_Vcal, conf)
            lo, hi = iv.predict_conformal(yhat_Vscore, q_h)
            for regime, mask in masks.items():
                results["conformal"][regime][conf] = ev.evaluate_intervals(y_Vscore, lo, hi, capacity, alpha, mask)
            bounds[("conformal", conf)] = (lo, hi)
        if "cqr" in cfg.interval_methods:
            q_h = iv.fit_cqr(y_Vcal, lo_Vcal, hi_Vcal, conf)
            lo, hi = iv.predict_cqr(lo_Vscore, hi_Vscore, q_h)
            for regime, mask in masks.items():
                results["cqr"][regime][conf] = ev.evaluate_intervals(y_Vscore, lo, hi, capacity, alpha, mask)
            bounds[("cqr", conf)] = (lo, hi)
        if "local_conformal" in cfg.interval_methods:
            state = iv.fit_local_conformal(ret_Vcal, cond[Vcal_idx], feat[Vcal_idx], resid_Vcal, cfg)
            lo, hi = iv.predict_local_conformal(state, cond[Vscore_idx], feat[Vscore_idx], yhat_Vscore, conf)
            for regime, mask in masks.items():
                results["local_conformal"][regime][conf] = ev.evaluate_intervals(y_Vscore, lo, hi, capacity, alpha, mask)
            bounds[("local_conformal", conf)] = (lo, hi)

    # ---- baselines (no trained model; climatology/persistence mode-independent) ----
    for conf in cfg.confidence_levels:
        alpha = 1.0 - conf
        lo, hi = bm.climatology(y_T, len(Vscore_idx), conf)
        for regime, mask in masks.items():
            results["climatology"][regime][conf] = ev.evaluate_intervals(y_Vscore, lo, hi, capacity, alpha, mask)
        lo, hi = bm.persistence(cond[Vscore_idx], y_Vscore.shape[1], conf, y_Vcal, cond[Vcal_idx])
        for regime, mask in masks.items():
            results["persistence"][regime][conf] = ev.evaluate_intervals(y_Vscore, lo, hi, capacity, alpha, mask)
        lo, hi = bm.analog(ret_M, cond[Vscore_idx], feat[Vscore_idx], conf, k=cfg.top_k)
        for regime, mask in masks.items():
            results["analog"][regime][conf] = ev.evaluate_intervals(y_Vscore, lo, hi, capacity, alpha, mask)

    vis = (df, Vscore_idx, d["origin_ts"], y_Vscore, yhat_Vscore, bounds, capacity) if make_plot else None
    return results, vis


def _print_ablation(summary: dict, cfg: Config, methods=("quantile", "conformal", "cqr")):
    print("\n===== retrieval ablation (cov% / width% / score, regime=all) =====")
    header = "mode     " + "".join(f"{m:>22s}" for m in methods)
    print(header)
    print("-" * len(header))
    for mode in ["none", "random", "similar"]:
        row = f"{mode:<9s}"
        for m in methods:
            r = summary[mode][m]["all"][cfg.confidence_levels[0]]
            row += f"{r['coverage']*100:>6.1f}% {r['width']*100:>6.1f}% {r['score']:>6.2f}"
        print(row)


def main():
    args = _parse_args()
    cfg = default_config(
        data_path=args.data,
        horizon_days=args.horizon_days,
        condition_days=args.condition_days,
        points_per_day=args.points_per_day,
        synthetic_days=args.days,
        confidence_levels=args.conf,
        interval_methods=args.methods,
        top_k=args.top_k,
        analog_bins=args.analog_bins,
        horizon_bins=args.horizon_bins,
        nn_candidates=args.nn_candidates,
        dtw_band=args.dtw_band,
        retrieval_mode=args.retrieval_mode,
        analog_noise_frac=args.noise_frac,
        n_estimators=args.n_estimators,
        use_dtw=not args.no_dtw,
        out_dir=args.out,
        seed=args.seed,
    )
    if args.kelmarsh:
        cfg.kelmarsh_root = args.kelmarsh
        cfg.kelmarsh_years = args.kelmarsh_years
        cfg.kelmarsh_cache = args.kelmarsh_cache
        cfg.points_per_day = 144                                  # 10-min grid
        cfg.stride_points = 144                                   # daily forecast origin (24h, no 8h overlap)
        cfg.capacity = 12300.0                                    # 6 x 2050 kW
        cfg.weather_cols = ["wind_speed", "wind_dir_sin", "wind_dir_cos", "temperature"]
    os.makedirs(cfg.out_dir, exist_ok=True)

    runner = run_kelmarsh if args.kelmarsh else run_once

    if args.ablation:
        summary = {}
        for mode in ["none", "random", "similar"]:
            print(f"\n######## retrieval_mode = {mode} ########")
            results, _ = runner(cfg, mode, make_plot=False)
            summary[mode] = results
            present = [m for m in cfg.interval_methods + BASELINE_METHODS if m in results]
            print(ev.format_table(results, present, cfg.confidence_levels))
        _print_ablation(summary, cfg)
        with open(os.path.join(cfg.out_dir, "ablation.json"), "w") as f:
            json.dump({"config": cfg.as_dict(), "ablation": summary}, f, indent=2, default=str)
        print(f"\n[done] ablation -> {os.path.join(cfg.out_dir, 'ablation.json')}")
    else:
        results, vis = runner(cfg, cfg.retrieval_mode, make_plot=True)
        print("\n===== interval results (cov% / width% / score) =====")
        present = [m for m in cfg.interval_methods + BASELINE_METHODS if m in results]
        print(ev.format_table(results, present, cfg.confidence_levels))
        out_json = os.path.join(cfg.out_dir, "results.json")
        with open(out_json, "w") as f:
            json.dump({"config": cfg.as_dict(), "results": results}, f, indent=2, default=str)
        if vis:
            _plot(cfg, *vis)
        print(f"\n[done] results -> {out_json}")
        print(f"       plot    -> {os.path.join(cfg.out_dir, 'forecast.png')}")


def _plot(cfg, df, test_idx, origin_ts, y_test, yhat_test, bounds, capacity):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    i = len(y_test) // 2
    H = y_test.shape[1]
    xs = np.arange(H)
    fig, axes = plt.subplots(2, 1, figsize=(11, 6), sharex=True)

    ax = axes[0]
    ax.plot(xs, y_test[i], color="k", lw=1.5, label="actual")
    ax.plot(xs, yhat_test[i], color="tab:blue", lw=1.0, ls="--", label="point")
    cmap = {"quantile": "tab:orange", "conformal": "tab:green",
            "cqr": "tab:red", "local_conformal": "tab:purple"}
    for (mth, conf), (lo, hi) in bounds.items():
        if conf != cfg.confidence_levels[0]:
            continue
        ax.fill_between(xs, lo[i], hi[i], alpha=0.18, color=cmap.get(mth, "gray"), label=mth)
    ax.set_ylabel("power (kW)")
    ax.set_title(f"test situation origin {origin_ts.iloc[test_idx[i]]}  (horizon {cfg.horizon_days}d)")
    ax.legend(fontsize=8, ncol=3)
    ax.grid(alpha=0.3)

    ax = axes[1]
    z = min(H, cfg.points_per_day)
    ax.plot(xs[:z], y_test[i][:z], color="k", lw=1.5, label="actual")
    for (mth, conf), (lo, hi) in bounds.items():
        if conf != cfg.confidence_levels[0]:
            continue
        ax.fill_between(xs[:z], lo[i][:z], hi[i][:z], alpha=0.18, color=cmap.get(mth, "gray"))
    ax.set_xlabel("horizon step")
    ax.set_ylabel("power (kW)")
    ax.set_title("first-day zoom")
    ax.grid(alpha=0.3)

    fig.tight_layout()
    fig.savefig(os.path.join(cfg.out_dir, "forecast.png"), dpi=110)
    plt.close(fig)


if __name__ == "__main__":
    main()
