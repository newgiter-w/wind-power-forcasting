"""Score the locked new site/year after the development gate, without fitting."""
import json
import sys
import joblib
import numpy as np
import pandas as pd

import run_kelmarsh_nwp_context_factorial as experiment
from run_kelmarsh_gfs_q90_expand import read_months
from run_uncapped_alarm_new_site import models
from run_q90_training_coverage import subset
from run_kelmarsh_ramp_probability import SEASONS
from prepare_q90_training_coverage import OUT as COVERAGE
from prepare_hill_of_towie_holdout import OUT,MONTHS,lock
from revision_common import write


def verify_frozen_chain():
    lock()
    manifest=json.loads((experiment.OUT/'weights.json').read_text(encoding='utf-8'))
    anchors=dict(qrf=prior_bundle(),q90=COVERAGE/'annual.joblib',
        old_probability=experiment.ROOT/'out_kelmarsh_ramp_probability'/'classifier.joblib')
    for name,path in anchors.items():
        assert experiment.sha(path)==manifest[name],f'Frozen anchor changed: {name}'
    return dict(anchor_hashes=manifest,independent_model_and_threshold_hashes=json.loads((OUT/'protocol.json').read_text(encoding='utf-8'))['weights'])


def prior_bundle():
    return experiment.prior.OUT/'q90_expanded_holdout'/'frozen_baseline.joblib'


def verify_existing():
    chain=verify_frozen_chain()
    decision=json.loads((OUT/'decision.json').read_text(encoding='utf-8'))
    seasonal=[]
    for name in ('winter_DJF','spring_MAM','summer_JJA','autumn_SON'):
        ci=pd.read_csv(OUT/name/'paired_blocks.csv')
        seasonal.append(float(recall_ci(ci,'q90_frozen').delta))
    # Include winter to align the guard with the literal frozen protocol.
    # This post-audit check changes neither the present verdict nor any score.
    assert all(v>=-.05 for v in seasonal)==decision['checks']['full_season_no_point_loss_beyond5pp_vs_q90']
    write(OUT/'post_audit_verification.json',dict(status='pass',full_frozen_chain=chain,
        all_four_season_guard_rechecked=True,decision_unchanged=True,no_rescoring_or_refitting=True,
        executed_validator_sha256=experiment.sha(OUT/'source_executed.py'),
        hardened_validator_sha256=experiment.sha(__file__),scores_sha256=experiment.sha(OUT/'scores.npz')))
    print('POST-AUDIT CHECK PASSED; all saved scores and verdict unchanged',flush=True)


def read():
    a=pd.concat([pd.read_csv(OUT/m/'paired_hourly.csv',parse_dates=['origin','target','cycle','archive_time']) for m in MONTHS])
    sc=pd.read_csv(OUT/'scada_hourly_2025.csv',parse_dates=['target']).set_index('target')
    rows=[];audit=[]
    for o,g in a.groupby('origin',sort=True):
        if o<pd.Timestamp('2025-01-02',tz='UTC'):continue
        h=sc.reindex(pd.date_range(o-pd.Timedelta(hours=23),o,freq='h'))
        complete=bool(len(g)==24 and g.paired.all() and h.power_valid.eq(True).all())
        audit.append(dict(origin=o,complete=complete,target_paired_hours=int(g.paired.sum()),history_valid_hours=int(h.power_valid.eq(True).sum())))
        if not complete:continue
        np.testing.assert_array_equal(g.lead,np.arange(1,25))
        assert (g.archive_time<=o).all() and (g.cycle<o).all()
        rows.append((o,h.power_pu.to_numpy(),g.power_pu.to_numpy(),g[['u100','v100']].to_numpy()))
    pd.DataFrame(audit).to_csv(OUT/'sample_audit.csv',index=False)
    assert rows
    origins,h,y,wind=zip(*rows);y=np.asarray(y);h=np.asarray(h)
    assert y.min()>=-.01 and y.max()<=1.05,'Unexpected target extremes require source quality review before scoring'
    write(OUT/'sample_counts.json',dict(issued=365,eligible_issues_after_Jan1_boundary=364,days=len(rows),
        first_origin=str(origins[0]),last_origin=str(origins[-1]),raw_power_min=float(y.min()),raw_power_max=float(y.max()),
        clipped_target_hours=int(((y<0)|(y>1)).sum()),clipped_history_hours=int(((h<0)|(h>1)).sum())))
    return dict(history=np.clip(h,0,1),y=np.clip(y,0,1),nwp=np.asarray(wind),
        origins=pd.DatetimeIndex(origins).tz_convert(None).to_numpy(),
        meta=pd.DataFrame(dict(nwp_age_hours=np.full(len(y),6))))


def evaluate(name,r,frozen):
    folder=OUT/name;folder.mkdir(exist_ok=True)
    retrospective=experiment.calibrations(r)
    frame=pd.concat([experiment.daily(r,retrospective,'retrospective_same_fpr'),
                     experiment.daily(r,frozen,'frozen_december')],ignore_index=True)
    summary=experiment.summarize(frame)
    frame.to_csv(folder/'daily.csv',index=False);summary.to_csv(folder/'summary.csv')
    ci=pd.concat([experiment.bootstrap(frame,b) for b in (7,14,28)],ignore_index=True)
    ci.to_csv(folder/'paired_blocks.csv',index=False)
    write(folder/'retrospective_cutoffs.json',retrospective)
    a=summary.xs(('retrospective_same_fpr','all'))
    assert a['false'].nunique()==1 and a.events.nunique()==1
    print('INDEPENDENT',name,'events',int(a.events.iloc[0]),'same_false',int(a['false'].iloc[0]),'hits',a.hits.astype(int).to_dict(),flush=True)
    return summary,ci


def recall_ci(ci,ref,operation='retrospective_same_fpr',block=14):
    return ci[(ci.operation==operation)&(ci.scope=='all')&(ci.metric=='recall')&(ci.block==block)&(ci.contrast==f'D_vs_{ref}')].iloc[0]


def main():
    verify_frozen_chain()
    assert json.loads((experiment.OUT/'decision.json').read_text())['selected']=='D'
    assert (OUT/'data_complete.json').exists()
    frozen=json.loads((experiment.OUT/'thresholds.json').read_text())['cutoffs']
    forest,imp,_=models()
    q90=joblib.load(COVERAGE/'annual.joblib')
    old=joblib.load(experiment.ROOT/'out_kelmarsh_ramp_probability'/'classifier.joblib')
    trained={name:joblib.load(experiment.OUT/f'{name}.joblib') for name in ('point','context')}
    data=read();r=experiment.make_scores(data,forest,imp,q90,old,trained)
    np.savez_compressed(OUT/'scores.npz',**{k:r[k] for k in ('origins','actual','base','same','near','eligible','q90','old','point','context','tie')})
    m,ci=evaluate('all',r,frozen)
    seasonal={}
    for name,months in {'winter_DJF':(1,2,12),'spring_MAM':(3,4,5),'summer_JJA':(6,7,8),'autumn_SON':(9,10,11)}.items():
        seasonal[name]=evaluate(name,subset(r,months),frozen)
    matched=m.xs(('retrospective_same_fpr','all'));fixed=m.xs(('frozen_december','all'))
    checks=dict(equal_fpr_recall_ci_above_all_three=bool(all(recall_ci(ci,ref).low>0 for ref in ('A','QRF','q90_frozen'))),
        frozen_recall_not_lower_than_A_or_q90=bool(all(fixed.loc['D','recall']>=fixed.loc[ref,'recall'] for ref in ('A','q90_frozen'))),
        frozen_quiet_fpr_not_above_QRF=bool(fixed.loc['D','quiet_fpr']<=fixed.loc['QRF','quiet_fpr']),
        full_season_no_point_loss_beyond5pp_vs_q90=bool(all(recall_ci(v[1],'q90_frozen').delta>=-.05 for v in seasonal.values())))
    decision=dict(candidate='D',checks=checks,passed=all(checks.values()),
        selection_changed=False,scope='zero-shot Hill of Towie T01–T06,2025,13.8MW; no target used for fitting or threshold selection',
        interpretation='ranking diagnostics and frozen operating rules separated; interval endpoints unchanged')
    write(OUT/'decision.json',decision)
    verify_frozen_chain()
    write(OUT/'verification.json',dict(status='pass',no_model_fit=True,no_threshold_fit_for_frozen_operation=True,
        preselected_candidate_unchanged=True,common_dates_and_event_denominator=True,same_retrospective_false_budget=True,
        source_hour_end_clock_used=True,source_archive_times_checked=True,protocol_hashes_rechecked=True))
    write(OUT/'completion.json',dict(status='complete',passed=decision['passed']))
    parent_decision=json.loads((experiment.OUT/'decision.json').read_text(encoding='utf-8'))
    parent_decision['independent_status']='complete: '+('passed' if decision['passed'] else 'failed')+'; see independent_hill_of_towie/decision.json'
    write(experiment.OUT/'decision.json',parent_decision)
    parent=json.loads((experiment.OUT/'completion.json').read_text())
    parent.update(status='complete',independent_run=True,independent_passed=decision['passed'],reason='development and new site/year validation completed')
    write(experiment.OUT/'completion.json',parent)
    print('INDEPENDENT DECISION',json.dumps(decision),flush=True)


if __name__=='__main__':
    if '--verify-existing' in sys.argv:verify_existing()
    else:main()
