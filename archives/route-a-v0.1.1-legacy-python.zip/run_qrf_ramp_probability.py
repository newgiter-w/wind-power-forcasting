"""Train hourly ramp probabilities and compare with the original QRF score."""
from run_qrf_power_increment import BASE, ROOT, cells, feature_array, increments, index, load_farms, frozen_spec, write
from run_qrf_speed_delta import added_features
from report_qrf_speed_delta import table
from gefcom_protocol_v2 import PKG
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import average_precision_score, roc_curve, roc_auc_score, brier_score_loss
import joblib
import numpy as np
import pandas as pd

OUT = ROOT/'out_gefcom_ramp_probability_20261106'
BUDGET = .05
SCORES = ('qrf_score','probability')
GROUPS = ('all','signal')


def fit_predictions(year):
    frames = []
    for farm,d in load_farms(year).items():
        folder = OUT/f'gefcom{year}/farm_{farm:02}'
        folder.mkdir(parents=True,exist_ok=True)
        x = feature_array(year,farm,'QRF')
        tr = index(d,'train',True)
        truth = increments(d['y'],d['history'])>.1
        model = HistGradientBoostingClassifier(**PKG).fit(x[cells(tr)],truth[tr].ravel())
        joblib.dump(model,folder/'classifier.joblib',compress=1)
        saved = joblib.load(folder/'classifier.joblib')
        wind = added_features(feature_array(year,farm,'GBM'))[:,0].reshape(-1,24)
        with np.load(BASE/f'gefcom{year}/farm_{farm:02}/heads.npz') as z:
            np.testing.assert_array_equal(z['origins'],d['origins'])
            qrf = increments(z['qrf'],d['history'])
        for stage in ('validation','evaluation'):
            days = index(d,stage,True)
            assert d['ends'][tr].max() <= d['origins'][days].min()
            query = x[cells(days)]
            probability = model.predict_proba(query)[:,1]
            np.testing.assert_array_equal(probability,saved.predict_proba(query)[:,1])
            assert np.isfinite(probability).all() and np.isfinite(qrf[days]).all()
            frames.append(pd.DataFrame(dict(year=year,farm=farm,stage=stage,
                origin=np.repeat(d['origins'][days],24),lead=np.tile(np.arange(1,25),len(days)),
                event=truth[days].ravel(),wind_delta=wind[days].ravel(),
                qrf_score=qrf[days].ravel(),probability=probability)))
    return pd.concat(frames,ignore_index=True)


def subset(frame, group):
    return frame if group=='all' else frame[frame.wind_delta>=.5]


def threshold(frame, score):
    negatives = np.sort(frame.loc[~frame.event,score].to_numpy())[::-1]
    # Strict comparison keeps complete ties below the cap.
    return float(negatives[int(np.floor(BUDGET*len(negatives)))])


def rates(frame, score, cutoff):
    y = frame.event.to_numpy()
    alert = frame[score].to_numpy()>cutoff
    tp,fp = int((alert&y).sum()),int((alert&~y).sum())
    return dict(TP=tp,FP=fp,P=int(y.sum()),N=int((~y).sum()),
                recall=tp/y.sum(),FPR=fp/(~y).sum(),precision=tp/max(1,tp+fp))


def matched_recall(y, score):
    # Linear interpolation between attainable ROC points is a descriptive
    # matched-budget estimate, equivalent to mixing adjacent policies.
    fpr,tpr,_ = roc_curve(y,score,drop_intermediate=False)
    unique,first = np.unique(fpr,return_index=True)
    last = np.r_[first[1:]-1,len(fpr)-1]
    pos = np.searchsorted(unique,BUDGET,side='right')-1
    lo,hi = last[pos],first[pos+1]
    return float(tpr[lo]+(BUDGET-fpr[lo])/(fpr[hi]-fpr[lo])*(tpr[hi]-tpr[lo]))


def bootstrap(frame,year):
    dates = pd.date_range(frame.origin.min(),frame.origin.max())
    dates_index = dates.get_indexer(frame.origin)
    assert (dates_index>=0).all()
    rows_by_date = [np.flatnonzero(dates_index==i) for i in range(len(dates))]
    y=frame.event.to_numpy()
    a,b=(frame[s].to_numpy() for s in SCORES)
    rng=np.random.default_rng(20261106+year)
    diffs=[]
    for _ in range(1000):
        starts=rng.integers(0,len(dates)-13,size=int(np.ceil(len(dates)/14)))
        days=(starts[:,None]+np.arange(14)).ravel()[:len(dates)]
        ix=np.concatenate([rows_by_date[i] for i in days])
        diffs.append(matched_recall(y[ix],b[ix])-matched_recall(y[ix],a[ix]))
    return [float(v) for v in np.quantile(diffs,[.025,.975])]


def main():
    frozen_spec(OUT/'protocol.json',dict(classifier=PKG, budget=BUDGET,
        target='hourly increment strictly greater than 0.10 of capacity',
        features='saved original QRF R2 input matrix, proper training only',
        baseline='original QRF median difference as continuous score',
        threshold='separate pooled dataset and group cutoffs on Q2, strict greater than cutoff; frozen for evaluation',
        signal='same issue NWP wind-speed rise >=0.5 m/s, leads 2 through 24',
        equal_fpr='evaluation ROC interpolation at 5%, descriptive only',
        ci='paired synchronous 14 calendar day moving blocks, 1000 draws',
        decision='candidate for a separate upper-bound trial only if both datasets show positive matched-FPR recall gain with 95% interval above zero in signal group, and frozen signal operating point improves recall without increasing FPR by more than 0.5pp versus baseline'))
    result, ranking, quiet, thresholds = [],[],[],[]
    for year in (2014,2012):
        data=fit_predictions(year)
        dev=data[data.stage=='validation']
        ev=data[data.stage=='evaluation']
        for group in GROUPS:
            v,e=subset(dev,group),subset(ev,group)
            for score in SCORES:
                cutoff=threshold(v,score)
                assert rates(v,score,cutoff)['FPR']<=BUDGET
                thresholds.append(dict(year=year,group=group,score=score,cutoff=cutoff))
                pd.DataFrame(thresholds).to_csv(OUT/'frozen_thresholds.csv',index=False)
                for stage,frame in [('validation',v),('evaluation',e)]:
                    result.append(dict(year=year,group=group,score=score,stage=stage,cutoff=cutoff,
                                       **rates(frame,score,cutoff)))
                if group=='all':
                    q=ev[ev.wind_delta.abs()<.25]
                    quiet.append(dict(year=year,score=score,**rates(q,score,cutoff)))
            y=e.event.to_numpy()
            low,high=bootstrap(e,year)
            a,b=[matched_recall(y,e[s].to_numpy()) for s in SCORES]
            ranking.append(dict(year=year,group=group,events=int(y.sum()),hours=len(e),
                qrf_recall=a,prob_recall=b,gain=b-a,low=low,high=high,
                qrf_AP=average_precision_score(y,e.qrf_score),prob_AP=average_precision_score(y,e.probability),
                qrf_AUC=roc_auc_score(y,e.qrf_score),prob_AUC=roc_auc_score(y,e.probability),
                Brier=brier_score_loss(y,e.probability),prob_mean=e.probability.mean()))
        data.to_csv(OUT/f'{year}_paired_hours.csv',index=False)
        print('DONE',year,flush=True)
    metrics=pd.DataFrame(result)
    rank=pd.DataFrame(ranking)
    metrics.to_csv(OUT/'frozen_operating_points.csv',index=False)
    rank.to_csv(OUT/'matched_fpr.csv',index=False)
    pd.DataFrame(quiet).to_csv(OUT/'quiet_nwp.csv',index=False)
    gates={}
    for year in (2014,2012):
        a,b=metrics.query("year==@year and group=='signal' and stage=='evaluation'").itertuples(index=False)
        row=rank.query("year==@year and group=='signal'").iloc[0]
        gates[str(year)]=bool(row.low>0 and b.recall>a.recall and b.FPR<=a.FPR+.005)
    write(OUT/'completion.json',dict(status='complete',farms=17,gate=gates,
        eligible_for_upper_bound_trial=all(gates.values())))
    print(rank.to_string(index=False))
    print(metrics.to_string(index=False))
    print('GATE',gates)


if __name__=='__main__':
    main()
