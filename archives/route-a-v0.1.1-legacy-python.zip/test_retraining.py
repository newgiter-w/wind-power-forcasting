"""Leakage and model-transition checks for monthly refitting."""
import copy
import unittest
import numpy as np
import pandas as pd
from retraining_common import split_month
from online_calibration import simulate


def toy():
    origins=pd.date_range('2010-01-01','2013-12-31').to_numpy()
    rng=np.random.default_rng(12)
    return dict(origins=origins,ends=origins+np.timedelta64(24,'h'),valid=np.ones(len(origins),bool),
        y=rng.uniform(size=(len(origins),24)),meta=pd.DataFrame({'phase':np.where(origins<np.datetime64('2012-01-01'),'train','evaluation')}))


class RetrainingChecks(unittest.TestCase):
    def test_disjoint_arrived_windows(self):
        d=toy();tr,ca,sc=split_month(d,'2013-07','expanding')
        self.assertLessEqual(d['ends'][tr].max(),np.datetime64('2013-04-08'))
        self.assertEqual(len(ca),84)
        self.assertEqual(d['origins'][sc[0]],np.datetime64('2013-07-01'))
        self.assertEqual(d['ends'][ca[-1]],np.datetime64('2013-07-01'))
        self.assertFalse(np.intersect1d(tr,ca).size)

    def test_365_days_not_365_unrelated_rows(self):
        d=toy();tr,ca,sc=split_month(d,'2013-07','rolling365')
        self.assertEqual(len(tr),365)
        d['valid'][tr[2]]=False
        tr2,_,_=split_month(d,'2013-07','rolling365')
        self.assertEqual(len(tr2),364)

    def test_unarrived_labels_cannot_enter_fit(self):
        d=toy();tr,ca,sc=split_month(d,'2013-07','expanding');changed=copy.deepcopy(d)
        changed['y'][ca]=999;changed['y'][sc]=999
        tr2,_,_=split_month(changed,'2013-07','expanding')
        np.testing.assert_equal(d['y'][tr],changed['y'][tr2])

    def test_frozen_monthly_reset_equals_continuous_rolling(self):
        d=toy();lo=np.full_like(d['y'],.1);hi=np.full_like(lo,.9)
        _,ca,july=split_month(d,'2013-07','expanding');_,_,aug=split_month(d,'2013-08','expanding')
        full=simulate(d['origins'],d['ends'],d['y'],lo,hi,d['valid'],ca,np.r_[july,aug],'rolling',84)
        for month,ix in [('2013-07',slice(0,len(july))),('2013-08',slice(len(july),None))]:
            _,seed,score=split_month(d,month,'expanding')
            part=simulate(d['origins'],d['ends'],d['y'],lo,hi,d['valid'],seed,score,'rolling',84)
            np.testing.assert_equal(part['lo'],full['lo'][ix]);np.testing.assert_equal(part['hi'],full['hi'][ix])

    def test_current_month_future_values_do_not_change_first_interval(self):
        d=toy();_,ca,sc=split_month(d,'2013-07','expanding');lo=np.full_like(d['y'],.1);hi=np.full_like(lo,.9)
        a=simulate(d['origins'],d['ends'],d['y'],lo,hi,d['valid'],ca,sc,'rolling',84)
        changed=d['y'].copy();changed[sc]=100
        b=simulate(d['origins'],d['ends'],changed,lo,hi,d['valid'],ca,sc,'rolling',84)
        np.testing.assert_equal(a['lo'][0],b['lo'][0]);np.testing.assert_equal(a['hi'][0],b['hi'][0])


if __name__=='__main__':unittest.main()
