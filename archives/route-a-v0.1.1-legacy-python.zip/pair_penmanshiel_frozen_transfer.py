"""Acquire a preselected new-site cohort without fitting or selecting on outcomes."""
from pathlib import Path
import numpy as np
import pandas as pd

from pair_kelmarsh_gfs import fetch_weather
from kelmarsh import read_turbine
from revision_common import frozen_spec, write

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_penmanshiel_frozen_transfer'
SOURCE=ROOT.parent/'wind_datasets'/'penmanshiel'
TURBINES=(11,12,13,14,15)
CAPACITY=10250
MONTHS=tuple(f'2024-{m:02}' for m in range(2,13))


def scada():
    cache=OUT/'scada_hourly_2024.csv'
    if cache.exists():
        return pd.read_csv(cache,parse_dates=['target']).set_index('target')
    frames=[]
    quality=[]
    for t in TURBINES:
        paths=list((SOURCE/'extracted').glob(f'Penmanshiel_SCADA_2024_WT_11-15_*/Turbine_Data_Penmanshiel_{t}_*.csv'))
        assert len(paths)==1
        d=read_turbine(str(paths[0]))[['timestamp','power','wind_speed']]
        d['timestamp']=d.timestamp.dt.tz_localize('UTC')
        d=d[d.timestamp.ge('2024-01-01')&d.timestamp.lt('2025-01-01')].copy()
        grid=d.timestamp.eq(d.timestamp.dt.floor('10min'))
        off=int((~grid).sum())
        d=d[grid]
        dupe=d.timestamp.duplicated(keep=False)
        grouped=d.loc[dupe].groupby('timestamp')[['power','wind_speed']]
        lo,hi=grouped.min(),grouped.max()
        conflict=lo.ne(hi)&lo.notna()&hi.notna()
        one=lo.mask(conflict).reset_index()
        rows=int(dupe.sum())
        d=pd.concat([d.loc[~dupe],one],ignore_index=True)
        assert not d.timestamp.duplicated().any()
        quality.append(dict(turbine=t,duplicates=rows,off_grid=off,
            power_conflict=int(conflict.power.sum()),wind_conflict=int(conflict.wind_speed.sum())))
        d['turbine']=t
        frames.append(d)
        print('SCADA',t,flush=True)
    a=pd.concat(frames,ignore_index=True)
    a.loc[~np.isfinite(a.power),'power']=np.nan
    a.loc[~np.isfinite(a.wind_speed)|(a.wind_speed<0),'wind_speed']=np.nan
    a['target']=a.timestamp.dt.floor('h')+pd.Timedelta(hours=1)
    h=a.groupby('target').agg(total=('power','sum'),power_count=('power','count'),
        wind_speed=('wind_speed','mean'),wind_count=('wind_speed','count'))
    h=h.reindex(pd.date_range('2024-01-01T01:00Z','2025-01-01T00:00Z',freq='h'))
    h.index.name='target'
    h['power_valid']=h.power_count.eq(30)
    h['wind_valid']=h.wind_count.eq(30)
    h['power_pu']=(h.total/6/CAPACITY).where(h.power_valid)
    h['wind_speed']=h.wind_speed.where(h.wind_valid)
    h=h.drop(columns='total')
    h.to_csv(cache)
    pd.DataFrame(quality).to_csv(OUT/'scada_quality.csv',index=False)
    return h


def weather(m):
    folder=OUT/m
    folder.mkdir(exist_ok=True)
    cache=folder/'gfs_hourly.csv'
    if cache.exists():
        return
    static=pd.read_csv(SOURCE/'Penmanshiel_WT_static.csv').dropna(subset=['Title'])
    static=static[static.Title.isin([f'Penmanshiel {t:02}' for t in TURBINES])]
    assert len(static)==5 and static['Rated power (kW)'].sum()==CAPACITY
    first=pd.Timestamp(m+'-01',tz='UTC')
    origins=pd.date_range(first,first+pd.offsets.MonthBegin(),inclusive='left',freq='D')
    fetch_weather(origins,static.Latitude.mean(),static.Longitude.mean()).to_csv(cache,index=False)
    print('WEATHER',m,flush=True)


def pair(m,measure):
    folder=OUT/m
    a=pd.read_csv(folder/'gfs_hourly.csv',parse_dates=['origin','target','cycle','archive_time'])
    np.testing.assert_array_equal(a.target,a.origin+pd.to_timedelta(a.lead,unit='h'))
    np.testing.assert_array_equal(a.target,a.cycle+pd.to_timedelta(a.native_lead,unit='h'))
    a=a.merge(measure.reset_index(),on='target',validate='one_to_one')
    a['paired']=a.decoded&a.available&a.power_valid&a.wind_valid
    a.to_csv(folder/'paired_hourly.csv',index=False)
    audit=a.groupby('origin').agg(forecast_hours=('decoded','sum'),available_hours=('available','sum'),
        paired_hours=('paired','sum'),power_hours=('power_valid','sum'),wind_hours=('wind_valid','sum'))
    audit['history_complete']=[measure.reindex(pd.date_range(o-pd.Timedelta(hours=23),o,freq='h')).power_valid.eq(True).all()
                              for o in audit.index]
    audit.to_csv(folder/'issue_audit.csv')
    write(folder/'completion.json',dict(days=len(audit),full_days=int((audit.paired_hours.eq(24)&audit.history_complete).sum()),
        forecast_hours=int(a.decoded.sum()),available_hours=int(a.available.sum()),paired_hours=int(a.paired.sum())))
    print('PAIRED',m,flush=True)


def main():
    frozen_spec(OUT/'data_protocol.json',dict(site='Penmanshiel fixed turbines 11–15, not whole farm',capacity_kw=CAPACITY,
        turbines=list(TURBINES),months=list(MONTHS),selection='cohort and dates fixed from file availability before reading target outcomes',
        clock='00UTC, prior18UTC GFS leads7–30; source GRIB LastModified availability proxy',
        scada='UTC hour-ending target, assume start-labeled 10-minute rows; require 5 turbines x6 values; same duplicate handling as Kelmarsh',
        sample='complete24 target+history days, both observed fields complete, [0,1] power clip later in evaluation'))
    # Fetch only metadata and forecasts before the new-site target is read.
    for m in MONTHS:
        weather(m)
    measured=scada()
    for m in MONTHS:
        pair(m,measured)
    write(OUT/'data_complete.json',dict(status='complete'))


if __name__=='__main__':
    main()
