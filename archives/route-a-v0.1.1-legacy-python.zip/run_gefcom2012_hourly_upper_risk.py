"""Chronological risk-ranking test without changing any QRF endpoints."""
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist

from run_gefcom2012_retrieval_screen import YEAR, ROOT, BASE, K, SEEDS, representation
from run_point_residual import load_farms, feature_array, index
from pooling_common import local_heads
from revision_common import calibration, frozen_spec, write

OUT = ROOT/'out_gefcom2012_hourly_upper_risk'
METHODS = ('local','whole_day','simple',*(f'random_{s}' for s in SEEDS))
STAGES = ('validation','evaluation')
COUNT = ('hours','marked','events','hits','quiet','quiet_marked','severity','severity_hit')


def load_stage(farm, d):
    base = BASE/f'gefcom2012/farm_{farm:02}'
    raw = local_heads(YEAR,farm,'QRF',0)
    records = {}
    with np.load(base/'heads.npz') as z:
        np.testing.assert_array_equal(z['origins'],d['origins'])
        median = z['qrf']
    wind = feature_array(YEAR,farm,'GBM')[:, -14:-12].reshape(-1,24,2)
    for stage in STAGES:
        ids, result = calibration(d,*raw,stage)
        lo,hi = np.clip([result['lo'],result['hi']],0,1)
        with np.load(base/f'{stage}_direct_qrf.npz') as z:
            for a,b in ((ids,z['ids']),(lo,z['lo']),(hi,z['hi'])):
                np.testing.assert_array_equal(a,b)
        assert np.isfinite(median[ids]).all()
        assert (result['max_label_end_used']<=d['origins'][ids]).all()
        records[stage] = (ids,hi)
    return wind,median,records


def inputs(wind, median, upper, last):
    speed = np.linalg.norm(wind,axis=2)
    dw = np.diff(speed,axis=1,prepend=speed[:,:1])
    direction = wind/np.maximum(speed[...,None],1.)
    turn = np.linalg.norm(np.diff(direction,axis=1,prepend=direction[:,:1]),axis=2)
    slope = np.diff(median,axis=1,prepend=last[:,None])
    room = np.maximum(upper-median,0)
    local = []
    simple = np.empty_like(speed)
    for h in range(24):
        window = slice(max(0,h-2),min(24,h+3))
        weather = np.stack([speed[:,window]/2,dw[:,window],turn[:,window]/.5],axis=2)
        power = slope[:,window]/.10
        local.append(np.column_stack([weather.reshape(len(wind),-1)/np.sqrt(weather.shape[1]*3),
            power/np.sqrt(power.shape[1]),room[:,h]/.15]))
        simple[:,h] = np.maximum(dw[:,window].max(axis=1),0)-room[:,h]/.15
    return local,simple


def neighbor_scores(ids, d, events, local_x, whole_distance, simple, farm, stage):
    n = len(ids)
    n_dev = len(index(d,'validation'))
    n_eval = len(index(d,'evaluation'))
    start, stop = (0,n_dev) if stage == 'validation' else (n_dev,n_dev+n_eval)
    distance = [cdist(x[start:stop],x) for x in local_x]
    scores = np.broadcast_to(simple[start:stop],(len(METHODS),stop-start,24)).copy()
    rng = [np.random.default_rng(100*farm+s) for s in SEEDS]
    support = np.zeros(stop-start,dtype=int)
    ages_used = np.full((stop-start,24,K),-1,dtype=np.int16)
    for row, pos in enumerate(range(start,stop)):
        day = ids[pos]
        previous = ids[:pos]
        age = (d['origins'][day]-d['ends'][previous])/np.timedelta64(1,'D')
        allowed = (age>=0)&(age<84)&d['valid'][previous]
        pool = np.flatnonzero(allowed)
        support[row] = len(pool)
        if len(pool)<K:
            continue
        assert (d['ends'][ids[pool]]<=d['origins'][day]).all() and (pool<pos).all()
        bins = (age[pool]//21).astype(int)
        past_events = events[pool]
        prior = (past_events.sum(axis=0)+1)/(len(pool)+2)
        whole = np.argsort(whole_distance[day,ids[pool]],kind='stable')[:K]
        scores[1,row] = (past_events[whole].sum(axis=0)+K*prior)/(2*K)
        for h in range(24):
            nearest = np.argsort(distance[h][row,pool],kind='stable')[:K]
            ages_used[row,h] = pool[nearest]
            scores[0,row,h] = (past_events[nearest,h].sum()+K*prior[h])/(2*K)
            age_bins, counts = np.unique(bins[nearest],return_counts=True)
            choices = [np.flatnonzero(bins==b) for b in age_bins]
            for j, gen in enumerate(rng,3):
                chosen = np.concatenate([gen.choice(c,size=k,replace=False) for c,k in zip(choices,counts)])
                assert np.array_equal(np.sort(bins[chosen]),np.sort(bins[nearest]))
                scores[j,row,h] = (past_events[chosen,h].sum()+K*prior[h])/(2*K)
    assert np.isfinite(scores).all()
    return scores,support,ages_used


def farm_scores(farm, d):
    wind,median,records = load_stage(farm,d)
    ids = np.concatenate([records[s][0] for s in STAGES])
    assert (np.diff(d['origins'][ids])>np.timedelta64(0,'h')).all()
    upper = np.concatenate([records[s][1] for s in STAGES])
    last = d['history'][ids,-1]
    actual = d['y'][ids]
    dy = np.diff(actual,axis=1,prepend=last[:,None])
    events = (dy>.10)&(actual>upper)
    quiet = np.abs(dy)<=.05
    severity = np.where(events,actual-upper,0.)
    local,simple = inputs(wind[ids],median[ids],upper,last)
    whole_distance,_ = representation(d,farm)
    output = []
    for stage in STAGES:
        stage_ids = records[stage][0]
        positions = np.searchsorted(ids,stage_ids)
        scores,support,neighbors = neighbor_scores(ids,d,events,local,whole_distance,simple,farm,stage)
        # Fixed issuance-time budget: 12 slots every five forecast days.
        budget = np.diff(np.arange(len(stage_ids)+1)*12//5)
        order = np.argsort(-scores,axis=2,kind='stable')
        marked = np.zeros_like(scores,dtype=bool)
        np.put_along_axis(marked,order,np.broadcast_to(np.arange(24)<budget[:,None],scores.shape),axis=2)
        np.testing.assert_array_equal(marked.sum(axis=2),np.broadcast_to(budget,scores.shape[:2]))
        valid = d['valid'][stage_ids]
        ev,q,sev = events[positions],quiet[positions],severity[positions]
        folder = OUT/f'farm_{farm:02}'
        folder.mkdir(exist_ok=True)
        np.savez_compressed(folder/f'{stage}.npz', ids=stage_ids, origins=d['origins'][stage_ids],
            history_ids=ids, methods=METHODS, score=scores, marked=marked, events=ev, quiet=q,
            support=support, neighbors=neighbors, valid=valid)
        for j,method in enumerate(METHODS):
            keep = marked[j]
            daily = np.column_stack([np.full(len(keep),24),keep.sum(axis=1),ev.sum(axis=1),(keep&ev).sum(axis=1),
                q.sum(axis=1),(keep&q).sum(axis=1),sev.sum(axis=1),np.where(keep,sev,0).sum(axis=1)])
            frame = pd.DataFrame(daily[valid],columns=COUNT).assign(
                origin=d['origins'][stage_ids][valid],stage=stage,farm=farm,method=method,
                retrieval_available=(support>=K)[valid])
            output.append(frame)
    return output


def rates(values):
    _,marked,events,hits,quiet,quiet_marked,severity,severity_hit = np.moveaxis(values,-1,0)
    return np.stack([hits/events,quiet_marked/quiet,hits/marked,severity_hit/severity],axis=-1)


def report(frame):
    keys = ['stage','origin','farm','retrieval_available']
    random = (frame[frame.method.str.startswith('random_')].groupby(keys,as_index=False)[list(COUNT)]
              .mean().assign(method='random_mean'))
    frame = pd.concat([frame,random],ignore_index=True)
    frame.to_csv(OUT/'daily.csv',index=False)
    metrics = ['recall','quiet_false_mark','precision','severity_capture']
    totals = frame.groupby(['stage','method'])[list(COUNT)].sum()
    result = totals.join(pd.DataFrame(rates(totals.to_numpy()),index=totals.index,columns=metrics))
    result.to_csv(OUT/'summary.csv')
    frame.groupby(['stage','farm','method'])[list(COUNT)].sum().to_csv(OUT/'per_farm.csv')
    eval_frame = frame.query("stage=='evaluation'")
    dates = pd.date_range(eval_frame.origin.min(),eval_frame.origin.max())
    names = ('local','whole_day','random_mean','simple')
    cube = np.stack([eval_frame[eval_frame.method.eq(m)].groupby('origin')[list(COUNT)].sum()
                    .reindex(dates,fill_value=0).to_numpy() for m in names])
    rng = np.random.default_rng(20261106)
    n = len(dates)
    start = rng.integers(0,n-13,size=(2000,int(np.ceil(n/14))))
    take = (start[:,:,None]+np.arange(14)).reshape(2000,-1)[:,:n]
    draws = rates(cube[:,take].sum(axis=2))
    point = rates(cube.sum(axis=1))
    ci = []
    for j,ref in enumerate(names[1:],1):
        lo,hi = np.quantile(draws[0]-draws[j],[.025,.975],axis=0)
        ci.extend(dict(reference=ref,metric=m,delta=x,low=l,high=h)
                  for m,x,l,h in zip(metrics,point[0]-point[j],lo,hi))
    pd.DataFrame(ci).to_csv(OUT/'paired_blocks.csv',index=False)
    dev = result.loc['validation']
    dev_pass = bool(all(dev.loc['local','recall']>dev.loc[r,'recall'] for r in names[1:]) and
                    dev.loc['local','quiet_false_mark']<=dev.loc['simple','quiet_false_mark']+.01)
    eval_pass = all(r['low']>0 for r in ci if r['metric']=='recall') and point[0,1]<=point[-1,1]+.01
    write(OUT/'completion.json',dict(status='complete',farms=7,dev_pass=dev_pass,
        eval_pass=bool(eval_pass),advance_to_upper_adjustment=bool(dev_pass and eval_pass)))
    print(result.loc[(slice(None),list(names)),:].round(5).to_string(),flush=True)
    print(pd.DataFrame(ci).round(5).to_string(index=False),flush=True)


def main():
    frozen_spec(OUT/'protocol.json',dict(farms=list(range(1,8)),base='frozen QRF500 signed rolling84; verify original endpoints',
        split='2011Q2 development and original 2011H2–2012H1 retrospective evaluation',
        event='actual hourly increment >0.10 and actual power > original upper; quiet abs(actual increment)<=0.05',
        budget='12 marks per five issued farm-days, 2–3 per day; descending score and earlier lead tie-break',
        library='same farm and lead; last 84 days; valid targets arrived by issuance; Q2 and subsequent arrived evaluation forecasts only, no Q1 because archived sample-out QRF median/calibrated upper unavailable for comparable search',
        ranking='K24 local ±2 lead window, equal blocks weather, QRF median slope, upper room; fixed physical scaling 2m/s, 1m/s, .5 direction chord, .10 power increment, .15 room; whole day existing retrieval representation; shrink rates 50% to smoothed simultaneous lead pool rate',
        random='same days, pool, lead, age-bin counts, shrinkage, fallback, five fixed seeds',
        simple='nonnegative maximum NWP speed increase within ±2 leads minus upper room / .15',
        fallback='all retrieval arms use simple score until 24 comparable historical dates arrive',
        selection='no fitted hyperparameters; development gate beats all on event recall and quiet false mark <= simple+1pp; require all evaluation recall-difference 95% lower bounds >0 and same quiet gate',
        inference='micro across hours, matched synchronous 14-calendar-day moving blocks, 2000 draws; random rates averaged across five policies'))
    farms = load_farms(YEAR)
    assert list(farms)==list(range(1,8))
    frames = []
    for farm,d in farms.items():
        frames.extend(farm_scores(farm,d))
        print('SCORED',farm,flush=True)
    report(pd.concat(frames,ignore_index=True))


if __name__ == '__main__':
    main()
