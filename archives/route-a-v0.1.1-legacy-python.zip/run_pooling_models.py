"""Within-dataset pooled GBM/MLP/QRF, with unchanged local controls."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='2'
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'.aris/qrf-packages'))
import argparse
import ctypes
import gc
import time
import joblib
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import torch
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import HistGradientBoostingRegressor
from quantile_forest import RandomForestQuantileRegressor
from sparse_leaf_qrf import SparseLeafQRF
from threadpoolctl import threadpool_limits
from gefcom_protocol_v2 import PKG
from run_dl_baseline import train_model,QuantileMLP
from pooling_common import OUT,write,pooled_data,evaluate_family,choose_pooling,save_family_metrics


def available_memory():
    class Memory(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(n,ctypes.c_ulonglong) for n in
            ['total','available','page_total','page_available','virtual_total','virtual_available','extended']]
    mem=Memory();mem.length=ctypes.sizeof(mem);ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem))
    return int(mem.available)


def qrf_memory_pilot(year,X,y,tm):
    folder=OUT/f'QRF/gefcom{year}';folder.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter()
    m=RandomForestQuantileRegressor(n_estimators=8,min_samples_leaf=10,max_features=1.,max_samples_leaf=None,
        random_state=0,n_jobs=8).fit(X[tm],y[tm])
    leaves=np.asarray(m.forest_.y_train_leaves)
    predicted=leaves.nbytes*500/8*1.5+700_000_000
    free=available_memory()
    result=dict(year=year,pilot_trees=8,train_cells=int(tm.sum()),shape=list(leaves.shape),
        pilot_leaf_bytes=leaves.nbytes,projected_full_bytes_with_margin=predicted,available_bytes=free,
        full_forest_allowed=bool(predicted<.75*free),elapsed_seconds=time.perf_counter()-start)
    write(folder/'memory_pilot.json',result);print('QRF memory pilot',result,flush=True)
    del m,leaves;gc.collect()
    return result


def fit_dataset(year,family,seeds,pilot_only=False):
    farms,X,y,tm,sm,fm,slices=pooled_data(year,family)
    folder=OUT/f'{family}/gefcom{year}';folder.mkdir(parents=True,exist_ok=True)
    contract=dict(train_rows=int(tm.sum()),stop_rows=int(sm.sum()),
        feature_columns=X.shape[1],farms=list(farms),equal_farm_training_counts=True,
        time_safety='all farms proper training ends <= first Q1 origin; no labels from Q1/Q2/H2 used for fit except MLP Q1 early stopping',
        inputs='own history/NWP plus one-hot ID; no other-farm contemporaneous or future power features')
    if not (folder/'training_contract.json').exists():write(folder/'training_contract.json',contract)
    if family=='QRF':
        if pilot_only:
            qrf_memory_pilot(year,X,y,tm);return
        import json
        assert json.loads((OUT/'sparse_qrf_equivalence.json').read_text())['status']=='passed'
        if not (folder/'backend.json').exists():
            write(folder/'backend.json',dict(storage='sparse all-bootstrap leaf responses',algorithm='same as full-response baseline',
                max_samples_leaf='unlimited; no sampling or truncation',witness=str(OUT/'sparse_qrf_equivalence.json')))
    for seed in seeds:
        sf=folder/f'seed_{seed}';sf.mkdir(exist_ok=True)
        if (sf/'fit.json').exists() and all((OUT/f'{family}/gefcom{year}/pooled/seed_{seed}/farm_{farm:02d}/heads.npz').exists() for farm in farms):
            print('reuse',family,year,seed,flush=True);continue
        began=time.perf_counter()
        if family.startswith('GBM'):
            sc=StandardScaler().fit(X[tm]);xx=sc.transform(X);models=[];pred=[]
            pkg=dict(PKG)
            if family=='GBM_budget':pkg['max_iter']=PKG['max_iter']*len(farms)
            for q in [.05,.95]:
                m=HistGradientBoostingRegressor(loss='quantile',quantile=q,**pkg).fit(xx[tm],y[tm])
                pred.append(m.predict(xx));models.append(m)
            prediction=np.column_stack(pred);joblib.dump(dict(models=models,scaler=sc),sf/'models.joblib',compress=3)
        elif family.startswith('MLP'):
            xx=X.astype('float32');pred=[]
            for q in [.05,.95]:
                if (sf/f'q{q:.2f}.pt').exists() and (sf/f'q{q:.2f}_trace.json').exists():
                    m=QuantileMLP(xx.shape[1]);m.load_state_dict(torch.load(sf/f'q{q:.2f}.pt',weights_only=True));m.eval()
                else:
                    m=train_model(xx[tm],y[tm],xx[sm],y[sm],q,seed=seed)
                    torch.save(m.state_dict(),sf/f'q{q:.2f}.pt');write(sf/f'q{q:.2f}_trace.json',m.fit_summary)
                with torch.no_grad():p=m(torch.tensor(xx)).numpy()
                pred.append(p)
            prediction=np.column_stack(pred)
        else:
            m=SparseLeafQRF(n_estimators=500,min_samples_leaf=10,random_state=seed,n_jobs=4).fit(X[tm],y[tm])
            prediction=np.full((len(X),2),np.nan);ids=np.flatnonzero(fm)
            for start in range(0,len(ids),128):
                ix=ids[start:start+128];prediction[ix]=m.predict(X[ix],quantiles=[.05,.95])
            joblib.dump(m,sf/'model.joblib',compress=3)
            del m;gc.collect()
        for farm,d in farms.items():
            dest=OUT/f'{family}/gefcom{year}/pooled/seed_{seed}/farm_{farm:02d}';dest.mkdir(parents=True,exist_ok=True)
            p=prediction[slices[farm]];lo=np.minimum(p[:,0],p[:,1]).reshape(-1,24);hi=np.maximum(p[:,0],p[:,1]).reshape(-1,24)
            np.savez_compressed(dest/'heads.npz',lo=lo,hi=hi,origins=d['origins'],crossings=int((p[:,0]>p[:,1]).sum()))
        write(sf/'fit.json',dict(year=year,family=family,seed=seed,train_rows=int(tm.sum()),features=X.shape[1],
            elapsed_seconds=time.perf_counter()-began,model_training='only proper-training rows; Q1 early stopping for MLP'))
        print('FIT COMPLETE',family,year,seed,f'{time.perf_counter()-began:.1f}s',flush=True)


def train_year(year,family,seeds,pilot_only=False):
    if family.startswith('GBM') or pilot_only:return fit_dataset(year,family,seeds,pilot_only)
    # Separate processes preserve each seed's Torch RNG; no shared-RNG thread training.
    fit_dataset(year,family,[])
    with ProcessPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(fit_dataset,year,family,[seed]) for seed in seeds]
        for future in futures:future.result()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--family',choices=['GBM','GBM_budget','MLP','MLP_global','QRF'],required=True)
    parser.add_argument('--pilot-only',action='store_true');args=parser.parse_args();family=args.family
    torch.set_num_threads(2);began=time.perf_counter();seeds=[0] if family.startswith('GBM') else [0,1,2]
    (OUT/family).mkdir(exist_ok=True)
    train_year(2014,family,seeds,args.pilot_only)
    if args.pilot_only:return
    rows=evaluate_family(2014,family,seeds,['validation']);choose_pooling(family,rows)
    rows+=evaluate_family(2014,family,seeds,['evaluation']);save_family_metrics(family,rows)
    train_year(2012,family,seeds)
    rows+=evaluate_family(2012,family,seeds,['validation','evaluation']);save_family_metrics(family,rows)
    write(OUT/f'{family}/completion.json',dict(status='complete',family=family,years=[2014,2012],seeds=seeds,
        elapsed_seconds=time.perf_counter()-began))


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
