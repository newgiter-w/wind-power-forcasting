"""Render the fixed-budget ramp experiment from its saved outputs."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from run_qrf_ramp_probability import OUT,BUDGET,GROUPS,SCORES,subset,table,roc_curve

def main():
    status=json.loads((OUT/'completion.json').read_text())
    assert status['status']=='complete'
    frozen=pd.read_csv(OUT/'frozen_operating_points.csv')
    matched=pd.read_csv(OUT/'matched_fpr.csv')
    rows,rank,quiet=[],[],[]
    labels=dict(qrf_score='原 QRF 中位数差',probability='上爬坡概率模型',all='全部时段',signal='NWP 上升信号')
    for a in frozen.itertuples():
        rows.append([a.year,labels[a.group],labels[a.score],a.stage,f'{a.cutoff:.5f}',
                     f'{100*a.FPR:.2f}',f'{100*a.recall:.2f}',f'{100*a.precision:.2f}',f'{a.TP}/{a.P}',f'{a.FP}/{a.N}'])
    for a in matched.itertuples():
        rank.append([a.year,labels[a.group],a.events,a.hours,f'{100*a.qrf_recall:.2f}',f'{100*a.prob_recall:.2f}',
                     f'{100*a.gain:+.2f}',f'[{100*a.low:+.2f}, {100*a.high:+.2f}]',f'{a.qrf_AP:.3f} / {a.prob_AP:.3f}'])
    for a in pd.read_csv(OUT/'quiet_nwp.csv').itertuples():
        quiet.append([a.year,labels[a.score],f'{100*a.FPR:.2f}',f'{a.FP}/{a.N}'])
    fig,axes=plt.subplots(2,2,figsize=(10,7),sharex=True,sharey=True,layout='constrained')
    for i,year in enumerate((2014,2012)):
        data=pd.read_csv(OUT/f'{year}_paired_hours.csv').query("stage=='evaluation'")
        for j,group in enumerate(GROUPS):
            ax=axes[i,j]
            e=subset(data,group)
            for score,color,name in zip(SCORES,['#52616e','#138574'],['Original QRF','Ramp probability']):
                fpr,tpr,_=roc_curve(e.event,e[score])
                ax.plot(fpr*100,tpr*100,color=color,label=name)
                r=frozen.query("year==@year and group==@group and score==@score and stage=='evaluation'").iloc[0]
                ax.scatter(100*r.FPR,100*r.recall,color=color,zorder=5)
            ax.axvline(100*BUDGET,ls='--',color='#888888')
            ax.set_title(f'GEFCom{year} · '+('All hours' if group=='all' else 'NWP wind-speed rise'))
            ax.set_xlim(0,15)
            ax.set_ylim(0,85)
            ax.grid(alpha=.2)
    axes[0,0].legend(fontsize=8,loc='lower right')
    fig.supxlabel('False-positive rate (%)')
    fig.supylabel('Recall (%)')
    fig.savefig(OUT/'low_fpr_roc.png',dpi=170)
    plt.close(fig)
    verdict='可以进入独立的区间上界对照' if status['eligible_for_upper_bound_trial'] else '本轮不支持进入区间上界对照'
    text=f"""# 上爬坡概率模型配对对照

**{verdict}。** 资格门槛要求两套数据在 NWP 上升信号组的 5% 同误报率召回增益，其配对 95% 区间均高于零，同时冻结阈值下召回提高且误报率至多比原 QRF 高 0.5 个百分点。逐数据门槛见 completion.json。

17 个风场分别训练固定配置的梯度提升树分类器。输入与原 QRF 相同。标签为单小时实测功率增幅严格大于装机容量的 10%，第 1 小时用发报时最后实测功率作为前值。原 QRF 的连续评分为相邻小时中位数之差。NWP 上升信号组要求同次发报风速至少上升 0.5 m/s，第 1 时效因没有窗内前值只计入全部时段。每个数据集和工况组各定一个阈值，所有场的验证样本合并计数，严格大于阈值才告警。两模型分别用各自的验证负例选阈值，预算为 5% FPR。概率输出来自分类器，未额外做概率校准。

{table(['数据','工况','方法','阶段','阈值','误报率%','召回率%','精确率%','检出/事件','误报/非事件'],rows)}

## 评价期同误报率

{table(['数据','工况','事件数','小时数','QRF 召回%','概率模型召回%','增益pp','95%配对区间','平均精确率 QRF / 概率模型'],rank)}

同误报率表由评价期 ROC 在 FPR=5% 处插值得出，用来比较排序能力。它使用评价标签计算曲线，与上表预先冻结的实际运行阈值分开。95% 区间由 1000 次同步跨场 14 日移动块重采样得到。比例按有效小时合并计数。评价期为既有回溯窗口，推断条件于固定拟合配置。

## 平稳 NWP 时段

使用全时段告警阈值，取同批风速变化绝对值小于 0.25 m/s 的时段。分母是该组实测未发生上爬坡的小时。

{table(['数据','方法','误报率%','误报/非事件'],quiet)}

![低误报区间 ROC](low_fpr_roc.png)

虚线是 5% 误报预算，圆点是验证阈值在评价期的实际运行点。所有保存分类器均已重载并逐点核对验证和评价概率。
"""
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')

if __name__=='__main__':
    main()
