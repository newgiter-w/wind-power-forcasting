"""Plot saved revision artifacts only; never train while plotting."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from revision_common import OUT, REFERENCE, ROOT, write


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--year',type=int,default=2014)
    parser.add_argument('--lower',type=float,default=.05);args=parser.parse_args()
    folder=ROOT/'paper/gefcom_nwp_interval/figures/revision_20261104';folder.mkdir(parents=True,exist_ok=True)
    label=f'MLP_q{args.lower:.2f}_signed'
    macro=pd.read_csv(OUT/'mlp/metrics_macro.csv')
    mlp=macro[(macro.year==args.year)&(macro.stage=='evaluation')&(macro.method==label)].groupby('group')[['coverage','width','IS']].mean()
    r2=pd.read_csv(REFERENCE/'evaluation_macro.csv')
    r2=r2[(r2.year==args.year)&(r2.method=='R2_shared_aug')].set_index('group')
    groups=['all','up_ramp','down_ramp','near_zero']
    fig,axes=plt.subplots(1,3,figsize=(13,4));source=[]
    for ax,metric,title in zip(axes,['coverage','width','IS'],['coverage (%)','width (% capacity)','interval score']):
        scale=100 if metric in ['width','coverage'] else 1
        x=np.arange(len(groups));rv=r2.loc[groups,metric].to_numpy()*scale;mv=mlp.loc[groups,metric].to_numpy()*scale
        ax.bar(x-.18,rv,.36,label='R2 factorial v2');ax.bar(x+.18,mv,.36,label='MLP 3-seed mean')
        ax.set_xticks(x,groups,rotation=20);ax.set_title(title);ax.grid(axis='y',alpha=.25)
        if metric=='coverage':ax.axhline(90,color='gray',ls='--',lw=.8)
        for g,r,m in zip(groups,rv,mv):source.append(dict(group=g,metric=metric,R2=r,MLP=m,scale=scale))
    handles,legend_labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,legend_labels,loc='upper center',ncol=2,fontsize=9)
    fig.tight_layout(rect=(0,0,1,.9));fig.savefig(folder/f'fig_dl_vs_gbm_{args.year}.png',dpi=160);plt.close(fig)
    pd.DataFrame(source).to_csv(folder/f'fig_dl_vs_gbm_{args.year}_data.csv',index=False)
    with np.load(OUT/f'mlp/gefcom{args.year}/farm_01/samples.npz') as z:
        y=z['y'];valid=z['valid'];origins=z['origins']
    with np.load(OUT/f'mlp/gefcom{args.year}/farm_01/seed_0/lower_{args.lower:.2f}/evaluation.npz') as z:
        ids=z['indices'];L=z['clipped_lo'];U=z['clipped_hi']
    with np.load(REFERENCE/f'gefcom{args.year}/farm_01/R2_shared_aug/evaluation.npz') as z:
        np.testing.assert_equal(ids,z['indices']);rl=np.clip(z['lo'],0,1);ru=np.clip(z['hi'],0,1)
    day=int(np.flatnonzero(valid[ids])[0]);x=np.arange(1,25)
    fig,ax=plt.subplots(figsize=(9,4))
    ax.fill_between(x,rl[day],ru[day],alpha=.25,label='R2 factorial v2')
    ax.fill_between(x,L[day],U[day],alpha=.3,label='MLP seed0')
    ax.plot(x,y[ids[day]],color='black',label='observed');ax.set(xlabel='lead (h)',ylabel='normalized power',
        title=f'{args.year} farm1, first valid evaluation origin: {str(origins[ids[day]])[:10]}')
    ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(folder/f'fig_dl_interval_{args.year}.png',dpi=160);plt.close(fig)
    write(folder/f'figure_sources_{args.year}.json',dict(lower_quantile=args.lower,
        bars='all 3 seeds; evaluation macro; same capacity units',interval_seed=0,
        origin=str(origins[ids[day]]),selection='first valid evaluation origin; no performance-based selection',
        MLP=str(OUT/'mlp'),R2=str(REFERENCE),training_performed=False))
    print('saved',folder)


if __name__=='__main__':main()
