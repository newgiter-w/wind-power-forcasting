"""Paired moving-calendar-block inference and explicit predeclared decision gates."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def calendar_blocks(dates, block_days, calendar_start=None, calendar_end=None):
    days = pd.DatetimeIndex(pd.to_datetime(dates, utc=True)).normalize()
    if len(days) < 2 or days.has_duplicates or not days.is_monotonic_increasing:
        raise ValueError("Expected at least two unique, ordered daily forecast origins")
    first = days[0] if calendar_start is None else pd.to_datetime(calendar_start, utc=True).normalize()
    last = days[-1] if calendar_end is None else pd.to_datetime(calendar_end, utc=True).normalize()
    if days[0] < first or days[-1] > last:
        raise ValueError("Observed dates fall outside the specified scoring calendar")
    n_days = int((last - first).days + 1)
    if not 1 <= block_days <= n_days:
        raise ValueError("Block length must fit the complete calendar span")
    return {"origin_positions": np.asarray((days - first).days, dtype=int),
            "n_days": n_days, "block_days": int(block_days),
            "first_day": str(first), "last_day": str(last)}


def paired_comparison(loss_r, loss_b, dates, block_days=7, n_resample=5000, seed=0,
                      calendar_start=None, calendar_end=None):
    r, b = np.asarray(loss_r, dtype=float), np.asarray(loss_b, dtype=float)
    if r.shape != b.shape or r.ndim != 1 or len(r) != len(dates):
        raise ValueError("Paired losses must match dated origins")
    if not np.isfinite(r).all() or not np.isfinite(b).all() or b.mean() <= 0:
        raise ValueError("Finite paired losses and positive baseline mean are required")
    blocks = calendar_blocks(dates, block_days, calendar_start, calendar_end)
    n = blocks["n_days"]
    rg, bg = np.full(n, np.nan), np.full(n, np.nan)
    rg[blocks["origin_positions"]] = r
    bg[blocks["origin_positions"]] = b
    rng = np.random.default_rng(seed)
    starts = rng.integers(0, n - block_days + 1,
                          size=(n_resample, int(np.ceil(n / block_days))))
    sampled_days = (starts[:, :, None] + np.arange(block_days)).reshape(n_resample, -1)[:, :n]
    mr = np.nanmean(rg[sampled_days], axis=1)
    mb = np.nanmean(bg[sampled_days], axis=1)
    if not np.isfinite(mr).all() or not np.isfinite(mb).all() or np.any(mb <= 0):
        raise ValueError("A bootstrap draw has no usable observations or a zero denominator")
    gains = 1.0 - mr / mb
    differences = mr - mb
    return {"gain": float(1.0 - r.mean() / b.mean()),
            "gain_ci95": np.quantile(gains, [.025, .975]).tolist(),
            "absolute_loss_difference": float((r - b).mean()),
            "difference_ci95": np.quantile(differences, [.025, .975]).tolist(),
            "candidate_IS": float(r.mean()), "baseline_IS": float(b.mean()),
            "block_days": block_days, "calendar_days": n, "valid_origins": len(r),
            "resamples": n_resample, "seed": seed,
            "method": "paired_moving_calendar_blocks_with_missing_days"}


def paired_bootstrap(loss_r, loss_b, blocks, n_resample=5000, seed=0):
    first = pd.Timestamp(blocks["first_day"])
    dates = first + pd.to_timedelta(blocks["origin_positions"], unit="D")
    result = paired_comparison(loss_r, loss_b, dates, blocks["block_days"], n_resample, seed,
                               blocks["first_day"], blocks["last_day"])
    return result["gain"], *result["gain_ci95"]


def classify_decision(primary, sensitivity, random_comparison, coverage, thresholds):
    delta = thresholds["min_relative_IS_improvement"]
    lower, upper = primary["gain_ci95"]
    cov_lo, cov_hi = thresholds["coverage_tolerance"]
    checks = {
        "gain_at_least_delta": primary["gain"] >= delta,
        "primary_lower_above_zero": lower > 0,
        "coverage_in_tolerance": cov_lo <= coverage <= cov_hi,
        "random_identity_evidence": (None if random_comparison is None else
                                     random_comparison["gain_ci95"][0] > 0),
        "sensitivity_lower_above_zero": sensitivity["gain_ci95"][0] > 0,
        "primary_interval_crosses_zero": lower <= 0 <= upper,
        "primary_allows_meaningful_gain": upper >= delta,
        "meaningful_gain_excluded_both_block_lengths":
            upper < delta and sensitivity["gain_ci95"][1] < delta,
    }
    if all(checks[k] is True for k in ("gain_at_least_delta", "primary_lower_above_zero",
                                      "coverage_in_tolerance", "random_identity_evidence",
                                      "sensitivity_lower_above_zero")):
        decision = "continue_conditioned_retrieval"
        reason = "All predeclared gain, coverage, identity and block-sensitivity gates passed"
    elif checks["meaningful_gain_excluded_both_block_lengths"]:
        decision = "stop_current_conditioning"
        reason = "Both block-length intervals exclude the prespecified useful improvement"
    else:
        decision = "insufficient_evidence"
        reason = "Useful improvement is not excluded and the complete continuation gates are not met"
    return {"decision": decision, "reason": reason, "checks": checks,
            "scope": "Current frozen candidates and this historical protocol; not all retrieval methods"}


def analyze_tasks(tasks, dates, B, R, random_names, thresholds, calendar_range=None):
    calendar_kwargs = {} if calendar_range is None else dict(
        calendar_start=calendar_range[0], calendar_end=calendar_range[1])
    for name, task in tasks.items():
        if "cqr_per_origin" in task and len(task["cqr_per_origin"]) != len(dates):
            raise ValueError(f"Mismatched loss count: {name}")
        if "origin_ids" in task:
            if not pd.DatetimeIndex(pd.to_datetime(task["origin_ids"], utc=True)).equals(
                    pd.DatetimeIndex(pd.to_datetime(dates, utc=True))):
                raise ValueError(f"Origin identity mismatch: {name}")
    comparisons = {}
    for length in (7, 14):
        comparisons[str(length)] = paired_comparison(
            tasks[R]["cqr_per_origin"], tasks[B]["cqr_per_origin"], dates, length, **calendar_kwargs)
    random_results = {}
    if random_names:
        for name in random_names:
            if tasks[name].get("package") != tasks[R].get("package"):
                raise ValueError("Selected retrieval and random controls must use the identical package")
        random_mean = np.mean([tasks[k]["cqr_per_origin"] for k in random_names], axis=0)
        for length in (7, 14):
            random_results[str(length)] = paired_comparison(
                tasks[R]["cqr_per_origin"], random_mean, dates, length, **calendar_kwargs)
    decision = classify_decision(comparisons["7"], comparisons["14"],
                                 random_results.get("7"), tasks[R]["cqr"]["coverage"], thresholds)
    return {"B": B, "R": R, "B_metrics": tasks[B]["cqr"], "R_metrics": tasks[R]["cqr"],
            "R_vs_B": comparisons, "R_vs_random_seed_mean": random_results,
            "random_names": random_names, "thresholds": thresholds, **decision,
            "inference_status": "Exploratory historical validation; no winner-selection correction"}


def render_analysis(result):
    names = {"continue_conditioned_retrieval": "通过本fold继续门槛，待独立确认",
             "stop_current_conditioning": "停止当前候选条件化主线",
             "insufficient_evidence": "证据不足"}
    lines = ["# 配对统计与决策", "", f"B={result['B']}；R={result['R']}。",
             f"判定：**{names[result['decision']]}**。", "",
             "| 对照 | 块长 | 相对IS改善 | 95%区间 |", "|---|---:|---:|---:|"]
    for label, key in (("R vs B", "R_vs_B"), ("R vs 匹配随机种子均值", "R_vs_random_seed_mean")):
        for length, comp in result[key].items():
            lo, hi = comp["gain_ci95"]
            lines.append(f"| {label} | {length}天 | {comp['gain']:.2%} | [{lo:.2%}, {hi:.2%}] |")
    lines += ["", f"B覆盖={result['B_metrics']['coverage']:.2%}；R覆盖={result['R_metrics']['coverage']:.2%}。",
              "", "子条件：", ""]
    for key, value in result["checks"].items():
        lines.append(f"- {key}: {value}")
    lines += ["", result["reason"], "", result["inference_status"],
              "", "统计停止不等于所有检索无效；点估计接近和区间跨零均不等于等价。"]
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="out_v3/b12_results.json")
    parser.add_argument("--out", default="out_v3/repair/statistics")
    args = parser.parse_args()
    from experiment import select_candidates, PACKAGES
    from config import Config
    from data import build_situations, load_dataframe
    from run import segment_split
    source = json.loads(Path(args.input).read_text(encoding="utf-8"))
    tasks = source["results"]["tasks"]
    B, R = select_candidates(tasks)
    cfg = Config(**source["config"])
    d = build_situations(load_dataframe(cfg), cfg)
    mask = segment_split(d["origin_ts"])["V_score"] & d["target_valid"]
    dates = d["origin_ts"][mask]
    package = R.rsplit("_", 1)[1]
    random_names = [k for k in tasks if "random" in k and k.endswith("_" + package)]
    for k, task in tasks.items():
        task.setdefault("package", PACKAGES[k.rsplit("_", 1)[1]])
    protocol = json.loads(Path("out_v3/protocol.json").read_text(encoding="utf-8"))
    result = analyze_tasks(tasks, dates, B, R, random_names, protocol["decision_thresholds"],
                           ("2021-04-01", "2021-06-30"))
    output = Path(args.out)
    output.mkdir(parents=True, exist_ok=True)
    (output / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "DECISION.md").write_text(render_analysis(result), encoding="utf-8")
    print(render_analysis(result))


if __name__ == "__main__":
    main()
