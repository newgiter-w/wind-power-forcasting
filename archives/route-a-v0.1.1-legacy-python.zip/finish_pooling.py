"""Wait for authorized local fits, then verify, plot and report once complete."""
from pathlib import Path
import json
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'out_gefcom_pooling_20261105'


def run(*args):
    print('RUN',*args,flush=True);subprocess.run([sys.executable,*args],cwd=ROOT,check=True)


def main():
    start=time.monotonic()
    logs={'GBM':'out_pooling_gbm_execution.log','GBM_budget':'out_pooling_gbm_budget_execution.log','MLP':'out_pooling_mlp_parallel_execution.log',
        'MLP_global':'out_pooling_mlp_global_execution.log','QRF':'out_pooling_qrf_parallel_execution.log'}
    while not all((OUT/family/'completion.json').exists() for family in logs):
        if time.monotonic()-start>7200:raise TimeoutError('Pooled fits did not finish within 2h; inspect per-family logs')
        for family,name in logs.items():
            text=(ROOT/name).read_text(encoding='utf-8',errors='replace')
            if 'Traceback (most recent call last)' in text[-5000:]:raise RuntimeError(f'{family} fit failed; inspect {name}')
        time.sleep(5)
    for family in logs:assert json.loads((OUT/family/'completion.json').read_text())['status']=='complete'
    run('verify_pooling_inputs.py')
    run('analyze_pooling.py')
    run('-m','unittest','test_pooling','test_revision_integrity','test_online_calibration','test_gefcom_tail_dynamic',
        'test_quantile_sort_factorial','test_gefcom_protocol_v2','-q')
    run('report_pooling.py')
    print('POOLING_FINISHED',OUT/'RESULTS.md',flush=True)


if __name__=='__main__':main()
