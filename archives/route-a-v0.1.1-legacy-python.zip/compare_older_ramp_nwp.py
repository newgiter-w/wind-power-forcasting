"""Check earlier, available NWP vintages for the same GEFCom2012 valid times."""
import numpy as np
import pandas as pd
from gefcom_protocol_v2 import DATA
from run_qrf_speed_delta import OUT, ROOT, load_farms

source = ROOT/'out_gefcom_up_ramp_diagnosis_20261106/aligned_hours.csv'
hours = pd.read_csv(source,parse_dates=['origin']).query('year == 2012 and valid and lead > 1')
events = hours.query('up_ramp and upper_miss and max_delta_wind_pm2 < .5')
rows = []
for farm,d in load_farms(2012).items():
    weather = pd.read_csv(DATA/f'gefcom2012_wind/data/windforecasts_wf{farm}.csv')
    weather['issue'] = pd.to_datetime(weather.date.astype(str),format='%Y%m%d%H')
    weather['speed'] = np.hypot(weather.u,weather.v)
    lookup = weather.set_index(['issue','hors']).speed
    issue_by_origin = pd.Series(pd.to_datetime(d['meta'].nwp_issue).to_numpy(),index=d['origins'])
    for origin,group in events[events.farm==farm].groupby('origin'):
        issue = issue_by_origin.loc[origin]
        older = issue-pd.Timedelta(hours=12)
        assert older < issue <= origin
        age = int((origin-issue)/pd.Timedelta(hours=1))
        selected = lookup.reindex(pd.MultiIndex.from_product([[issue],np.arange(1,25)+age])).to_numpy()
        alt = lookup.reindex(pd.MultiIndex.from_product([[older],np.arange(1,25)+age+12])).to_numpy()
        known = np.diff(alt,prepend=np.nan)
        for row in group.itertuples():
            j=row.lead-1
            np.testing.assert_allclose(selected[j],row.nwp_speed,atol=1e-12)
            np.testing.assert_allclose(selected[j]-selected[j-1],row.delta_wind,atol=1e-12)
            window=known[max(1,j-2):min(24,j+3)]
            available=np.isfinite(window).all()
            rows.append(dict(farm=farm,origin=origin,lead=row.lead,selected_issue=issue,older_issue=older,
                             older_window_available=available,older_same_hour_delta=known[j],
                             older_max_delta_pm2=float(window.max()) if available else np.nan))
frame=pd.DataFrame(rows)
assert len(frame)==487
frame.to_csv(OUT/'older_nwp_2012.csv',index=False)
ok=frame[frame.older_window_available]
print('total',len(frame),'available',len(ok),'same hour',sum(ok.older_same_hour_delta>=.5),
      'nearby including same hour',sum(ok.older_max_delta_pm2>=.5),flush=True)
