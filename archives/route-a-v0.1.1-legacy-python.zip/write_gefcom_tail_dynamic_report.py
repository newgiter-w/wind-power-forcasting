"""Report all prespecified candidates without changing validation selection."""
from pathlib import Path
from datetime import datetime
import json
import pandas as pd
from run_gefcom_tail_dynamic import OUT,ROOT,METHODS,write,sha

LABELS={'R0_reference':'R0 独立头参考','C0_symmetric':'原R2／对称CQR（D00）',
    'C1_asymmetric':'独立上下尾CQR','C2_risk':'风险驱动双尾修正',
    'D01_base150':'原R2＋150轮','D10_dynamic50':'动态特征＋50轮','D11_dynamic150':'动态特征＋150轮'}
FAIL_CN={'coverage90':'总体覆盖<90%','coverage_noninferior_point':'总体覆盖下降>0.5pp',
    'width_5pct':'缩宽不足5%','IS_5pct':'IS改善不足5%','up_coverage_3pp':'上升覆盖增益不足3pp',
    'up_IS':'上升IS变差','up_width':'上升宽度增加>2pp','near_zero':'近零覆盖不达标'}

def main():
    macro=pd.read_csv(OUT/'metrics_macro.csv');boot=pd.read_csv(OUT/'paired_bootstrap.csv')
    per=pd.read_csv(OUT/'metrics_per_farm.csv');monthly=pd.read_csv(OUT/'monthly_macro.csv')
    selection=json.loads((OUT/'selection.json').read_text());verification=json.loads((OUT/'verification.json').read_text())
    completion=json.loads((OUT/'completion.json').read_text())
    auditpath=OUT/'EXPERIMENT_AUDIT.json'
    audit=json.loads(auditpath.read_text(encoding='utf-8')) if auditpath.exists() else None
    assert selection['choice']=='C0_symmetric' and not selection['promoted']
    assert verification['status']=='passed'
    def m(year,method,group='all',stage='evaluation'):
        return macro[(macro.year==year)&(macro.method==method)&(macro.group==group)&
            (macro.stage==stage)&(macro.kind=='cqr')&(macro.support=='clipped')].iloc[0]
    def ci(year,method,metric,group='all',base='C0_symmetric',block=14):
        name=method if method=='dynamic_capacity_interaction' else method+'_minus_'+base
        return boot[(boot.year==year)&(boot.contrast==name)&(boot.metric==metric)&(boot.group==group)&(boot.block_days==block)].iloc[0]
    gates=[];risk=[]
    for year in [2014,2012]:
        base=m(year,'C0_symmetric');up0=m(year,'C0_symmetric','up_ramp');nz0=m(year,'C0_symmetric','near_zero');rnz=m(year,'R0_reference','near_zero')
        for method in METHODS[2:]:
            a=m(year,method);up=m(year,method,'up_ramp');nz=m(year,method,'near_zero')
            flags=dict(coverage90=bool(a.coverage>=.9),coverage_noninferior_point=bool(a.coverage>=base.coverage-.005),
                width_5pct=bool(a.width<=.95*base.width),IS_5pct=bool(a.IS<=.95*base.IS),
                up_coverage_3pp=bool(up.coverage>=up0.coverage+.03),up_IS=bool(up.IS<=up0.IS),
                up_width=bool(up.width<=up0.width+.02),near_zero=bool(nz.coverage>=max(rnz.coverage-.01,nz0.coverage-.005)))
            cc=ci(year,method,'coverage');cw=ci(year,method,'width');cs=ci(year,method,'IS');cu=ci(year,method,'coverage','up_ramp')
            gates.append(dict(year=year,method=method,**flags,all_point_gates=all(flags.values()),
                coverage_noninferiority_evidence=bool(cc.low95>=-.005),width_improvement_evidence=bool(cw.high95<0),
                IS_improvement_evidence=bool(cs.high95<0),up_coverage_evidence=bool(cu.low95>0),
                relative_width_reduction=float(1-a.width/base.width),relative_IS_reduction=float(1-a.IS/base.IS)))
    # Include retained references as well as candidates: keeping C0 does not erase its failures.
    for year in [2014,2012]:
        f=per[(per.year==year)&(per.stage=='evaluation')&(per.kind=='cqr')&(per.support=='clipped')&(per.group=='all')]
        ref=f[f.method=='C0_symmetric'].set_index('farm')
        for method in METHODS:
            for _,r in f[f.method==method].iterrows():
                delta=r.coverage-ref.loc[r.farm,'coverage']
                if delta<-.01:risk.append(dict(year=year,method=method,type='farm_coverage_drop_gt1pp',key=str(r.farm),value=float(r.coverage),delta=float(delta)))
            mm=monthly[(monthly.year==year)&(monthly.method==method)&(monthly.stage=='evaluation')&(monthly.group=='all')]
            for _,r in mm.iterrows():
                farms=10 if year==2014 else 7
                if r.coverage<.85 and r.origins*farms>=20:
                    risk.append(dict(year=year,method=method,type='monthly_coverage_below85',key=r.month,value=float(r.coverage),delta=None))
    pd.DataFrame(gates).to_csv(OUT/'evaluation_gates.csv',index=False)
    pd.DataFrame(risk,columns=['year','method','type','key','value','delta']).to_csv(OUT/'operational_risk_flags.csv',index=False)
    lines=['# GEFCom：上下尾校准、风险修正与动态特征实验结果', '',
        '报告整理日期：2026-11-04（Asia/Shanghai）。训练与选型于2026-11-03完成。', '',
        '**已完成原计划三个阶段；没有新增方案通过2014Q2全部预设门槛，因此冻结决策为保留原R2／对称CQR，不晋升新候选。评价结果没有用于改参数或重新选型。**', '',
        '## 核心结果', '',
        '1. 独立上下尾校准C1提高上升爬坡覆盖，但总体区间变宽、近零覆盖下降。总体IS的14日配对区间在两套数据上均跨零，不能称稳定的总体IS改善。',
        '2. 风险驱动C2同时改善总体宽度、IS和上升爬坡覆盖，但近零覆盖严重下降。2014近零92.413%→80.980%，2012为96.703%→82.335%；收益不能抵消这一失败。',
        '3. 150轮模型D01/D11使总体区间变窄，却损害上升爬坡覆盖；2012 D01总体覆盖低于90%。动态17列在50轮下的总体收益未跨数据复现，2012宽度和IS反而变差。',
        '4. 当前尚未获得“总体覆盖保持、区间显著变窄、爬坡改善、近零无明显损失”的统一方案。不能挑C2的总体分数、D11的宽度和C1的覆盖拼成一个不存在的最终模型。', '',
        '## 实际执行与冻结', '',
        f'- 两套数据、17场、7个预设参考/方法，共119个场/方法组合；验证和评价共238组。训练流水线耗时{completion["elapsed_seconds"]:.1f}秒，不含后续重算、统计和文档。',
        '- C0与D00为同一个已冻结R2，R0也复用已有模型。新增204个标量分位数HistGBR模型：68个时间前缀OOF骨干、34个风险尾模型、102个动态/轮数骨干；另外保存51个isotonic代理。',
        '- 顺序：2014验证C1→C2→动态四格→写selection.json→2014评价→2012冻结迁移；所有固定消融均报告。没有满足条件的独立模块可组合，本轮未启动可选的组合搜索。',
        f'- 冻结时刻UTC：`{selection["frozen_at_utc"]}`；冻结选择`{selection["choice"]}`，`promoted=false`。选型只读2014Q2，2012Q2仅作诊断。',
        '- 原时间切分、样本资格、24h历史/24h时效、q05/q95、84日历日反馈、额定容量1、最后clip[0,1]不变。每场单独训练；逐场先求指标再等权宏平均。此90%为逐小时点覆盖，不是24小时路径同时覆盖。',
        '- C2仅用proper training中的Q3/Q4时间前缀预测构造34个OOF块，辅助尾模型不使用Q1标签拟合；Q1仍作为最终冻结模型的独立校准种子。',
        '- 动态消融为原特征/加17列 × 50/150轮；新列只由当时可知NWP和已观测历史计算，不使用目标拟合代理，不改变训练样本。所有原始交叉端点从未修改的两个预测同时排序。', '',
        '## 2014Q2验证：为何没有晋升', '',
        '| 候选 | 总体覆盖 % | 宽度 % | IS | 上升覆盖 % | 近零覆盖 % | 未通过的点估计门槛 |',
        '|---|---:|---:|---:|---:|---:|---|']
    for method in METHODS[1:]:
        a=m(2014,method,stage='validation');up=m(2014,method,'up_ramp','validation');nz=m(2014,method,'near_zero','validation')
        failures='原参考'
        if method!='C0_symmetric':
            record=next(x for x in selection['candidates'] if x['method']==method)
            failures='、'.join(FAIL_CN[k] for k,v in record['gates'].items() if not v) or '无'
        lines.append(f'| {LABELS[method]} | {100*a.coverage:.3f} | {100*a.width:.3f} | {a.IS:.6f} | {100*up.coverage:.3f} | {100*nz.coverage:.3f} | {failures} |')
    lines+=['', '门槛包括：总体≥90%且相对C0下降≤0.5pp；宽度/IS相对各改善≥5%；上升覆盖增加≥3pp、组IS不增、组宽度增≤2pp；近零≥max(R0−1pp,C0−0.5pp)。验证失败原因与运行前计划一致，不根据评价结果放宽。', '',
        '## 两套评价段的总体结果', '',
        '| 数据 | 方法 | 覆盖 % | 宽度 %容量 | IS | 相对C0宽度降幅 % | 相对C0 IS降幅 % |',
        '|---|---|---:|---:|---:|---:|---:|']
    for year in [2014,2012]:
        b=m(year,'C0_symmetric')
        for method in METHODS:
            a=m(year,method)
            lines.append(f'| {year} | {LABELS[method]} | {100*a.coverage:.3f} | {100*a.width:.3f} | {a.IS:.6f} | {100*(1-a.width/b.width):+.3f} | {100*(1-a.IS/b.IS):+.3f} |')
    lines+=['', '## 评价段条件表现', '',
        '| 数据 | 工况 | 方法 | 覆盖 % | 宽度 %容量 | IS | 下尾漏点 % | 上尾漏点 % |',
        '|---|---|---|---:|---:|---:|---:|---:|']
    for year in [2014,2012]:
        for group,cn in [('ramp','全部爬坡'),('up_ramp','上升爬坡'),('down_ramp','下降爬坡'),('near_zero','近零')]:
            for method in METHODS:
                a=m(year,method,group)
                lines.append(f'| {year} | {cn} | {LABELS[method]} | {100*a.coverage:.3f} | {100*a.width:.3f} | {a.IS:.6f} | {100*a.lower_miss:.3f} | {100*a.upper_miss:.3f} |')
    lines+=['', '## 相对C0的配对统计', '',
        '下表为后者减C0。覆盖/宽度单位pp，IS保持原尺度；方括号为95%区间。主表使用14日历日移动块、2000次同步跨方法/风场抽样；7日块与全部上下尾/时效相关结果另存。区间未作多重比较校正，属于固定风场、固定种子、历史回溯中的探索性证据。', '',
        '| 数据 | 方法 | Δ总体覆盖 pp [CI] | Δ宽度 pp [CI] | ΔIS [CI] | Δ上升覆盖 pp [CI] | Δ近零覆盖 pp [CI] |',
        '|---|---|---|---|---|---|---|']
    for year in [2014,2012]:
        for method in METHODS[2:]:
            values=[]
            for metric,group,scale in [('coverage','all',100),('width','all',100),('IS','all',1),('coverage','up_ramp',100),('coverage','near_zero',100)]:
                a=ci(year,method,metric,group)
                values.append(f'{a.delta*scale:+.4f} [{a.low95*scale:+.4f}, {a.high95*scale:+.4f}]')
            lines.append(f'| {year} | {LABELS[method]} | '+' | '.join(values)+' |')
    lines+=['', 'C2相对C0的总体覆盖不劣检验（允许下降0.5pp）：14日区间下端2014为−0.414pp、2012为−0.149pp，均在−0.5pp以上。这只支持总体经验不劣，不修复其近零失败。', '',
        '## 动态特征与轮数的贡献', '',
        '| 数据 | 对照 | Δ总体IS [95% CI] | Δ宽度 pp [95% CI] |',
        '|---|---|---|---|']
    for year in [2014,2012]:
        for method,base,label in [('D01_base150','C0_symmetric','原特征50→150轮'),('D10_dynamic50','C0_symmetric','50轮时加动态特征'),
            ('D11_dynamic150','D01_base150','150轮时加动态特征'),('D11_dynamic150','D10_dynamic50','动态特征50→150轮')]:
            a=ci(year,method,'IS',base=base);w=ci(year,method,'width',base=base)
            lines.append(f'| {year} | {label} | {a.delta:+.6f} [{a.low95:+.6f}, {a.high95:+.6f}] | {100*w.delta:+.4f} [{100*w.low95:+.4f}, {100*w.high95:+.4f}] |')
    lines+=['', '150轮的总体缩宽较一致，但上升覆盖下降也在两套数据的配对区间中得到支持。17个动态特征没有稳定跨数据增益，不能把D11相对C0的全部缩宽归给特征。交互项及C2−C1增量见paired_bootstrap.csv。', '',
        '## 失败机制与下一步边界', '',
        f'- C1/C2使总体上尾漏点减少，却增加了近零下尾漏点。C2近零下尾漏点2014为{100*m(2014,"C2_risk","near_zero").lower_miss:.3f}%、2012为{100*m(2012,"C2_risk","near_zero").lower_miss:.3f}%，几乎解释该组全部失败。固定5%/5%的总体尾预算不等于近零组也有5%尾预算。',
        '- 数据与这些端点错误一致的解释是：低出力时的正下界估计/收缩过强，稀有低出力状态的尾风险没有被全局再校准充分保护。C2的前缀OOF骨干与完整训练骨干也存在误差分布差异。这些是机制线索，尚不能唯一量化各自因果贡献。',
        '- 不能基于真实未来近零标签把下界强制置零；也不能在已看过的评价段搜索低尾alpha或阈值。若继续研究，应另冻结“边界/零功率概率建模或预测时低出力风险保护”的验证方案，并包含原C0/C1/C2作为参考。',
        '- 2014 C1上升覆盖达到90.220%，但靠更宽区间且近零下降实现；2012仍只有86.143%。150轮模型也没有解决爬坡。因此当前没有实现全部目标，不应替换为新的默认方案。', '',
        '## 时效、月份、风场与服务率', '',
        '- `group_lead_macro.csv` / `group_lead_per_farm.csv`：全部工况×1–6/7–12/13–24h；`per_lead.csv`：逐小时；`monthly_macro.csv` / `monthly_per_farm.csv`：月份分组。',
        '- `operational_risk_flags.csv`记录全部七组（含保留的参考）评价期相对C0单场总体覆盖下降>1pp，以及至少20个评分场日的月组覆盖<85%的情况。它是风险标注，不用于重新选型。',
        '- 保留C0不等于其月份问题已解决：2011年11月，GEFCom2012的C0覆盖81.662%、R0覆盖79.396%（各场26个评分日）。两者同样列入风险标注，不能因候选失败而隐去基线失效。', '',
        '| 数据 | 日历场日 | 发报场日 | 完整评分场日 | 服务率 % |',
        '|---|---:|---:|---:|---:|']
    for _,s in pd.read_csv(OUT/'service.csv').iterrows():lines.append(f'| {int(s.year)} | {int(s.calendar_farm_days)} | {int(s.issued_farm_days)} | {int(s.scored_farm_days)} | {100*s.service_rate:.3f} |')
    lines+=['', '只在相同可服务子集比较准确率，不能把这些指标当成全日历服务表现。', '',
        '## 完整性与复现', '',
        '- 8项回归/种子计算检查通过，涵盖动态/风险特征不读取未来目标、同原点时效顺序、OOF标签到达、独立尾反馈、signed收缩和训练段缩放。',
        '- 238组阶段结果、4760行指标已独立从保存数组重算；全部预测原点配对，校准反馈不超过当时原点；源文件哈希与冻结协议一致。R0/C0两个阶段区间与旧正式结果逐元素一致。',
        '- C2评价中触发1个空区间中点保护，其余方法/阶段均为0；原始修正端点交叉及bL/bU分布见各场C2_risk/fit.json。',
        '- 本轮最少有49个到达校准日。维护提示：独立95%尾顺序统计量至少需要19日才能有限，现有helper的提前计数检查只写9日，但另有非有限端点检查；本轮所有样本远高于19日，结果未受影响。为保持冻结代码可追溯，本轮未事后改动该helper。',
        '- 新训练脚本：`python -u run_gefcom_tail_dynamic.py`；数组与统计：`python analyze_gefcom_tail_dynamic.py`；报告：`python write_gefcom_tail_dynamic_report.py`。已完成运行无需为查看报告重训。',
        '- `protocol.json`、`source_snapshot/`、`selection.json`、`frozen_validation_macro.csv`、`oof_checks.json`、逐场模型/代理/Scaler/数组/反馈均保留。旧结果未覆盖。',
        '- `evaluation_gates.csv`为评价时固定门槛检查；它不是重新选型。训练/选型已完成不代表新独立数据确认已完成。2014 NWP缺原生发布时间，沿用竞赛可用性假设；2012只有一个可用高度。', '']
    if audit:
        lines.extend(['### 额外复核状态', '',f'状态：{audit.get("overall_verdict",audit.get("verdict","unknown"))}；详情见EXPERIMENT_AUDIT.md。独立性与可接受级别以该报告为准。',''])
    else:
        lines.extend(['### 额外复核状态', '', '确定性的数组、时间和哈希检查已通过；额外fresh-agent语义复核尚未完成。不得据此声称外部独立审计通过。',''])
    (OUT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    write(OUT/'report_status.json',dict(date='2026-11-04',experiments='complete',analysis='complete',
        selection='retain_C0_no_promotion',report='complete',audit='unavailable' if audit is None else audit.get('overall_verdict'),
        writer_sha256=sha(Path(__file__))))
    print('Report and evaluation gates written',flush=True)

if __name__=='__main__':main()
