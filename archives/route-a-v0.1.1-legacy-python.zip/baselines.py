"""Skill baselines for interval evaluation.

These answer "does the interval have any predictive value?" before attributing
anything to retrieval or a trained model:

  * climatology  : per-lead-time quantiles of the training power distribution
                   (constant across origins; captures diurnal/lead-time shape).
  * persistence  : last-observed power held forward + split-conformal calibration.
  * analog       : direct empirical quantiles of the retrieved neighbors'
                   continuations (no trained model; classic analog ensemble).
"""
from __future__ import annotations

import numpy as np

from config import Config
from retrieval import Retriever


def climatology(target_train: np.ndarray, n_test: int, conf: float):
    H = target_train.shape[1]
    lo = np.array([np.quantile(target_train[:, h], (1 - conf) / 2) for h in range(H)])
    hi = np.array([np.quantile(target_train[:, h], 1 - (1 - conf) / 2) for h in range(H)])
    return np.broadcast_to(lo, (n_test, H)), np.broadcast_to(hi, (n_test, H))


def persistence_point(cond: np.ndarray, H: int) -> np.ndarray:
    return np.repeat(cond[:, -1:], H, axis=1)


def _conf_quantile(resid: np.ndarray, conf: float) -> np.ndarray:
    n = resid.shape[0]
    k = int(np.ceil((n + 1) * conf)); k = min(k, n)
    return np.array([np.sort(np.abs(resid[:, h]))[k - 1] for h in range(resid.shape[1])])


def persistence(cond_test: np.ndarray, H: int, conf: float,
                y_cal: np.ndarray = None, cond_cal: np.ndarray = None):
    yhat = persistence_point(cond_test, H)
    if y_cal is not None and cond_cal is not None:
        yhat_cal = persistence_point(cond_cal, H)
        q_h = _conf_quantile(yhat_cal - y_cal, conf)
        return yhat - q_h[None, :], yhat + q_h[None, :]
    return yhat, yhat


def analog(ret: Retriever, cond_test: np.ndarray, feat_test: np.ndarray,
           conf: float, k: int):
    """Direct analog quantiles from the retrieved neighbors' continuations."""
    n = len(cond_test)
    H = ret.target.shape[1]
    lo = np.empty((n, H)); hi = np.empty((n, H))
    for i in range(n):
        local, _, _ = ret.query(cond_test[i], feat_test[i], exclude_local=-1, top_k=k)
        tgt = ret.target[local]                     # (k, H)
        lo[i] = np.quantile(tgt, (1 - conf) / 2, axis=0)
        hi[i] = np.quantile(tgt, 1 - (1 - conf) / 2, axis=0)
    return lo, hi
