"""Two shared-pool classifiers crossed with same-hour / local NWP gates."""
from pathlib import Path
import hashlib
import json
import sys

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

import run_kelmarsh_gfs_q90 as prior
from run_kelmarsh_gfs_q90_expand import read_months
from run_q90_training_coverage import apply,subset
from run_uncapped_alarm_new_site import models,calibrate,alarm
from run_kelmarsh_ramp_probability import CONFIG,FEATURES,PERIODS,QUARTERS,SEASONS,COUNTS,METRICS,rates,summarize
from diagnose_kelmarsh_ramp_bottleneck import nearby
from diagnose_gefcom2012_data_attribution import match_truth
from prepare_q90_training_coverage import TRAIN,OUT as COVERAGE
from revision_common import frozen_spec,write

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_kelmarsh_nwp_context_factorial'
ARMS=('QRF','q90_frozen','probability_old_frozen','A','B','C','D')
SPECS={'q90_frozen':('q90','same'),'probability_old_frozen':('old','same'),
       'A':('point','same'),'B':('context','same'),'C':('point','near'),'D':('context','near')}
LABELS={'A':'单时刻特征＋同小时门控','B':'局部轨迹特征＋同小时门控',
        'C':'单时刻特征＋邻域门控','D':'局部轨迹特征＋邻域门控'}
FACTOR_NAMES=('feature_same','feature_near','gate_point','gate_context','interaction')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def shift(x,offset):
    result=np.full_like(x,np.nan,dtype=float)
    if offset<0: result[:,-offset:]=x[:,:offset]
    elif offset>0: result[:,:-offset]=x[:,offset:]
    else: result[:]=x
    return result


def context_features(d,base):
    speed=np.linalg.norm(d['nwp'],axis=2)
    fields=[speed,d['nwp'][:,:,0],d['nwp'][:,:,1]]
    extra=[];names=[]
    for off in (-2,-1,1,2):
        for name,x in zip(('speed','u','v'),fields):
            extra.append(shift(x,off));names.append(f'nwp_{name}_offset_{off:+d}')
    extra.extend([speed-shift(speed,-2),shift(speed,2)-speed])
    names.extend(['nwp_speed_rise_previous2','nwp_speed_rise_next2'])
    dw=base['features'][:,:,4]
    window=np.stack([shift(dw,o) for o in (-2,-1,0,1,2)],axis=-1)
    peak=np.nanmax(window,axis=-1)
    position=np.argmax(np.where(np.isnan(window),-np.inf,window),axis=-1)-2
    extra.extend([peak,position]);names.extend(['nwp_max_hourly_rise_local2','nwp_max_rise_offset_local2'])
    return np.concatenate([base['features'],np.stack(extra,axis=-1)],axis=-1),list(FEATURES)+names


def protocol():
    frozen_spec(OUT/'protocol.json',dict(train=list(TRAIN),model=CONFIG,target='same-hour actual increment >0.10 capacity',
        common_training_pool='all forecast leads2–24 on identical297 complete annual issue days;6831 rows; gate NOT used to select training rows',
        models='only two classifiers fitted: point9 and context25; each shared across both gates',
        context='point9 plus NWP speed/U/V at offsets -2,-1,+1,+2,previous/next2h speed rise,local2h maximum hourly rise and peak offset',
        availability='all NWP valid times belong to the same archived prior18UTC run available before issuance; no future actual wind/power inputs',
        boundary='no crossing issued24h forecast; unavailable context offsets are NaN, handled by fixed HistGB native missing support; lead1 remains QRF for all arms',
        same_gate='same-hour forecast speed rise>=0.5m/s',near_gate='any forecast hourly rise>=0.5m/s within ±2 leads, excluding lead1',
        arms=LABELS,anchors='unchanged QRF,annual q90,old gate-trained event classifier; A uses a new common training pool and is NOT old classifier reproduction',
        development=['2023-12'],expanded_development=list(PERIODS),
        status='previously inspected Kelmarsh2024 is development/retrospective; no independent targets opened',
        budget='all24h quiet abs(actual increment)<=0.05; every arm matches total QRF quiet false count including unchanged off-gate alarms',
        matching='±1h one-to-one within one issued24h day; same full true-event denominator; disjoint same/near-only/no-near/first-lead groups',
        thresholds='per-subset matched cutoffs are retrospective diagnostics; also apply pooled development cutoffs unchanged to seasonal subsets',
        inference='2000 paired calendar moving blocks,14d primary,7/28d sensitivity; conditional on scores and cutoffs; no bootstrap recalibration',
        factorial='B-A,D-C,C-A,D-B and interaction D-C-B+A; report95% and Bonferroni99% CIs for five-effect family; averaged main effects descriptive',
        candidate_gate=dict(candidates=['B','C','D'],priority=['C','B','D'],
            primary='all-event recall CI lower>0 vs A, frozen q90, QRF; Bonferroni family9 limits across3 candidates x3 comparisons',
            stability='against A and q90 separately:3/4 quarterly and2/3 full meteorological seasons nonnegative; no point drop beyond5pp and no95%CI upper<0',
            negatives='all nonramp FPR not above q90 by more than0.5pp',december='recall not below A and q90 at same December quiet budget'),
        independent='only after gate passes: freeze one candidate and December2023 cutoffs; lock a genuinely unused site/cohort before any target access; previously scored Kelmarsh/Penmanshiel cannot become independent again',
        interval='unchanged QRF point forecasts and interval endpoints; no interval coverage/width/IS efficacy claim',
        execution='warm reuse project Python3.13/sklearn1.5.2/NumPy2.1.3/pandas2.2.3;CPU2threads,no environment changes'))


def make_scores(d,forest,imp,q90,old,trained):
    with threadpool_limits(limits=2):
        base=prior.record(d,forest,imp)[0]
        r=apply(base,q90)[0]
        r['same']=base['gate'];r['near']=nearby(base['gate'],2);r['near'][:,0]=False
        r['eligible']=np.broadcast_to(np.arange(24)>0,r['base'].shape)
        r['q90']=r['uncapped']
        ctx,_=context_features(d,base)
        for field,model,x in [('point',trained['point'],base['features']),('context',trained['context'],ctx),('old',old,base['features'])]:
            r[field]=np.full(r['base'].shape,np.nan)
            use=r['same'] if field=='old' else r['eligible']
            r[field][use]=model.predict_proba(x[use])[:,1]
    return r


def arm_record(r,name):
    field,gate=SPECS[name]
    return dict(base=r['base'],actual=r['actual'],tie=r['tie'],gate=r[gate],selected=r[field])


def calibrations(r):
    return {name:calibrate([arm_record(r,name)],'selected') for name in SPECS}


def daily(r,cutoffs,operation):
    y=r['actual'];up=y>.1;q=np.abs(y)<=.05
    first=~r['eligible']
    scopes={'all':np.ones_like(up),'same_signal':r['same'],'nearby_only':r['near']&~r['same'],
            'no_nearby':r['eligible']&~r['near'],'first_lead':first}
    np.testing.assert_array_equal(sum(scopes[k].astype(int) for k in list(scopes)[1:]),np.ones_like(up,dtype=int))
    rows=[]
    for name in ARMS:
        al=r['base']>.1 if name=='QRF' else alarm(arm_record(r,name),'selected',cutoffs[name])
        if name!='QRF':
            _,g=SPECS[name]
            np.testing.assert_array_equal(al[~r[g]],(r['base']>.1)[~r[g]])
        hit=match_truth(up,al)
        for scope,keep in scopes.items():
            a=[up&keep,up&keep&hit,q&keep,q&keep&al,~up&keep,~up&keep&al,keep,al&keep,up&al&keep]
            rows.append(pd.DataFrame(np.column_stack([v.sum(axis=1) for v in a]),columns=COUNTS)
                .assign(origin=r['origins'],model=name,scope=scope,operation=operation))
    return pd.concat(rows,ignore_index=True)


def coefficients():
    def v(**kw):return np.asarray([kw.get(k,0.) for k in ARMS])
    c=dict(feature_same=v(B=1,A=-1),feature_near=v(D=1,C=-1),gate_point=v(C=1,A=-1),
        gate_context=v(D=1,B=-1),interaction=v(D=1,C=-1,B=-1,A=1),
        feature_main=v(B=.5,A=-.5,D=.5,C=-.5),gate_main=v(C=.5,A=-.5,D=.5,B=-.5),
        A_vs_old=v(A=1,probability_old_frozen=-1))
    for a in ('B','C','D'):
        for ref in ('A','QRF','q90_frozen','probability_old_frozen'):
            c[f'{a}_vs_{ref}']=v(**{a:1,ref:-1})
    return c


def bootstrap(frame,block):
    dates=pd.date_range(frame.origin.min(),frame.origin.max());n=len(dates)
    rng=np.random.default_rng(20120516)
    starts=rng.integers(0,n-block+1,size=(2000,int(np.ceil(n/block))))
    take=(starts[:,:,None]+np.arange(block)).reshape(2000,-1)[:,:n]
    weights=np.zeros((2000,n));np.add.at(weights,(np.arange(2000)[:,None],take),1)
    cs=coefficients();rows=[]
    for (op,scope),g in frame[frame.scope.ne('first_lead')].groupby(['operation','scope']):
        v=np.stack([g[g.model.eq(m)].set_index('origin')[list(COUNTS)].reindex(dates,fill_value=0).to_numpy() for m in ARMS])
        with threadpool_limits(limits=2):
            totals=(weights @ v.transpose(1,0,2).reshape(n,-1)).reshape(2000,len(ARMS),len(COUNTS)).transpose(1,0,2)
        sim=rates(totals);point=rates(v.sum(axis=1))
        for name,c in cs.items():
            use=c!=0
            delta=np.einsum('m,mdk->dk',c[use],sim[use]);value=c[use]@point[use]
            for j,k in enumerate(METRICS):
                finite=delta[np.isfinite(delta[:,j]),j]
                qs=np.quantile(finite,[.025,.975,.005,.995,.05/18,1-.05/18]) if len(finite) else np.full(6,np.nan)
                rows.append(dict(operation=op,scope=scope,contrast=name,block=block,metric=k,
                    delta=float(value[j]),low=float(qs[0]),high=float(qs[1]),family5_low=float(qs[2]),family5_high=float(qs[3]),
                    family9_low=float(qs[4]),family9_high=float(qs[5]),valid_draws=len(finite)))
    return pd.DataFrame(rows)


def evaluate(label,r,pooled=None):
    folder=OUT/label;folder.mkdir(exist_ok=True)
    cuts=calibrations(r)
    frame=daily(r,cuts,'matched_development')
    if pooled is not None:
        frame=pd.concat([frame,daily(r,pooled,'pooled_development_cutoff')],ignore_index=True)
    summary=summarize(frame)
    summary.to_csv(folder/'summary.csv');frame.to_csv(folder/'daily.csv',index=False)
    ci=pd.concat([bootstrap(frame,b) for b in (7,14,28)],ignore_index=True)
    ci.to_csv(folder/'paired_blocks.csv',index=False)
    write(folder/'diagnostic_cutoffs.json',cuts)
    np.savez_compressed(folder/'scores.npz',**{k:r[k] for k in ('origins','base','actual','same','near','eligible','point','context','old','q90','tie')})
    all_scope=summary.xs(('matched_development','all'))
    assert all_scope['false'].nunique()==1 and all_scope.events.nunique()==1
    print(label,'events',int(all_scope.events.iloc[0]),'false',int(all_scope['false'].iloc[0]),
          'hits',all_scope.hits.astype(int).to_dict(),flush=True)
    return dict(frame=frame,summary=summary,ci=ci,cutoffs=cuts)


def cirow(result,contrast,scope='all',metric='recall',block=14):
    c=result['ci']
    return c[(c.operation=='matched_development')&(c.scope==scope)&(c.metric==metric)&(c.block==block)&(c.contrast==contrast)].iloc[0]


def stability(results,arm,groups,minimum):
    detail={}
    for ref in ('A','q90_frozen'):
        values=[cirow(results[g],f'{arm}_vs_{ref}') for g in groups]
        detail[ref]=dict(nonnegative=int(sum(r.delta>=0 for r in values)),required=minimum,
            no_drop_beyond5pp=bool(all(r.delta>=-.05 for r in values)),no_significant_negative=bool(all(r.high>=0 for r in values)))
    passed=all(v['nonnegative']>=minimum and v['no_drop_beyond5pp'] and v['no_significant_negative'] for v in detail.values())
    return dict(pass_gate=bool(passed),comparisons=detail)


def decisions(results):
    year=results['expanded_development'];d=year['summary'].xs(('matched_development','all'))
    candidates={}
    for arm in ('B','C','D'):
        quarter=stability(results,arm,list(QUARTERS),3)
        season=stability(results,arm,['spring_MAM','summer_JJA','autumn_SON'],2)
        checks=dict(primary_all_three_family9_ci_positive=bool(all(cirow(year,f'{arm}_vs_{ref}').family9_low>0 for ref in ('A','QRF','q90_frozen'))),
            quarterly_stability=quarter['pass_gate'],meteorological_stability=season['pass_gate'],
            nonramp_fpr_guard=bool(d.loc[arm,'nonramp_fpr']<=d.loc['q90_frozen','nonramp_fpr']+.005),
            december_guard=bool(all(cirow(results['december2023_development'],f'{arm}_vs_{ref}').delta>=0 for ref in ('A','q90_frozen'))))
        candidates[arm]=dict(checks=checks,quarterly=quarter,seasonal=season,passed=all(checks.values()))
    selected=next((a for a in ('C','B','D') if candidates[a]['passed']),None)
    return dict(candidates=candidates,selected=selected,development_passed=selected is not None,
        independent_status='pending: lock new truly unused cohort/site before target access' if selected else 'not run; no candidate passed; preserve holdout',
        interval_status='unchanged')


def main():
    protocol();(OUT/'source_executed.py').write_bytes(Path(__file__).read_bytes())
    forest,imp,_=models();q90=joblib.load(COVERAGE/'annual.joblib')
    old_path=ROOT/'out_kelmarsh_ramp_probability'/'classifier.joblib';old=joblib.load(old_path)
    frozen_paths=dict(qrf=prior.OUT/'q90_expanded_holdout'/'frozen_baseline.joblib',q90=COVERAGE/'annual.joblib',old_probability=old_path)
    hashes={k:sha(p) for k,p in frozen_paths.items()};frozen_spec(OUT/'weights.json',hashes)
    train=read_months(TRAIN)
    with threadpool_limits(limits=2):base=prior.record(train,forest,imp)[0]
    use=np.broadcast_to(np.arange(24)>0,base['actual'].shape)
    assert len(base['origins'])==297 and use.sum()==6831
    assert base['ends'].max()<=np.datetime64('2023-08-01')
    ctx,names=context_features(train,base)
    frozen_spec(OUT/'feature_names.json',dict(point=list(FEATURES),context=names))
    assert ctx.shape[-1]==25 and np.isfinite(base['features'][use]).all()
    target=(base['actual'][use]>.1).astype(int)
    trained={}
    for name,x in [('point',base['features']),('context',ctx)]:
        with threadpool_limits(limits=2):trained[name]=HistGradientBoostingClassifier(**CONFIG).fit(x[use],target)
        assert trained[name].get_params()==old.get_params()
        joblib.dump(trained[name],OUT/f'{name}.joblib')
    write(OUT/'training_counts.json',dict(days=297,hours=int(use.sum()),positive=int(target.sum()),negative=int((target==0).sum()),
        features=dict(point=9,context=25),shared_label_sha256=hashlib.sha256(target.tobytes()).hexdigest(),
        shared_origin_lead_sha256=hashlib.sha256(np.column_stack([np.repeat(base['origins'],23).astype('int64'),np.tile(np.arange(2,25),297)]).tobytes()).hexdigest(),
        original_gate_hours=int(base['gate'].sum())))
    with threadpool_limits(limits=2):witness=prior.record({**train,'y':np.zeros_like(train['y'])},forest,imp)[0]
    np.testing.assert_array_equal(base['features'],witness['features'])
    np.testing.assert_array_equal(ctx,context_features({**train,'y':np.zeros_like(train['y'])},witness)[0])
    print('TRAINED shared hours',int(use.sum()),'events',int(target.sum()),'features9/25',flush=True)
    results={}
    dec=make_scores(read_months(('2023-12',)),forest,imp,q90,old,trained)
    results['december2023_development']=evaluate('december2023_development',dec)
    year=make_scores(read_months(PERIODS),forest,imp,q90,old,trained)
    results['expanded_development']=evaluate('expanded_development',year)
    pooled=results['expanded_development']['cutoffs']
    for label,months in {**QUARTERS,**SEASONS}.items():
        results[label]=evaluate(label,subset(year,months),pooled)
    decision=decisions(results);write(OUT/'decision.json',decision)
    if decision['selected']:
        frozen_spec(OUT/'thresholds.json',dict(source='Kelmarsh December2023 only',candidate=decision['selected'],
            cutoffs=results['december2023_development']['cutoffs'],status='after development gate; independent data unopened'))
    current=results['expanded_development']['summary'].xs(('matched_development','all'))
    previous=pd.read_csv(ROOT/'out_kelmarsh_ramp_probability'/'expanded_development'/'summary.csv')
    previous=previous[(previous.operation=='same_fpr_development')&(previous.scope=='all')].set_index('model')
    for a,b in [('QRF','qrf'),('q90_frozen','annual_q90'),('probability_old_frozen','ramp_probability')]:
        for c in COUNTS:assert current.loc[a,c]==previous.loc[b,c]
    assert all(sha(p)==hashes[k] for k,p in frozen_paths.items())
    write(OUT/'verification.json',dict(status='pass',same_training_rows_and_labels=True,old_hyperparameters_identical=True,
        future_targets_do_not_change_features=True,frozen_anchor_counts_reproduce=True,hashes_unchanged=True,
        all_arms_same_total_false_budget=True,disjoint_regions=True,off_gate_alarms_unchanged=True,
        independent_targets_scored=False,interpreter=sys.executable,sklearn=sklearn.__version__,numpy=np.__version__,pandas=pd.__version__))
    write(OUT/'completion.json',dict(status='development_complete' if decision['selected'] else 'complete',
        selected=decision['selected'],independent_run=False,reason=decision['independent_status']))
    print('DECISION',json.dumps(decision),flush=True)


if __name__=='__main__':
    main()
