"""Test upper-bound donors alone under the previous policy's exact daily budget."""
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from run_gefcom2012_upper_width_budget import ROOT, YEAR, LIMIT, load_farms, read, policy
from run_point_residual import feature_array
from gefcom2014_experiment import masks
from revision_common import collect, frozen_spec, write, METRIC_COLS
from run_qrf_regime_bounds import GROUPS, bootstrap

OUT = ROOT/'out_gefcom2012_safe_upper_donors'
CUTOFF = np.datetime64('2011-05-16')
DONORS = ('margin','weather_guard','learned_tail')


def data(farm,d,stage):
    ids,lo,hi,median,score,marked = read(d,farm,stage)
    raised = policy(lo,hi,median,score,marked,.05,.10)
    legacy = np.minimum(raised,hi)
    budget = (hi-legacy).sum(axis=1)
    cap = np.where(marked,0,np.minimum(hi-lo,LIMIT))
    assert (cap.sum(axis=1)>=budget-1e-12).all()
    wind = feature_array(YEAR,farm,'GBM')[:,-14:-12].reshape(-1,24,2)[ids]
    speed = np.linalg.norm(wind,axis=2)
    dw = np.diff(speed,axis=1,prepend=speed[:,:1])
    rise = np.stack([np.maximum(dw[:,max(0,h-2):h+3].max(axis=1),0) for h in range(24)],axis=1)
    delta = np.diff(median,axis=1,prepend=d['history'][ids,-1,None])
    margin = hi-median
    leads = np.broadcast_to(np.arange(1,25),hi.shape)
    features = np.stack([margin, hi-lo, hi, median, delta, speed, rise, leads],axis=-1)
    return ids,lo,hi,legacy,budget,cap,features


def fit(farms, dev):
    x, y = [], []
    last = []
    for farm,d in farms.items():
        ids,lo,hi,legacy,budget,cap,features = dev[farm]
        train = d['valid'][ids] & (d['ends'][ids]<=CUTOFF)
        assert (d['origins'][ids][train]<CUTOFF).all()
        last.append(str(d['ends'][ids][train].max()))
        # Predict the tail probability at a feasible maximum cut, including old misses.
        eligible = train[:,None] & (cap>0)
        x.append(features[eligible])
        y.append((d['y'][ids]>hi-cap)[eligible])
    x,y = np.concatenate(x),np.concatenate(y)
    model = make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=500))
    model.fit(x,y)
    write(OUT/'fit.json',dict(rows=len(y),positives=int(y.sum()),last_label=max(last)))
    return model


def allocate(hi,lo,cap,budget,risk):
    order = np.argsort(risk,axis=1,kind='stable')
    ranked = np.take_along_axis(cap,order,axis=1)
    before = np.cumsum(ranked,axis=1)-ranked
    cut = np.minimum(np.maximum(budget[:,None]-before,0),ranked)
    cuts = np.empty_like(cut)
    np.put_along_axis(cuts,order,cut,axis=1)
    upper = np.maximum(lo,hi-cuts)
    assert (upper<=hi).all()
    np.testing.assert_allclose((hi-upper).sum(axis=1),budget,atol=1e-11,rtol=0)
    assert (hi-upper<=cap+1e-12).all()
    return upper


def compare(farms, dataset, stage, model, chosen=None):
    rows, transitions, daily = [], [], {}
    for farm,d in farms.items():
        ids,lo,hi,legacy,budget,cap,features = dataset[farm]
        use = (d['origins'][ids]>=CUTOFF) if stage=='development' else np.ones(len(ids),dtype=bool)
        ids,lo,hi,legacy,budget,cap,features = (a[use] for a in dataset[farm])
        np.testing.assert_allclose((hi-legacy).sum(axis=1),budget,atol=1e-11,rtol=0)
        y = d['y'][ids]
        valid = d['valid'][ids,None]
        groups = masks(y,d['history'][ids,-1])
        margin,_,_,_,delta,_,rise,_ = np.moveaxis(features,-1,0)
        risk = dict(margin=-margin,weather_guard=-margin+np.maximum(delta,0)+.05*rise,
                    learned_tail=model.predict_proba(features.reshape(-1,features.shape[-1]))[:,1].reshape(hi.shape))
        methods = {'original':hi,'legacy':legacy}
        for name in DONORS if chosen is None else (chosen,):
            methods[name] = allocate(hi,lo,cap,budget,risk[name])
        for name,u in methods.items():
            collect(rows,d,ids,lo,u,farm=farm,model=name)
            lost = (y<=hi)&(y>u)&valid
            transitions.append(dict(farm=farm,model=name,new=int(lost.sum()),
                up_new=int((lost&groups['up_ramp']).sum()),recovered_width=float((hi-u)[valid[:,0]].sum())))
            if chosen is not None:
                width = u-lo
                vals = [width,(y>=lo)&(y<=u),width+20*np.maximum(lo-y,0)+20*np.maximum(y-u,0),y>u]
                for g in GROUPS:
                    keep=groups[g]&valid
                    daily[name,farm,g] = (d['origins'][ids],np.column_stack(
                        [keep.sum(axis=1)]+[np.where(keep,v,0).sum(axis=1) for v in vals]))
        if chosen is not None:
            np.savez_compressed(OUT/f'evaluation_farm_{farm:02}.npz',ids=ids,lo=lo,budget=budget,**methods)
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{stage}_per_farm.csv',index=False)
    macro=frame.groupby(['model','group'])[METRIC_COLS].mean()
    macro.to_csv(OUT/f'{stage}_macro.csv')
    counts=pd.DataFrame(transitions)
    counts.to_csv(OUT/f'{stage}_transitions.csv',index=False)
    counts=counts.groupby('model').sum(numeric_only=True)
    if chosen is not None:
        contrasts=[]
        for ref in ('original','legacy'):
            pair={k:v for k,v in daily.items() if k[0] in (ref,chosen)}
            contrasts.extend(dict(reference=ref,**r) for r in bootstrap(YEAR,pair,chosen))
        pd.DataFrame(contrasts).to_csv(OUT/'evaluation_paired_blocks.csv',index=False)
    print(stage,counts[['new','up_new','recovered_width']].to_string(),flush=True)
    return macro,counts


def checks(m,c,name):
    a,b,l = (m.loc[k] for k in ('original',name,'legacy'))
    return dict(new=bool(c.loc[name,'new']<c.loc['legacy','new']),
        up_new=bool(c.loc[name,'up_new']<c.loc['legacy','up_new']),
        up_macro=bool(b.loc['up_ramp','upper_miss']<l.loc['up_ramp','upper_miss']),
        coverage=bool(b.loc['all','coverage']>=.90),
        near_zero=bool(b.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
        down_ramp=bool(b.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01),
        IS=bool(b.loc['all','IS']<=a.loc['all','IS']))


def main():
    frozen_spec(OUT/'protocol.json',dict(year=YEAR,farms=7, base='original frozen QRF and lower, upper contraction only',
        development='fit pooled logistic on arrived Q2 labels up to 2011-05-16 00:00; select from origins at or after cutoff through Q2',
        budget='exact original 5pp-add 10pp-room policy donor width by farm and day; no recipient hours; 5pp per hour cap',
        rules=list(DONORS), model='logistic standard scaling, C=1, score P(Y>U-feasible cap), predeclared 8 issue-time features',
        gate='fewer new all/up misses and smaller macro up miss than legacy at same width, coverage>=90%, near/down loss<=1pp and IS<=original',
        selection='among passes minimize new up misses, then all new misses, then IS; if none pass stop before evaluation',
        inference='historical evaluation, fixed 14-day synchronized date block intervals conditional on development fit'))
    farms=load_farms(YEAR)
    assert list(farms)==list(range(1,8))
    dev={f:data(f,d,'validation') for f,d in farms.items()}
    model=fit(farms,dev)
    m,c=compare(farms,dev,'development',model)
    gates={name:checks(m,c,name) for name in DONORS}
    options=[k for k,g in gates.items() if all(g.values())]
    selected=min(options,key=lambda k:(c.loc[k,'up_new'],c.loc[k,'new'],m.loc[(k,'all'),'IS'])) if options else None
    frozen_spec(OUT/'selection.json',dict(selected=selected,checks=gates))
    print('SELECTED',selected,gates,flush=True)
    outcome=dict(status='complete',selected=selected,advance_to_reallocation=False)
    if selected:
        evaluation={f:data(f,d,'evaluation') for f,d in farms.items()}
        m,c=compare(farms,evaluation,'evaluation',model,selected)
        g=checks(m,c,selected)
        ci=pd.read_csv(OUT/'evaluation_paired_blocks.csv')
        up=ci.query("reference=='legacy' and group=='up_ramp' and metric=='upper_miss'")
        assert len(up)==1
        outcome.update(evaluation=g,advance_to_reallocation=bool(all(g.values()) and up.high.iloc[0]<0))
    write(OUT/'completion.json',outcome)


if __name__=='__main__':
    main()
