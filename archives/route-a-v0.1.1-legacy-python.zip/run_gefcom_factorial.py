"""Fixed-protocol 2x2 architecture/representation ablation, CPU only."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='2'
from pathlib import Path
import hashlib,json,time,platform,sys
import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits
from gefcom_protocol_v2 import prepare,index,features,PKG
from gefcom2014_experiment import metrics
from strong_baselines import build_shared,order_quantile_bounds
from run_p2_2012 import build_shared_2012
from online_calibration import simulate

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_gefcom_factorial_20261103_v2'
METHODS=['R0_ind_base','R0_ind_aug','R1_shared_base','R2_shared_aug']

def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def write(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def fit_head(X,y,tr,q):
    # Fixed-lead lag-edge columns can be all NaN. They contain no training signal.
    keep=~np.isnan(X[tr]).all(axis=0)
    # Preserve protocol_v2's contiguous feature layout. Boolean column slicing
    # otherwise changes reduction order at ~1e-14 and can move bin-edge values.
    Xk=np.ascontiguousarray(X[:,keep])
    sc=StandardScaler().fit(Xk[tr]);xs=sc.transform(Xk)
    model=HistGradientBoostingRegressor(loss='quantile',quantile=q,**PKG)
    model.fit(xs[tr],y[tr])
    return model.predict(xs),dict(model=model,scaler=sc,keep=keep)

def main():
    OUT.mkdir(exist_ok=True);began=time.perf_counter();allrows=[];allchecks=[]
    spec=dict(date='2026-11-03',question='fixed-H0 2x2 ablation: independent/shared heads x explicit weather absent/present',
       methods=METHODS,model=PKG,quantiles=[.05,.95],calendar='same prepare/index as protocol_v2',
       splits={'2014':'train2012; validation seed2013Q1/scoreQ2; evaluation seedQ2/scoreH2',
               '2012':'train2009H2+2010; validation seed2011Q1/scoreQ2; evaluation seedQ2/score2011H2-2012H1'},
       calibration='per-lead signed rolling CQR 84 calendar days; full labels only after target_end<=origin; clip[0,1] after CQR',
       information='identical full B_speed curve/history columns in all cells, same 14 R2 extras in both augmented cells; h provided to shared model, implicit constant in independent head',
       column_order='canonical protocol_v2 B_speed order across all cells; no reuse of submitted interleaved-curve model predictions',
       missing_columns='training-only all-NaN columns removed per head; remaining NaNs native HistGBR',
       array_layout='C-contiguous kept features before train-only scaler fit/transform; reproduces protocol_v2 baseline floating-point reductions',
       selection='no tuning or new winner selection; all four prespecified cells reported on both previously used datasets',
       limitations=['previously evaluated dates are retrospective, not untouched','architecture contrast includes parameter-sharing and total-capacity differences under fixed per-model H0'],
       python=sys.executable,versions={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__},
       source_sha256={n:sha(ROOT/n) for n in ['run_gefcom_factorial.py','strong_baselines.py','run_p2_2012.py','gefcom_protocol_v2.py','online_calibration.py']})
    path=OUT/'protocol.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==spec,'Frozen spec changed'
    else:write(path,spec)
    for year in [2014,2012]:
        farms,sources=prepare(year);dest=OUT/f'gefcom{year}';dest.mkdir(exist_ok=True)
        write(dest/'raw_sources.json',{str(p):sha(p) for p in sources})
        pd.concat([d['calendar'] for d in farms.values()]).to_csv(dest/'calendar.csv',index=False)
        for farm,d in farms.items():
            folder=dest/f'farm_{farm:02d}';folder.mkdir(exist_ok=True)
            base=features(d,'B_speed',year);S=len(base)
            oldX,oldy,_=(build_shared if year==2014 else build_shared_2012)(d,'R2')
            extra=oldX[:,-14:].reshape(S,24,14)
            np.testing.assert_equal(oldy.reshape(S,24),d['y'])
            np.testing.assert_equal(extra[:,:,0],d['nwp'][:,:,-2])
            tr=index(d,'train',True);vs=index(d,'validation_seed');vi=index(d,'validation');ei=index(d,'evaluation')
            assert d['ends'][tr].max()<=d['origins'][vs].min()
            assert d['ends'][vi].max()<=d['origins'][ei].min()
            np.savez_compressed(folder/'samples.npz',y=d['y'],valid=d['valid'],history=d['history'],origins=d['origins'],ends=d['ends'])
            d['meta'].to_csv(folder/'issued_manifest.csv',index=False)
            for method in METHODS:
                target=folder/method;target.mkdir(exist_ok=True);start=time.perf_counter();raw=target/'heads.npz'
                if raw.exists():
                    with np.load(raw) as z:qlo=z['q05'];qhi=z['q95'];np.testing.assert_equal(z['origins'],d['origins'])
                else:
                    augment=method.endswith('aug');shared='shared' in method
                    if shared:
                        X=np.c_[np.repeat(base,24,axis=0),np.tile(np.arange(1,25),S)]
                        if augment:X=np.c_[X,extra.reshape(S*24,14)]
                        train=np.repeat(np.isin(np.arange(S),tr),24)
                        np.testing.assert_equal(d['y'].ravel().reshape(S,24),d['y'])
                        qlo,ml=fit_head(X,d['y'].ravel(),train,.05);qhi,mh=fit_head(X,d['y'].ravel(),train,.95)
                        qlo=qlo.reshape(S,24);qhi=qhi.reshape(S,24)
                        joblib.dump((ml,mh),target/'models.joblib',compress=3)
                    else:
                        qlo=np.empty((S,24));qhi=np.empty((S,24));models=[]
                        for h in range(24):
                            X=np.c_[base,extra[:,h,:]] if augment else base
                            qlo[:,h],ml=fit_head(X,d['y'][:,h],tr,.05)
                            qhi[:,h],mh=fit_head(X,d['y'][:,h],tr,.95)
                            models.append((ml,mh))
                        joblib.dump(models,target/'models.joblib',compress=3)
                    np.savez_compressed(raw,q05=qlo,q95=qhi,origins=d['origins'])
                lo,hi=order_quantile_bounds(qlo,qhi)
                for stage,seed,score in [('validation',vs,vi),('evaluation',vi,ei)]:
                    result=simulate(d['origins'],d['ends'],d['y'],lo,hi,d['valid'],seed,score,'rolling',84)
                    assert (result['max_label_end_used']<=d['origins'][score]).all()
                    np.savez_compressed(target/f'{stage}.npz',indices=score,lo=result['lo'],hi=result['hi'],
                        max_label_end=result['max_label_end_used'],n_cal=result['n_cal'])
                    pd.DataFrame(result['feedback']).to_csv(target/f'{stage}_feedback.csv',index=False)
                    for kind,L,U in [('raw',lo[score],hi[score]),('cqr',result['lo'],result['hi'])]:
                        for support in ['unclipped','clipped']:
                            l,u=(np.clip(L,0,1),np.clip(U,0,1)) if support=='clipped' else (L,U)
                            m=metrics(d['y'][score],l,u,d['valid'][score],d['history'][score,-1])
                            for g,v in m.items():allrows.append(dict(year=year,farm=farm,method=method,stage=stage,kind=kind,support=support,group=g,**v))
                allchecks.append(dict(year=year,farm=farm,method=method,train_days=len(tr),
                       validation_issued=len(vi),evaluation_issued=len(ei),evaluation_scored=int(d['valid'][ei].sum()),
                       crossing_cells=int((qlo>qhi).sum()),label_time=True,feature_tensor_order=True))
                pd.DataFrame(allrows).to_csv(OUT/'metrics_per_farm.csv',index=False);write(OUT/'checks.json',allchecks)
                print(f'{year} farm{farm:02d} {method} {time.perf_counter()-start:.1f}s elapsed={time.perf_counter()-began:.1f}s',flush=True)
        print('DATASET COMPLETE',year,flush=True)
    frame=pd.DataFrame(allrows)
    frame.groupby(['year','method','stage','kind','support','group'])[['coverage','width','IS','lower_miss','upper_miss']].mean().reset_index().to_csv(OUT/'metrics_macro.csv',index=False)
    write(OUT/'completion.json',dict(status='complete',groups=68,datasets=[2014,2012],methods=METHODS,elapsed_seconds=time.perf_counter()-began))

if __name__=='__main__':
    with threadpool_limits(limits=2):main()
