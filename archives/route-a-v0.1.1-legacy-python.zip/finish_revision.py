"""Finish artifact verification and reporting after the QRF training job."""
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_gefcom_revision_20261104'


def run(*args):
    print('RUN',*args,flush=True)
    subprocess.run([sys.executable,*args],cwd=ROOT,check=True)


def main():
    began=time.monotonic();completion=OUT/'qrf/completion.json'
    while not completion.exists():
        if time.monotonic()-began>3600:raise TimeoutError('QRF did not complete within 1h')
        log=(ROOT/'out_revision_qrf_execution.log').read_text(encoding='utf-8',errors='replace')
        if 'Traceback (most recent call last)' in log[-5000:]:raise RuntimeError('QRF failed; inspect execution log')
        time.sleep(5)
    assert json.loads(completion.read_text())['status']=='complete'
    run('apply_qrf_protection.py')
    run('analyze_revision.py')
    run('benchmark_revision.py')
    run('make_dl_figures.py','--year','2014')
    run('make_dl_figures.py','--year','2012')
    run('make_revision_overview.py')
    run('-m','unittest','test_revision_integrity','test_online_calibration','test_gefcom_tail_dynamic',
        'test_quantile_sort_factorial','test_gefcom_protocol_v2','-q')
    run('write_revision_report.py')
    print('REVISION_FINISHED',OUT/'RESULTS.md',flush=True)


if __name__=='__main__':main()
