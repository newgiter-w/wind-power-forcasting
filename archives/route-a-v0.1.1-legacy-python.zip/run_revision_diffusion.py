"""Single-farm controlled velocity diagnostic, with all controls saved."""
import os
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'): os.environ[name]='2'
from pathlib import Path
import time
import joblib
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import HistGradientBoostingRegressor
from scipy.special import ndtr
from threadpoolctl import threadpool_limits
from gefcom_protocol_v2 import prepare,index
from retrieval_diffusion import HistoryAnchor,ResidualDenoiser,VelocityDiffusion
from run_diffusion_nwp import build_anchor_features
from revision_common import OUT,write,frozen_spec,save_stage,collect,save_metrics

DEST=OUT/'diffusion'


def anchor_fit(xs,yn,tr,stop,seed=0):
    torch.manual_seed(seed); model=HistoryAnchor(xs.shape[1]);opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
    xt=torch.tensor(xs);yt=torch.tensor(yn);best=float('inf');bad=0;trace=[]
    for epoch in range(180):
        model.train();loss_sum=0.;n=0
        for ids in torch.tensor(tr)[torch.randperm(len(tr))].split(128):
            opt.zero_grad();loss=(model(xt[ids])[0]-yt[ids]).square().mean();loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(),1);opt.step();loss_sum+=loss.item()*len(ids);n+=len(ids)
        model.eval()
        with torch.no_grad(): val=(model(xt[stop])[0]-yt[stop]).square().mean().item()
        trace.append(dict(epoch=epoch+1,train_mse=loss_sum/n,stop_mse=val))
        if val<best-1e-6:
            best=val;bad=0;state={k:v.clone() for k,v in model.state_dict().items()}
        else:
            bad+=1
            if bad>=25:break
    model.load_state_dict(state);model.eval()
    with torch.no_grad():mu,latent=model(xt)
    return model,mu.numpy(),latent.numpy(),trace


def train_denoiser(clean,context,tr,stop,name,diff):
    folder=DEST/name;folder.mkdir(exist_ok=True)
    torch.manual_seed(0);net=ResidualDenoiser(context=context.shape[1],width=192,blocks=4,dropout=.1)
    generator=torch.Generator().manual_seed(9821)
    ids=np.tile(stop,4);steps=torch.randint(1000,(len(ids),),generator=generator)
    noise=torch.randn((len(ids),24),generator=generator)
    ct=torch.tensor(clean);cx=torch.tensor(context)
    z,target=diff.noisy(ct[ids],steps,noise);zero=float(target.square().mean())
    np.savez_compressed(folder/'fixed_validation_batch.npz',indices=ids,steps=steps.numpy(),noise=noise.numpy(),
        z=z.numpy(),target=target.numpy(),context=context[ids])
    path=folder/'model.pt'
    if path.exists():
        net.load_state_dict(torch.load(path,weights_only=True));net.eval()
    else:
        opt=torch.optim.AdamW(net.parameters(),lr=.0003,weight_decay=.0003);best=float('inf');bad=0;trace=[]
        for epoch in range(300):
            net.train();total=0.;n=0
            for ii in torch.tensor(tr)[torch.randperm(len(tr))].split(128):
                opt.zero_grad();loss=diff.loss(net,ct[ii],cx[ii]);loss.backward();nn.utils.clip_grad_norm_(net.parameters(),1);opt.step()
                total+=loss.item()*len(ii);n+=len(ii)
            net.eval()
            with torch.no_grad():val=(net(z,steps,cx[ids])-target).square().mean().item()
            trace.append(dict(epoch=epoch+1,train_epoch_v_mse=total/n,stop_v_mse=val,zero_v_mse=zero,skill=1-val/zero))
            if val<best-1e-6:
                best=val;bad=0;state={k:v.clone() for k,v in net.state_dict().items()}
            else:
                bad+=1
                if epoch>=49 and bad>=40:break
        net.load_state_dict(state);net.eval();torch.save(net.state_dict(),path);write(folder/'curve.json',trace)
    with torch.no_grad():
        errors=(net(z,steps,cx[ids])-target).square().numpy()
        perm=torch.randperm(len(ids),generator=torch.Generator().manual_seed(620))
        shuffled=(net(z,steps,cx[ids][perm])-target).square().mean().item()
    buckets=[]
    for start in range(0,1000,100):
        m=(steps.numpy()>=start)&(steps.numpy()<start+100)
        buckets.append(dict(start=start,cells=int(m.sum()*24),model_mse=float(errors[m].mean()),zero_mse=float(target.numpy()[m].__pow__(2).mean())))
    pd.DataFrame(buckets).to_csv(folder/'timestep_diagnostics.csv',index=False)
    write(folder/'diagnostics.json',dict(model_mse=float(errors.mean()),zero_mse=zero,skill=float(1-errors.mean()/zero),
        shuffled_context_mse=shuffled,shuffling_caution='off-manifold diagnostic; compare separately trained unconditional model'))
    print(name,'actual_zero',zero,'model',errors.mean(),'skill',1-errors.mean()/zero,flush=True)
    return net


@torch.no_grad()
def sample_batch(net,context,diff,samples=200,steps=40):
    initial=torch.randn((samples,24),generator=torch.Generator().manual_seed(8101))
    times=torch.linspace(999,0,steps).round().long();output=[]
    for start in range(0,len(context),8):
        c=torch.tensor(context[start:start+8]);count=len(c)
        z=initial.repeat(count,1);cx=c.repeat_interleave(samples,dim=0)
        for j,t in enumerate(times):
            prev=times[j+1] if j+1<len(times) else -1
            a=diff.abar[t].sqrt();b=(1-diff.abar[t]).sqrt()
            v=net(z,torch.full((len(z),),int(t),dtype=torch.long),cx) if net is not None else torch.zeros_like(z)
            clean=a*z-b*v;noise=b*z+a*v;ap=diff.abar[prev] if prev>=0 else torch.tensor(1.)
            z=ap.sqrt()*clean+(1-ap).sqrt()*noise
        output.append(z.numpy().reshape(count,samples,24))
    return np.concatenate(output)


def sample_metrics(d,ids,samples):
    y=d['y'][ids];valid=d['valid'][ids];s=samples[ids][valid];yy=y[valid]
    sorted_s=np.sort(s,axis=1);n=s.shape[1]
    coef=(2*np.arange(1,n+1)-n-1)[None,:,None]/(n*n)
    crps=np.abs(s-yy[:,None,:]).mean(axis=1)-(sorted_s*coef).sum(axis=1)
    bounded=np.clip(s,0,1)
    return dict(raw_CRPS=float(crps.mean()),
        mean_probability_below_zero=float((s<0).mean()),mean_probability_above_one=float((s>1).mean()),
        mean_clipped_daily_energy=float(bounded.sum(axis=2).mean()),actual_daily_energy=float(yy.sum(axis=1).mean()),
        mean_clipped_ramp_count=float((np.abs(np.diff(bounded,axis=2))>.1).sum(axis=2).mean()),
        actual_ramp_count=float((np.abs(np.diff(yy,axis=1))>.1).sum(axis=1).mean()))


def main():
    DEST.mkdir(parents=True,exist_ok=True)
    frozen_spec(DEST/'protocol.json',dict(farm=1,year=2014,seed=0,anchor='HistoryAnchor 96->128->64->24',
        train='2012; Q1 stop, Q2 decision, H2 retrospective only',context='train-standardized latent/mu/NWP',
        variants=['empirical','gaussian','conditional_gaussian','zero_v','unconditional','conditional'],
        sampling_pool='same Torch N(0,1) pool, seed8101; empirical per-lead inverse CDF and Gaussian share DDIM initial noise',
        diffusion='velocity, 192x4, dropout.1, lr.0003, 300 epochs/patience40, 40 steps/200 samples',
        gate='Q2 conditional IS at least2% below best simple control and unconditional; positive actual-zero skill; near-zero/up/down coverage no more than.5pp below best-simple',
        limitations='diffusion uses in-sample anchor residuals; prefix OOF is diagnostic, not silently substituted',
        expansion='no multi-farm expansion without passing Q2 gates; one seed diagnostic is not final evidence'))
    torch.set_num_threads(2);began=time.perf_counter();d=prepare(2014)[0][1]
    tr=index(d,'train',True);stop=index(d,'validation_seed',True);vi=index(d,'validation');ei=index(d,'evaluation')
    X=build_anchor_features(d);ym=float(d['y'][tr].mean());ys=float(d['y'][tr].std());yn=((d['y']-ym)/ys).astype('float32')
    sc=StandardScaler().fit(X[tr]);xs=sc.transform(X).astype('float32');joblib.dump(sc,DEST/'anchor_scaler.joblib')
    anchor,mu,latent,trace=anchor_fit(xs,yn,tr,stop);torch.save(anchor.state_dict(),DEST/'anchor.pt');write(DEST/'anchor_curve.json',trace)
    residual=yn-mu;scale=residual[tr].std(axis=0).clip(min=.1);clean=(residual/scale).astype('float32')
    # Prefix OOF: early-stop quarter belongs strictly before the predicted quarter.
    oof=np.full_like(residual,np.nan);checks=[]
    for end,next_end in [(.5,.75),(.75,1.)]:
        prior=tr[:int(len(tr)*end)];pred=tr[int(len(tr)*end):int(len(tr)*next_end)]
        fit=prior[:int(len(prior)*.75)];astop=prior[int(len(prior)*.75):]
        assert d['ends'][fit].max()<=d['origins'][astop].min()
        assert d['ends'][astop].max()<=d['origins'][pred].min()
        oscaler=StandardScaler().fit(X[fit]);ox=oscaler.transform(X).astype('float32')
        _,omu,_,_=anchor_fit(ox,yn,fit,astop)
        oof[pred]=yn[pred]-omu[pred]
        checks.append(dict(fit_end=str(d['ends'][fit].max()),stop_end=str(d['ends'][astop].max()),predict_start=str(d['origins'][pred].min())))
    write(DEST/'oof_checks.json',checks)
    moments=[]
    groups=[('train',tr),('prefix_oof',np.flatnonzero(np.isfinite(oof).all(axis=1))),('Q1',stop),('Q2',vi)]
    for label,idx in groups:
        rr=oof[idx] if label=='prefix_oof' else residual[idx]
        finite=np.isfinite(rr).all(axis=1);rr=rr[finite]
        moments.append(dict(stage=label,origins=len(rr),mean=float(rr.mean()),std=float(rr.std()),
            normalized_second_moment=float((rr/scale).__pow__(2).mean()),
            lag1_correlation=float(np.corrcoef(rr[:,:-1].ravel(),rr[:,1:].ravel())[0,1])))
    write(DEST/'residual_moments.json',moments)
    ctxraw=np.c_[latent,mu,X[:,24:]].astype('float32');csc=StandardScaler().fit(ctxraw[tr]);ctx=csc.transform(ctxraw).astype('float32')
    joblib.dump(csc,DEST/'context_scaler.joblib');diff=VelocityDiffusion()
    nets={name:train_denoiser(clean,ctx if name=='conditional' else np.zeros((len(X),1),dtype='float32'),tr,stop,name,diff)
          for name in ['unconditional','conditional']}
    np.savez_compressed(DEST/'anchor_residuals.npz',mu=mu,latent=latent,residual=residual,clean=clean,scale=scale,
        oof_residual=oof,context=ctx,y=d['y'],valid=d['valid'],history=d['history'],origins=d['origins'],ends=d['ends'],ym=ym,ys=ys)
    # Simple controls share this exact anchor; conditional scale is fitted on OOF targets.
    rr=residual[tr];zpool=torch.randn((200,24),generator=torch.Generator().manual_seed(8101)).numpy()
    empirical_residual=np.stack([np.quantile(rr[:,h],ndtr(zpool[:,h])) for h in range(24)],axis=1)
    empirical=mu[:,None,:]+empirical_residual[None,:,:]
    constant=mu[:,None,:]+rr.mean(axis=0)[None,None,:]+zpool[None,:,:]*rr.std(axis=0)[None,None,:]
    om=np.isfinite(oof).all(axis=1)
    variance=HistGradientBoostingRegressor(max_iter=50,max_leaf_nodes=7,min_samples_leaf=100,early_stopping=False,random_state=0)
    vx=np.c_[np.repeat(xs,24,axis=0),np.tile(np.arange(24),len(xs))]
    variance.fit(vx[np.repeat(om,24)],np.log(oof[om].ravel()**2+1e-3))
    sd=np.sqrt(np.exp(variance.predict(vx))).reshape(-1,24)
    # Correct log-squared-error Jensen bias using only held-out Q1 labels.
    multiplier=np.sqrt(np.nanmean((residual[stop]/sd[stop])**2))
    condgauss=mu[:,None,:]+zpool[None,:,:]*sd[:,None,:]*multiplier
    joblib.dump(dict(model=variance,multiplier=multiplier),DEST/'conditional_scale.joblib',compress=3)
    samples={'empirical':empirical,'gaussian':constant,'conditional_gaussian':condgauss}
    forecast=np.flatnonzero(~d['meta'].phase.eq('train').to_numpy())
    for name in ['zero_v','unconditional','conditional']:
        c=ctx[forecast] if name!='unconditional' else np.zeros((len(forecast),1),dtype='float32')
        ss=sample_batch(nets.get(name),c,diff)
        full=np.full((len(X),200,24),np.nan,dtype='float32');full[forecast]=mu[forecast,None,:]+ss*scale
        samples[name]=full
        print('sampled',name,flush=True)
    rows=[];sample_rows=[]
    for name,s in samples.items():
        s=s*ys+ym;folder=DEST/name;folder.mkdir(exist_ok=True)
        lo,hi=np.quantile(s,.05,axis=1),np.quantile(s,.95,axis=1)
        np.savez_compressed(folder/'samples.npz',samples=s[forecast].astype('float32'),indices=forecast)
        np.savez_compressed(folder/'heads.npz',lo=lo,hi=hi,origins=d['origins'])
        for stage in ['validation']:
            ids,res=save_stage(folder,d,lo,hi,stage)
            for kind,ll,uu in [('raw',np.clip(lo[ids],0,1),np.clip(hi[ids],0,1)),('signed',np.clip(res['lo'],0,1),np.clip(res['hi'],0,1))]:
                collect(rows,d,ids,ll,uu,year=2014,farm=1,seed=0,stage=stage,method=name+'_'+kind)
            sample_rows.append(dict(method=name,stage=stage,**sample_metrics(d,ids,s)))
    df=pd.DataFrame(rows);allm=df[(df.group=='all')&df.method.str.endswith('_signed')].set_index('method')
    simple=min(['empirical','gaussian','conditional_gaussian','zero_v'],key=lambda n:allm.loc[n+'_signed','IS'])
    best=float(allm.loc[simple+'_signed','IS']);cond=float(allm.loc['conditional_signed','IS']);uncond=float(allm.loc['unconditional_signed','IS'])
    from json import loads
    diag=loads((DEST/'conditional/diagnostics.json').read_text())
    coverage_gates=all(float(df[(df.method=='conditional_signed')&(df.group==g)].coverage.iloc[0])>=float(df[(df.method==simple+'_signed')&(df.group==g)].coverage.iloc[0])-.005 for g in ['near_zero','up_ramp','down_ramp'])
    passed=bool(cond<=.98*best and cond<=.98*uncond and diag['skill']>0 and coverage_gates)
    write(DEST/'selection.json',dict(expand=passed,best_simple=simple,best_simple_IS=best,conditional_IS=cond,unconditional_IS=uncond,
        coverage_gates=coverage_gates,reason='Q2 criteria met; multi-seed confirmation still needed' if passed else 'Q2 criteria not met; stop expansion; no Gaussianity claim'))
    # Only after recording the Q2 decision, produce retrospective H2 comparisons.
    for name in samples:
        folder=DEST/name
        with np.load(folder/'heads.npz') as z:lo,hi=z['lo'],z['hi']
        ids,res=save_stage(folder,d,lo,hi,'evaluation')
        for kind,ll,uu in [('raw',np.clip(lo[ids],0,1),np.clip(hi[ids],0,1)),('signed',np.clip(res['lo'],0,1),np.clip(res['hi'],0,1))]:
            collect(rows,d,ids,ll,uu,year=2014,farm=1,seed=0,stage='evaluation',method=name+'_'+kind)
        sample_rows.append(dict(method=name,stage='evaluation',**sample_metrics(d,ids,samples[name]*ys+ym)))
    save_metrics(DEST,rows);pd.DataFrame(sample_rows).to_csv(DEST/'sample_metrics.csv',index=False)
    write(DEST/'completion.json',dict(status='complete',farm=1,seed=0,expand=passed,elapsed_seconds=time.perf_counter()-began))


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
