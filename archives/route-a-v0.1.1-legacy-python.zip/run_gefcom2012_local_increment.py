"""Fit and evaluate a gated residual correction to the frozen QRF increments."""
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
import joblib

from diagnose_gefcom2012_data_attribution import BASE, YEAR, ROOT, load_farms, feature_array, match_truth
from pooling_common import local_heads
from revision_common import calibration, frozen_spec, write

OUT=ROOT/'out_gefcom2012_local_increment'
CUTOFF=np.datetime64('2011-05-16')
STRENGTHS=(.5,1.)
COLS=('events','hits','signed','absolute','quiet','false','hours','all_absolute')
RATES=('recall','bias','mae','quiet_fpr','all_mae')


def load_stage(farms,stage,year=YEAR):
    records=[]
    for farm,d in farms.items():
        ids,res=calibration(d,*local_heads(year,farm,'QRF',0),stage)
        with np.load(BASE/f'gefcom{year}/farm_{farm:02}/{stage}_direct_qrf.npz') as z:
            np.testing.assert_array_equal(ids,z['ids'])
            for key in ('lo','hi'):
                np.testing.assert_array_equal(np.clip(res[key],0,1),z[key])
        ids=ids[d['valid'][ids]]
        with np.load(BASE/f'gefcom{year}/farm_{farm:02}/heads.npz') as z:
            np.testing.assert_array_equal(z['origins'],d['origins'])
            med=z['qrf'][ids]
        last=d['history'][ids,-1,None]
        before=np.concatenate([last,med[:,:-1]],axis=1)
        base=med-before
        actual=np.diff(d['y'][ids],axis=1,prepend=last)
        wind=feature_array(year,farm,'GBM')[:,-14:-12].reshape(-1,24,2)[ids]
        speed=np.linalg.norm(wind,axis=2)
        dw=np.diff(speed,axis=1,prepend=np.full((len(ids),1),np.nan))
        turn=wind/np.maximum(speed[...,None],1.)
        turn_delta=np.diff(turn,axis=1,prepend=turn[:,:1])
        direction_change=np.linalg.norm(turn_delta,axis=2)
        lead=np.broadcast_to(np.arange(1,25),base.shape)
        features=np.stack([base,before,med,speed,dw,direction_change,turn[:,:,0],turn[:,:,1],lead],axis=-1)
        gate=dw>=.5
        assert np.isfinite(features[gate]).all() and not gate[:,0].any()
        records.append(dict(farm=farm,origins=d['origins'][ids],ends=d['ends'][ids],base=base,
            before=before,actual=actual,gate=gate,features=features))
    return records


def dev_fit(records,cutoff=CUTOFF,out=OUT):
    x,y=[],[]
    for r in records:
        eligible=r['gate']&(r['ends']<=cutoff)[:,None]
        x.append(r['features'][eligible])
        y.append((r['actual']-r['base'])[eligible])
    x,y=np.concatenate(x),np.concatenate(y)
    model=make_pipeline(StandardScaler(),Ridge(alpha=10.))
    model.fit(x,y)
    joblib.dump(model,out/'ridge.joblib')
    write(out/'fit.json',dict(rows=len(y),cutoff=str(cutoff),mean_training_residual=float(y.mean())))
    return model


def score(model,records,strength,dev=False,cutoff=CUTOFF):
    scored=[]
    for r in records:
        use=r['origins']>=cutoff if dev else np.ones(len(r['origins']),dtype=bool)
        z={k:v[use] for k,v in r.items() if k!='farm'}
        gate=z['gate']
        pred=z['base'].copy()
        change=np.clip(strength*model.predict(z['features'][gate]),-.10,.10)
        pred[gate]=np.clip(pred[gate]+change,-z['before'][gate],1-z['before'][gate])
        np.testing.assert_array_equal(pred[~gate],z['base'][~gate])
        scored.append(dict(**z,farm=r['farm'],candidate=pred))
    return scored


def threshold(records):
    """Match the baseline number of quiet alarms in gated hours."""
    count=0
    values=[]
    for r in records:
        quiet=(np.abs(r['actual'])<=.05)&r['gate']
        count+=int((r['base'][quiet]>.10).sum())
        values.append(r['candidate'][quiet])
    v=np.sort(np.concatenate(values))[::-1]
    assert len(v)>count>0
    if v[count-1]>v[count]:
        cutoff=float(v[count-1]+(v[count]-v[count-1])/2)
    else:
        # Preserve a single numerical threshold if ties prevent an exact match.
        cutoffs=[v[count],np.nextafter(v[count],-np.inf)]
        cutoff=float(min(cutoffs,key=lambda t:abs((v>t).sum()-count)))
    return cutoff


def daily(records,cutoff,operation):
    rows=[]
    for r in records:
        y,gate=r['actual'],r['gate']
        up,quiet=y>.10,np.abs(y)<=.05
        for name,p in [('original',r['base']),('corrected',r['candidate'])]:
            limit=np.where(gate,cutoff,.10) if name=='corrected' else .10
            alarm=p>limit
            hit=match_truth(up,alarm)
            err=p-y
            for scope,keep in [('gated',gate),('all',np.ones_like(gate))]:
                u,q=keep&up,keep&quiet
                stats=[u,u&hit,np.where(u,err,0),np.where(u,np.abs(err),0),
                       q,q&alarm,keep,np.where(keep,np.abs(err),0)]
                counts=np.column_stack([v.sum(axis=1) for v in stats])
                rows.append(pd.DataFrame(counts,columns=COLS).assign(farm=r['farm'],origin=r['origins'],
                                    model=name,scope=scope,operation=operation))
    return pd.concat(rows,ignore_index=True)


def rates(a):
    events,hits,bias,mae,quiet,false,hours,overall=np.moveaxis(a,-1,0)
    return np.stack([hits/events,bias/events,mae/events,false/quiet,overall/hours],axis=-1)


def summarize(df):
    m=df.groupby(['operation','scope','model'])[list(COLS)].sum()
    return m.join(pd.DataFrame(rates(m.to_numpy()),index=m.index,columns=RATES))


def gates(m,operation):
    a,b=(m.loc[(operation,'gated',k)] for k in ('original','corrected'))
    all_a,all_b=(m.loc[(operation,'all',k)] for k in ('original','corrected'))
    return dict(bias=bool(abs(b.bias)<abs(a.bias)),mae=bool(b.mae<a.mae),
        timing=bool(b.recall>a.recall),quiet=bool(b.quiet_fpr<=a.quiet_fpr),
        all_quiet=bool(all_b.quiet_fpr<=all_a.quiet_fpr),all_gated_mae=bool(b.all_mae<=a.all_mae))


def paired(df):
    dates=pd.date_range(df.origin.min(),df.origin.max())
    rng=np.random.default_rng(20120516)
    n=len(dates)
    start=rng.integers(0,n-13,size=(2000,int(np.ceil(n/14))))
    take=(start[:,:,None]+np.arange(14)).reshape(2000,-1)[:,:n]
    rows=[]
    for (op,scope),g in df.groupby(['operation','scope']):
        a=np.stack([g[g.model.eq(name)].groupby('origin')[list(COLS)].sum().reindex(dates,fill_value=0).to_numpy()
                    for name in ('original','corrected')])
        sim=rates(a[:,take].sum(axis=2))
        draws=sim[1]-sim[0]
        point=rates(a.sum(axis=1))
        lo,hi=np.quantile(draws,[.025,.975],axis=0)
        rows.extend(dict(operation=op,scope=scope,metric=k,delta=d,low=l,high=h)
                    for k,d,l,h in zip(RATES,point[1]-point[0],lo,hi))
    return pd.DataFrame(rows)


def main(year=YEAR):
    cutoff = np.datetime64('2013-05-16') if year==2014 else CUTOFF
    out = ROOT/f'out_gefcom{year}_local_increment'
    n_farms = 10 if year==2014 else 7
    frozen_spec(out/'protocol.json',dict(year=year,farms=n_farms,gate='same-batch NWP wind speed rise >=0.5 m/s, h1 ineligible',
        base='frozen original median increments and interval endpoints; no accumulation or interval update',
        fit=f'Q2 targets arrived by {cutoff}; pooled standardized ridge alpha10, target actual minus QRF increment, 9 issue-time inputs',
        dev=f'Q2 origins from {cutoff}; strengths .5 and 1; cap absolute correction 10pp and preserve power support using original prior-hour level',
        decision='among passing dev settings select greatest gated recall then least gated true-up MAE; if none pass same ranking for diagnosis only',
        alarms='baseline increment >10pp; corrected threshold fitted to original gated quiet count in late Q2, ungated threshold unchanged; exact evaluation match is retrospective',
        gates='gated real-ramp bias magnitude and MAE improve, ±1h recall improves, no increase gated or overall quiet FPR, gated all-hour MAE not worse',
        inference='historical evaluation 14-calendar-day moving paired blocks, synchronized across farms; fixed thresholds conditional'))
    farms=load_farms(year)
    assert list(farms)==list(range(1,n_farms+1))
    dev=load_stage(farms,'validation',year)
    model=dev_fit(dev,cutoff,out)
    options={}
    dev_rows=[]
    for s in STRENGTHS:
        records=score(model,dev,s,dev=True,cutoff=cutoff)
        alarm_cutoff=threshold(records)
        name=str(s)
        frame=daily(records,alarm_cutoff,name)
        m=summarize(frame)
        gate=gates(m,name)
        row=m.loc[(name,'gated','corrected')]
        options[name]=dict(strength=s,threshold=alarm_cutoff,checks=gate,recall=float(row.recall),mae=float(row.mae))
        dev_rows.append(frame)
    candidates=[v for v in options.values() if all(v['checks'].values())]
    pick=min(candidates or options.values(),key=lambda v:(-v['recall'],v['mae'],v['strength']))
    frozen_spec(out/'selection.json',dict(chosen=pick,dev_pass=bool(candidates),candidates=options))
    summarize(pd.concat(dev_rows)).to_csv(out/'development_summary.csv')
    records=score(model,load_stage(farms,'evaluation',year),pick['strength'])
    exact=threshold(records)
    ev=pd.concat([daily(records,pick['threshold'],'frozen'),daily(records,exact,'exact_fpr')])
    ev.to_csv(out/'evaluation_daily.csv',index=False)
    m=summarize(ev)
    m.to_csv(out/'evaluation_summary.csv')
    ci=paired(ev)
    ci.to_csv(out/'evaluation_paired_blocks.csv',index=False)
    decisions={op:gates(m,op) for op in ('frozen','exact_fpr')}
    strong=ci.query("scope=='gated' and operation=='frozen' and metric=='recall'").low.iloc[0]>0
    write(out/'completion.json',dict(status='complete',chosen=pick,dev_pass=bool(candidates),
        evaluation=decisions,exact_fpr_threshold=exact,
        advance_to_upper=bool(candidates and all(all(g.values()) for g in decisions.values()) and strong)))
    print('DEVELOPMENT',options,flush=True)
    print(m.round(6).to_string(),flush=True)
    print(ci.query("scope=='gated'").round(6).to_string(index=False),flush=True)


if __name__=='__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--year',type=int,choices=(2012,2014),default=YEAR)
    main(parser.parse_args().year)


