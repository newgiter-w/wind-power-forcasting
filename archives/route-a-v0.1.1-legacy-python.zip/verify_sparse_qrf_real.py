"""Real saved-local-forest equivalence witness before pooled sparse fitting."""
from pathlib import Path
import copy
import gc
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'.aris/qrf-packages'))
import joblib
import numpy as np
from gefcom_protocol_v2 import index
from pooling_common import OUT,REVISION,write,load_farms,feature_array
from sparse_leaf_qrf import SparseLeafQRF


def main():
    checks=[]
    for year in [2014,2012]:
        d=load_farms(year)[1];tm=np.repeat(np.isin(np.arange(len(d['y'])),index(d,'train',True)),24)
        X=feature_array(year,1,'QRF');y=d['y'].ravel()[tm]
        model=joblib.load(REVISION/f'qrf/gefcom{year}/farm_01/leaf_10/seed_0/model.joblib')['model']
        sparse=SparseLeafQRF();sparse.forest=copy.copy(model);sparse.forest.forest_=None
        sparse.build_responses(X[tm],y)
        query=np.r_[np.flatnonzero(tm)[::101],np.flatnonzero(~tm)[::127]]
        expected=model.predict(X[query],quantiles=[.05,.95],weighted_quantile=True,weighted_leaves=True,aggregate_leaves_first=True)
        predicted=sparse.predict(X[query]);delta=float(np.abs(expected-predicted).max())
        np.testing.assert_allclose(predicted,expected,atol=1e-10,rtol=1e-10)
        checks.append(dict(year=year,farm=1,trees=500,queries=len(query),max_abs_error=delta,
            sparse_storage_bytes=sparse.storage_bytes(),dense_leaf_bytes=np.asarray(model.forest_.y_train_leaves).nbytes))
        del model,sparse;gc.collect()
    write(OUT/'sparse_qrf_equivalence.json',dict(status='passed',checks=checks,
        method='same trees, all bootstrap responses, inverse leaf-size weights, same compiled quantile kernel; no truncation'))
    print(checks,flush=True)


if __name__=='__main__':main()
