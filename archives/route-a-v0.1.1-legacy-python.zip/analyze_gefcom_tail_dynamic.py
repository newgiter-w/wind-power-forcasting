"""Independent saved-array recheck, conditional diagnostics and paired blocks."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='2'
from pathlib import Path
import json
import numpy as np
import pandas as pd
from gefcom2014_experiment import metrics,masks
from run_gefcom_tail_dynamic import OUT,ROOT,METHODS,GROUPS,write,sha

METS=['coverage','width','IS','lower_miss','upper_miss']

def counts(y,L,U,mask):
    width=U-L;hit=(y>=L)&(y<=U)
    score=width+20*np.maximum(L-y,0)+20*np.maximum(y-U,0)
    return np.stack([mask.sum(axis=1),(hit&mask).sum(axis=1),
        np.where(mask,width,0).sum(axis=1),np.where(mask,score,0).sum(axis=1),
        ((y<L)&mask).sum(axis=1),((y>U)&mask).sum(axis=1)],axis=-1)

def aggregate(daily):
    t=daily.sum(axis=2)
    return np.nanmean(np.divide(t[:,:,:,1:],t[:,:,:,0,None],
        out=np.full(t[:,:,:,1:].shape,np.nan),where=t[:,:,:,0,None]>0),axis=1)

def main():
    completion=json.loads((OUT/'completion.json').read_text())
    assert completion['status']=='complete' and completion['stage_groups']==238
    spec=json.loads((OUT/'protocol.json').read_text())
    for name,digest in spec['source_sha256'].items():assert sha(ROOT/name)==digest,name
    table=pd.read_csv(OUT/'metrics_per_farm.csv')
    assert len(table)==4760
    reference=table.set_index(['year','farm','method','stage','kind','support','group'])
    diag=[];leadrows=[];monthrows=[];rawrows=[];allstats=[];checks=[];services=[]
    for year in [2014,2012]:
        folders=sorted((OUT/f'gefcom{year}').glob('farm_*'));F=len(folders)
        dates=pd.date_range('2013-07-01' if year==2014 else '2011-07-01',
            '2013-12-31' if year==2014 else '2012-06-27',freq='D')
        daily=np.zeros((len(METHODS),F,len(dates),len(GROUPS),6))
        calendars=[]
        for f,folder in enumerate(folders):
            farm=int(folder.name.split('_')[-1]);calendars.append(pd.read_csv(folder/'calendar.csv'))
            with np.load(folder/'samples.npz') as z:
                yy=z['y'];history=z['history'];valid=z['valid'];origins=z['origins']
            common={}
            for j,method in enumerate(METHODS):
                target=folder/method
                with np.load(target/'raw.npz') as z:
                    rawlo=z['lo'];rawhi=z['hi'];np.testing.assert_array_equal(z['origins'],origins)
                for stage in ['validation','evaluation']:
                    with np.load(target/f'{stage}.npz') as z:
                        idx=z['indices'];L=z['lo'];U=z['hi'];ncal=z['n_cal']
                        assert (z['max_label_end']<=origins[idx]).all()
                    if stage in common:np.testing.assert_array_equal(common[stage],idx)
                    else:common[stage]=idx.copy()
                    assert np.isfinite(L).all() and np.isfinite(U).all() and (L<=U).all()
                    y=yy[idx];v=valid[idx];last=history[idx,-1];gs=masks(y,last)
                    for kind,ll,uu in [('raw',rawlo[idx],rawhi[idx]),('cqr',L,U)]:
                        for support in ['unclipped','clipped']:
                            l,u=(np.clip(ll,0,1),np.clip(uu,0,1)) if support=='clipped' else (ll,uu)
                            mm=metrics(y,l,u,v,last)
                            for g,values in mm.items():
                                ref=reference.loc[(year,farm,method,stage,kind,support,g)]
                                for metric in METS+['cells','origins']:
                                    assert np.isclose(values[metric],ref[metric],atol=1e-12,rtol=1e-10),(year,farm,method,stage,g,metric)
                    l=np.clip(L,0,1);u=np.clip(U,0,1);lead=np.broadcast_to(np.arange(1,25),y.shape)
                    for group,mask in gs.items():
                        for block,lm in [('all',lead>0),('01-06',lead<=6),('07-12',(lead>=7)&(lead<=12)),('13-24',lead>=13)]:
                            m=mask&lm&v[:,None];s=counts(y,l,u,m).sum(axis=0);n=s[0]
                            vals={key:float(s[k+1]/n) if n else None for k,key in enumerate(METS)}
                            diag.append(dict(year=year,farm=farm,method=method,stage=stage,group=group,lead_block=block,
                                cells=int(n),origins=int(m.any(axis=1).sum()),**vals))
                    for h in range(24):
                        m=np.zeros_like(y,bool);m[:,h]=v;s=counts(y,l,u,m).sum(axis=0);n=s[0]
                        leadrows.append(dict(year=year,farm=farm,method=method,stage=stage,lead=h+1,
                            cells=int(n),**{key:float(s[k+1]/n) for k,key in enumerate(METS)}))
                    months=pd.DatetimeIndex(origins[idx]).strftime('%Y-%m')
                    for month in sorted(set(months)):
                        mv=v&(months==month);mm=metrics(y,l,u,mv,last)
                        for group,values in mm.items():monthrows.append(dict(year=year,farm=farm,method=method,stage=stage,month=month,group=group,**values))
                    # Endpoint pinball is reported literally; C2 endpoints include conditional tail correction.
                    a=y-rawlo[idx];b=y-rawhi[idx]
                    rawrows.append(dict(year=year,farm=farm,method=method,stage=stage,
                        endpoint_pinball05=float(np.maximum(.05*a,-.95*a)[v].mean()),
                        endpoint_pinball95=float(np.maximum(.95*b,-.05*b)[v].mean()),
                        raw_width_clipped=float((np.clip(rawhi[idx],0,1)-np.clip(rawlo[idx],0,1))[v].mean()),
                        cqr_width_clipped=float((u-l)[v].mean())))
                    if stage=='evaluation':
                        pos=dates.get_indexer(pd.to_datetime(origins[idx]));assert (pos>=0).all()
                        for g,group in enumerate(GROUPS):daily[j,f,pos,g]=counts(y,l,u,gs[group]&v[:,None])
                    checks.append(dict(year=year,farm=farm,method=method,stage=stage,metrics_exact=True,
                        paired_origins=True,causal_feedback=True,min_calibration_days=int(ncal.min())))
        calendar=pd.concat(calendars);calendar=calendar[calendar.phase=='evaluation']
        services.append(dict(year=year,calendar_farm_days=len(calendar),issued_farm_days=int(calendar.input_valid.sum()),
            scored_farm_days=int((calendar.input_valid&calendar.target_valid).sum()),
            service_rate=float(calendar.input_valid.mean())))
        point=aggregate(daily)
        expected=table[(table.year==year)&(table.stage=='evaluation')&(table.kind=='cqr')&(table.support=='clipped')]
        for j,method in enumerate(METHODS):
            for g,group in enumerate(GROUPS):
                ref=expected[(expected.method==method)&(expected.group==group)][METS].mean().to_numpy()
                np.testing.assert_allclose(point[j,g],ref,atol=1e-12,rtol=1e-10)
        np.savez_compressed(OUT/f'gefcom{year}_paired_daily.npz',daily=daily,dates=dates.to_numpy(),methods=METHODS,groups=GROUPS)
        contrasts={}
        for method in METHODS[1:]:
            for baseline in ['R0_reference','C0_symmetric']:
                if method==baseline:continue
                c=np.zeros(len(METHODS));c[METHODS.index(method)]=1;c[METHODS.index(baseline)]=-1
                contrasts[f'{method}_minus_{baseline}']=c
        for a,b in [('C2_risk','C1_asymmetric'),('D11_dynamic150','D01_base150'),('D11_dynamic150','D10_dynamic50')]:
            c=np.zeros(len(METHODS));c[METHODS.index(a)]=1;c[METHODS.index(b)]=-1;contrasts[f'{a}_minus_{b}']=c
        c=np.zeros(len(METHODS))
        for name,sign in [('C0_symmetric',1),('D01_base150',-1),('D10_dynamic50',-1),('D11_dynamic150',1)]:c[METHODS.index(name)]=sign
        contrasts['dynamic_capacity_interaction']=c
        for block in [7,14]:
            B=2000;D=len(dates);rng=np.random.default_rng(20261103+block);weights=np.zeros((B,D))
            for b in range(B):
                starts=rng.integers(0,D-block+1,size=int(np.ceil(D/block)))
                idx=np.concatenate([np.arange(s,s+block) for s in starts])[:D];weights[b]=np.bincount(idx,minlength=D)
            total=np.einsum('bd,mfdgs->bmfgs',weights,daily,optimize=True)
            boots=np.nanmean(np.divide(total[:,:,:,:,1:],total[:,:,:,:,0,None],
                out=np.full(total[:,:,:,:,1:].shape,np.nan),where=total[:,:,:,:,0,None]>0),axis=2)
            for name,c in contrasts.items():
                delta=np.einsum('m,mgk->gk',c,point);bs=np.einsum('m,bmgk->bgk',c,boots)
                for g,group in enumerate(GROUPS):
                    for k,metric in enumerate(METS):
                        allstats.append(dict(year=year,contrast=name,group=group,metric=metric,block_days=block,
                            resamples=B,delta=float(delta[g,k]),low95=float(np.quantile(bs[:,g,k],.025)),high95=float(np.quantile(bs[:,g,k],.975))))
            print(year,'paired blocks',block,'complete',flush=True)
    pd.DataFrame(checks).to_csv(OUT/'array_checks.csv',index=False)
    frame=pd.DataFrame(diag);frame.to_csv(OUT/'group_lead_per_farm.csv',index=False)
    frame.groupby(['year','method','stage','group','lead_block'])[METS].mean().reset_index().to_csv(OUT/'group_lead_macro.csv',index=False)
    pd.DataFrame(leadrows).to_csv(OUT/'per_lead.csv',index=False)
    pd.DataFrame(monthrows).to_csv(OUT/'monthly_per_farm.csv',index=False)
    pd.DataFrame(monthrows).groupby(['year','method','stage','month','group'])[METS+['cells','origins']].mean().reset_index().to_csv(OUT/'monthly_macro.csv',index=False)
    pd.DataFrame(rawrows).to_csv(OUT/'raw_endpoint_diagnostics.csv',index=False)
    pd.DataFrame(services).to_csv(OUT/'service.csv',index=False)
    pd.DataFrame(allstats).to_csv(OUT/'paired_bootstrap.csv',index=False)
    write(OUT/'verification.json',dict(status='passed',checked_stage_groups=len(checks),metric_rows_recomputed=4760,
        all_training_source_hashes_unchanged=True,paired_origins=True,causal_feedback=True,
        OOF_blocks=len(json.loads((OUT/'oof_checks.json').read_text())),analysis_sha256=sha(Path(__file__)),
        bootstrap='2000 resamples,7/14-day blocks,synchronous calendar across farms/methods; macro ratios; unadjusted exploratory CIs',
        inference_scope='fixed farms,seed0,already observed historical evaluation dates'))

if __name__=='__main__':main()
