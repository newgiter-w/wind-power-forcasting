"""Complete-model comparison from independently recomputed macro metrics."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from revision_common import ROOT,OUT,write


def main():
    data=pd.read_csv(OUT/'evaluation_macro.csv')
    dest=ROOT/'paper/gefcom_nwp_interval/figures/revision_20261104';dest.mkdir(exist_ok=True,parents=True)
    methods=['R2','MLP_q05','MLP_q05_protected','QRF','QRF_protected']
    labels=['R2','MLP','MLP + guard','QRF','QRF + guard (exploratory)']
    colors=['#555555','#86b9d5','#176b9c','#edb576','#b4610f']
    groups=['all','up_ramp','down_ramp','near_zero']
    for year in [2014,2012]:
        frame=data[data.year==year].set_index(['method','group'])
        fig,axes=plt.subplots(1,3,figsize=(14,4.5));x=np.arange(4);source=[]
        for ax,metric,title in zip(axes,['coverage','width','IS'],['Coverage (%)','Width (% capacity)','Interval score']):
            factor=100 if metric!='IS' else 1
            for j,(method,label,color) in enumerate(zip(methods,labels,colors)):
                values=np.array([frame.loc[(method,g),metric] for g in groups])*factor
                ax.bar(x+(j-2)*.15,values,.145,label=label,color=color)
                for g,v in zip(groups,values):source.append(dict(year=year,method=method,group=g,metric=metric,value=v))
            ax.set_xticks(x,['All','Up ramp','Down ramp','Near zero'],rotation=15)
            ax.set_title(title);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
            if metric=='coverage':ax.set_ylim(0,100);ax.axhline(90,ls='--',color='#999999',lw=.8)
        handles,ll=axes[0].get_legend_handles_labels();fig.legend(handles,ll,loc='upper center',ncol=5,fontsize=9)
        fig.tight_layout(rect=(0,0,1,.89));fig.savefig(dest/f'fig_all_models_{year}.png',dpi=180);plt.close(fig)
        pd.DataFrame(source).to_csv(dest/f'fig_all_models_{year}_data.csv',index=False)
    write(dest/'overview_sources.json',dict(source=str(OUT/'evaluation_macro.csv'),
        uncertainty=str(OUT/'paired_bootstrap.csv'),values='three-seed mean within farm, then farm macro; R2 deterministic',
        QRF_guard='exploratory transfer after baseline inspection, unchanged MLP Q2 threshold',training_performed=False))
    print('overview figures saved',dest)


if __name__=='__main__':main()
