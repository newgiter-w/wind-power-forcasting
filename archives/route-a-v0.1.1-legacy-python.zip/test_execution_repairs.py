"""Focused checks for the protocol mistakes fixed before X01."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

import evaluate as ev
import intervals as iv
from experiment import analog_quantiles, neighbor_stats, run_task, select_candidates

root=Path(__file__).parent
spec=importlib.util.spec_from_file_location('kelmarsh_statistics_test',root/'statistics.py')
stats=importlib.util.module_from_spec(spec)
spec.loader.exec_module(stats)


class RepairChecks(unittest.TestCase):
    def test_nominal_analog_is_not_representation_quantiles(self):
        targets=np.arange(20,dtype=float)[None,:,None]
        lo,hi=analog_quantiles(targets,.9)
        self.assertAlmostEqual(float(lo[0,0]),.95)
        self.assertAlmostEqual(float(hi[0,0]),18.05)
        _,_,_,q10,q90=neighbor_stats(targets,np.ones((1,20)))
        self.assertAlmostEqual(float(q10[0,0]),1.9)
        self.assertAlmostEqual(float(q90[0,0]),17.1)

    def test_rd_is_in_candidate_selection(self):
        task=lambda score:{'cqr':{'score':score}}
        b,r=select_candidates({'N0_H0':task(1),'NH_H0':task(.9),
                               'R0_dtw_H1':task(.8),'RD_dtw_H1':task(.7),
                               'R0_dtw_random0_H1':task(.1)})
        self.assertEqual((b,r),('NH_H0','RD_dtw_H1'))

    def test_moving_calendar_preserves_gaps_and_ratio(self):
        full=pd.date_range('2021-04-01',periods=35,freq='D')
        dates=full.delete([3,4,10])
        b=np.arange(1,len(dates)+1,dtype=float)
        result=stats.paired_comparison(.9*b,b,dates,7,n_resample=500)
        self.assertEqual(result['calendar_days'],35)
        self.assertEqual(result['valid_origins'],32)
        np.testing.assert_allclose(result['gain_ci95'],[.1,.1],atol=1e-14)
        padded=stats.calendar_blocks(dates[:-1],7,calendar_start=full[0],calendar_end=full[-1])
        self.assertEqual(padded['n_days'],35)

    def test_decision_uses_point_delta_not_lower_delta(self):
        thresholds={'min_relative_IS_improvement':.02,'coverage_tolerance':[.88,.92]}
        primary={'gain':.03,'gain_ci95':[.005,.06]}
        random={'gain':.02,'gain_ci95':[.001,.04]}
        a=stats.classify_decision(primary,primary,random,.9,thresholds)
        self.assertEqual(a['decision'],'continue_conditioned_retrieval')
        a=stats.classify_decision(primary,primary,random,.944,thresholds)
        self.assertEqual(a['decision'],'insufficient_evidence')
        positive_small={'gain':.01,'gain_ci95':[.005,.015]}
        a=stats.classify_decision(positive_small,positive_small,random,.9,thresholds)
        self.assertEqual(a['decision'],'stop_current_conditioning')
        self.assertNotIn('stable',a['reason'])

    def test_score_contract_and_calibration_sign(self):
        with self.assertRaises(ValueError):
            ev.interval_score(np.array([.5]),np.array([2.]),np.array([-1.]),.1)
        y=np.array([[0.,2.],[1.,3.],[2.,4.],[3.,5.]])
        np.testing.assert_array_equal(iv.fit_cqr(y,y-2,y+2,.8),[-2.,-2.])
        with self.assertRaises(ValueError):
            iv._conformal_quantile(np.array([1.]),.95)

    def test_seeded_cpu_model_artifacts_roundtrip(self):
        rng=np.random.default_rng(71)
        X=rng.normal(size=(120,4))
        y=np.column_stack([X[:,0]+rng.normal(size=120),X[:,1]+rng.normal(size=120)])
        pkg=dict(max_iter=3,max_leaf_nodes=7,min_samples_leaf=5,l2_regularization=1.)
        with tempfile.TemporaryDirectory(prefix='kelmarsh_x01_witness_') as tmp:
            result=run_task(X[:80],y[:80],X[80:100],y[80:100],X[100:],y[100:],10.,.9,pkg,0,tmp)
            models=joblib.load(Path(tmp)/'models.joblib')
            with np.load(Path(tmp)/'predictions.npz') as arrays:
                np.testing.assert_array_equal(models['lower'].predict(X[100:]),arrays['lo_raw_score'])
            self.assertEqual(len(result['cqr_per_origin']),20)
            self.assertTrue(np.isfinite(result['cqr']['score']))
            self.assertEqual(result['package'],pkg)
            print('WITNESS seeded CPU quantile fit, calibration, model reload: PASS')


if __name__=='__main__':
    unittest.main(verbosity=2)
