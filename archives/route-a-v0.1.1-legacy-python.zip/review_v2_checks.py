"""Read-only V2 audit: cached data, split timing, baseline checks; no model training."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from config import Config
from data import load_dataframe, build_situations
from run import segment_split
from baselines import climatology
from intervals import fit_cqr, predict_cqr
from evaluate import evaluate_intervals

root=Path(__file__).parent
artifact=json.loads((root/'out'/'ablation.json').read_text())
cfg=Config(**artifact['config'])
df=load_dataframe(cfg)
d=build_situations(df,cfg)
seg=segment_split(d['origin_ts'])
ids={name:np.flatnonzero(mask & d['target_valid']) for name,mask in seg.items()}
out={'saved_config':cfg.as_dict(),'data':{'rows':len(df),'irregular_steps':int((df.timestamp.diff().dropna()!=pd.Timedelta(minutes=10)).sum()),'power_invalid_rows':int((~df.power_valid).sum()),'target_shape':list(d['target'].shape),'target_invalid_situations':int((~d['target_valid']).sum())},'segments':{}}
for name,idx in ids.items():
    out['segments'][name]={'count':len(idx),'first_origin':str(d['origin_ts'].iloc[idx[0]]),'last_origin':str(d['origin_ts'].iloc[idx[-1]]),'targets_all_finite':bool(np.isfinite(d['target'][idx]).all()),'conditions_all_finite':bool(np.isfinite(d['cond'][idx]).all()),'features_all_finite':bool(np.isfinite(d['feat'][idx]).all())}
out['label_timing']={}
for before,after in [('M','T'),('T','V'),('V','C'),('C','E')]:
    end=d['origin_ts'].iloc[ids[before][-1]]+pd.Timedelta(days=cfg.horizon_days)
    origin=d['origin_ts'].iloc[ids[after][0]]
    out['label_timing'][before+'_'+after]={'last_label_end':str(end),'next_first_origin':str(origin),'valid':bool(end<=origin)}
yC=d['target'][ids['C']];yE=d['target'][ids['E']]
out['baseline_checks']={}
for name in ('T','M'):
    lo,hi=climatology(d['target'][ids[name]],len(yE),.9)
    out['baseline_checks'][name+'_climatology_raw']=evaluate_intervals(yE,lo,hi,cfg.capacity,.1)
    lc,hc=climatology(d['target'][ids[name]],len(yC),.9)
    q=fit_cqr(yC,lc,hc,.9)
    lo,hi=predict_cqr(lo,hi,q)
    out['baseline_checks'][name+'_climatology_cqr']=evaluate_intervals(yE,lo,hi,cfg.capacity,.1)
out['baseline_checks']['random_analog_M_k30']=[]
for seed in range(5):
    rng=np.random.default_rng(seed)
    draw=np.array([rng.choice(ids['M'],size=30,replace=False) for _ in ids['E']])
    neighbors=d['target'][draw]
    lo=np.quantile(neighbors,.05,axis=1); hi=np.quantile(neighbors,.95,axis=1)
    out['baseline_checks']['random_analog_M_k30'].append({'seed':seed,**evaluate_intervals(yE,lo,hi,cfg.capacity,.1)})
out['saved_method_metrics']={mode:{method:values['all']['0.9'] for method,values in rows.items()} for mode,rows in artifact['ablation'].items()}
out['saved_ramp_metrics']={mode:rows['cqr']['ramp']['0.9'] for mode,rows in artifact['ablation'].items()}
out['baseline_reproduction_abs_difference']=abs(out['baseline_checks']['T_climatology_raw']['score']-artifact['ablation']['none']['climatology']['all']['0.9']['score'])
path=root/'review_v2_checks.json'
path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ('saved_config','saved_method_metrics')},ensure_ascii=False,indent=2))
