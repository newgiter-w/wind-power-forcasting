"""Final method: L01 base model (q=0.05, 2019+2020H1 lower) + Hybrid calibration
(lower = C0 symmetric q, upper = C3 conditioned bU). Produces definitive metrics
(with IS) and per-lead-time breakdown for the paper.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.multioutput import MultiOutputRegressor
from threadpoolctl import threadpool_limits

import evaluate as ev
from data import build_situations, load_dataframe
from execute_x01 import cfg_for
from online_calibration import simulate
from run_c1 import masks_for, signed_change
from run_c3 import build_cells, fit_head
from run_calibration import cache_predictions, indices_for

ROOT = Path(__file__).parent
MODEL = ROOT / 'out_v3/x01/tasks/NH_H0'
OUT = ROOT / 'out_final'
H0 = dict(max_iter=50, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, random_state=0)


def full_metrics(data, res, capacity=12300.0, conf=0.9):
    idx = res['indices']
    y = data['y'][idx]
    lo, hi = res['lo'], res['hi']
    valid = data['valid'][idx]
    inside = (y >= lo) & (y <= hi)
    vmask = np.broadcast_to(valid[:, None], y.shape)
    alpha = 1 - conf
    width = np.maximum(hi - lo, 0)
    is_cell = (width + (2/alpha)*np.where(y < lo, lo - y, 0.0)
               + (2/alpha)*np.where(y > hi, y - hi, 0.0)) / capacity

    def g(mask):
        m = mask & vmask
        if not m.any():
            return None
        return {'coverage': float(inside[m].mean()), 'width': float(width[m].mean()/capacity),
                'IS': float(is_cell[m].mean()),
                'origins': int(m.any(axis=1).sum()), 'cells': int(m.sum())}
    chg = signed_change(y, data['last_hour'][idx])
    masks = {'all': np.ones_like(y, bool), 'ramp': np.abs(chg) > 1230.0,
             'up_ramp': chg > 1230.0, 'down_ramp': chg < -1230.0,
             'near_zero': np.abs(y) <= 123.0}
    out = {k: g(masks[k]) for k in masks}
    # per-lead-time coverage/width
    lead = {}
    for h in range(y.shape[1]):
        m = np.zeros_like(y, bool); m[:, h] = True
        r = g(m)
        lead[str(h+1)] = {'coverage': r['coverage'], 'width': r['width']} if r else None
    out['per_lead'] = lead
    return out


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    cfg = cfg_for()
    d = build_situations(load_dataframe(cfg), cfg)
    X_all = np.hstack([d['feat'], d['cond']])
    y_all = d['target']
    origins = d['origin_ts']
    valid = d['target_valid']
    mmore = (origins >= '2019-01-01') & (origins < '2020-07-01') & valid
    scaler = joblib.load(MODEL / 'scaler.joblib')
    Xs_all = scaler.transform(X_all)

    # L01 lower head (q=0.05, 2019+2020H1)
    lower_head = MultiOutputRegressor(HistGradientBoostingRegressor(loss='quantile', quantile=0.05, **H0))
    lower_head.fit(Xs_all[mmore], y_all[mmore])

    # features for residual head + raw predictions
    X_cells, sL, sU, cvalid, corigins = build_cells()
    data = cache_predictions()
    upper_frozen = data['raw_upper_original']
    pred_idx = data['global_indices']
    raw_lo = np.minimum(lower_head.predict(Xs_all[pred_idx]), upper_frozen)
    raw_hi = np.maximum(lower_head.predict(Xs_all[pred_idx]), upper_frozen)

    # bU conditioned upper head (R_fit = 2020 H1), trained on L01 upper residual
    N, H = sU.shape
    rfit = (corigins >= np.datetime64('2020-01-01')) & (corigins < np.datetime64('2020-07-01'))
    train_mask = np.broadcast_to((rfit & cvalid)[:, None], (N, H))
    head_u = fit_head(X_cells.reshape(N*H, -1), sU.reshape(-1), train_mask.reshape(-1))
    bU = head_u.predict(X_cells.reshape(N*H, -1)).reshape(N, H)

    out = {}
    for year in ('2021', '2022'):
        seed, score = indices_for(data, year)
        c0 = simulate(data['origins'], data['target_end'], data['y'], raw_lo, raw_hi,
                      data['valid'], seed, score, 'rolling', 84)
        # hybrid final
        hy_lo = raw_lo[score] - c0['q_signed']
        hy_hi = raw_hi[score] + bU[score]
        empty = hy_lo > hy_hi
        center = (raw_lo[score] + raw_hi[score]) / 2
        hy_lo = np.where(empty, center, hy_lo); hy_hi = np.where(empty, center, hy_hi)
        final = {'indices': score, 'lo': hy_lo, 'hi': hy_hi, 'n_cal': c0['n_cal'],
                 'midpoint_expansion_count': int(empty.sum()), 'state_projection_count': 0,
                 'support_projection_count': 0}
        m0 = full_metrics(data, c0)
        mf = full_metrics(data, final)
        out[year] = {'C0': m0, 'Final': mf}
        print(f'\n===== {year} =====')
        for g in ('all', 'ramp', 'up_ramp', 'down_ramp', 'near_zero'):
            a, b = m0[g], mf[g]
            def f(r): return ('n/a' if r is None else
                              f"cov={r['coverage']*100:5.1f}% w={r['width']*100:5.1f}% IS={r['IS']:.3f}")
            print(f"  {g:9s} C0   : {f(a)}")
            print(f"  {'':9s} Final: {f(b)}")
    (OUT / 'results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> out_final/results.json ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
