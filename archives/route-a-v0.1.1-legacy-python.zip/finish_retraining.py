"""Finish verification/reporting once the explicitly launched local jobs complete."""
import subprocess
import sys
import time
from retraining_common import OUT,ROOT,write


def run(args):
    print('RUN',*args,flush=True)
    subprocess.run([sys.executable,*args],cwd=ROOT,check=True)


def main():
    start=time.monotonic()
    while not (OUT/'training_complete.json').exists():
        log=ROOT/'out_retraining_resumed_execution.log'
        if log.exists() and 'Traceback (most recent call last)' in log.read_text(encoding='utf-8',errors='replace'):
            raise RuntimeError('Training failed: inspect out_retraining_execution.log')
        if time.monotonic()-start>21600:raise TimeoutError('Six-hour execution bound exceeded')
        time.sleep(5)
    run(['analyze_retraining.py'])
    modules=['test_retraining','test_pooling','test_revision_integrity','test_online_calibration','test_gefcom_tail_dynamic','test_quantile_sort_factorial','test_gefcom_protocol_v2']
    run(['-m','unittest',*modules,'-q'])
    write(OUT/'test_result.json',dict(status='passed',count=29,modules=modules))
    run(['report_retraining.py'])
    print('RETRAINING_FINISHED',flush=True)


if __name__=='__main__':main()
