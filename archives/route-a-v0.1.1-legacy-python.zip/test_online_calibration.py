import unittest
import numpy as np
import pandas as pd
from online_calibration import alpha_update,score_quantile,simulate


def toy():
    origins=pd.date_range('2020-01-01 23:50',periods=30,freq='D').to_numpy()
    ends=origins+np.timedelta64(1,'D')
    y=np.column_stack([np.sin(np.arange(30)),np.cos(np.arange(30))])
    lo=np.full_like(y,-.8);hi=np.full_like(y,.8)
    valid=np.ones(30,dtype=bool)
    return origins,ends,y,lo,hi,valid


class OnlineChecks(unittest.TestCase):
    def test_miss_widens_via_lower_alpha(self):
        self.assertAlmostEqual(float(alpha_update(np.array([.1]),np.array([1]),.01,True)[0][0]),.091)
        self.assertAlmostEqual(float(alpha_update(np.array([.1]),np.array([0]),.01,True)[0][0]),.101)

    def test_future_label_and_future_quality_cannot_change_past_forecasts(self):
        data=list(toy());seed=np.arange(12);score=np.arange(12,30)
        original=simulate(*data,seed,score,'aci_projected',28,.005)
        changed=[v.copy() for v in data]
        changed[2][18]+=1000;changed[5][18]=False
        perturbed=simulate(*changed,seed,score,'aci_projected',28,.005)
        before=changed[0][score]<changed[1][18]
        np.testing.assert_array_equal(original['lo'][before],perturbed['lo'][before])
        np.testing.assert_array_equal(original['hi'][before],perturbed['hi'][before])
        self.assertEqual(len(original['indices']),len(perturbed['indices']))
        for row in original['feedback']:
            self.assertLessEqual(pd.Timestamp(row['source_target_end']),pd.Timestamp(row['processed_at']))

    def test_zero_gamma_matches_rolling(self):
        d=toy();seed=np.arange(12);score=np.arange(12,30)
        rolling=simulate(*d,seed,score,'rolling',28,0.)
        aci=simulate(*d,seed,score,'aci_projected',28,0.)
        np.testing.assert_array_equal(rolling['lo'],aci['lo'])
        np.testing.assert_array_equal(rolling['hi'],aci['hi'])

    def test_finite_support_is_explicit(self):
        scores=np.arange(18,dtype=float).reshape(9,2)
        q,_,_=score_quantile(scores,.02,False)
        self.assertTrue(np.isposinf(q).all())
        q,effective,changed=score_quantile(scores,.02,True)
        np.testing.assert_array_equal(q,scores[-1])
        np.testing.assert_allclose(effective,.1)
        self.assertEqual(changed,2)

    def test_missing_day_is_skipped_only_when_feedback_arrives(self):
        d=list(toy());d[5][20:23]=False;seed=np.arange(12);score=np.arange(12,30)
        result=simulate(*d,seed,score,'rolling',28,0.)
        skipped=[r for r in result['feedback'] if not r['valid_feedback']]
        self.assertEqual(len(skipped),3)
        self.assertEqual(len(result['indices']),18)
        self.assertTrue(np.all(result['max_label_end_used']<=d[0][score]))

    def test_seed_future_end_is_rejected(self):
        d=toy()
        with self.assertRaises(ValueError):
            simulate(*d,np.arange(15),np.arange(12,30),'global')


if __name__=='__main__':unittest.main(verbosity=2)
