"""Versioned monthly local QRF refits; no calibration target enters fitting."""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='2'
import argparse
import time
import json
from concurrent.futures import ProcessPoolExecutor,as_completed
import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from threadpoolctl import threadpool_limits
from sparse_leaf_qrf import SparseLeafQRF
from online_calibration import simulate
from retraining_common import OUT,METHODS,split_month,split_witness,schedule,folder_for,load_farms,feature_array,local_heads,write,frozen_spec


def run_job(year,farm,method,seed,month):
    folder=folder_for(year,farm,method,seed,month);folder.mkdir(parents=True,exist_ok=True)
    if (folder/'complete.json').exists():return dict(year=year,farm=farm,method=method,seed=seed,month=month,reused=True)
    start=time.perf_counter();d=load_farms(year)[farm];tr,ca,sc=split_month(d,month,method)
    queries=np.r_[ca,sc];cell=(queries[:,None]*24+np.arange(24)).ravel()
    if method=='frozen':
        lo,hi=local_heads(year,farm,'QRF',seed);fit_seconds=0.
    else:
        X=feature_array(year,farm,'GBM');tm=(tr[:,None]*24+np.arange(24)).ravel()
        imputer=SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True).fit(X[tm])
        xx=imputer.transform(X[tm]).astype('float32');y=d['y'][tr].ravel()
        with threadpool_limits(limits=2):
            model=SparseLeafQRF(500,10,seed,n_jobs=2).fit(xx,y)
            fit_seconds=time.perf_counter()-start
            predictions=model.predict(imputer.transform(X[cell])).reshape(len(queries),24,2)
        lo=np.full_like(d['y'],np.nan);hi=lo.copy();lo[queries]=predictions[:,:,0];hi[queries]=predictions[:,:,1]
        # Preserve every fitted model, train-only preprocessor and exact fitting membership.
        joblib.dump(dict(model=model,imputer=imputer),folder/'model.joblib',compress=1)
    result=simulate(d['origins'],d['ends'],d['y'],lo,hi,d['valid'],ca,sc,'rolling',84)
    assert np.all(result['max_label_end_used']<=d['origins'][sc])
    np.savez_compressed(folder/'predictions.npz',queries=queries,train_indices=tr,seed_indices=ca,indices=sc,
        query_lo=lo[queries],query_hi=hi[queries],raw_lo=lo[sc],raw_hi=hi[sc],
        lo=np.clip(result['lo'],0,1),hi=np.clip(result['hi'],0,1),q_signed=result['q_signed'],q_used=result['q_used'],
        n_cal=result['n_cal'],max_label_end=result['max_label_end_used'])
    pd.DataFrame(result['feedback']).to_csv(folder/'feedback.csv',index=False)
    witness=dict(year=year,farm=farm,method=method,seed=seed,month=month,**split_witness(d,tr,ca,sc),
        fit_seconds=fit_seconds,total_seconds=time.perf_counter()-start,status='complete')
    write(folder/'complete.json',witness)
    print('REFIT',year,farm,method,seed,month,round(witness['total_seconds'],1),flush=True)
    return witness


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');parser.add_argument('--workers',type=int);args=parser.parse_args()
    if args.pilot:
        result=run_job(2014,1,'expanding',0,'2013-07');write(OUT/'timing_pilot.json',result);return
    protocol=json.loads((OUT/'protocol.json').read_text(encoding='utf-8'));seeds=protocol['seeds']
    began=time.perf_counter()
    for year,stage in [(2014,'validation'),(2014,'evaluation'),(2012,'evaluation')]:
        jobs=[(year,farm,method,seed,month) for month in schedule(year,stage)
            for farm in load_farms(year) for method in METHODS for seed in seeds]
        with ProcessPoolExecutor(max_workers=args.workers or protocol['workers']) as pool:
            futures=[pool.submit(run_job,*job) for job in jobs]
            for f in as_completed(futures):f.result()
        write(OUT/f'{year}_{stage}_complete.json',dict(status='complete',jobs=len(jobs),seeds=seeds))
        # Development comparison is persisted before any evaluation-month fitting.
        if stage=='validation':
            from analyze_retraining import analyze_development
            analyze_development()
    write(OUT/'training_complete.json',dict(status='complete',elapsed_seconds=time.perf_counter()-began))


if __name__=='__main__':main()
