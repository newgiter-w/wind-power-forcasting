"""Recompute pooled/local intervals, replay pooled weights, and paired time blocks."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='2'
import json
import time
import joblib
import numpy as np
import pandas as pd
import torch
from scipy.sparse import csr_matrix
from threadpoolctl import threadpool_limits
from run_dl_baseline import QuantileMLP
from pooling_common import OUT,ANALYSIS_FAMILIES as FAMILIES,write,load_farms,pooled_data,local_heads,REVISION,REFERENCE
from revision_common import collect,calibration,METRIC_COLS,paired_daily_arrays
from gefcom2014_experiment import masks
from gefcom_protocol_v2 import index

GROUPS=['all','ramp','up_ramp','down_ramp','near_zero']


def replay_pooled(year,family,seeds):
    farms,X,y,tm,sm,fm,slices=pooled_data(year,family);checks=[]
    cells=[];local_cells={}
    for farm,d in farms.items():
        days=np.r_[index(d,'validation')[:2],index(d,'evaluation')[:2]]
        ix=(days[:,None]*24+np.arange(24)).ravel();local_cells[farm]=ix;cells.extend(ix+slices[farm].start)
    cells=np.asarray(cells)
    for seed in seeds:
        folder=OUT/f'{family}/gefcom{year}/seed_{seed}'
        if family.startswith('GBM'):
            bundle=joblib.load(folder/'models.joblib')
            np.testing.assert_allclose(bundle['scaler'].mean_,np.nanmean(X[tm],axis=0),rtol=1e-10,atol=1e-10)
            pred=np.column_stack([m.predict(bundle['scaler'].transform(X[cells])) for m in bundle['models']])
        elif family.startswith('MLP'):
            ps=[]
            for q in [.05,.95]:
                model=QuantileMLP(X.shape[1]);model.load_state_dict(torch.load(folder/f'q{q:.2f}.pt',weights_only=True));model.eval()
                with torch.no_grad():ps.append(model(torch.tensor(X[cells],dtype=torch.float32)).numpy())
            pred=np.column_stack(ps)
        else:
            model=joblib.load(folder/'model.joblib');pred=model.predict(X[cells])
            if seed==0:
                # Does a farm-ID-conditioned forest still mix other farms in its leaves?
                all_farm=np.empty(len(X),dtype=int);sample_cells=[];query_farm=[]
                for pos,(farm,d) in enumerate(farms.items()):
                    all_farm[slices[farm]]=pos
                    days=index(d,'evaluation')[::7]
                    ix=(days[:,None]*24+np.array([0,11,23])).ravel()
                    sample_cells.extend(ix+slices[farm].start);query_farm.extend([pos]*len(ix))
                sample_cells=np.asarray(sample_cells);query_farm=np.asarray(query_farm)
                sorter=np.argsort(y[tm]);np.testing.assert_equal(model.sorted_y,y[tm][sorter])
                sorted_farm=all_farm[tm][sorter]
                indicator=csr_matrix((np.ones(len(sorted_farm)),(np.arange(len(sorted_farm)),sorted_farm)),shape=(len(sorted_farm),len(farms)))
                nodes=model.forest.apply(X[sample_cells])
                leafrows=np.column_stack([model.lookups[t][nodes[:,t]] for t in range(model.n_trees)])
                unique,inverse=np.unique(leafrows,return_inverse=True)
                distribution=model.responses[unique]@indicator
                np.testing.assert_allclose(np.asarray(distribution.sum(axis=1)).ravel(),1.,atol=1e-12)
                own=np.asarray(distribution[inverse.ravel(),np.repeat(query_farm,model.n_trees)]).ravel().reshape(len(sample_cells),model.n_trees).mean(axis=1)
                mix=[]
                for pos,farm in enumerate(farms):
                    a=own[query_farm==pos]
                    mix.append(dict(year=year,farm=farm,queries=len(a),mean_own_farm_weight=float(a.mean()),
                        median_own_farm_weight=float(np.median(a)),minimum_own_farm_weight=float(a.min()),
                        maximum_own_farm_weight=float(a.max()),selection='every7th evaluation issue; leads1,12,24; no target-based selection'))
                pd.DataFrame(mix).to_csv(OUT/f'{year}_QRF_leaf_farm_mix.csv',index=False)
        saved=[]
        for farm in farms:
            with np.load(OUT/f'{family}/gefcom{year}/pooled/seed_{seed}/farm_{farm:02d}/heads.npz') as z:
                saved.append(np.c_[z['lo'].ravel()[local_cells[farm]],z['hi'].ravel()[local_cells[farm]]])
        saved=np.concatenate(saved);pred=np.sort(pred,axis=1)
        delta=float(np.abs(pred-saved).max());np.testing.assert_allclose(pred,saved,atol=3e-6 if family.startswith('MLP') else 1e-10,rtol=3e-6 if family.startswith('MLP') else 1e-10)
        checks.append(dict(year=year,family=family,seed=seed,queries=len(cells),max_abs_error=delta,selection='first2 Q2 and evaluation origins per farm'))
        print('pooled model replay',year,family,seed,delta,flush=True)
    return checks


def load_stage(year,farm,family,regime,seed,stage,variant):
    folder=OUT/f'{family}/gefcom{year}/{regime}/seed_{seed}/farm_{farm:02d}'
    name=f'{stage}_protected.npz' if variant=='protected' else f'{stage}.npz'
    with np.load(folder/name) as z:
        ids=z['indices']
        if variant=='signed':lo,hi=z['clipped_lo'],z['clipped_hi']
        elif variant=='raw':lo,hi=np.clip(z['raw_lo'],0,1),np.clip(z['raw_hi'],0,1)
        else:lo,hi=z['lo'],z['hi']
        return ids,lo,hi,z['max_label_end']


def main():
    torch.set_num_threads(2);began=time.perf_counter();rows=[];checks=[];replays=[];slice_rows=[];monthly_rows=[];bootstrap=[]
    for family in FAMILIES:
        assert json.loads((OUT/family/'completion.json').read_text())['status']=='complete'
    for year in [2014,2012]:
        farms=load_farms(year)
        for family in FAMILIES:
            seeds=[0] if family.startswith('GBM') else [0,1,2]
            replays.extend(replay_pooled(year,family,seeds))
            for farm,d in farms.items():
                # Match the original local calendar, labels and observed history exactly.
                with np.load(REFERENCE/f'gefcom{year}/farm_{farm:02d}/samples.npz') as z:
                    for key in ['origins','ends','y','valid','history']:np.testing.assert_equal(d[key],z[key])
                probability=np.load(REVISION/f'mlp/gefcom{year}/farm_{farm:02d}/risk_probabilities.npz')['probability']
                for seed in seeds:
                    for regime in ['local','pooled']:
                        folder=OUT/f'{family}/gefcom{year}/{regime}/seed_{seed}/farm_{farm:02d}'
                        if regime=='local':rawlo,rawhi=local_heads(year,farm,family,seed)
                        else:
                            with np.load(folder/'heads.npz') as z:
                                rawlo,rawhi=z['lo'],z['hi'];np.testing.assert_equal(z['origins'],d['origins'])
                        for stage in ['validation','evaluation']:
                            expected_ids,result=calibration(d,rawlo,rawhi,stage)
                            with np.load(folder/f'{stage}.npz') as z:
                                np.testing.assert_equal(z['indices'],expected_ids)
                                for key in ['lo','hi','q_signed','q_used']:np.testing.assert_equal(z[key],result[key])
                            for variant in ['raw','signed','protected']:
                                ids,L,U,end=load_stage(year,farm,family,regime,seed,stage,variant)
                                assert np.isfinite(L).all() and np.isfinite(U).all() and (L<=U).all()
                                assert ((L>=0)&(U<=1)).all() and (end<=d['origins'][ids]).all()
                                if variant=='protected':
                                    np.testing.assert_equal(L,np.where(probability[ids]>=.1,0.,np.clip(result['lo'],0,1)))
                                    np.testing.assert_equal(U,np.clip(result['hi'],0,1))
                                collect(rows,d,ids,L,U,year=year,farm=farm,family=family,regime=regime,seed=seed,stage=stage,variant=variant)
                                if stage=='evaluation' and variant=='signed':
                                    months=d['origins'][ids].astype('datetime64[M]')
                                    for month in np.unique(months):
                                        ix=months==month
                                        collect(monthly_rows,d,ids[ix],L[ix],U[ix],year=year,farm=farm,family=family,
                                            regime=regime,seed=seed,month=str(month))
                                    yy=d['y'][ids];valid=np.broadcast_to(d['valid'][ids,None],yy.shape)
                                    for group,mask in masks(yy,d['history'][ids,-1]).items():
                                        mask=mask&valid
                                        for h in range(24):
                                            m=mask[:,h]
                                            if not m.any():continue
                                            yv,l,u=yy[:,h][m],L[:,h][m],U[:,h][m]
                                            slice_rows.append(dict(year=year,family=family,regime=regime,farm=farm,seed=seed,group=group,
                                                lead=h+1,cells=int(m.sum()),coverage=float(((yv>=l)&(yv<=u)).mean()),width=float((u-l).mean()),
                                                IS=float((u-l+20*np.maximum(l-yv,0)+20*np.maximum(yv-u,0)).mean())))
                        checks.append(dict(year=year,family=family,farm=farm,seed=seed,regime=regime,
                            calendar_matches_local=True,calibration_replayed=True,protection_replayed=True,arrival_checked=True))
            # Synchronous calendar blocks retain same-weather farm dependence.
            dates=pd.date_range('2013-07-01' if year==2014 else '2011-07-01','2013-12-31' if year==2014 else '2012-06-27',freq='D').to_numpy()
            for variant in ['signed','protected']:
                daily=np.zeros((2,len(farms),len(dates),5,4))
                for f,(farm,d) in enumerate(farms.items()):
                    for r,regime in enumerate(['local','pooled']):
                        for seed in seeds:
                            ids,L,U,_=load_stage(year,farm,family,regime,seed,'evaluation',variant)
                            stats=paired_daily_arrays(d,ids,L,U);pos=np.searchsorted(dates,d['origins'][ids]);np.testing.assert_equal(dates[pos],d['origins'][ids])
                            for g,group in enumerate(GROUPS):
                                a=np.stack([stats[group+'_n'],stats[group+'_IS'],stats[group+'_coverage'],stats[group+'_width']],axis=1)
                                daily[r,f,pos,g,:]+=a/len(seeds)
                np.savez_compressed(OUT/f'{year}_{family}_{variant}_daily.npz',daily=daily,dates=dates)
                def macro(a):
                    total=a.sum(axis=2)
                    return np.nanmean(np.divide(total[:,:,:,1:],total[:,:,:,0,None],
                        out=np.full(total[:,:,:,1:].shape,np.nan),where=total[:,:,:,0,None]>0),axis=1)
                point=macro(daily);n=len(dates)
                for block in [7,14]:
                    rng=np.random.default_rng(20261105+year+block);samples=[]
                    for _ in range(2000):
                        start=rng.integers(0,n-block+1,size=int(np.ceil(n/block)))
                        ix=(start[:,None]+np.arange(block)).ravel()[:n]
                        samples.append(macro(daily[:,:,ix,:,:]))
                    samples=np.stack(samples)
                    for g,group in enumerate(GROUPS):
                        for k,metric in enumerate(['IS','coverage','width']):
                            delta=samples[:,1,g,k]-samples[:,0,g,k];low,high=np.quantile(delta,[.025,.975])
                            pl,ph=np.quantile(samples[:,1,g,k],[.025,.975])
                            bootstrap.append(dict(year=year,family=family,variant=variant,group=group,metric=metric,block_days=block,
                                local=float(point[0,g,k]),pooled=float(point[1,g,k]),difference=float(point[1,g,k]-point[0,g,k]),
                                low=float(low),high=float(high),pooled_low=float(pl),pooled_high=float(ph),
                                interpretation='seed-mean fitted-model conditional, retrospective, calendar blocks synchronous across farms'))
            print('array verification and bootstrap',year,family,flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(OUT/'recomputed_per_farm.csv',index=False)
    per_seed=frame.groupby(['year','family','regime','seed','stage','variant','group'])[METRIC_COLS].mean().reset_index()
    per_seed.to_csv(OUT/'macro_per_seed.csv',index=False)
    farmmeans=frame.groupby(['year','family','regime','farm','stage','variant','group'])[METRIC_COLS].mean().reset_index()
    farmmeans.to_csv(OUT/'seed_mean_per_farm.csv',index=False)
    macro=farmmeans.groupby(['year','family','regime','stage','variant','group'])[METRIC_COLS].mean().reset_index()
    macro.to_csv(OUT/'metrics_macro.csv',index=False);pd.DataFrame(slice_rows).to_csv(OUT/'per_lead.csv',index=False)
    monthly=pd.DataFrame(monthly_rows);monthly.to_csv(OUT/'monthly_per_farm.csv',index=False)
    monthly.groupby(['year','family','regime','farm','month','group'])[METRIC_COLS].mean().groupby(
        ['year','family','regime','month','group']).mean().reset_index().to_csv(OUT/'monthly_macro.csv',index=False)
    pd.DataFrame(bootstrap).to_csv(OUT/'paired_bootstrap.csv',index=False)
    success=[]
    for year in [2014,2012]:
        for family in FAMILIES:
            for variant in ['signed','protected']:
                m=macro[(macro.year==year)&(macro.family==family)&(macro.stage=='evaluation')&(macro.variant==variant)].set_index(['regime','group'])
                local=m.loc[('local','all')];pooled=m.loc[('pooled','all')]
                ff=farmmeans[(farmmeans.year==year)&(farmmeans.family==family)&(farmmeans.stage=='evaluation')&(farmmeans.variant==variant)&(farmmeans.group=='all')]
                conditions=dict(coverage_at_least90=pooled.coverage>=.90,coverage_drop_at_most_halfpp=pooled.coverage>=local.coverage-.005,
                    width_minus3pct=pooled.width<=.97*local.width,IS_not_worse=pooled.IS<=local.IS)
                degraded=[g for g in ['near_zero','up_ramp','down_ramp'] if m.loc[('pooled',g),'coverage']<m.loc[('local',g),'coverage']-.01]
                success.append(dict(year=year,family=family,variant=variant,target_pass=all(conditions.values()),**conditions,
                    coverage_width_pass=bool(pooled.coverage>=.90 and pooled.width<local.width),
                    local_farms_ge90=int(((ff.regime=='local')&(ff.coverage>=.90)).sum()),pooled_farms_ge90=int(((ff.regime=='pooled')&(ff.coverage>=.90)).sum()),
                    farms=7 if year==2012 else 10,width_relative_change=float(pooled.width/local.width-1),
                    groups_coverage_drop_over1pp=';'.join(degraded),scope='descriptive test gates; not evaluation-based reselection'))
    pd.DataFrame(success).to_csv(OUT/'target_checks.csv',index=False)
    # Independently recomputed macros must match the training runner's CSVs.
    differences=[]
    for family in FAMILIES:
        saved=pd.read_csv(OUT/f'{family}/metrics_macro.csv')
        for regime in ['local','pooled']:
            for variant in ['raw','signed','protected']:
                old=saved[saved.method==family+'_'+regime+'_'+variant].set_index(['year','seed','stage','group'])[METRIC_COLS].sort_index()
                new=per_seed[(per_seed.family==family)&(per_seed.regime==regime)&(per_seed.variant==variant)].set_index(['year','seed','stage','group'])[METRIC_COLS].sort_index()
                delta=float(np.abs(old.to_numpy()-new.to_numpy()).max());assert delta<1e-10
                differences.append(dict(family=family,regime=regime,variant=variant,max_abs_error=delta))
    write(OUT/'verification.json',dict(status='passed',checks=checks,pooled_model_replays=replays,macro_differences=differences,
        sparse_QRF_equivalence=json.loads((OUT/'sparse_qrf_equivalence.json').read_text()),
        global_normalization_input_check=json.loads((OUT/'global_normalization_feature_check.json').read_text()),
        elapsed_seconds=time.perf_counter()-began,limitations='retrospective periods; conditional bootstrap; no unseen-farm test'))
    print('POOLING VERIFIED',len(checks),'regime/farm/seed combinations',flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
