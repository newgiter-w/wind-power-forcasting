"""Compare increment upper-quantile scores with frozen QRF on both GEFCom datasets."""
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits

from run_gefcom2012_local_increment import ROOT,load_farms,load_stage,score,threshold,daily,summarize,paired
from revision_common import frozen_spec,write

OUT=ROOT/'out_gefcom_increment_upper_quantiles'
QUANTILES=(.75,.90)
CONFIG={2012:('2011-05-16',7),2014:('2013-05-16',10)}


def fit_arrays(dev,cutoff):
    xx,yy=[],[]
    for d in dev:
        use=d['gate']&(d['ends']<=cutoff)[:,None]
        assert (d['origins'][use.any(axis=1)]<cutoff).all()
        xx.append(d['features'][use])
        yy.append((d['actual']-d['base'])[use])
    return np.concatenate(xx),np.concatenate(yy)


def check(m,op):
    a,b=(m.loc[(op,'gated',k)] for k in ('original','corrected'))
    return dict(timing=bool(b.recall>a.recall),quiet=bool(b.quiet_fpr<=a.quiet_fpr),
        bias=bool(abs(b.bias)<abs(a.bias)),ramp_mae=bool(b.mae<a.mae))


def development(year):
    date,n_farms=CONFIG[year]
    cutoff=np.datetime64(date)
    farms=load_farms(year)
    assert len(farms)==n_farms
    folder=OUT/f'gefcom{year}'
    folder.mkdir(exist_ok=True)
    dev=load_stage(farms,'validation',year)
    x,y=fit_arrays(dev,cutoff)
    models,options,frames={},{},[]
    for q in QUANTILES:
        name=str(q)
        model=HistGradientBoostingRegressor(loss='quantile',quantile=q,max_iter=40,max_leaf_nodes=7,
            min_samples_leaf=50,l2_regularization=1,early_stopping=False,random_state=0)
        with threadpool_limits(limits=2):
            model.fit(x,y)
            rec=score(model,dev,1.,dev=True,cutoff=cutoff)
        alarm=threshold(rec)
        frame=daily(rec,alarm,name)
        m=summarize(frame)
        a=m.loc[(name,'gated','corrected')]
        models[q]=model
        options[q]=dict(threshold=alarm,checks=check(m,name),recall=float(a.recall),mae=float(a.mae))
        frames.append(frame)
    passing=[q for q,v in options.items() if all(v['checks'].values())]
    q=min(passing or QUANTILES,key=lambda q:(-options[q]['recall'],options[q]['mae'],q))
    choice=dict(quantile=q,dev_pass=bool(passing),fit_rows=len(y),cutoff=date,**options[q])
    frozen_spec(folder/'selection.json',dict(choice=choice,candidates={str(k):v for k,v in options.items()}))
    summarize(pd.concat(frames)).to_csv(folder/'development_summary.csv')
    joblib.dump(models[q],folder/'selected.joblib')
    print('FROZEN',year,choice,flush=True)
    return farms,models[q],choice


def evaluate(year,farms,model,choice):
    folder=OUT/f'gefcom{year}'
    with threadpool_limits(limits=2):
        rec=score(model,load_stage(farms,'evaluation',year),1.)
    exact=threshold(rec)
    a=pd.concat([daily(rec,choice['threshold'],'frozen'),daily(rec,exact,'exact_fpr')])
    a.to_csv(folder/'evaluation_daily.csv',index=False)
    m=summarize(a)
    m.to_csv(folder/'evaluation_summary.csv')
    ci=paired(a)
    ci.to_csv(folder/'evaluation_paired_blocks.csv',index=False)
    checks={op:check(m,op) for op in ('frozen','exact_fpr')}
    strong=ci.query("scope=='gated' and operation=='exact_fpr' and metric=='recall'").low.iloc[0]>0
    result=dict(choice=choice,evaluation=checks,exact_threshold=exact,
        advance=bool(choice['dev_pass'] and all(all(v.values()) for v in checks.values()) and strong))
    write(folder/'completion.json',result)
    print(year,m.xs('gated',level='scope')[['events','hits','false','recall','bias','mae','quiet_fpr','all_mae']].round(5).to_string(),flush=True)
    print(year,ci.query("scope=='gated' and operation=='exact_fpr'").round(6).to_string(index=False),flush=True)
    return result


def main():
    frozen_spec(OUT/'protocol.json',dict(datasets=list(CONFIG),quantiles=list(QUANTILES),
        data='same GEFCom frozen point forecasts, historical splits, inputs and gate as ridge experiment',
        target='upper quantile of actual minus original increment; added to original increment; cap ±10pp; no changed interval or power trajectory',
        fit='first part of own Q2, two fixed shallow HistGBR pinball heads; choose on remaining Q2 then freeze before either evaluation',
        gate='at same quiet false count require higher ±1h hit rate, reduced true-ramp absolute bias and MAE, no increase in quiet FPR; track gated all-hour MAE separately',
        selection='prefer passing setting, otherwise choose diagnostic only; largest recall then lowest true-ramp MAE then lowest q',
        testing='historical evaluation frozen thresholds plus retrospective exact quiet count; require both operating points pass and paired lower CI for exact recall >0 before proposing upper adjustment'))
    fitted={year:development(year) for year in CONFIG}
    result={str(year):evaluate(year,*fitted[year]) for year in CONFIG}
    write(OUT/'completion.json',dict(status='complete',datasets=result,advance_both=all(v['advance'] for v in result.values())))


if __name__=='__main__':
    main()
