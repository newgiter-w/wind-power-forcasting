"""Interval construction: quantile, split conformal, CQR, and local (retrieval) conformal.

Conformal corrections use the finite-sample ORDER STATISTIC
(k = ceil((n+1)*conf)), not an interpolated np.quantile. Insufficient
calibration samples for a finite correction are rejected explicitly.

Important: the CQR score `max(q_lo - y, y - q_hi)` is SIGNED (negative when the
interval already covers y). It must NOT be passed through abs(); doing so turns a
well-covered point into a positive penalty and inflates the correction.
"""
from __future__ import annotations

import numpy as np

from config import Config
from retrieval import Retriever


def _conformal_quantile(scores: np.ndarray, conf: float) -> float:
    """Finite-sample order statistic; reject unsupported finite calibration."""
    n = len(scores)
    if n == 0 or not 0 < conf < 1 or not np.isfinite(scores).all():
        raise ValueError("calibration requires finite scores, n>0 and confidence in (0,1)")
    k = int(np.ceil((n + 1) * conf))
    if k > n:
        raise ValueError(f"{n} calibration samples cannot support finite {conf:g} correction")
    return float(np.sort(scores)[k - 1])


def fit_conformal(y_cal: np.ndarray, yhat_cal: np.ndarray, conf: float) -> np.ndarray:
    """Split-conformal: per-horizon-step correction q_h on |residuals|. Shape (H,)."""
    resid = yhat_cal - y_cal                       # (N_cal, H)
    H = resid.shape[1]
    return np.array([_conformal_quantile(np.abs(resid[:, h]), conf) for h in range(H)])


def predict_conformal(yhat: np.ndarray, q_h: np.ndarray) -> "tuple[np.ndarray, np.ndarray]":
    return yhat - q_h[None, :], yhat + q_h[None, :]


def fit_cqr(y_cal: np.ndarray, lo_cal: np.ndarray, hi_cal: np.ndarray, conf: float) -> np.ndarray:
    """CQR correction on the SIGNED score max(q_lo-y, y-q_hi). Shape (H,)."""
    score = np.maximum(lo_cal - y_cal, y_cal - hi_cal)   # signed (N_cal, H)
    H = score.shape[1]
    return np.array([_conformal_quantile(score[:, h], conf) for h in range(H)])


def predict_cqr(lo_q: np.ndarray, hi_q: np.ndarray, q_h: np.ndarray) -> "tuple[np.ndarray, np.ndarray]":
    return lo_q - q_h[None, :], hi_q + q_h[None, :]


def fit_local_conformal(
    ret_cal: Retriever,
    q_cond_cal: np.ndarray,
    q_feat_cal: np.ndarray,
    resid_cal: np.ndarray,
    cfg: Config,
) -> dict:
    """Local (retrieval) split-conformal: calibrate on retrieved neighbors' residuals.

    NOTE: this is an empirical, adaptive-width heuristic. It does NOT carry a
    finite-sample *conditional* coverage guarantee (neighbor selection breaks
    exchangeability); it should be reported as "local calibration", not "LCP".
    """
    return {
        "ret": ret_cal,
        "cond": q_cond_cal,
        "feat": q_feat_cal,
        "resid": resid_cal,
        "conf_k": cfg.conformal_k,
    }


def predict_local_conformal(
    state: dict,
    q_cond_test: np.ndarray,
    q_feat_test: np.ndarray,
    yhat_test: np.ndarray,
    conf: float,
) -> "tuple[np.ndarray, np.ndarray]":
    ret = state["ret"]
    resid = state["resid"]                       # (N_cal, H)
    conf_k = state["conf_k"]
    n_test = len(q_cond_test)
    H = yhat_test.shape[1]
    lo = np.empty_like(yhat_test)
    hi = np.empty_like(yhat_test)
    for i in range(n_test):
        local, _, _ = ret.query(q_cond_test[i], q_feat_test[i], exclude_local=-1, top_k=conf_k)
        r_local = resid[local]                   # (k, H)
        q_h = np.array([_conformal_quantile(np.abs(r_local[:, h]), conf) for h in range(H)])
        lo[i] = yhat_test[i] - q_h
        hi[i] = yhat_test[i] + q_h
    return lo, hi
