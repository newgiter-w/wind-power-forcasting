"""Diagnose the depth of the 2012 up-ramp upper miss vs the base QRF upper quantile.

Read-only. For up-ramp hours (delta > +0.10), measure how far the realized power
rises above (a) the QRF median, (b) the raw QRF q95, (c) the frozen R15 upper
bound. This tells us whether raising the base upper quantile (q95 -> q97/q98) is
the right lever, and by how much.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SAMPLES = ROOT / 'out_gefcom_pooling_20261105' / 'inputs'
GUARD = ROOT / 'out_gefcom_qrf_down_guard_classifier_20261106'
POINT = ROOT / 'out_gefcom_point_residual_20261106'
OUT = ROOT / 'out_gefcom_p0_rescue_20261106'


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for year in (2014, 2012):
        nfarms = 10 if year == 2014 else 7
        for farm in range(1, nfarms + 1):
            with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'samples.npz') as z:
                d = {k: z[k] for k in z.files}
            with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'R15.npz') as z:
                ids = z['ids']; u_r15 = z['hi']
            with np.load(POINT / f'gefcom{year}' / f'farm_{farm:02d}' / 'heads.npz') as z:
                qmed = z['qrf'][ids]          # (n,24) median
                direct = z['direct_qrf'][:, ids]  # (2,n,24): q05, q95
            q05_raw = direct[0]; q95_raw = direct[1]

            y = d['y'][ids]
            valid = d['valid'][ids]
            hist_last = d['history'][ids, -1]
            valid2 = np.broadcast_to(valid[:, None], y.shape)
            delta = np.diff(y, axis=1, prepend=hist_last[:, None])
            up = (delta > 0.10) & valid2

            if not up.any():
                continue
            miss = up & (y > u_r15)
            for label, m in [('up_ramp_all', up), ('up_ramp_upper_miss', miss)]:
                for name, arr in [('y_minus_median', y - qmed),
                                  ('y_minus_q95raw', y - q95_raw),
                                  ('y_minus_U_R15', y - u_r15)]:
                    v = arr[m]
                    rows.append(dict(year=year, farm=farm, label=label, signal=name,
                                     n=int(v.size),
                                     mean=float(np.nanmean(v)),
                                     p50=float(np.nanpercentile(v, 50)),
                                     p75=float(np.nanpercentile(v, 75)),
                                     p90=float(np.nanpercentile(v, 90)),
                                     p95=float(np.nanpercentile(v, 95))))

    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / 'up_ramp_overshoot_diagnosis.csv', index=False)
    summ = frame.groupby(['year', 'label', 'signal'])[['mean', 'p50', 'p75', 'p90', 'p95', 'n']].mean().reset_index()
    summ.to_csv(OUT / 'up_ramp_overshoot_summary.csv', index=False)
    print('=== up-ramp overshoot (macro mean across farms, capacity fraction) ===')
    print(summ.round(4).to_string(index=False))
    print()
    print('COMPLETE')


if __name__ == '__main__':
    main()
