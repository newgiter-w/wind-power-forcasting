"""Fit a matched QRF on hourly power increments and compare frozen forecasts."""
from concurrent.futures import ProcessPoolExecutor
import joblib
import numpy as np
from run_point_residual import ROOT, OUT as BASE, cells, load_farms, feature_array, index, frozen_spec, write, SparseLeafQRF

OUT = ROOT/'out_gefcom_qrf_power_increment_20261106'


def increments(power, history):
    return np.diff(np.c_[history[:, -1], power], axis=1)


def fit_farm(task):
    year, farm = task
    folder = OUT/f'gefcom{year}/farm_{farm:02}'
    folder.mkdir(parents=True, exist_ok=True)
    if (folder/'complete.json').exists():
        return
    d = load_farms(year)[farm]
    train = index(d, 'train', True)
    days = np.r_[index(d,'validation'), index(d,'evaluation')]
    assert d['ends'][train].max() <= d['origins'][days].min()
    x = feature_array(year,farm,'QRF')
    y = increments(d['y'], d['history'])
    model = SparseLeafQRF(500,10,0,n_jobs=2).fit(x[cells(train)],y[train].ravel())
    forecast = model.predict(x[cells(days)],(.5,)).reshape(-1,24)
    np.testing.assert_array_equal(model.sorted_y,np.sort(y[train].ravel()))
    assert np.isfinite(forecast).all()
    joblib.dump(model,folder/'model.joblib',compress=1)
    np.savez_compressed(folder/'increments.npz',days=days,origins=d['origins'][days],
                        train_days=train,forecast=forecast)
    write(folder/'complete.json',dict(year=year,farm=farm))
    print('SAVED',year,farm,flush=True)


def main():
    frozen_spec(OUT/'protocol.json',dict(seed=0,model='same single-farm QRF500 leaf10 all features',
        inputs='identical saved QRF R2 imputed inputs',
        label='P(h)-P(h-1); for h1 previous power is last pre-issue observation',
        baseline='difference of frozen QRF medians, same first-hour anchor',
        decision='2014Q2: lower MAE and miss rate on true up ramps with same-hour NWP signal, lower MAE on all signal hours, overall up-ramp miss does not increase, quiet proxy and observed-quiet false alarm increases each <=0.5pp',
        signal='same-issue wind speed difference >=0.5 m/s at h>=2; quiet forecast abs difference <0.25; quiet actual abs power difference <=0.05',
        event='true and predicted increments strictly >0.10 capacity; fixed threshold',
        evaluation='all 17 farms and same retrospective dates; no integration in this diagnostic'))
    for year in (2014,2012):
        with ProcessPoolExecutor(max_workers=6) as pool:
            list(pool.map(fit_farm,[(year,farm) for farm in load_farms(year)]))
        if year==2014:
            from report_qrf_power_increment import compare, select
            select(compare(year,'validation')[0])
    from report_qrf_power_increment import report
    report()


if __name__=='__main__':
    main()
