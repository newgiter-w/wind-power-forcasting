"""Compare direct QRF with GBM point forecasts and conditional residual intervals."""
import os
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[key] = '2'

import copy
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from scipy.special import ndtri
from sklearn.ensemble import HistGradientBoostingRegressor
from gefcom_protocol_v2 import PKG, index
from revision_common import ROOT, collect, calibration, frozen_spec, paired_daily_arrays, write
from pooling_common import REVISION, load_farms, feature_array, local_heads
from run_gefcom_tail_dynamic import fit, predict
from sparse_leaf_qrf import SparseLeafQRF
from gefcom2014_experiment import masks

OUT = ROOT / 'out_gefcom_point_residual_20261106'
METHODS = ['direct_qrf', 'conditional_gaussian', 'conditional_quantile']
GROUPS = ['all', 'near_zero', 'up_ramp', 'down_ramp']
LEVELS = [.05, .15, .25, .35, .45, .5, .55, .65, .75, .85, .95]
RESIDUAL_PARAMS = dict(PKG, max_leaf_nodes=7, min_samples_leaf=100)


def cells(days):
    return (days[:, None] * 24 + np.arange(24)).ravel()


def context(x, point, history):
    previous = np.c_[history[:, -1], point[:, :-1]]
    return np.c_[x, point.ravel(), (point - previous).ravel()]


def run_farm(task):
    year, farm = task
    folder = OUT / f'gefcom{year}/farm_{farm:02}'
    folder.mkdir(parents=True, exist_ok=True)
    d = load_farms(year)[farm]
    x = feature_array(year, farm, 'GBM')
    y = d['y']
    train = index(d, 'train', True)
    train_mask = np.repeat(np.isin(np.arange(len(y)), train), 24)
    point, anchor = fit(x, y.ravel(), train_mask, .5, PKG)
    np.testing.assert_allclose(point, predict(anchor, x), atol=1e-12)
    point = np.clip(point.reshape(-1, 24), 0, 1)
    oof = np.full_like(y, np.nan)
    folds = []
    edges = [len(train)//2, 2*len(train)//3, 5*len(train)//6, len(train)]
    for start, stop in zip(edges[:-1], edges[1:]):
        prefix, heldout = train[:start], train[start:stop]
        assert d['ends'][prefix].max() <= d['origins'][heldout].min()
        mask = np.repeat(np.isin(np.arange(len(y)), prefix), 24)
        prediction, model = fit(x, y.ravel(), mask, .5, PKG)
        oof[heldout] = np.clip(prediction.reshape(-1, 24)[heldout], 0, 1)
        folds.append(dict(fit_days=prefix, residual_days=heldout, model=model))
    heldout = train[edges[0]:]
    e = (y[heldout] - oof[heldout]).ravel()
    design = context(x, oof, d['history'])[cells(heldout)]
    forecast = context(x, point, d['history'])
    scale_model = HistGradientBoostingRegressor(**RESIDUAL_PARAMS).fit(design, e**2)
    sd = np.sqrt(np.maximum(scale_model.predict(forecast), .01**2)).reshape(y.shape)
    tails = [HistGradientBoostingRegressor(loss='quantile', quantile=q, **RESIDUAL_PARAMS)
             .fit(design, e) for q in [.05, .95]]
    gaussian = (point + ndtri(.05)*sd, point + ndtri(.95)*sd)
    asymmetric = np.sort(np.stack([point + m.predict(forecast).reshape(y.shape)
                                   for m in tails]), axis=0)
    qlo, qhi = local_heads(year, farm, 'QRF', 0)
    qx = feature_array(year, farm, 'QRF')
    original = joblib.load(REVISION / f'qrf/gefcom{year}/farm_{farm:02}/leaf_10/seed_0/model.joblib')['model']
    sparse = SparseLeafQRF(n_jobs=2)
    sparse.forest = copy.copy(original)
    sparse.forest.forest_ = None
    sparse.forest.n_jobs = 2
    sparse.build_responses(qx[train_mask], y.ravel()[train_mask])
    eval_days = index(d, 'evaluation')
    dev_days = index(d, 'validation')
    queries = cells(np.r_[dev_days, eval_days])
    pred = sparse.predict(qx[queries], (.05, .5, .95))
    np.testing.assert_allclose(pred[:, [0, 2]], np.c_[qlo.ravel()[queries], qhi.ravel()[queries]], atol=1e-10, rtol=1e-10)
    qmedian = np.full_like(y, np.nan)
    qmedian.ravel()[queries] = pred[:, 1]
    if year == 2012 and farm == 1:
        valid = index(d, 'evaluation', True)
        month = pd.DatetimeIndex(d['origins'][valid]).month.to_numpy()
        season_days = np.array([valid[np.flatnonzero(np.isin(month, group))[0]]
                                for group in ([3,4,5], [6,7,8], [9,10,11], [12,1,2])])
        fan = sparse.predict(qx[cells(season_days)], LEVELS).reshape(4,24,-1)
        assert np.all(np.diff(fan, axis=-1) >= -1e-12)
        np.savez_compressed(folder/'fan.npz', days=season_days, levels=LEVELS, quantiles=fan)
    joblib.dump(dict(anchor=anchor, folds=folds, scale=scale_model, tails=tails),
                folder/'models.joblib', compress=1)
    np.savez_compressed(folder/'heads.npz', origins=d['origins'], gbm=point, qrf=qmedian,
                        oof=oof, oof_days=heldout, direct_qrf=np.stack([qlo,qhi]),
                        conditional_gaussian=gaussian, conditional_quantile=asymmetric)
    print('SAVED', year, farm, flush=True)


def interval_rows(year, stage, farms, rows, points, daily):
    for farm, d in farms.items():
        path = OUT / f'gefcom{year}/farm_{farm:02}/heads.npz'
        with np.load(path) as z:
            np.testing.assert_equal(z['origins'], d['origins'])
            ids = index(d, stage)
            good = d['valid'][ids]
            yy = d['y'][ids][good]
            group_masks = masks(yy, d['history'][ids][good, -1])
            for key in ['gbm','qrf']:
                pp = z[key][ids][good]
                err = pp-yy
                for group in GROUPS:
                    mask = group_masks[group]
                    if mask.any():
                        points.append(dict(year=year, farm=farm, stage=stage, model=key,
                                           group=group, lead=0, n=int(mask.sum()),
                                           MAE=np.abs(err[mask]).mean(), bias=err[mask].mean()))
                for lead in range(24):
                    points.append(dict(year=year, farm=farm, stage=stage, model=key,
                                       group='all', lead=lead+1, n=len(yy),
                                       MAE=np.abs(err[:,lead]).mean(), bias=err[:,lead].mean()))
                peak_error = pp.argmax(axis=1)-yy.argmax(axis=1)
                points.append(dict(year=year, farm=farm, stage=stage, model=key,
                                   group='peak_time_hours', lead=0, n=len(yy),
                                   MAE=np.abs(peak_error).mean(), bias=peak_error.mean()))
            for method in METHODS:
                lo, hi = z[method]
                idx, result = calibration(d, lo, hi, stage)
                np.testing.assert_equal(idx, ids)
                for variant, ll, uu in [('raw', lo[ids], hi[ids]), ('signed',result['lo'],result['hi'])]:
                    ll, uu = np.clip(ll,0,1),np.clip(uu,0,1)
                    assert np.isfinite(ll).all() and np.isfinite(uu).all() and (ll<=uu).all()
                    collect(rows,d,ids,ll,uu,year=year,farm=farm,stage=stage,method=method,variant=variant)
                    if variant=='signed' and stage=='evaluation':
                        daily[method,farm] = (d['origins'][ids], paired_daily_arrays(d,ids,ll,uu))
                np.savez_compressed(path.parent/f'{stage}_{method}.npz', ids=ids,
                                    lo=np.clip(result['lo'],0,1), hi=np.clip(result['hi'],0,1),
                                    q=result['q_signed'], max_label_end=result['max_label_end_used'])


def bootstrap(year, daily, farms):
    start = min(d['origins'][index(d,'evaluation')][0] for d in farms.values())
    end = max(d['origins'][index(d,'evaluation')][-1] for d in farms.values())
    dates = pd.date_range(start,end).to_numpy()
    data = np.zeros((3,len(farms),len(dates),len(GROUPS),4))
    for m, method in enumerate(METHODS):
        for f, farm in enumerate(farms):
            origins, stats = daily[method,farm]
            pos = np.searchsorted(dates,origins)
            for g, group in enumerate(GROUPS):
                data[m,f,pos,g] = np.stack([stats[f'{group}_{k}'] for k in ['n','coverage','width','IS']],axis=-1)
    def macro(x):
        totals = x.sum(axis=2)
        n = totals[...,0,None]
        values = np.divide(totals[...,1:],n,out=np.full_like(totals[...,1:],np.nan),where=n>0)
        return np.nanmean(values,axis=1)
    rng = np.random.default_rng(20261106+year)
    point = macro(data)
    n = len(dates)
    samples = []
    for _ in range(2000):
        starts = rng.integers(0,n-13,size=int(np.ceil(n/14)))
        ids = (starts[:,None]+np.arange(14)).ravel()[:n]
        samples.append(macro(data[:,:,ids]))
    samples = np.stack(samples)
    result = []
    for m, method in enumerate(METHODS[1:],1):
        for g, group in enumerate(GROUPS):
            for k, metric in enumerate(['coverage','width','IS']):
                lo,hi = np.quantile(samples[:,m,g,k]-samples[:,0,g,k],[.025,.975])
                result.append(dict(year=year,method=method,group=group,metric=metric,
                                   difference=point[m,g,k]-point[0,g,k],low=lo,high=hi))
    return result


def main():
    frozen_spec(OUT/'protocol.json',dict(seed=0, forests='reuse original fixed QRF500, all 17 farms',
        anchor='R2 features, fixed 50 round GBM q=.5, per farm',
        oof='three forward blocks over second half of proper training, complete arrived targets',
        error_models='zero location residual Gaussian scale estimated by squared-residual regression with 0.01 floor; or q05/q95 GBM residuals; 50 rounds, 7 leaves, min leaf100',
        calibration='same signed rolling84 CQR for all, final clip [0,1]',
        selection='2014 Q2 only, macro coverage>=max(.90, QRF-.005), width<=.97 QRF, IS<=QRF, near-zero and both ramps drop<=1pp; retain every candidate',
        evaluation='same retrospective dates in both datasets; all methods reported, no 2012 selection',
        fan='2012 farm1, first valid evaluation day in each season, raw QRF five equal-tailed bands'))
    rows,points,boot = [],[],[]
    for year in [2014,2012]:
        farms = load_farms(year)
        with ProcessPoolExecutor(max_workers=3) as pool:
            list(pool.map(run_farm,[(year,farm) for farm in farms]))
        daily = {}
        interval_rows(year,'validation',farms,rows,points,daily)
        if year==2014:
            macro = pd.DataFrame(rows).query("variant == 'signed'").groupby(['method','group'])[['coverage','width','IS']].mean()
            base = macro.loc['direct_qrf']
            passing = []
            for method in METHODS[1:]:
                cand = macro.loc[method]
                a,b = cand.loc['all'],base.loc['all']
                if a.coverage>=max(.90,b.coverage-.005) and a.width<=.97*b.width and a.IS<=b.IS and all(cand.loc[g,'coverage']>=base.loc[g,'coverage']-.01 for g in ['near_zero','up_ramp','down_ramp']):
                    passing.append(method)
            frozen_spec(OUT/'selection.json',dict(passing=passing, preferred=min(passing,key=lambda m:macro.loc[(m,'all'),'IS']) if passing else 'direct_qrf'))
        interval_rows(year,'evaluation',farms,rows,points,daily)
        boot.extend(bootstrap(year,daily,farms))
    frame = pd.DataFrame(rows)
    frame.to_csv(OUT/'interval_per_farm.csv',index=False)
    frame.groupby(['year','stage','method','variant','group'])[['coverage','width','IS','lower_miss','upper_miss']].mean().reset_index().to_csv(OUT/'interval_macro.csv',index=False)
    point = pd.DataFrame(points)
    point.to_csv(OUT/'point_per_farm.csv',index=False)
    point.groupby(['year','stage','model','group','lead'])[['MAE','bias']].mean().reset_index().to_csv(OUT/'point_macro.csv',index=False)
    pd.DataFrame(boot).to_csv(OUT/'paired_bootstrap.csv',index=False)
    write(OUT/'completion.json',dict(status='complete',farms=17,seed=0,qrf_replay='all 2014/2012 Q2 and evaluation endpoints verified'))


if __name__=='__main__':
    main()
