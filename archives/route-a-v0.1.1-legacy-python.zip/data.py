"""Data loading, preprocessing, situation construction and chronological split.

A "situation" is one forecast origin: a condition window (recent past power) plus
a target window (future power to be interval-forecast), with weather + calendar
features. Situations slide by `stride_points`.

Target vs history are kept SEPARATE:
  * history / condition window uses `power_filled` (causal forward-fill);
  * target window uses raw `power` (NaN where not fully observed) + `power_valid`.
This lets the target mask flow through training / memory / calibration / eval
without ever compressing the time grid by dropping rows.
"""
from __future__ import annotations

import os

import numpy as np
import pandas as pd

from config import Config
from synthetic import generate_synthetic


def load_dataframe(cfg: Config) -> pd.DataFrame:
    """Return a standardized frame: timestamp, power, power_filled, power_valid, + weather."""
    if cfg.kelmarsh_root:
        from kelmarsh import load_farm_cache, load_kelmarsh, prepare_farm
        if cfg.kelmarsh_cache and os.path.exists(cfg.kelmarsh_cache):
            df = load_farm_cache(cfg.kelmarsh_cache)
            if cfg.kelmarsh_years:
                cache_years = set(df["timestamp"].dt.year)
                missing = [y for y in cfg.kelmarsh_years if y not in cache_years]
                if missing:
                    raise ValueError(f"cache {cfg.kelmarsh_cache} lacks requested years {missing}")
        else:
            farm = load_kelmarsh(cfg.kelmarsh_root, years=cfg.kelmarsh_years)
            df = prepare_farm(farm)
            if cfg.kelmarsh_cache:
                os.makedirs(os.path.dirname(cfg.kelmarsh_cache) or ".", exist_ok=True)
                df.to_csv(cfg.kelmarsh_cache, index=False)
    elif cfg.data_path:
        raw = pd.read_csv(cfg.data_path, parse_dates=[cfg.timestamp_col])
        df = pd.DataFrame({
            "timestamp": raw[cfg.timestamp_col],
            "power": pd.to_numeric(raw[cfg.target_col], errors="coerce"),
        })
        for w in cfg.weather_cols:
            df[w] = pd.to_numeric(raw[w], errors="coerce")
        df["power_filled"] = df["power"].ffill()
        df["power_valid"] = df["power"].notna()
    else:
        raw = generate_synthetic(
            n_days=cfg.synthetic_days, points_per_day=cfg.points_per_day, seed=cfg.seed,
        )
        df = pd.DataFrame({
            "timestamp": raw["timestamp"],
            "power": raw[cfg.target_col].astype(float),
        })
        for w in cfg.weather_cols:
            df[w] = raw[w].astype(float)
        df["power_filled"] = df["power"]
        df["power_valid"] = np.ones(len(df), dtype=bool)

    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


def _cyclic(x: float, period: float) -> "tuple[float, float]":
    a = 2 * np.pi * x / period
    return float(np.sin(a)), float(np.cos(a))


def downsample(v: np.ndarray, bins: int) -> np.ndarray:
    """Aggregate a 1-D array into `bins` contiguous blocks (mean per block)."""
    if len(v) <= bins:
        return v
    idx = np.linspace(0, len(v), bins + 1).astype(int)
    return np.array([v[idx[i]:idx[i + 1]].mean() for i in range(bins)])


def base_features(
    cond_power: np.ndarray,
    cond_weather: np.ndarray,
    ts: pd.Timestamp,
    ramp_thresh: float,
) -> np.ndarray:
    """Shape + weather + calendar features for one situation."""
    p = cond_power
    x = np.arange(len(p))
    slope = float(np.polyfit(x, p, 1)[0])
    ramp_count = float(np.sum(np.abs(np.diff(p)) > ramp_thresh))

    f = [
        float(np.mean(p)),
        float(np.std(p)),
        float(p[-1]),
        float(np.min(p)),
        float(np.max(p)),
        slope,
        ramp_count,
    ]
    for w in cond_weather.T:
        f += [float(np.mean(w)), float(np.std(w)), float(w[-1])]

    hs, hc = _cyclic(ts.hour + ts.minute / 60.0, 24.0)
    ds, dc = _cyclic(ts.dayofyear, 365.25)
    f += [hs, hc, ds, dc]
    return np.asarray(f, dtype=float)


def build_situations(df: pd.DataFrame, cfg: Config) -> dict:
    power_raw = df["power"].to_numpy(dtype=float)          # NaN where not fully observed
    power_filled = df["power_filled"].to_numpy(dtype=float)
    power_valid = df["power_valid"].to_numpy(dtype=bool)
    weather = df[cfg.weather_cols].to_numpy(dtype=float)
    ts_all = df["timestamp"]

    valid_power = power_raw[~np.isnan(power_raw)]
    capacity = cfg.capacity or float(np.percentile(valid_power, 99))
    ramp_thresh = cfg.ramp_threshold_frac * capacity

    C = cfg.condition_points
    H = cfg.horizon_points
    stride = cfg.stride_points

    # include the LAST origin that can still produce a full target (o + H <= len)
    origins = list(range(C, len(power_raw) - H + 1, stride))

    cond_list, target_list, feat_list = [], [], []
    ts_list, target_start_list, target_end_list, valid_list, idx_list = [], [], [], [], []

    for o in origins:
        tgt = power_raw[o:o + H]
        if len(tgt) < H:
            continue
        cond_p = power_filled[o - C:o]
        cond_w = weather[o - C:o]
        tgt_valid_all = bool(power_valid[o:o + H].all())
        if cfg.horizon_bins:
            tgt = downsample(tgt, cfg.horizon_bins)
        feat = base_features(cond_p, cond_w, ts_all.iloc[o - 1], ramp_thresh)
        cond_list.append(cond_p)
        target_list.append(tgt)
        valid_list.append(tgt_valid_all)
        feat_list.append(feat)
        ts_list.append(ts_all.iloc[o - 1])          # last_observed_ts (origin)
        target_start_list.append(ts_all.iloc[o])     # first target time
        target_end_list.append(ts_all.iloc[o + H - 1])  # last target time
        idx_list.append(o - 1)

    return {
        "cond": np.asarray(cond_list),        # (N, C) filled history
        "target": np.asarray(target_list),    # (N, H) raw target (NaN where invalid)
        "target_valid": np.asarray(valid_list, dtype=bool),  # (N,)
        "feat": np.asarray(feat_list),        # (N, F)
        "origin_ts": pd.Series(ts_list),      # last observed time
        "target_start_ts": pd.Series(target_start_list),
        "target_end_ts": pd.Series(target_end_list),
        "origin_idx": np.asarray(idx_list),
        "capacity": capacity,
    }


def chronological_split(n: int, cfg: Config) -> "tuple[np.ndarray, np.ndarray, np.ndarray]":
    idx = np.arange(n)
    n_train = int(n * cfg.train_frac)
    n_cal = int(n * cfg.cal_frac)
    return idx[:n_train], idx[n_train:n_train + n_cal], idx[n_train + n_cal:]
