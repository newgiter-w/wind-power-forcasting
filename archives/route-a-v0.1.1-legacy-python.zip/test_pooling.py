"""New pooled QRF must reproduce the existing full-leaf implementation."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'.aris/qrf-packages'))
import unittest
import copy
import pandas as pd
import numpy as np
from quantile_forest import RandomForestQuantileRegressor
from sparse_leaf_qrf import SparseLeafQRF
from pooling_common import assemble_pool


def toy_farm(ntrain=2):
    n=ntrain+2;origins=pd.date_range('2012-01-01',periods=n,freq='D').to_numpy()
    return dict(y=np.arange(n*24,dtype=float).reshape(n,24),valid=np.ones(n,dtype=bool),origins=origins,
        ends=origins+np.timedelta64(1,'D'),meta=pd.DataFrame(dict(phase=['train']*ntrain+['validation_seed','evaluation'])))


class PoolingProtocolChecks(unittest.TestCase):
    def test_identity_masks_and_back_mapping(self):
        farms={1:toy_farm(),2:toy_farm()};a={1:np.ones((96,3)),2:np.full((96,3),2.)}
        _,X,y,tr,stop,forecast,slices=assemble_pool(farms,a)
        np.testing.assert_equal(X[:96,-2:],np.tile([1,0],(96,1)))
        np.testing.assert_equal(X[96:,-2:],np.tile([0,1],(96,1)))
        for farm in farms:np.testing.assert_equal(y[slices[farm]].reshape(-1,24),farms[farm]['y'])
        self.assertEqual(tr.sum(),96);self.assertEqual(stop.sum(),48);self.assertEqual(forecast.sum(),96)

    def test_future_labels_do_not_change_training_or_features(self):
        farms={1:toy_farm(),2:toy_farm()};a={k:np.ones((96,3)) for k in farms}
        original=assemble_pool(farms,a);changed=copy.deepcopy(farms)
        changed[2]['y'][2:]+=10000
        new=assemble_pool(changed,a)
        np.testing.assert_equal(original[1],new[1]);np.testing.assert_equal(original[2][original[3]],new[2][new[3]])

    def test_other_farm_later_training_labels_are_rejected(self):
        farms={1:toy_farm(),2:toy_farm(3)};a={k:np.ones((len(d['y'])*24,3)) for k,d in farms.items()}
        with self.assertRaises(AssertionError):assemble_pool(farms,a)


class SparseQRFChecks(unittest.TestCase):
    def check_distribution(self,y):
        rng=np.random.default_rng(28);X=rng.normal(size=(len(y),5)).astype('float32')
        query=rng.normal(size=(90,5)).astype('float32')
        for seed in [0,1]:
            q=RandomForestQuantileRegressor(n_estimators=11,min_samples_leaf=4,max_features=1.,
                max_samples_leaf=None,random_state=seed,n_jobs=2).fit(X,y)
            s=SparseLeafQRF(n_estimators=11,min_samples_leaf=4,random_state=seed,n_jobs=2).fit(X,y)
            for a,b in zip(q.estimators_,s.forest.estimators_):
                np.testing.assert_equal(a.tree_.feature,b.tree_.feature)
                np.testing.assert_equal(a.tree_.threshold,b.tree_.threshold)
            qs=[.01,.05,.25,.5,.75,.95,.99]
            expected=q.predict(query,quantiles=qs,weighted_quantile=True,weighted_leaves=True,aggregate_leaves_first=True)
            np.testing.assert_allclose(s.predict(query,qs,batch_size=13),expected,atol=2e-12,rtol=2e-12)

    def test_continuous(self):
        self.check_distribution(np.random.default_rng(10).uniform(size=300))

    def test_boundary_atoms_and_duplicates(self):
        self.check_distribution(np.r_[np.zeros(160),np.ones(40),np.random.default_rng(10).uniform(size=100)])

    def test_constant_leaf_is_response_not_tree_mean(self):
        X=np.zeros((40,2),dtype='float32');y=np.r_[np.zeros(20),np.ones(20)]
        s=SparseLeafQRF(n_estimators=10,min_samples_leaf=4,n_jobs=2).fit(X,y)
        np.testing.assert_equal(s.predict(X[:1]),[[0.,1.]])


if __name__=='__main__':unittest.main()
