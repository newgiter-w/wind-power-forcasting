"""Regression witnesses for the substantive calibration/diffusion fixes."""
import unittest
import numpy as np
import torch
from online_calibration import score_quantile
from retrieval_diffusion import VelocityDiffusion
from run_revision_diffusion import sample_batch


class RevisionChecks(unittest.TestCase):
    def test_velocity_zero_reference_uses_target_not_one(self):
        diff=VelocityDiffusion();g=torch.Generator().manual_seed(19)
        clean=2*torch.randn((8000,24),generator=g)
        steps=torch.randint(1000,(len(clean),),generator=g)
        noise=torch.randn(clean.shape,generator=g)
        _,target=diff.noisy(clean,steps,noise)
        expected=(diff.abar[steps]+4*(1-diff.abar[steps])).mean().item()
        self.assertAlmostEqual(target.square().mean().item(),expected,delta=.06)
        self.assertGreater(target.square().mean().item(),2.)

    def test_zero_velocity_sampler_matches_finite_step_gaussian_gain(self):
        diff=VelocityDiffusion();steps=7
        samples=sample_batch(None,np.zeros((2,1),dtype='float32'),diff,samples=40,steps=steps)
        times=torch.linspace(999,0,steps).round().long().numpy()
        angles=np.arccos(np.sqrt(diff.abar.numpy()[times]));gain=np.prod(np.cos(np.diff(np.r_[angles,0.])))
        initial=torch.randn((40,24),generator=torch.Generator().manual_seed(8101)).numpy()
        np.testing.assert_allclose(samples[0],initial*gain,atol=2e-6,rtol=2e-6)
        np.testing.assert_equal(samples[0],samples[1])

    def test_signed_cqr_can_cancel_lower_quantile_shift(self):
        y=np.linspace(.1,.3,84)[:,None]
        final=[]
        for lo in [.1,0.]:
            q,_,_=score_quantile(np.maximum(lo-y,y-1.),.1)
            final.append(lo-q)
        np.testing.assert_allclose(final[0],final[1])

    def test_post_calibration_zero_protection_is_expansion(self):
        rng=np.random.default_rng(12);lower=rng.uniform(0,.5,(80,24));upper=lower+.4
        y=rng.uniform(0,1,lower.shape);risk=rng.uniform(0,1,lower.shape)
        protected=np.where(risk>=.2,0.,lower)
        self.assertTrue(np.all(protected<=lower))
        before=(y>=lower)&(y<=upper);after=(y>=protected)&(y<=upper)
        self.assertTrue(np.all(after|~before))


if __name__=='__main__':
    torch.set_num_threads(2)
    unittest.main()
