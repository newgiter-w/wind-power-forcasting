"""Generate GBM training/validation loss curves (pinball loss per boosting iteration).

The frozen models used early_stopping=False, so train_score_ is empty. This script
retrains a representative R2 (shared-head) HistGBR WITH early stopping + a
validation split, purely to visualize convergence (not to replace the frozen model).
"""
from __future__ import annotations

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from gefcom_protocol_v2 import index, prepare
from strong_baselines import build_shared

PKG = dict(max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, random_state=0)


def main():
    farms, _ = prepare(2014)
    d = farms[1]  # farm 1
    tr = index(d, 'train', True)
    X, y, S = build_shared(d, 'R2')  # unfolded (S*24, F)
    tr_unfolded = np.repeat(np.isin(np.arange(len(d['origins'])), tr), 24)
    sc = StandardScaler().fit(X[tr_unfolded])
    xs = sc.transform(X)
    Xtr = xs[tr_unfolded]; ytr = y[tr_unfolded]

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    for ax, q in zip(axes, (0.05, 0.95)):
        m = HistGradientBoostingRegressor(loss='quantile', quantile=q, max_iter=200, early_stopping=True,
                                          validation_fraction=0.2, n_iter_no_change=20, **PKG)
        m.fit(Xtr, ytr)
        ax.plot(np.arange(1, len(m.train_score_) + 1), m.train_score_, label='train pinball')
        ax.plot(np.arange(1, len(m.validation_score_) + 1), m.validation_score_, label='validation pinball')
        ax.axvline(50, color='gray', ls='--', lw=0.8, label='frozen max_iter=50')
        ax.axvline(m.n_iter_, color='red', ls=':', lw=1, label=f'early-stop at {m.n_iter_}')
        ax.set_title(f'R2 shared head · farm1 · q={q}')
        ax.set_xlabel('boosting iteration'); ax.set_ylabel('pinball loss')
        ax.grid(alpha=0.3); ax.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig('out_gefcom_strong_baselines_v1/gbm_loss_curve.png', dpi=110)
    plt.close(fig)
    print('saved: out_gefcom_strong_baselines_v1/gbm_loss_curve.png')
    for q in (0.05, 0.95):
        m = HistGradientBoostingRegressor(loss='quantile', quantile=q, max_iter=200, early_stopping=True,
                                          validation_fraction=0.2, n_iter_no_change=20, **PKG)
        m.fit(Xtr, ytr)
        i50 = min(49, len(m.validation_score_) - 1)
        print(f'q={q}: early-stop n_iter_={m.n_iter_}, val_loss@iter50={m.validation_score_[i50]:.4f}, '
              f'val_loss@final={m.validation_score_[-1]:.4f}')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
