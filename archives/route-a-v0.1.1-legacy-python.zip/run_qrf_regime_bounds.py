"""Replay grouped one-sided calibration for frozen single-farm QRF."""
from itertools import product
import numpy as np
import pandas as pd
from run_qrf_power_increment import BASE, ROOT, load_farms, feature_array, index, frozen_spec, write
from pooling_common import REVISION, local_heads
from revision_common import collect, calibration, METRIC_COLS
from run_qrf_speed_delta import added_features
from gefcom2014_experiment import masks

OUT = ROOT/'out_gefcom_qrf_regime_bounds_20261106'
PARAMS = dict(zip(
    (f'R{i:02}' for i in range(1,37)),
    product((.025,.05,.075),(.05,.075,.10),(.05,.075),(.5,1.))))
METHODS = ['original','guard_only',*PARAMS]
METRICS = ['width','coverage','IS','upper_miss']
GROUPS = ['all','up_ramp','near_zero','down_ramp']


def quantile(values, alpha):
    n = len(values)
    rank = min(n,int(np.ceil((n+1)*(1-alpha))))-1
    return float(np.partition(values,rank)[rank])


def variants(d,ids,seed,lo,hi,original_lo,original_hi,q,wind,risk):
    # The entire forecast NWP trajectory is available at issuance.
    nearby = pd.DataFrame(wind.T).rolling(5,center=True,min_periods=1).max().to_numpy().T
    state = np.where(wind>=.5,2,np.where(nearby>=.5,1,0))
    state[:,0] = 3
    low_state = risk>=.1
    width = hi-lo
    # Width class is computed from the issued raw endpoints, with fixed cutoffs.
    upper_group = 2*state+(width>=.45)
    lower_group = 2*low_state.astype(int)+(width>=.45)
    leads = np.broadcast_to(np.arange(24)//6,lo.shape)
    lower_adjustments = {a:q.copy() for a in (.05,.075)}
    upper_adjustments = {a:q.copy() for a in (.025,.05,.075,.10)}
    previous = np.r_[seed,ids]
    max_end=[]
    for k,day in enumerate(ids):
        now=d['origins'][day]
        past=previous[:len(seed)+k]
        ends=d['ends'][past]
        use=past[(ends<=now)&(ends>now-np.timedelta64(84,'D'))]
        use=use[d['valid'][use]]
        assert len(use)>=9 and np.all(d['ends'][use]<=now) and day not in use
        max_end.append(d['ends'][use].max())
        side_scores = (lo[use]-d['y'][use],d['y'][use]-hi[use])
        for labels,scores,adjustments in [(lower_group,side_scores[0],lower_adjustments),
                                           (upper_group,side_scores[1],upper_adjustments)]:
            for band in range(4):
                for group in np.unique(labels[day,6*band:6*(band+1)]):
                    target=(leads[day]==band)&(labels[day]==group)
                    values=scores[(leads[use]==band)&(labels[use]==group)]
                    n=len(values)
                    if n>=40:
                        shrink=n/(n+80)
                        for a,arr in adjustments.items():
                            arr[k,target]=(1-shrink)*q[k,target]+shrink*quantile(values,a)
    np.testing.assert_equal(np.array(max_end).shape,ids.shape)
    yield 'original',original_lo,original_hi,np.array(max_end)
    yield 'guard_only',np.where(low_state[ids],0,original_lo),original_hi,np.array(max_end)
    for name,(risky,calm,lower_alpha,strength) in PARAMS.items():
        uq=np.where((state[ids]==1)|(state[ids]==2),upper_adjustments[risky],upper_adjustments[calm])
        uq=np.where(state[ids]==3,q,uq)
        lq=lower_adjustments[lower_alpha]
        lower=np.clip(lo[ids]-((1-strength)*q+strength*lq),0,1)
        upper=np.clip(hi[ids]+((1-strength)*q+strength*uq),0,1)
        lower=np.where(low_state[ids],0,lower)
        midpoint=(lower+upper)/2
        crossed=lower>upper
        yield name,np.where(crossed,midpoint,lower),np.where(crossed,midpoint,upper),np.array(max_end)


def compare(year,stage,chosen=None):
    rows,daily=[],{}
    seed_phase='validation_seed' if stage=='validation' else 'validation'
    for farm,d in load_farms(year).items():
        folder=BASE/f'gefcom{year}/farm_{farm:02}'
        ids=index(d,stage)
        seed=index(d,seed_phase)
        lo,hi=local_heads(year,farm,'QRF',0)
        _,base=calibration(d,lo,hi,stage)
        with np.load(folder/f'{stage}_direct_qrf.npz') as z:
            np.testing.assert_equal(z['ids'],ids)
            lower,upper=z['lo'],z['hi']
            np.testing.assert_equal(lower,np.clip(base['lo'],0,1))
            np.testing.assert_equal(upper,np.clip(base['hi'],0,1))
        wind=added_features(feature_array(year,farm,'GBM'))[:,0].reshape(-1,24)
        risk=np.load(REVISION/f'mlp/gefcom{year}/farm_{farm:02}/risk_probabilities.npz')['probability']
        assert risk.shape==lo.shape and np.isfinite(risk).all()
        y=d['y'][ids]
        group_masks=masks(y,d['history'][ids,-1])
        for method,l,u,arrival in variants(d,ids,seed,lo,hi,lower,upper,base['q_signed'],wind,risk):
            np.testing.assert_equal(arrival,base['max_label_end_used'])
            assert np.isfinite(l).all() and np.isfinite(u).all() and (l<=u).all()
            collect(rows,d,ids,l,u,year=year,farm=farm,method=method,stage=stage)
            if method in ('original',chosen) and stage=='evaluation':
                vals=[u-l,(y>=l)&(y<=u),u-l+20*np.maximum(l-y,0)+20*np.maximum(y-u,0),y>u]
                for group in GROUPS:
                    keep=group_masks[group]&d['valid'][ids,None]
                    daily[method,farm,group]=(d['origins'][ids],np.column_stack(
                        [keep.sum(axis=1)]+[np.where(keep,v,0).sum(axis=1) for v in vals]))
                path=OUT/f'gefcom{year}/farm_{farm:02}'
                path.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(path/f'{method}.npz',ids=ids,lo=l,hi=u,max_calibration_end=arrival)
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{year}_{stage}_per_farm.csv',index=False)
    macro=frame.groupby(['method','group'])[METRIC_COLS].mean()
    macro.to_csv(OUT/f'{year}_{stage}_macro.csv')
    return macro,daily


def gates(macro,method):
    a,b=macro.loc['original'],macro.loc[method]
    return dict(coverage=bool(b.loc['all','coverage']>=.90),
        width=bool(b.loc['all','width']<a.loc['all','width']),
        up_upper=bool(b.loc['up_ramp','upper_miss']<a.loc['up_ramp','upper_miss']),
        near_zero=bool(b.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
        down_ramp=bool(b.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01),
        score=bool(b.loc['all','IS']<=a.loc['all','IS']))


def bootstrap(year,daily,chosen):
    dates=pd.date_range(min(v[0][0] for v in daily.values()),max(v[0][-1] for v in daily.values()))
    farms=sorted({k[1] for k in daily})
    cube=np.zeros((2,len(farms),len(GROUPS),len(dates),5))
    for (method,farm,group),(origin,values) in daily.items():
        pos=dates.get_indexer(origin)
        assert (pos>=0).all()
        cube[int(method==chosen),farms.index(farm),GROUPS.index(group),pos,:]=values
    def diff(a):
        sums=a.sum(axis=3)
        n=sums[...,:1]
        means=np.nanmean(np.divide(sums[...,1:],n,out=np.full_like(sums[...,1:],np.nan),where=n>0),axis=1)
        return means[1]-means[0]
    rng=np.random.default_rng(20261106+year)
    n=len(dates)
    samples=[]
    for _ in range(2000):
        start=rng.integers(0,n-13,size=int(np.ceil(n/14)))
        take=(start[:,None]+np.arange(14)).ravel()[:n]
        samples.append(diff(cube[:,:,:,take,:]))
    delta=diff(cube)
    lo,hi=np.quantile(samples,[.025,.975],axis=0)
    return [dict(year=year,group=g,metric=m,delta=delta[i,j],low=lo[i,j],high=hi[i,j])
            for i,g in enumerate(GROUPS) for j,m in enumerate(METRICS)]


def main():
    frozen_spec(OUT/'protocol.json',dict(seed=0,grid={k:list(v) for k,v in PARAMS.items()},
        calibrate='84-day rolling only arrived labels; empirical one-sided rank; six-lead bands; n>=40 and n/(n+80) shrinkage to signed CQR',
        groups='same-hour/nearby wind rise >=0.5m/s within +/-2 forecast leads; lead1 falls back on upper side; raw width >=.45; frozen near-zero risk .10',
        gates='coverage>=90%; lower width and up upper miss; near-zero/down coverage drop <=1pp; IS no worse',
        choose='2014Q2 narrowest passing; otherwise retain baseline and prefreeze diagnostic challenger by fewest failed gates then lowest IS',
        evaluation='both retrospective datasets with identical candidate grid; only 2014Q2 selects rule; evaluation frontier descriptive',
        bootstrap='2000 synchronous 14-day moving blocks'))
    dev,_=compare(2014,'validation')
    checks={m:gates(dev,m) for m in METHODS[1:]}
    passing=[m for m,v in checks.items() if all(v.values())]
    if passing:
        chosen=min(passing,key=lambda m:dev.loc[(m,'all'),'width'])
    else:
        chosen=min(checks,key=lambda m:(sum(not x for x in checks[m].values()),dev.loc[(m,'all'),'IS']))
    decision=dict(selected=chosen if passing else 'original',challenger=chosen,passing=passing,checks=checks)
    frozen_spec(OUT/'selection.json',decision)
    results={}
    boot=[]
    for year in (2014,2012):
        macro,daily=compare(year,'evaluation',chosen)
        boot.extend(bootstrap(year,daily,chosen))
        results[str(year)]={m:gates(macro,m) for m in METHODS[1:]}
    pd.DataFrame(boot).to_csv(OUT/'paired_blocks.csv',index=False)
    write(OUT/'completion.json',dict(status='complete',farms=17,decision=decision,evaluation_checks=results))
    print('COMPLETE',decision['selected'],chosen,flush=True)

if __name__=='__main__':
    main()
