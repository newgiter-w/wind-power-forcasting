"""Development-only oracle and prospectively usable equal-width upper policies."""
import numpy as np
import pandas as pd

from run_gefcom2012_hourly_upper_risk import OUT as RISK, BASE, YEAR, ROOT, load_farms
from gefcom2014_experiment import masks
from revision_common import collect, frozen_spec, write, METRIC_COLS
from run_qrf_regime_bounds import GROUPS, bootstrap

OUT = ROOT/'out_gefcom2012_upper_width_budget'
LIMIT = .05
POLICIES = {f'add{int(add*1000):03}_room{int(room*1000):03}': (add,room)
            for add in (.01,.025,.05) for room in (.10,.15)}


def read(d, farm, stage):
    folder = BASE/f'gefcom2012/farm_{farm:02}'
    with np.load(folder/f'{stage}_direct_qrf.npz') as z:
        ids, lo, hi = z['ids'], z['lo'], z['hi']
    with np.load(folder/'heads.npz') as z:
        np.testing.assert_array_equal(z['origins'],d['origins'])
        median = z['qrf'][ids]
    with np.load(RISK/f'farm_{farm:02}/{stage}.npz') as z:
        np.testing.assert_array_equal(z['ids'],ids)
        np.testing.assert_array_equal(z['valid'],d['valid'][ids])
        simple = z['methods'].tolist().index('simple')
        score, marked = z['score'][simple],z['marked'][simple]
    return ids,lo,hi,median,score,marked


def verify(lo, original, upper, daily):
    assert (upper>=lo).all() and (upper<=1).all()
    assert np.abs(upper-original).max()<=LIMIT+1e-12
    axis = 1 if daily else None
    np.testing.assert_allclose(upper.sum(axis=axis),original.sum(axis=axis),rtol=0,atol=1e-10)


def oracle(lo, hi, y, up):
    """Maximize exact rescues with no new misses or increased upper overrun."""
    cost = y-hi
    # Donors stop at observed power or at the frozen lower endpoint.
    donor_floor = np.minimum(hi,np.maximum.reduce([lo,y,hi-LIMIT]))
    donor = hi-donor_floor
    eligible = np.flatnonzero(up & (cost>0) & (cost<=LIMIT) & (y<=1))
    ranked = eligible[np.argsort(cost.flat[eligible],kind='stable')]
    cumulative = np.cumsum(cost.flat[ranked])
    selected = ranked[cumulative<=donor.sum()]
    spend = cost.flat[selected].sum()
    out = hi.copy()
    if spend:
        out = np.maximum(donor_floor,hi-donor*(spend/donor.sum()))
        out.flat[selected] = y.flat[selected]
    assert not ((y<=hi)&(y>out)).any()
    assert np.all(np.maximum(y-out,0)<=np.maximum(y-hi,0))
    return out, len(eligible), len(selected), float(spend), float(donor.sum())


def policy(lo, hi, median, score, marked, add, room):
    donor_rank = np.argsort(score,axis=1,kind='stable')[:,:12]
    donor_mask = np.zeros_like(marked)
    np.put_along_axis(donor_mask,donor_rank,True,axis=1)
    donor_mask &= ~marked
    supply = np.where(donor_mask,np.clip(hi-np.maximum(lo,median+room),0,LIMIT),0)
    demand = np.where(marked,np.minimum(add,1-hi),0)
    available = supply.sum(axis=1,keepdims=True)
    requested = demand.sum(axis=1,keepdims=True)
    budget = np.minimum(available,requested)
    plus = demand*np.divide(budget,requested,out=np.zeros_like(budget),where=requested>0)
    minus = supply*np.divide(budget,available,out=np.zeros_like(budget),where=available>0)
    out = np.clip(hi+plus-minus,lo,1)
    verify(lo,hi,out,daily=True)
    return out


def summary(rows, filename):
    data = pd.DataFrame(rows)
    data.to_csv(OUT/f'{filename}_per_farm.csv',index=False)
    macro = data.groupby(['model','group'])[METRIC_COLS].mean()
    macro.to_csv(OUT/f'{filename}_macro.csv')
    return macro


def gate(m, method):
    a,b = (m.loc[k] for k in ('original',method))
    return dict(up_delta=float(b.loc['up_ramp','upper_miss']-a.loc['up_ramp','upper_miss']),
        coverage=bool(b.loc['all','coverage']>=.90),
        IS=bool(b.loc['all','IS']<=a.loc['all','IS']),
        near_zero=bool(b.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
        down_ramp=bool(b.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01))


def passes(g):
    return g['up_delta']<=-.01 and all(g[k] for k in ('coverage','IS','near_zero','down_ramp'))


def oracle_stage(farms):
    audit, rows = [], []
    for farm,d in farms.items():
        ids,lo,hi,*_ = read(d,farm,'validation')
        assert d['valid'][ids].all()
        y = d['y'][ids]
        up = masks(y,d['history'][ids,-1])['up_ramp']
        base_miss = up&(y>hi)
        collect(rows,d,ids,lo,hi,farm=farm,model='original')
        for scope in ('farm_pool','farm_day'):
            ranges = [slice(None)] if scope=='farm_pool' else [slice(i,i+1) for i in range(len(ids))]
            out = hi.copy()
            for part in ranges:
                out[part], eligible, rescued, spend, supply = oracle(lo[part],hi[part],y[part],up[part])
                audit.append(dict(farm=farm,scope=scope,origin=str(d['origins'][ids[part][0]]),
                    missed=int(base_miss[part].sum()),eligible=eligible,rescued=rescued,spend=spend,safe_supply=supply))
            verify(lo,hi,out,daily=scope=='farm_day')
            assert not ((y<=hi)&(y>out)).any()
            collect(rows,d,ids,lo,out,farm=farm,model=scope)
    frame = pd.DataFrame(audit)
    frame.to_csv(OUT/'oracle_counts.csv',index=False)
    macro = summary(rows,'oracle')
    total = frame.groupby('scope')[['missed','eligible','rescued','spend','safe_supply']].sum()
    total.to_csv(OUT/'oracle_totals.csv')
    pooled = total.loc['farm_pool']
    proceed = bool(pooled.rescued/pooled.missed>=.10)
    frozen_spec(OUT/'oracle_decision.json',dict(advance_to_policy=proceed,
        missed=int(pooled.missed),rescued=int(pooled.rescued),daily_rescued=int(total.loc['farm_day','rescued'])))
    print(total.to_string(),flush=True)
    return proceed


def policy_stage(farms, stage, chosen=None):
    rows, daily, transitions = [], {}, []
    for farm,d in farms.items():
        ids,lo,hi,median,score,marked = read(d,farm,stage)
        y = d['y'][ids]
        groups = masks(y,d['history'][ids,-1])
        policies = POLICIES if chosen is None else {chosen:POLICIES[chosen]}
        methods = {'original':hi,**{k:policy(lo,hi,median,score,marked,*v) for k,v in policies.items()}}
        for name,u in methods.items():
            collect(rows,d,ids,lo,u,farm=farm,model=name)
            if name != 'original':
                valid = d['valid'][ids,None]
                up = groups['up_ramp']
                rescued = valid & (y>hi) & (y<=u)
                lost = valid & (y<=hi) & (y>u)
                transitions.append(dict(farm=farm,model=name,up_rescued=int((up&rescued).sum()),
                    up_new=int((up&lost).sum()),all_rescued=int(rescued.sum()),all_new=int(lost.sum())))
            if chosen is not None:
                w = u-lo
                values = [w,(y>=lo)&(y<=u),w+20*np.maximum(lo-y,0)+20*np.maximum(y-u,0),y>u]
                for group in GROUPS:
                    keep = groups[group]&d['valid'][ids,None]
                    daily[name,farm,group]=(d['origins'][ids],np.column_stack(
                        [keep.sum(axis=1)]+[np.where(keep,a,0).sum(axis=1) for a in values]))
        if chosen is not None:
            np.savez_compressed(OUT/f'evaluation_farm_{farm:02}.npz',ids=ids,lo=lo,original=hi,candidate=methods[chosen])
    macro = summary(rows,stage)
    pd.DataFrame(transitions).to_csv(OUT/f'{stage}_transitions.csv',index=False)
    if chosen is not None:
        pd.DataFrame(bootstrap(YEAR,daily,chosen)).to_csv(OUT/'evaluation_paired_blocks.csv',index=False)
    return macro


def main():
    frozen_spec(OUT/'protocol.json',dict(dataset='GEFCom2012 seven farms',base='frozen QRF signed rolling84 and fixed lower',
        development='2011 Q2',oracle='development only; greedy cheapest exact rescues from safe donors that create no new upper misses and no larger overrun; per-farm pooled primary and within-day sensitivity; 5pp cap in either direction',
        oracle_gate='rescue at least 10% of baseline up-ramp upper misses in pooled oracle',
        policies={k:list(v) for k,v in POLICIES.items()}, policy_rule='reuse simple ranking and 2-3 marked hours/day; fund from bottom 12 unmarked hours, protect median plus buffer, never exceed 5pp cut, proportionally scale to feasible daily total, allow unused demand',
        dev_gate='upper miss decreases at least 1pp macro, coverage >=90%, IS non-increasing, near-zero and down-ramp coverage each within 1pp of original',
        evaluation='run only if development passes; lowest up-miss difference among passing, then lowest IS and stable name; original historical evaluation only, synchronous paired 14-day blocks'))
    farms = load_farms(YEAR)
    assert list(farms)==list(range(1,8))
    if not oracle_stage(farms):
        write(OUT/'completion.json',dict(status='complete',decision='stop_at_oracle'))
        return
    dev = policy_stage(farms,'validation')
    checks = {m:gate(dev,m) for m in POLICIES}
    passing = [m for m,g in checks.items() if passes(g)]
    chosen = min(passing,key=lambda m:(checks[m]['up_delta'],dev.loc[(m,'all'),'IS'],m)) if passing else None
    frozen_spec(OUT/'selection.json',dict(selected=chosen,checks=checks))
    print('DEVELOPMENT',checks,'selected',chosen,flush=True)
    decision = dict(status='complete',decision='stop_at_development' if chosen is None else 'evaluated')
    if chosen is not None:
        result = policy_stage(farms,'evaluation',chosen)
        decision['evaluation_checks'] = gate(result,chosen)
    write(OUT/'completion.json',decision)


if __name__=='__main__':
    main()


