"""GEFCom2014-Wind NWP adapter: daily samples (24h history + 24h target + future NWP).

Per the analysis report: capacity=1.0 (normalized power), hourly grid, daily
origin at midnight, history=24 points, target=24 points, future NWP = the U/V
forecasts at the target's 24 valid times (protocol-derived origin; no fabricated
ECMWF issue time).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

TASK15 = r"D:\Study\wind_datasets\nwp_benchmarks\gefcom2014_wind\data\Wind\Task 15\Task15_W_Zone1_10\Task15_W_Zone1_10\Task15_W_Zone{}.csv"
ZONES = range(1, 11)
NWP_NAMES = ['U10', 'V10', 'U100', 'V100']


def load_zone(zone: int) -> pd.DataFrame:
    df = pd.read_csv(TASK15.format(zone))
    df['TIMESTAMP'] = pd.to_datetime(df['TIMESTAMP'], format='%Y%m%d %H:%M')
    df = df.sort_values('TIMESTAMP').reset_index(drop=True)
    return df


def build_samples(df: pd.DataFrame) -> dict:
    """Slice a zone's continuous hourly series into daily forecast samples."""
    times = pd.DatetimeIndex(df['TIMESTAMP'])
    if times.has_duplicates or not times.equals(pd.date_range(times.min(), times.max(), freq='h')):
        raise ValueError('A unique, continuous hourly grid is required')
    if times[0].hour != 1 or len(times) % 24:
        raise ValueError('Expected complete competition days from 01:00 to next midnight')
    power = df['TARGETVAR'].to_numpy(dtype=float)
    u10 = df['U10'].to_numpy(dtype=float); v10 = df['V10'].to_numpy(dtype=float)
    u100 = df['U100'].to_numpy(dtype=float); v100 = df['V100'].to_numpy(dtype=float)
    ts = df['TIMESTAMP'].to_numpy()
    n = len(power)
    n_days = n // 24
    hist, tgt, nwp, valid, origin = [], [], [], [], []
    for k in range(1, n_days):
        h = power[24 * (k - 1):24 * k]
        t = power[24 * k:24 * (k + 1)]
        u1 = u10[24 * k:24 * (k + 1)]; v1 = v10[24 * k:24 * (k + 1)]
        u2 = u100[24 * k:24 * (k + 1)]; v2 = v100[24 * k:24 * (k + 1)]
        t_valid = np.isfinite(t) & (t >= 0) & (t <= 1)
        if len(t) < 24:
            continue
        hist.append(h)
        tgt.append(t)
        nwp.append(np.stack([u1, v1, u2, v2], axis=1))  # (24, 4)
        valid.append(bool(t_valid.all()))
        origin.append(ts[24 * k - 1])
    return {
        'history': np.asarray(hist, dtype=float),      # (S, 24)
        'target': np.asarray(tgt, dtype=float),        # (S, 24)
        'future_nwp': np.asarray(nwp, dtype=float),    # (S, 24, 4)
        'target_valid': np.asarray(valid, dtype=bool), # (S,)
        'origin_ts': np.asarray(origin, dtype='datetime64[ns]'),
        'history_valid': np.isfinite(np.asarray(hist)).all(axis=1),
        'nwp_valid': np.isfinite(np.asarray(nwp)).all(axis=(1, 2)),
    }


def base_features(history: np.ndarray, origin_ts: np.datetime64) -> np.ndarray:
    """7 power stats + 4 calendar cycles (day-of-year + hour, both cyclic)."""
    p = history
    x = np.arange(len(p))
    slope = float(np.polyfit(x, p, 1)[0])
    ramp_count = float(np.sum(np.abs(np.diff(p)) > 0.10))
    f = [float(p.mean()), float(p.std()), float(p[-1]), float(p.min()), float(p.max()),
         slope, ramp_count]
    ts = pd.Timestamp(origin_ts)
    f += [np.sin(2 * np.pi * ts.dayofyear / 365.25), np.cos(2 * np.pi * ts.dayofyear / 365.25),
          np.sin(2 * np.pi * ts.hour / 24.0), np.cos(2 * np.pi * ts.hour / 24.0)]
    return np.asarray(f, dtype=float)
