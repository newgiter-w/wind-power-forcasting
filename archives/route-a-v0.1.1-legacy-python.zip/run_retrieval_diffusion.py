"""Frozen developmental three-arm experiment. Actual artifacts, no future test access."""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ.setdefault(k,'4')
from pathlib import Path
import json,time,hashlib,importlib.util,copy,sys
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler
from data import build_situations,load_dataframe
from execute_x01 import cfg_for
from retrieval import dtw_distance,zscore,Retriever
from retrieval_diffusion import HistoryAnchor,ResidualDenoiser,VelocityDiffusion
from online_calibration import simulate

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_diffusion_dev_v1'
PERIODS={'M':('2018-01-01','2019-01-01'),'fit':('2019-01-01','2020-10-01'),
         'stop':('2020-10-01','2021-01-01'),'cal':('2021-01-01','2021-04-01'),
         'score':('2021-04-01','2021-07-01')}
SPEC={'scope':'development only; NOT independent confirmation','periods':PERIODS,
      'target':'24 future hourly averages; 10-min grid, daily issue','capacity':12300,
      'model':'shared frozen history MLP anchor + FiLM joint residual velocity diffusion',
      'changes_from_manuscript':'residual coordinates, frozen shared anchor, v target, MLP denoiser, deterministic DDIM',
      'anchor_seed':0,'diffusion_seeds':[0,1,2],'modes':['none','random','similar'],
      'anchor_epochs':180,'anchor_patience':25,'diffusion_epochs':200,'diffusion_patience':30,
      'batch_size':128,'anchor_lr':.001,'diffusion_lr':.0005,'weight_decay':.0001,
      'noise_steps':1000,'sampling_steps':40,'samples':200,'sampling_seed':8101,
      'retrieval_k':20,'shortlist':40,'dtw_band':12,'random_neighbor_seed':71,
      'calibration':'raw, global CQR, rolling CQR84; same arrived whole-day feedback',
      'no_target_clipping':True,'threads':4,'max_opened_score_year':2021,
      'selection':'checkpoints only by chronological stop segment; all 9 candidates reported',
      'future_evaluation':'no 2022-2024 scoring in this round'}

def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def prepare():
    OUT.mkdir(exist_ok=True)
    if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==json.loads(json.dumps(SPEC))
    else:write(OUT/'protocol.json',SPEC)
    if (OUT/'data.npz').exists():
        with np.load(OUT/'data.npz') as p:return {k:p[k] for k in p.files}
    cfg=cfg_for();df=load_dataframe(cfg)
    df=df[df.timestamp<'2021-07-01'].reset_index(drop=True)
    d=build_situations(df,cfg);dates=d['origin_ts'].to_numpy(dtype='datetime64[ns]');ends=d['target_end_ts'].to_numpy(dtype='datetime64[ns]')
    phases={};manifest=[]
    for name,(start,end) in PERIODS.items():
        mask=(dates>=np.datetime64(start))&(dates<np.datetime64(end))
        if name!='M':mask &= ends<np.datetime64(end)
        if name in ('M','fit','stop'):mask &= d['target_valid']
        phases[name]=np.flatnonzero(mask)
        for i in phases[name]:manifest.append({'phase':name,'global_index':int(i),'origin':str(dates[i]),'target_end':str(ends[i]),'target_valid':bool(d['target_valid'][i])})
    assert ends[phases['M']].max()<=dates[phases['fit'][0]]
    for a,b in [('fit','stop'),('stop','cal'),('cal','score')]:assert ends[phases[a]].max()<dates[phases[b][0]]
    queries=np.concatenate([phases[n] for n in ('fit','stop','cal','score')]);memory=phases['M']
    assert ends[memory].max()<=dates[queries].min()
    quality=np.stack([df.power_valid.to_numpy()[o-143:o+1].reshape(24,6).mean(axis=1) for o in d['origin_idx']])
    hist=np.hstack([d['feat'],d['cond'],quality])[queries]
    scaler=StandardScaler().fit(hist[:len(phases['fit'])]);hist=scaler.transform(hist).astype('float32')
    assert np.isfinite(hist).all()
    y=d['target'][queries]/12300.
    fit_n=len(phases['fit']);ymu=float(y[:fit_n].mean());ysd=float(y[:fit_n].std())
    frame=pd.DataFrame(manifest);frame.to_csv(OUT/'split_manifest.csv',index=False)
    print('SPLIT',frame.groupby('phase').size().to_dict(),flush=True)
    # Reuse only exact matching previously computed correct-DTW neighbor rows.
    old=ROOT/'out_v3/repair/neighbors_dtw.npz'
    with np.load(old) as p:
        np.testing.assert_array_equal(p['memory'],memory)
        np.testing.assert_array_equal(p['memory_cond'],d['cond'][memory])
        np.testing.assert_array_equal(p['memory_targets'],d['target'][memory])
        rows=pd.Index(p['queries']).get_indexer(queries);cached=rows>=0
        np.testing.assert_array_equal(p['query_cond'][rows[cached]],d['cond'][queries[cached]])
        # Polyfit slopes vary at ~1e-13 across BLAS thread settings.
        np.testing.assert_allclose(p['query_feat'][rows[cached]],d['feat'][queries[cached]],rtol=1e-11,atol=1e-10)
        sim_local=np.empty((len(queries),20),dtype=int);sim_dist=np.empty((len(queries),20))
        sim_local[cached]=p['local'][rows[cached]];sim_dist[cached]=p['distances'][rows[cached]]
    if not cached.all():
        ret=Retriever(d['cond'][memory],d['feat'][memory],d['target'][memory],memory,cfg)
        for row in np.flatnonzero(~cached):
            ids,dist,_=ret.query(d['cond'][queries[row]],d['feat'][queries[row]],top_k=20)
            sim_local[row]=ids;sim_dist[row]=dist
    print('REUSED_NEIGHBORS',int(cached.sum()),'new queries',int((~cached).sum()),flush=True)
    rng=np.random.default_rng(71);random_local=[];random_dist=[];began=time.perf_counter()
    for count,qi in enumerate(queries):
        ids=rng.choice(len(memory),20,replace=False)
        distances=np.array([dtw_distance(zscore(d['cond'][qi]),zscore(d['cond'][memory[j]]),12) for j in ids])
        order=np.lexsort((memory[ids],distances));random_local.append(ids[order]);random_dist.append(distances[order])
        if count%100==0:print('Random matched DTW',count,len(queries),round(time.perf_counter()-began,1),flush=True)
    analog={};targets={}
    for name,ids,dist in [('similar',sim_local,sim_dist),('random',np.array(random_local),np.array(random_dist))]:
        yt=d['target'][memory][ids]/12300.;w=1/(dist+1e-6);w/=w.sum(axis=1,keepdims=True)
        analog[name]=np.hstack([(yt*w[:,:,None]).sum(axis=1),yt[:,0],np.ones((len(queries),1))]).astype('float32')
        targets[name]=yt
    result={'origins':dates[queries],'target_end':ends[queries],'valid':d['target_valid'][queries],
            'history':hist,'y':y.astype('float32'),'y_mean':np.array(ymu),'y_std':np.array(ysd),
            'last_hour':d['cond'][queries,-6:].mean(axis=1),'queries':queries,'memory':memory,
            'similar':analog['similar'],'random':analog['random'],'similar_targets':targets['similar'],
            'similar_ids':memory[sim_local],'random_ids':memory[np.array(random_local)],
            'hist_scaler_mean':scaler.mean_,'hist_scaler_scale':scaler.scale_}
    cursor=0
    for name in ('fit','stop','cal','score'):
        result[name]=np.arange(cursor,cursor+len(phases[name]));cursor+=len(phases[name])
    np.savez_compressed(OUT/'data.npz',**result)
    return result

def train_anchor(d):
    p=OUT/'anchor.pt';x=torch.from_numpy(d['history']);yn=torch.from_numpy(((d['y']-d['y_mean'])/d['y_std']).astype('float32'))
    torch.manual_seed(0);model=HistoryAnchor(x.shape[1]);optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
    if p.exists():model.load_state_dict(torch.load(p,weights_only=True)['weights'])
    else:
        best=float('inf');wait=0;trace=[]
        for epoch in range(180):
            order=d['fit'][torch.randperm(len(d['fit'])).numpy()];model.train();losses=[]
            for ids in np.array_split(order,max(1,int(np.ceil(len(order)/128)))):
                optimizer.zero_grad();mu,_=model(x[ids]);loss=(mu-yn[ids]).square().mean();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step();losses.append(loss.item())
            model.eval()
            with torch.no_grad():val=(model(x[d['stop']])[0]-yn[d['stop']]).square().mean().item()
            trace.append({'epoch':epoch+1,'train_mse':float(np.mean(losses)),'stop_mse':val})
            if val<best-1e-6:best=val;wait=0;torch.save({'weights':model.state_dict(),'epoch':epoch+1,'stop_mse':val},p)
            else:wait+=1
            if (epoch+1)%20==0:print('ANCHOR',epoch+1,round(val,4),flush=True)
            if wait>=25:break
        write(OUT/'anchor_curve.json',trace);model.load_state_dict(torch.load(p,weights_only=True)['weights'])
    model.eval()
    with torch.no_grad():mu,latent=model(x)
    residual=yn-mu;scale=residual[d['fit']].square().mean(dim=0).sqrt().clamp_min(.1)
    return mu.numpy(),latent.numpy(),scale.numpy(),(residual/scale).numpy()

def train_task(d,mu,latent,scale,residual,mode,seed):
    directory=OUT/f'{mode}_s{seed}';directory.mkdir(exist_ok=True)
    ctx=np.hstack([latent,mu,np.zeros_like(d['similar']) if mode=='none' else d[mode]]).astype('float32')
    context=torch.from_numpy(ctx);clean=torch.from_numpy(residual.astype('float32'))
    torch.manual_seed(seed);model=ResidualDenoiser(context=ctx.shape[1])
    diffusion=VelocityDiffusion();optimizer=torch.optim.AdamW(model.parameters(),lr=.0005,weight_decay=.0001)
    checkpoint=directory/'model.pt';start=time.perf_counter()
    vg=torch.Generator().manual_seed(9821);val_ids=np.tile(d['stop'],4)
    vs=torch.randint(1000,(len(val_ids),),generator=vg);vn=torch.randn((len(val_ids),24),generator=vg)
    vz,vtarget=diffusion.noisy(clean[val_ids],vs,vn)
    if not checkpoint.exists():
        trace=[];best=float('inf');wait=0
        for epoch in range(200):
            order=d['fit'][torch.randperm(len(d['fit'])).numpy()];model.train();losses=[]
            for ids in np.array_split(order,int(np.ceil(len(order)/128))):
                optimizer.zero_grad();loss=diffusion.loss(model,clean[ids],context[ids]);loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step();losses.append(loss.item())
            model.eval()
            with torch.no_grad():val=(model(vz,vs,context[val_ids])-vtarget).square().mean().item()
            trace.append({'epoch':epoch+1,'train_v_mse':float(np.mean(losses)),'stop_v_mse':val})
            if val<best-1e-6:best=val;wait=0;torch.save({'weights':model.state_dict(),'epoch':epoch+1,'stop_mse':val},checkpoint)
            else:wait+=1
            if (epoch+1)%25==0:print('TRAIN',mode,seed,epoch+1,round(val,4),'seconds',round(time.perf_counter()-start,1),flush=True)
            if epoch>=49 and wait>=30:break
        write(directory/'training_curve.json',trace)
    saved=torch.load(checkpoint,weights_only=True);model.load_state_dict(saved['weights']);model.eval()
    eval_ids=np.r_[d['cal'],d['score']]
    if not (directory/'predictions.npz').exists():
        sampled=diffusion.sample(model,context[eval_ids],samples=200,steps=40,seed=8101)
        samples=(mu[eval_ids,None,:]+sampled*scale[None,None,:])*float(d['y_std'])+float(d['y_mean'])
        assert np.isfinite(samples).all()
        np.savez_compressed(directory/'predictions.npz',indices=eval_ids,samples_kw=samples*12300,
            raw_lo=np.quantile(samples,.05,axis=1)*12300,raw_hi=np.quantile(samples,.95,axis=1)*12300,
            sample_mean=samples.mean(axis=1)*12300,sample_median=np.median(samples,axis=1)*12300)
    write(directory/'fit_info.json',{'mode':mode,'seed':seed,'best_epoch':saved['epoch'],'stop_loss':saved['stop_mse'],
        'parameters':sum(p.numel() for p in model.parameters()),'wall_seconds_this_invocation':time.perf_counter()-start,
        'anchor_shared_frozen':True,'anchor_weights_sha256':hashlib.sha256((OUT/'anchor.pt').read_bytes()).hexdigest()})
    print('DONE',mode,seed,'elapsed',round(time.perf_counter()-start,1),flush=True)

def main():
    torch.set_num_threads(4);torch.set_num_interop_threads(1)
    d=prepare();mu,latent,scale,residual=train_anchor(d)
    np.savez_compressed(OUT/'anchor_predictions.npz',mu_kw=(mu*float(d['y_std'])+float(d['y_mean']))*12300,
                        residual_scale=scale,normalized_residual=residual,latent=latent)
    for seed in [0,1,2]:
        for mode in ['none','random','similar']:train_task(d,mu,latent,scale,residual,mode,seed)
    print('ALL_TRAINED',flush=True)

if __name__=='__main__':main()
