"""Replay pooling input/preprocessing contracts against the original loader."""
import numpy as np
import joblib
from gefcom_protocol_v2 import prepare,index
from strong_baselines import build_shared
from run_p2_2012 import build_shared_2012
from pooling_common import OUT,write,load_farms,feature_array


def main():
    checks=[]
    for year in [2014,2012]:
        stored=load_farms(year)
        for farm,d in prepare(year)[0].items():
            for name in ['origins','ends','y','valid','history']:np.testing.assert_equal(stored[farm][name],d[name])
            canonical=feature_array(year,farm,'GBM');raw=canonical.copy()
            raw[:,35:107]=canonical[:,35:107].reshape(-1,3,24).transpose(0,2,1).reshape(-1,72)
            original=(build_shared if year==2014 else build_shared_2012)(d,'R2')[0]
            np.testing.assert_equal(raw,original)
            tm=np.repeat(np.isin(np.arange(len(d['y'])),index(d,'train',True)),24)
            bundle=joblib.load(OUT/f'inputs/gefcom{year}/farm_{farm:02d}/preprocessing.joblib')
            zero=np.nan_to_num(original,nan=0.)
            np.testing.assert_allclose(bundle['MLP_scaler'].mean_,zero[tm].mean(axis=0),atol=1e-10)
            np.testing.assert_equal(bundle['MLP_scaler'].transform(zero).astype('float32'),feature_array(year,farm,'MLP'))
            np.testing.assert_equal(bundle['QRF_imputer'].transform(canonical).astype('float32'),feature_array(year,farm,'QRF'))
            checks.append(dict(year=year,farm=farm,columns=raw.shape[1],rows=len(raw),
                exact_legacy_reconstruction=True,preprocessing_train_only=True,calendar_labels_history_match=True))
    write(OUT/'global_normalization_feature_check.json',dict(status='passed',checks=checks))
    print('POOLING INPUTS VERIFIED',len(checks),flush=True)


if __name__=='__main__':main()
