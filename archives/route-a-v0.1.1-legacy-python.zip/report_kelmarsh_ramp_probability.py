"""Publish development evidence and the predeclared gate decision."""
import json
import pandas as pd

from run_kelmarsh_ramp_probability import OUT,QUARTERS,SEASONS

LABELS={'december2023_development':'原开发期2023-12','expanded_development':'扩展开发期2024-02至12',
    'feb_mar':'2–3月','apr_jun':'4–6月','jul_sep':'7–9月','oct_dec':'10–12月',
    'winter_partial_DF':'不完整冬季：2月及12月','spring_MAM':'春季3–5月','summer_JJA':'夏季6–8月','autumn_SON':'秋季9–11月'}
NAMES={'qrf':'原QRF','annual_q90':'年度q90','ramp_probability':'直接概率模型'}


def summary(name,operation='same_fpr_development',scope='gated'):
    d=pd.read_csv(OUT/name/'summary.csv')
    return d[(d.operation==operation)&(d.scope==scope)].set_index('model')


def ci(name,ref='annual_q90',scope='gated',block=14,metric='recall',operation='same_fpr_development'):
    d=pd.read_csv(OUT/name/'paired_blocks.csv')
    return d[(d.operation==operation)&(d.scope==scope)&(d.block==block)&(d.reference==ref)&(d.metric==metric)].iloc[0]


def fmt(r):
    return f'{r.delta*100:+.2f} [{r.low*100:+.2f}, {r.high*100:+.2f}]'


def main():
    decision=json.loads((OUT/'decision.json').read_text(encoding='utf-8'))
    sample=json.loads((OUT/'sample_counts.json').read_text())
    lines=['# 同年度训练的直接上爬坡概率模型｜2026-11-07','',
        '开发比较完成，未通过预先锁定门槛。未打开新的独立评价数据，未冻结部署阈值，原QRF和区间端点保持不变。',
        '本轮主要回答：把年度q90残差上分位目标换为直接事件概率，在相同数据、输入、树复杂度及误报预算下能否提高事件识别。结果尚不支持这一收益。','',
        '## 数据、模型与时间规则','',
        '- 年度训练：Kelmarsh 2022-08至2023-07，与先前年度q90相同的297个完整发报日、1387个门控小时、231个正例、1156个负例。目标是该小时实测增幅>0.10装机容量；没有把邻近±1小时也改成正例。',
        '- 冻结QRF：仍为2023-09至10训练的原模型及预处理，离线生成更早且目标不重叠的年度训练特征；不把这写成2022年的真实历史上线回测。年度q90直接加载旧权重。',
        '- 输入：与年度q90相同的9项特征，即QRF增幅、前一功率水平、中位数、NWP风速、风速变化、风向变化、U/V单位分量和预测时效。NWP门控仍是同小时风速增加≥0.5m/s。',
        '- 候选：一个HistGradientBoostingClassifier，log_loss；其余共享超参数与年度q90相同，40轮、最大7叶、最小叶样本50、L2=1、随机种子0、无早停。无类别加权、重采样或超参数搜索。',
        '- 概率模型仅改报警分数，不将概率加到功率或区间端点。年度q90分数为原QRF增幅加原始预测残差，完全不裁剪。门控外所有方法均保留原QRF报警。',
        '- 00UTC发报，前一日18UTC GFS批次及原归档时间可用性规则不变，24小时完整目标及历史筛选不变。',
        '- 原开发期为2023-12，26个完整日；扩展开发期为已多次查看的2024-02至12，287/335个完整日。这里全部属于开发/回顾，不能称独立确认。',
        '- 误报预算匹配原QRF在门控平稳小时（实际绝对增幅≤0.05）上的误报数。并列分数按此前冻结的按日伪随机次序处理。±1小时为每个24小时发报日内一对一事件匹配，按真实事件是否在门控内归组。',
        '- 季节除沿用旧季度组外，另列春MAM、夏JJA、秋SON和缺1月的冬季。各子组事后工作点单独匹配误报数；另报告整期工作点原样用于子组的漂移。','',
        '## 主结果：同平稳误报数的开发排序诊断','',
        '| 数据 | 方案 | ±1h命中/真实爬坡 | 召回率% | 平稳误报/小时 | 所有非爬坡小时误报/小时 |',
        '|---|---|---:|---:|---:|---:|']
    for g in ('december2023_development','expanded_development'):
        d=summary(g)
        for m in NAMES:
            r=d.loc[m]
            lines.append(f'| {LABELS[g]} | {NAMES[m]} | {int(r.hits)}/{int(r.events)} | {100*r.recall:.2f} | {int(r["false"])}/{int(r.quiet)} | {int(r.false_nonramps)}/{int(r.nonramps)} |')
    lines.extend(['','| 扩展开发期对比 | 门控内±1h召回差pp [95%CI] | 全小时±1h召回差pp [95%CI] |',
                  '|---|---:|---:|'])
    for ref in ('annual_q90','qrf'):
        lines.append(f'| 概率模型 − {NAMES[ref]} | {fmt(ci("expanded_development",ref))} | {fmt(ci("expanded_development",ref,scope="all"))} |')
    lines.extend(['',
        '全小时口径包括门控外真实爬坡：QRF命中110/625，q90为124/625，概率模型为125/625；三组全小时平稳误报均为80/4193。这个略正的总体点估计不能替代预先指定的门控组主要终点，也未获配对区间确认。',
        '同预算仅指平稳小时；全部非爬坡小时误报可不同。门控内概率模型120次、q90为117次，不能宣称总体误报更低。','',
        '## 季节和季度稳定性','',
        '| 分组 | 真爬坡 | 原QRF命中 | 年度q90命中 | 概率命中 | 平稳误报数 | 概率减q90召回差pp [95%CI] |',
        '|---|---:|---:|---:|---:|---:|---:|'])
    for g in (*QUARTERS,*SEASONS):
        d=summary(g);r=d.loc['ramp_probability']
        lines.append(f'| {LABELS[g]} | {int(r.events)} | {int(d.loc["qrf","hits"])} | {int(d.loc["annual_q90","hits"])} | {int(r.hits)} | {int(r["false"])} | {fmt(ci(g))} |')
    lines.extend(['',
        '季度仅2/4方向非负，2–3月下降超过5pp；三个完整气象季均低于q90，夏、秋下降超过5pp。不能因4–6月单组改善就称季节稳定。未进行多重比较校正，分组是开发诊断。',
        '', '## 整期开发工作点原样用于子组','',
        '这些工作点使用整个扩展开发期标签确定，仍是开发诊断，不是冻结部署验证。以下展示工作点漂移，不强制各季节相同误报数。','',
        '| 分组 | q90命中/真爬坡 | 概率命中/真爬坡 | q90平稳误报/小时 | 概率平稳误报/小时 |',
        '|---|---:|---:|---:|---:|'])
    for g in (*QUARTERS,*SEASONS):
        d=summary(g,'pooled_development_cutoff');a=d.loc['annual_q90'];b=d.loc['ramp_probability']
        lines.append(f'| {LABELS[g]} | {int(a.hits)}/{int(a.events)} | {int(b.hits)}/{int(b.events)} | {int(a["false"])}/{int(a.quiet)} | {int(b["false"])}/{int(b.quiet)} |')
    lines.extend(['','## 概率学习与低误报事件识别的区别','',
        '| 范围 | 正例比例 | 平均预测概率 | 概率Brier | 训练频率常数Brier | 概率AUC | q90 AUC | 概率AP | q90 AP |',
        '|---|---:|---:|---:|---:|---:|---:|---:|'])
    for label,path in [('训练内',OUT/'training_ranking.json'),('扩展开发',OUT/'expanded_development'/'ranking.json')]:
        r=json.loads(path.read_text())
        keys=('prevalence','probability_mean','Brier','Brier_training_constant','probability_AUC','q90_AUC','probability_AP','q90_AP')
        lines.append('| '+label+' | '+' | '.join(f'{r[k]:.4f}' for k in keys)+' |')
    lines.extend(['',
        '1. 概率模型不是常数塌缩：开发期Brier优于训练频率常数，说明有部分可迁移的事件信息；但这不等于低误报工作点的召回更好。',
        '2. 开发AUC/AP未超过q90，精确同小时命中也从q90的59次降到概率模型51次。当前证据不支持“只需把q90目标换成同小时二分类就能解决爬坡”。',
        '3. 训练到开发的AUC从0.857降到0.717，AP从0.591降到0.263，可能涉及泛化差距或时序分布变化。单次固定配置无法区分过拟合、气象信号不足和输入表达不足。平均预测概率接近正例比例也不能证明尾部概率校准良好。',
        '4. log_loss优化全部门控小时的同小时事件概率；目标工作点是低平稳误报预算下的±1小时事件匹配。损失与终点仍有差别，但本轮不能据此认定差别就是主要原因。','',
        '## 配对置信区间与完整性','',
        '| 相对年度q90 | 7日区块 | 14日区块（主） | 28日区块 |',
        '|---|---:|---:|---:|',
        '| 扩展开发门控召回差pp [CI] | '+' | '.join(fmt(ci('expanded_development',block=b)) for b in (7,14,28))+' |','',
        '- 2000次配对非循环日历移动区块；同日期共同抽样，缺测日期记零计数，不填造预测或观测。置信区间条件于已拟合模型和诊断工作点，重采样内未重新匹配阈值；它不包含重训或阈值再估计不确定性。',
        '- 冬季包含不相邻的2月和12月，区块重采样不跨填造数据；该组缺1月且间隔很长，仅作补充，不进入完整气象季门槛。',
        '- 冻结QRF、q90哈希未变；共享模型超参数一致；将未来目标改为零后特征和QRF输出不变；全年QRF/q90计数精确复现上一轮70/73命中和56次误报。核验记录见verification.json。',
        '- 已用项目CPU环境实际完成种子量化内核检查，Python3.13 / sklearn1.5.2 / NumPy2.1.3 / pandas2.2.3，无环境重建。第一次执行仅在JSON输出numpy整数时失败，修复类型转换后原配置重跑，没有调整模型、门槛或评价样本。','',
        '## 门槛、独立验证与决定','',
        '```json',json.dumps(decision,ensure_ascii=False,indent=2),'```','',
        '本轮在开发阶段已经不满足条件，按预定顺序停止。没有thresholds.json部署冻结文件，也没有新的独立评分结果；目录中的diagnostic_cutoffs.json仅是开发排序诊断工作点。不得将此前已看过的Penmanshiel 2024年再标成独立确认。',
        '原功率与区间方法继续冻结。本轮不报告新的区间覆盖、宽度、IS或增幅MAE收益，因为概率分支没有给功率或区间作任何修正。',
        '后续若另行立项，应先在开发数据诊断错排事件的可辨识性及低误报损失目标，再决定是否需要补气象信息或改变训练。当前结果不足以支持直接接入区间、替换QRF，也不足以否定所有分类器或更广泛的区间预测方案。','',
        '## 复现','',
        '```powershell','python -u run_kelmarsh_ramp_probability.py','python report_kelmarsh_ramp_probability.py','```','',
        '- protocol.json：拟合前冻结的模型、口径与门槛；source_executed.py：本次执行源文件。',
        '- classifier.joblib / training_counts.json / training_ranking.json：模型、训练计数与拟合程度。',
        '- 各组summary.csv、daily.csv、paired_blocks.csv、ranking.json、scores.npz：原始配对计数、条件区间与逐小时评分，可独立复核。',
        '- weights.json / verification.json / decision.json / completion.json：冻结权重、完整性与门槛判定。',''])
    (OUT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print('REPORT WRITTEN',OUT/'RESULTS.md')


if __name__=='__main__':
    main()
