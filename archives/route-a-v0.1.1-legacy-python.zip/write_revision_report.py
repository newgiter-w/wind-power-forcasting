"""Generate the status and manuscript from verified revision artifacts."""
from pathlib import Path
import json
import shutil
import numpy as np
import pandas as pd
from revision_common import ROOT, OUT, REFERENCE, write


def table(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+
        ['| '+' | '.join(map(str,row))+' |' for row in rows])


def main():
    verification=json.loads((OUT/'verification.json').read_text(encoding='utf-8'))
    assert verification['status']=='passed'
    macro=pd.read_csv(OUT/'evaluation_macro.csv').set_index(['year','method','group'])
    boot=pd.read_csv(OUT/'paired_bootstrap.csv')
    selection=json.loads((OUT/'mlp/selection.json').read_text(encoding='utf-8'))
    qrf=json.loads((OUT/'qrf/selection.json').read_text(encoding='utf-8'))
    diff=json.loads((OUT/'diffusion/selection.json').read_text(encoding='utf-8'))
    diags=json.loads((OUT/'diffusion/recomputed_diagnostics.json').read_text(encoding='utf-8'))['checks']
    def metric(year,method,group,name):return float(macro.loc[(year,method,group),name])
    labels={'R2':'R2（factorial v2）','MLP_q05':'MLP q=.05','MLP_q02':'MLP q=.02',
        'MLP_q05_nonshrinking':'MLP q=.05 禁止收缩','MLP_q05_protected':'MLP q=.05 风险保护',
        'MLP_q02_protected':'MLP q=.02 风险保护','QRF':'QRF+CQR','QRF_protected':'QRF+冻结保护迁移（探索）'}
    rows=[]
    for year in [2014,2012]:
        for method in labels:
            rows.append([year,labels[method],f'{metric(year,method,"all","coverage")*100:.2f}',
                f'{metric(year,method,"all","width")*100:.2f}',f'{metric(year,method,"all","IS"):.4f}',
                f'{metric(year,method,"near_zero","coverage")*100:.2f}',f'{metric(year,method,"near_zero","IS"):.4f}',
                f'{metric(year,method,"up_ramp","coverage")*100:.2f}',f'{metric(year,method,"down_ramp","coverage")*100:.2f}'])
    headline=table(['数据','方法','总体覆盖%','宽度%容量','IS','近零覆盖%','近零IS','上升覆盖%','下降覆盖%'],rows)
    b=boot[(boot.block_days==14)&(boot.reference=='R2')&boot.method.isin(['MLP_q05','MLP_q05_protected','QRF','QRF_protected'])&
        (((boot.group=='all')&(boot.metric=='IS'))|((boot.group.isin(['near_zero','up_ramp','down_ramp']))&(boot.metric=='coverage')))]
    statrows=[]
    for r in b.itertuples():
        scale=100 if r.metric=='coverage' else 1
        statrows.append([r.year,labels[r.method],r.group,r.metric+(' (pp)' if scale==100 else ''),
            f'{r.difference*scale:+.4f}',f'[{r.low*scale:+.4f}, {r.high*scale:+.4f}]'])
    stats=table(['数据','方法−R2','工况','指标','差值','14日块95%区间'],statrows)
    nwp=json.loads((ROOT/'review_complete_status_20261104/evidence_checks.json').read_text(encoding='utf-8'))['nwp_macro']
    nwprows=[[r['year'],r['method'],f"{100*r['coverage']:.2f}",f"{100*r['width']:.2f}",f"{r['IS']:.4f}"] for r in nwp if r['clipped']]
    nwptable=table(['数据','输入','覆盖%','宽度%容量','IS'],nwprows)
    dtable=table(['模型','实际零预测MSE','模型MSE','相对零预测器技能%'],[[r['method'],f"{r['actual_zero_mse']:.4f}",
        f"{r['model_mse']:.4f}",f"{100*r['skill']:.2f}"] for r in diags])
    moments=json.loads((OUT/'diffusion/residual_moments.json').read_text())
    mtable=table(['残差来源','原点数','标准差（归一化功率）','按训练残差尺度归一后的二阶矩','相邻小时相关'],
        [[r['stage'],r['origins'],f"{r['std']:.4f}",f"{r['normalized_second_moment']:.4f}",f"{r['lag1_correlation']:.4f}"] for r in moments])
    boundary=[]
    for year in [2014,2012]:
        records=[]
        for p in (OUT/f'mlp/gefcom{year}').glob('farm_*/seed_*/lower_0.05/evaluation_boundary_diagnostics.csv'):
            records.append(pd.read_csv(p))
        avg=pd.concat(records).groupby('group').mean(numeric_only=True)
        for g in ['all','exact_zero','positive_near_zero','small_positive']:
            r=avg.loc[g]
            boundary.append([year,g,f'{100*r.raw_lower_miss:.2f}',f'{100*r.cqr_lower_miss:.2f}',f'{100*r.negative_correction_fraction:.2f}'])
    boundarytable=table(['数据','真实功率组','raw下尾漏点%','CQR下尾漏点%','负修正比例%'],boundary)
    low=pd.read_csv(OUT/'low_power_corrected/eval_macro.csv')
    lowrows=[[r.method,r.group,f'{100*r.coverage:.2f}',f'{100*r.width:.2f}',f'{r.IS:.4f}']
             for r in low[low.group.isin(['all','near_zero'])].itertuples()]
    lowtable=table(['方法','组','覆盖%','宽度%容量','IS'],lowrows)
    oldgates=pd.read_csv(OUT/'old_promotion_gates.csv').fillna('')
    gatetable=table(['数据','候选','种子均值通过旧门槛','通过的单独种子数/3','均值未通过项'],[[r.year,labels[r.method],r.all_old_gates_pass,f'{r.seeds_passing}/3',r.failures]
        for r in oldgates[oldgates.method.isin(['MLP_q05_protected','QRF','QRF_protected'])].itertuples()])
    costs=pd.read_csv(OUT/'inference_benchmark.csv')
    costtable=table(['方法','相同评价原点数','预处理+原始端点秒','每原点毫秒','保存模型MB'],
        [[r.method,r.forecast_origins,f'{r.median_seconds:.4f}',f'{1000*r.seconds_per_origin:.3f}',f'{r.stored_model_MB:.3f}'] for r in costs.itertuples()])
    gains=[]
    for year in [2014,2012]:
        near_delta=100*(metric(year,'MLP_q05_protected','near_zero','coverage')-metric(year,'MLP_q05','near_zero','coverage'))
        width_delta=100*(metric(year,'MLP_q05_protected','all','width')-metric(year,'MLP_q05','all','width'))
        is_delta=metric(year,'MLP_q05_protected','all','IS')-metric(year,'MLP_q05','all','IS')
        qrf_gain=100*(1-metric(year,'QRF','all','IS')/metric(year,'R2','all','IS'))
        gains.append(f'- {year}：q=.05保护相对原MLP，近零覆盖{near_delta:+.2f}pp，总体宽度{width_delta:+.2f}pp，总体IS差{is_delta:+.5f}；QRF相对R2的总体IS降幅{qrf_gain:+.2f}%。')
    result=f'''# 审查建议执行结果

日期：2026-11-04（Asia/Shanghai）。执行地点：本地CPU。状态：三条主实验及修正后的低功率消融已完成；数组复算与时间断言通过。无独立跨模型研究审计。

## 1. 做了哪些修改

- 恢复原MLP q=.05和q=.02，两套数据共17场、每场三个seed，q=.95头在同seed内复用；原结果目录保留。
- MLP沿用原122/123列顺序与0填补，用于隔离q和seed影响，不把它包装成新的缺失值处理方法。QRF使用factorial v2对应信息集和列顺序，训练中位数填补并加缺失指示；这是明确记录的表示差异。
- 保存模型、Scaler、分位数、标签/日期、校准修正、反馈、交叉计数和边界诊断；禁止画图时训练。
- q=.05/.02保护阈值均仅由2014Q2选为{selection['0.05']['threshold']}/{selection['0.02']['threshold']}，冻结后迁移2012。风险模型用proper-training时间前缀OOF作概率校准，运行只读取当时已知输入。
- QRF用真正的叶响应分布、500棵树、无限制叶响应保留及按叶大小加权；2014Q2 seed0在叶样本10/30/60中选择{qrf['selected_leaf']}，再运行两数据集三个seed。没有使用树均值的分位数冒充QRF。
- QRF保护迁移属于额外探索：看到seed0 H2近零失败后，直接迁移MLP此前冻结的同一风险模型和阈值，没有为QRF重调参数。它不构成新独立测试或自动晋升。
- 扩散固定farm1和anchor，比较经验残差、常方差高斯、条件尺度高斯、zero-v、无条件/条件velocity模型。记录实际零预测器损失、按t损失、打乱条件及训练内外残差差异。
- 低功率四列消融重新配对拟合base/aug，GBM均保留原生NaN，参数与冻结PKG一致；不再混入0填补变化。

原始状态和论文已备份至source_before；新脚本与最终源码另存source_snapshot。旧结果不会被新入口覆盖。

## 2. 统一口径总体与工况结果

R2来自factorial v2。其他方法先平均同场三个seed，再等权平均风场；覆盖/宽度以百分数列示。所有方法均为逐小时区间，signed rolling84后clip[0,1]。评价段已在项目开发中查看，属于回溯，不是新独立测试。

{headline}

{chr(10).join(gains)}

保护只下降下界、不改变上界，因此不可能因保护本身增加漏点；它仍可能让IS或宽度变差。不能因为近零覆盖恢复，就宣称所有工况改善。尤其必须同时检查下降爬坡和近零IS，不只看总体IS。

本轮阈值选择仅约束保护方案的总体、近零和上升覆盖，属于诊断门槛，不等于此前全部晋升约束。旧完整门槛另行核对（总体覆盖达标、宽度与IS各改善5%、上升覆盖+3pp及IS不增/宽度最多+2pp、近零≥max(R0−1pp,R2−.5pp)）：

{gatetable}

这些评价门槛检查不用于重新选阈值或改变默认方法；探索性QRF保护即使通过也仍需新数据确认。种子均值不是实际集成区间，也不能证明任一单个种子同时通过全部门槛，因此单独列出逐seed通过数量。

同一farm1、seed0、两CPU线程的推理计时（预热后3次中位数，包含预处理和原始端点，不含各方法共有的CQR）：

{costtable}

risk_guard为保护概率计算的额外成本；它不是独立区间模型。保存模型大小受序列化方式影响，不等于峰值内存。这是单场计时，不推广为所有硬件的固定加速倍数。

## 3. 配对不确定性

{stats}

同步跨场、跨方法抽取7/14日历日移动块，每种2000次；三个拟合seed先求平均。区间条件于这些已训练模型，不包含整个训练随机过程或新地点总体的不确定性。多比较与反复使用评价期的限制仍存在，不能写作独立确认。完整结果见paired_bootstrap.csv。

## 4. MLP边界诊断与低功率消融

{boundarytable}

这里按未来真实功率分组只用于评价，不用于发报时选择保护。负修正可能抬高下界，但必须以表中比例和nonshrinking对照量化，不能事先认定它是全部根因。raw与CQR统计是逐场逐seed等权平均；不是池化小时比例。

原单seed q=.05的历史总体结果已复现：2014 seed0覆盖90.6647%、宽49.3160%、IS0.665645、近零85.6215%。因此原报告数值不是伪结果，主要问题是q=.02覆盖了原目录与缺少完整产物。三seed均值应作为新主结果，不能再只挑seed0。

修正后的低功率对照：

{lowtable}

这四列只改变历史表示，没有增加新信息；无效不等于“所有信息已充分”。该消融为原列顺序单seed复算，与factorial v2主基线列顺序不同，不能混用其GBM数值替代主表。

## 5. 扩散诊断：撤回“>1⇒高斯塌缩”

{dtable}

同一固定验证批的实际零预测器损失约1.326，而不是1。条件和无条件模型均优于该零预测器；这直接否定原诊断阈值。无条件模型的velocity损失更低，不能据此证明条件更有用或更没用，需结合分布与任务指标。

{mtable}

训练外残差尺度明显更大，且小时相关很强。OOF锚点使用更短训练历史，因而OOF与训练内差距还混有训练长度和季节差异，不能把差值全部归因于过拟合。现有数据没有证明同方差、独立高斯，也没有证明扩散家族在区间任务上无优势。

2014Q2校准后，条件扩散IS={diff['conditional_IS']:.6f}，无条件={diff['unconditional_IS']:.6f}，最佳简单对照为{diff['best_simple']}、IS={diff['best_simple_IS']:.6f}。预设扩大条件是否通过：{diff['expand']}。因此本轮停止多场扩散扩张；这是一项资源决策，不是残差高斯性结论。这里只做farm1/seed0诊断，未用它支持多场优越性。

条件尺度高斯用训练前缀OOF残差拟合log平方误差，并以Q1尺度乘数校正；与Q1早停相同，属于开发信息。所有H2结果都在Q2决定写入后计算。分桶残差见diffusion/residual_condition_bins.csv，raw/CQR区间及CRPS见对应CSV。

## 6. NWP与论文口径

{nwptable}

统一裁剪后，2014/2012的NWP宽度降幅21.66%/24.98%、IS降幅22.73%/25.41%。R2的固定配置交互证据保留；不能称NWP为首次提出的贡献，也不能把宽区间称为已证明的信息上限。

论文围绕“同一NWP信息下，时效对齐表示与共享结构的互补及风险权衡”组织。MLP与QRF必须留在主文，依据完整工况和成本讨论方法选择。扩散移至探索性生成基线补充材料，撤回“决定性高斯塌缩”措辞。R2不再称全局最优；本轮没有通过事后修改业务约束来宣称新方法全面晋升。

## 7. 验证与复现

- 18项实质回归检查通过：velocity实际零参考、有限步zero-v采样、signed收缩抵消、保护单调性、原时间协议与特征/标签独立性。
- QRF编译内核见证给出[0,1]响应分位数，而树均值为0.5；新鲜环境文档见证通过。该见证不是独立研究审计。
- verification.json记录所有方法/场的原点配对、有限有序端点、物理支持、标签到达断言、宏平均独立复算和扩散损失复算。
- 新依赖仅在.aris/qrf-packages，未改系统numpy/sklearn/torch。QRF可并行6个独立场任务，每任务2线程；线程调度改变不影响冻结参数。
- 执行入口：run_revision_mlp.py、run_revision_qrf.py、run_revision_diffusion.py；分析：analyze_revision.py；图：make_dl_figures.py；文档：write_revision_report.py。

本轮未启动完整边界混合分布、场景生成或新的V/ws网格。前两项属于后续分支；V/ws动态表示已有17列消融，没有理由重复大范围搜索。本轮也没有凭空创造未触碰测试数据；新独立数据确认仍待未来工作。
'''
    (OUT/'RESULTS.md').write_text(result,encoding='utf-8')
    # A concise current handoff replaces outdated claims; original remains backed up.
    status=f'''# 风电日前区间预测完整现状（审查修订后）

更新：2026-11-04，Asia/Shanghai。主结果目录：out_gefcom_revision_20261104。原版状态备份：out_gefcom_revision_20261104/source_before/COMPLETE_STATUS.md。

## 1. 当前判断

NWP收益与R2固定配置交互成立；R2不是全局最优。MLP q=.05旧单seed结果已复现，现在使用三个seed主表。校准后风险保护可修复部分近零失败，但仍有其他工况权衡。QRF已完成真实叶响应强基线。扩散MSE>1不能推出高斯塌缩；当前单场受控实验未达到扩大门槛。

## 2. 协议

GEFCom2014：2012训练、2013Q1早停/校准种子、Q2选择、H2回溯评价。2012：2009H2+2010训练、2011Q1/Q2开发、2011H2至2012H1回溯评价。每日原点、24h历史/目标、84日到达反馈、逐小时区间、clip[0,1]、风场宏平均。2012不重新选阈值或QRF参数。

## 3. 修订主表

{headline}

## 4. 允许与禁止的主张

- 允许：当前协议下NWP最大收益；固定HistGBR配置的共享×显式表示交互；MLP整体锐度与工况覆盖权衡；当前扩散实现不满足扩大条件。
- 禁止：MSE>1说明扩散没学；残差因中心极限定理成为同方差高斯；QR固有近零失败；R2在所有指标最优；无NWP宽度是已证明信息上限；把这些回溯区间写成新独立确认。

## 5. 详细结果与验证

详见[完整执行报告](out_gefcom_revision_20261104/RESULTS.md)、evaluation_macro.csv、paired_bootstrap.csv、verification.json。此前factorial v2的两套交互结果保留；此前tail_dynamic的失败结果保留，不能挑不同模型的优势拼成一个方法。

## 6. 代码与产物

- run_revision_mlp.py：两分位数版本×三个seed×17场、prefix-OOF风险与冻结保护。
- run_revision_qrf.py：500树叶响应QRF，Q2选型及17场三个seed。
- run_revision_diffusion.py：farm1固定anchor、6种控制、实际零损失和残差诊断。
- run_low_power.py：缺失处理一致的base/aug配对消融。
- analyze_revision.py、write_revision_report.py：数组复算、配对块区间和文档生成。
- make_dl_figures.py：只读保存数组作图；新图位于paper/gefcom_nwp_interval/figures/revision_20261104。
- 旧MLP/单场扩散入口转向修订流程；旧多场扩散入口改为独立新目录并修正MSE日志，当前未启动扩张。

## 7. 保留局限

2014缺原生NWP发布字段，2012单高度；风场共享天气；评价期已反复查看；共享/独立头容量不同；风险分组与边际CQR保证不同；下降爬坡与近零IS不能因总体收益而忽略。未完成新的独立测试与跨模型研究审计。后续优先新数据确认，而不是继续在H2调参。
'''
    (ROOT/'COMPLETE_STATUS.md').write_text(status,encoding='utf-8')
    original=(OUT/'source_before/manuscript_zh.md').read_text(encoding='utf-8')
    references=original.split('## 参考文献')[-1]
    paper=f'''# 风电日前区间预测中的气象表示与边界风险：共享模型的跨基准实证研究

## 摘要

本文研究同一条数值天气预报（NWP）曲线在独立时效与共享时效分位数模型中的表示差异。在GEFCom2014和GEFCom2012的固定回溯协议中，引入NWP使裁剪后区间宽度相对减少约22%–25%，区间得分（IS）减少约23%–25%。2×2实验表明，当前HistGBR配置中显式逐时表示与共享结构存在负IS交互；组合模型R2相对基础独立头IS减少3.88%/4.48%，上升爬坡覆盖提高3.70/5.87个百分点，但该工况区间加宽。进一步以三个随机种子的MLP和真正的分位数随机森林（QRF）检验模型选择与工况权衡。MLP的近零失败可部分通过预测时风险驱动的校准后下界保护缓解，不能归为分位数回归固有缺陷。残差扩散诊断显示，以1作为velocity零预测损失阈值不正确；当前单场实现未优于最佳简单对照，不据此推断残差高斯性或扩散方法普遍无效。

QRF相对R2的总体IS降幅为{100*(1-metric(2014,'QRF','all','IS')/metric(2014,'R2','all','IS')):.2f}%/{100*(1-metric(2012,'QRF','all','IS')/metric(2012,'R2','all','IS')):.2f}%，但其近零覆盖为{100*metric(2014,'QRF','near_zero','coverage'):.2f}%/{100*metric(2012,'QRF','near_zero','coverage'):.2f}%。直接迁移此前冻结的保护阈值后，近零覆盖为{100*metric(2014,'QRF_protected','near_zero','coverage'):.2f}%/{100*metric(2012,'QRF_protected','near_zero','coverage'):.2f}%；这部分为看到基线失效后增加的探索性迁移，不作为新独立确认。

关键词：风电区间预测；NWP表示；共享时效；分位数回归；工况覆盖

## 1. 研究问题与贡献边界

日前概率预测需要利用未来天气[1,2,4]，本文不把NWP的必要性包装为新方法。研究问题是：同样的完整NWP曲线信息，是否需要按预测时效显式对齐，才能在共享模型中得到有效利用？贡献是可复现的固定配置交互实验、跨模型对照与边界/爬坡风险审查。本文不宣称R2为全局最优、不宣称宽区间为信息论下界，也不宣称发现了新的通用保形理论。

## 2. 方法

### 2.1 逐小时任务与表示

每个每日原点用过去24小时功率与当时可用NWP预测未来24个逐小时90%区间。它不是24小时路径同时覆盖90%。R0按时效分别拟合q=.05/.95；R1将(origin,h)展开，加入lead共享模型；R2在完整曲线基础上再加入当前U/V/ws、ws³、方向两分量、目标小时sin/cos、U的±1/±2小时及前后差分，共14列。2014共122维，2012增加NWP年龄为123维。

所有邻时量仅来自同原点已知的预报曲线。显式列主要改变表示，不引入新的真实未来观测。固定HistGBR为50轮、31叶、最小叶样本20、L2=0；共享与独立头的容量和统计约束并不等同，因此交互解释限定在本配置。

### 2.2 到达反馈与校准

每时效分数s=max(raw_lower−y,y−raw_upper)，取过去84日历日已到达完整标签的有限样本90%顺序统计量q，输出[raw_lower−q,raw_upper+q]，最后clip[0,1]。q可以为负，因而会收缩区间。只有target_end≤当前origin的标签可反馈。标准CQR理论依赖交换性并给出边际保证[3]；本文滚动时序与工况子集只报告经验覆盖。

### 2.3 强对照及下界保护

MLP沿用原122/123列、训练段Scaler、0填补与pinball loss，Q1早停；q=.05/.02分别保留，q=.95同seed复用。QRF[9]使用500树、训练中位数与缺失指示，叶响应全部保留、按叶大小加权求分位数；叶样本数{qrf['selected_leaf']}只由2014Q2从10/30/60中选择，固定迁移2012。两个家族都报告seed0/1/2，区别于确定性的原R2。

风险模型在训练段时间前缀OOF预测上校准P(y≤.01|X)，然后用完整proper training重拟合分类器。阈值{selection['0.05']['threshold']}仅在2014Q2按预设覆盖门槛选择；校准后若风险超过阈值，最终下界置0，上界保留。这是区间扩张，必须同时报告宽度和IS。真实未来近零标签只用于评价。禁止收缩是诊断对照，不默认晋升为主方法。

## 3. 实验协议

2014用2012训练、2013Q1早停与验证种子、Q2开发、H2评价；2012用2009H2+2010训练、2011H1开发、2011H2至2012H1评价。日期与风场资格保持一致，完整标签只在到达后检查。全部评价期已在研究过程中查看，属于回溯；没有称为未触碰确认。2014 NWP可用性沿用竞赛时钟推导，2012采用原生issue/lead。

先逐场计算，再对风场宏平均；神经网络和QRF先平均同场三个seed。总体指标为覆盖、容量归一宽度和90%IS：IS=(U−L)+20 max(L−y,0)+20 max(y−U,0)。上升/下降爬坡为相邻小时变化>0.1/<−0.1，首小时使用最后已观测功率；近零为y≤.01。同步跨场7/14日块bootstrap各2000次，描述固定模型的配对不确定性。

## 4. 结果

### 4.1 输入信息

{nwptable}

统一裁剪后覆盖不变，NWP宽度相对降21.66%/24.98%，IS降22.73%/25.41%。不混用旧未裁剪表与新裁剪表。

### 4.2 表示与共享结构的交互

factorial v2的2014四格IS为0.743227、0.743875、0.792596、0.714384；2012为0.677178、0.678287、0.705382、0.646831。交互定义为“共享加显式特征变化−独立加显式特征变化”，2014为−0.078860，14日块95%区间[−0.097711,−0.061254]；2012为−0.059660，[−0.076887,−0.044308]。它支持当前配置的互补，不证明唯一因果机制或任意模型上的普适性。

### 4.3 跨模型与工况权衡

{headline}

{chr(10).join(gains)}

不能仅根据总体IS宣布业务最优，也不能因为MLP存在近零欠覆盖而隐去其整体分数优势。R2是原保留参考；保护MLP改善近零覆盖后仍需检查下降爬坡和近零IS。所有候选均保留在表中，不根据评价结果重新选择。

![三种子MLP与R2的保存结果比较](figures/revision_20261104/fig_dl_vs_gbm_2014.png)

![完整方法比较，保护迁移为探索性分析](figures/revision_20261104/fig_all_models_2014.png)

![第二数据集完整方法比较](figures/revision_20261104/fig_all_models_2012.png)

![首个有效评价原点的示例，非按性能挑日](figures/revision_20261104/fig_dl_interval_2014.png)

### 4.4 配对区间

{stats}

区间条件于已有训练模型和日期；不把小时或共享NWP风场当独立样本，亦不把多次查看评价数据后的区间称为新独立验证。

## 5. 边界诊断与讨论

{boundarytable}

精确零功率在评价样本中的逐场宏平均占比为2014约6.56%、2012约13.10%，不能一概称为极稀疏尾部。全局pinball目标、函数近似、边界质量与校准可能共同影响近零下界。降低原始分位数不保证最终CQR下界降低；但本实验也不能仅凭该机制的存在，把全部失败归因于收缩。运行时可知风险保护的效果见主表，完整低功率配对消融及条件诊断见执行报告。

模型选择还取决于训练/推理成本和风险容忍。R2的两个共享分位数模型具有简洁实现优势，不能据此省略500树QRF和MLP的准确率对照。2012迁移、场间差异、低服务率月份和下降爬坡均应纳入应用判断。

同机、同farm1发报原点、两CPU线程、预热3次的原始端点推理计时如下，包含预处理，不含共有CQR；风险模型作为保护额外成本单列：

{costtable}

## 6. 结论

本文实证支持固定配置下显式时效表示与共享HistGBR的互补作用；NWP提供最大输入收益，跨模型进一步展示总体锐度和工况风险的权衡。MLP近零问题可以通过预测时保护缓解，尚不构成全面解决。后续优先在未参与开发的新时间段或数据源确认结果，而不是继续在既有H2搜索特征或阈值。

## 附录A：探索性残差扩散对照

此实验不是R2组件消融，只是farm1、seed0的受控诊断。固定同一anchor，比较六种残差分布实现，原始样本、分位数、校准结果及CRPS均保留。

{dtable}

velocity目标v=aε−br的零预测损失由mean(v²)决定，并非恒为1。两模型虽MSE>1仍优于实际零预测器。训练内外尺度不匹配和强小时相关见下表：

{mtable}

Q2条件扩散IS={diff['conditional_IS']:.6f}，最佳简单对照{diff['best_simple']}为{diff['best_simple_IS']:.6f}，没有通过预设扩大门槛，因此停止多场扩张。这个有限负结果不证明残差同方差高斯，也不证明扩散在区间任务本来无优势。若后续研究场景生成，需要另行评价联合轨迹及加入copula/残差块重采样对照。

## 参考文献
{references}

[9] N. Meinshausen, “Quantile Regression Forests,” Journal of Machine Learning Research, vol. 7, pp. 983–999, 2006. https://jmlr.org/beta/papers/v7/meinshausen06a.html

研究版本说明：本稿按保存实验修订，尚未完成全面查新与引用审计；不表示投稿录用或独立外部审查通过。
'''
    (ROOT/'paper/gefcom_nwp_interval/manuscript_zh.md').write_text(paper,encoding='utf-8')
    (ROOT/'REVISION_NOTES_20261104.md').write_text('''# 2026-11-04修订交接

当前状态读COMPLETE_STATUS.md；完整执行与局限读out_gefcom_revision_20261104/RESULTS.md，数字源为该目录evaluation_macro.csv、paired_bootstrap.csv及verification.json。原R2唯一数字源为factorial v2。

历史MLP q=.05 seed0已经复现，不再是未验证记录；新主表三个seed。不要再写velocity MSE>1说明扩散没学或残差高斯，不要称QR固有近零缺陷。QRF真实叶响应强基线已完成；保护迁移沿用MLP Q2阈值，额外跨家族分析为探索性，不能宣称独立确认或自动晋升。旧完整业务门槛与新保护选择门槛分开列示，平均seed表现不是可部署集成。

论文已据完整强对照重写，不宣称R2全局最优。无新独立测试数据、完整边界混合模型或场景生成；这些是后续分支。本轮原状态/论文在source_before，源码在source_snapshot；中间非共享噪声扩散目录不用于正式结果。
''',encoding='utf-8')
    snapshot=OUT/'source_snapshot';snapshot.mkdir(exist_ok=True)
    for name in ['revision_common.py','run_revision_mlp.py','run_revision_qrf.py','run_revision_diffusion.py',
        'run_dl_baseline.py','run_diffusion_nwp.py','run_diffusion_nwp_multifarm.py','run_low_power.py',
        'analyze_revision.py','write_revision_report.py','make_dl_figures.py','make_revision_overview.py','test_revision_integrity.py','apply_qrf_protection.py','finish_revision.py','benchmark_revision.py']:
        shutil.copy2(ROOT/name,snapshot/name)
    log=ROOT/'diffusion_tuning_log.md'
    history=(OUT/'source_before/diffusion_tuning_log.md').read_text(encoding='utf-8')
    log.write_text('''# 扩散调参日志：诊断已修订

2026-11-04更新：以下旧日志作为历史记录保留，其“velocity MSE>1⇒没学到/同方差高斯塌缩”诊断已撤回。固定验证批实际零预测器MSE约1.326；新条件模型1.194，相对零技能约9.9%。当前单场Q2未胜过条件尺度高斯，故停止多场扩张。详见out_gefcom_revision_20261104/diffusion及RESULTS.md；旧版本与宏平均不能直接作池化因果比较。

---

'''+history,encoding='utf-8')
    write(OUT/'completion.json',dict(status='complete',models=['MLP','QRF','single-farm diffusion controls'],
        verification='passed',publication_status='retrospective research draft; no universal optimality claim',
        results=str(OUT/'RESULTS.md')))
    print('updated status, manuscript, results, source snapshots')


if __name__=='__main__':main()
