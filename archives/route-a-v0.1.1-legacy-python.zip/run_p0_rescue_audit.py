"""P0 read-only audit: how much down-ramp lower-miss coverage can be recovered.

Reads frozen evaluation arrays only (original / R15 / wind_drop_0.750) and the
pooling-input samples (y, valid, history). Recomputes, per farm and hour:

    L_restore = min(L_R15, L_O)
    gap        = L_R15 - L_restore            (>= 0)
    rescuable  = valid & (L_restore <= y < L_R15) & (y <= U_R15)
    rescuable_down = rescuable & (delta < -0.10)

and two diagnostics (post-hoc, never used for selection):
    restore_all : lower := L_restore on every gap>0 hour
    oracle      : lower := L_restore only on rescuable_down hours

No fitting; pure NumPy/pandas. Outputs per-farm cross-tab and a macro summary.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SAMPLES = ROOT / 'out_gefcom_pooling_20261105' / 'inputs'
GUARD = ROOT / 'out_gefcom_qrf_down_guard_20261106'
OUT = ROOT / 'out_gefcom_p0_rescue_20261106'


def load_samples(year, farm):
    with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'samples.npz') as z:
        return {k: z[k] for k in z.files}


def load_guard(year, farm, name):
    with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / f'{name}.npz') as z:
        return dict(z.items())


def down_cov_and_width(y, lo, hi, mask):
    inside = (y >= lo) & (y <= hi)
    return float(inside[mask].mean()), float((hi - lo)[mask].mean())


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    diag = []
    for year in (2014, 2012):
        nfarms = 10 if year == 2014 else 7
        for farm in range(1, nfarms + 1):
            d = load_samples(year, farm)
            g_o = load_guard(year, farm, 'original')
            g_r = load_guard(year, farm, 'R15')
            g_g = load_guard(year, farm, 'wind_drop_0.750')
            ids = g_o['ids']
            for g in (g_r, g_g):
                np.testing.assert_array_equal(g['ids'], ids)
            lo_o, hi_o = g_o['lo'], g_o['hi']
            lo_r, hi_r = g_r['lo'], g_r['hi']
            lo_g, hi_g = g_g['lo'], g_g['hi']
            assert lo_o.shape == hi_o.shape == (len(ids), 24)
            y = d['y'][ids]
            valid = d['valid'][ids]
            hist_last = d['history'][ids, -1]
            valid2 = np.broadcast_to(valid[:, None], y.shape)
            delta = np.diff(y, axis=1, prepend=hist_last[:, None])
            down = (delta < -0.10) & valid2
            near_zero = (np.abs(y) <= 0.01) & valid2

            L_restore = np.minimum(lo_r, lo_o)
            gap = lo_r - L_restore
            assert (gap >= 0).all()
            rescuable = valid2 & (L_restore <= y) & (y < lo_r) & (y <= hi_r)
            rescuable_down = rescuable & down

            dlm_o = (y < lo_o) & down
            dlm_r = (y < lo_r) & down
            dlm_g = (y < lo_g) & down
            non_rescuable_down = dlm_r & (y < L_restore)  # y below even the restored bound

            # two post-hoc diagnostics
            lo_restore_all = L_restore
            lo_oracle = np.where(rescuable_down, L_restore, lo_r)

            # per-farm row (counts on down-ramp hours)
            rows.append(dict(
                year=year, farm=farm,
                down_events=int(down.sum()),
                lower_miss_O=int(dlm_o.sum()),
                lower_miss_R15=int(dlm_r.sum()),
                lower_miss_G=int(dlm_g.sum()),
                upper_miss_O=int(((y > hi_o) & down).sum()),
                upper_miss_R15=int(((y > hi_r) & down).sum()),
                rescuable_down=int(rescuable_down.sum()),
                non_rescuable_down=int(non_rescuable_down.sum()),
                rescuable_all=int(rescuable.sum()),
                gap_sum_restore_all=float(gap[valid2].sum()),
                gap_sum_oracle=float(gap[rescuable_down].sum()),
            ))

            for name, lo, hi in [('O', lo_o, hi_o), ('R15', lo_r, hi_r), ('G', lo_g, hi_g),
                                 ('restore_all', lo_restore_all, hi_r),
                                 ('oracle', lo_oracle, hi_r)]:
                dc, dw = down_cov_and_width(y, lo, hi, down)
                nz_cov, _ = down_cov_and_width(y, lo, hi, near_zero)
                w_all = float((hi - lo)[valid2].mean())
                diag.append(dict(year=year, farm=farm, method=name,
                                 down_cov=dc, down_width=dw, near_zero_cov=nz_cov,
                                 width_all=w_all))

    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / 'rescue_breakdown_per_farm.csv', index=False)
    diagf = pd.DataFrame(diag)
    diagf.to_csv(OUT / 'rescue_diagnostics_per_farm.csv', index=False)

    # macro (per-farm mean) for the headline table
    macro = diagf.groupby(['year', 'method'])[['down_cov', 'down_width', 'near_zero_cov', 'width_all']].mean().reset_index()
    macro.to_csv(OUT / 'rescue_diagnostics_macro.csv', index=False)

    # per-year totals of the rescuable split
    totals = frame.groupby('year')[['down_events', 'lower_miss_O', 'lower_miss_R15', 'lower_miss_G',
                                    'rescuable_down', 'non_rescuable_down', 'rescuable_all',
                                    'gap_sum_restore_all', 'gap_sum_oracle']].sum().reset_index()
    totals.to_csv(OUT / 'rescue_totals.csv', index=False)

    print('=== per-year totals ===')
    print(totals.to_string(index=False))
    print()
    print('=== macro down-ramp coverage / width / near-zero ===')
    print(macro.round(4).to_string(index=False))
    print()
    print('COMPLETE')


if __name__ == '__main__':
    main()
