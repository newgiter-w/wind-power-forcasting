"""Where do the up-ramp upper misses live? (wind-rise state breakdown).

Read-only. Rebuild the R15 'state' grouping (same-hour / nearby wind rise) and
cross-tabulate up-ramp upper-miss hours against it, for 2012 vs 2014. This tells
us whether the extreme up-ramps missed by the upper bound sit inside the group
where R15 already applies its fattest tail, or outside it (group definition is
the bottleneck).
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SAMPLES = ROOT / 'out_gefcom_pooling_20261105' / 'inputs'
GUARD = ROOT / 'out_gefcom_qrf_down_guard_classifier_20261106'
OUT = ROOT / 'out_gefcom_p0_rescue_20261106'


def added_features(x):
    speed = x[:, -12].reshape(-1, 24)
    cols = []
    for lag in (1, 2, 3):
        difference = np.full_like(speed, np.nan)
        difference[:, lag:] = speed[:, lag:] - speed[:, :-lag]
        cols.append(difference.ravel())
    return np.column_stack(cols)


def cells(days):
    return (days[:, None] * 24 + np.arange(24)).ravel()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for year in (2014, 2012):
        nfarms = 10 if year == 2014 else 7
        for farm in range(1, nfarms + 1):
            with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'samples.npz') as z:
                d = {k: z[k] for k in z.files}
            with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'features.npz') as z:
                fgbm = z['GBM']
            with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'R15.npz') as z:
                ids = z['ids']; u_r15 = z['hi']

            y = d['y'][ids]
            valid = d['valid'][ids]
            hist_last = d['history'][ids, -1]
            valid2 = np.broadcast_to(valid[:, None], y.shape)
            delta = np.diff(y, axis=1, prepend=hist_last[:, None])
            up = (delta > 0.10) & valid2
            miss = up & (y > u_r15)

            wind = added_features(fgbm)[cells(ids), 0].reshape(y.shape)
            nearby = pd.DataFrame(wind.T).rolling(5, center=True, min_periods=1).max().to_numpy().T
            state = np.where(wind >= .5, 2, np.where(nearby >= .5, 1, 0))
            state[:, 0] = 3

            for label, m in [('up_ramp_all', up), ('up_ramp_upper_miss', miss)]:
                tot = int(m.sum())
                if tot == 0:
                    continue
                for s in (0, 1, 2, 3):
                    rows.append(dict(year=year, farm=farm, label=label, state=s,
                                     n=int((m & (state == s)).sum()),
                                     frac=float((m & (state == s)).sum()) / tot))

    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / 'up_ramp_miss_state_breakdown.csv', index=False)
    summ = frame.groupby(['year', 'label', 'state'])[['frac', 'n']].mean().reset_index()
    summ.to_csv(OUT / 'up_ramp_miss_state_summary.csv', index=False)
    print('=== up-ramp upper-miss location by wind-rise state (macro frac) ===')
    print(summ.round(4).to_string(index=False))
    print()
    print('COMPLETE')


if __name__ == '__main__':
    main()
