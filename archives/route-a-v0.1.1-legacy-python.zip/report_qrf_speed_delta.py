"""Evaluate speed-delta QRF and retain paired time-block uncertainty."""
import numpy as np
import pandas as pd
from run_qrf_speed_delta import OUT,BASE,load_farms,feature_array,index,added_features,frozen_spec,write
from gefcom2014_experiment import masks
from revision_common import calibration

METHODS = ('original','speed_delta')
BOOT_GROUPS = ('all','up_ramp','same_hour','nearby_only','none_nearby','quiet_proxy')
BOOT_METRICS = ('coverage','width','IS','upper_miss','predicted_ramp')


def compare(year,stage):
    rows,daily = [],[]
    for farm,d in load_farms(year).items():
        new = OUT/f'gefcom{year}/farm_{farm:02}'
        old = BASE/f'gefcom{year}/farm_{farm:02}'
        ids = index(d,stage)
        y = d['y'][ids]
        prev = d['history'][ids,-1,None]
        dy = np.diff(np.c_[prev,y],axis=1)
        valid = d['valid'][ids,None]
        dw = added_features(feature_array(year,farm,'GBM'))[:,0].reshape(-1,24)[ids]
        nearby = pd.DataFrame(dw.T).rolling(5,center=True,min_periods=1).max().to_numpy().T >= .5
        known = np.isfinite(dw)
        same = dw>=.5
        up = dy>.1
        groups = masks(y,prev[:,0])
        groups.update(same_hour=up&same,nearby_only=up&known&~same&nearby,
                      none_nearby=up&known&~nearby,lead1=up&~known,
                      quiet_actual=np.abs(dy)<=.05,quiet_proxy=np.abs(dw)<.25)
        assert np.array_equal(up,groups['up_ramp'])
        assert np.array_equal(up,sum(groups[k].astype(int) for k in ['same_hour','nearby_only','none_nearby','lead1']))
        with np.load(old/'heads.npz') as a, np.load(new/'heads.npz') as b:
            np.testing.assert_equal(a['origins'],b['origins'])
            np.testing.assert_equal(b['train_days'],index(d,'train',True))
            points = [a['qrf'][ids],b['heads'][ids,:,1]]
            heads = b['heads']
        for method,point,file in zip(METHODS,points,[old/f'{stage}_direct_qrf.npz',new/f'{stage}.npz']):
            with np.load(file) as z:
                np.testing.assert_equal(z['ids'],ids)
                assert (z['max_label_end']<=d['origins'][ids]).all()
                lo,hi = z['lo'],z['hi']
            if method=='speed_delta':
                _, replay = calibration(d,heads[:,:,0],heads[:,:,2],stage)
                np.testing.assert_equal(lo,np.clip(replay['lo'],0,1))
                np.testing.assert_equal(hi,np.clip(replay['hi'],0,1))
            dp = np.diff(np.c_[prev,point],axis=1)
            values = dict(coverage=(y>=lo)&(y<=hi),width=hi-lo,
                          IS=hi-lo+20*np.maximum(lo-y,0)+20*np.maximum(y-hi,0),
                          upper_miss=y>hi,lower_miss=y<lo,
                          point_MAE=np.abs(point-y),point_bias=point-y,
                          observed_delta=dy,predicted_delta=dp,predicted_ramp=dp>.1,
                          false_alarm=(dp>.1)&~up)
            for group,mask in groups.items():
                keep = mask&valid
                if keep.any():
                    rows.append(dict(year=year,farm=farm,stage=stage,method=method,group=group,
                                     n=int(keep.sum()),**{k:float(v[keep].mean()) for k,v in values.items()}))
                if stage=='evaluation' and group in BOOT_GROUPS:
                    daily.append((method,farm,group,d['origins'][ids],np.column_stack(
                        [keep.sum(axis=1)]+[np.where(keep,values[k],0).sum(axis=1) for k in BOOT_METRICS])))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{year}_{stage}_per_farm.csv',index=False)
    metrics=[k for k in values]
    macro=frame.groupby(['method','group'])[metrics].mean()
    macro.to_csv(OUT/f'{year}_{stage}_macro.csv')
    if daily:
        block_stats(year,daily)
    return macro


def block_stats(year,daily):
    dates=pd.date_range(min(item[3][0] for item in daily),max(item[3][-1] for item in daily)).to_numpy()
    farms=sorted({item[1] for item in daily})
    array=np.zeros((2,len(farms),len(BOOT_GROUPS),len(dates),1+len(BOOT_METRICS)))
    for method,farm,group,origin,values in daily:
        ix=np.searchsorted(dates,origin)
        np.testing.assert_equal(dates[ix],origin)
        array[METHODS.index(method),farms.index(farm),BOOT_GROUPS.index(group),ix,:]=values
    def delta(data):
        totals=data.sum(axis=3)
        counts=totals[...,:1]
        means=np.divide(totals[...,1:],counts,out=np.full_like(totals[...,1:],np.nan),where=counts>0)
        macro=np.nanmean(means,axis=1)
        return macro[1]-macro[0]
    rng=np.random.default_rng(20261106+year)
    n=len(dates)
    draws=[]
    for _ in range(2000):
        starts=rng.integers(0,n-13,size=int(np.ceil(n/14)))
        ids=(starts[:,None]+np.arange(14)).ravel()[:n]
        draws.append(delta(array[:,:,:,ids,:]))
    lo,hi=np.quantile(draws,[.025,.975],axis=0)
    point=delta(array)
    pd.DataFrame([dict(year=year,group=g,metric=m,difference=point[i,j],low=lo[i,j],high=hi[i,j])
                  for i,g in enumerate(BOOT_GROUPS) for j,m in enumerate(BOOT_METRICS)]).to_csv(OUT/f'{year}_paired_blocks.csv',index=False)


def select(macro):
    a,b=(macro.loc[m] for m in METHODS)
    aa,bb=a.loc['all'],b.loc['all']
    checks=dict(coverage=bool(bb.coverage>=max(.9,aa.coverage-.005)),
                width=bool(bb.width<=aa.width+.01),score=bool(bb.IS<=aa.IS),
                up_upper_miss=bool(b.loc['up_ramp','upper_miss']<a.loc['up_ramp','upper_miss']),
                near_zero=bool(b.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
                down_ramp=bool(b.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01),
                quiet_false_alarm=bool(b.loc['quiet_proxy','false_alarm']<=a.loc['quiet_proxy','false_alarm']+.01))
    frozen_spec(OUT/'selection.json',dict(preferred='speed_delta' if all(checks.values()) else 'original',checks=checks))
    print('Q2 gate',checks,flush=True)


def table(columns,rows):
    return '\n'.join(['| '+' | '.join(columns)+' |','|'+'|'.join(['---']*len(columns))+'|']+
                     ['| '+' | '.join(map(str,r))+' |' for r in rows])


def report():
    import json
    overview,signals,blocks=[],[],[]
    for year in (2014,2012):
        if year==2012:
            compare(year,'validation')
        macro=compare(year,'evaluation')
        for method in METHODS:
            a=macro.loc[(method,'all')]
            u=macro.loc[(method,'up_ramp')]
            q=macro.loc[(method,'quiet_proxy')]
            z=macro.loc[(method,'near_zero')]
            d=macro.loc[(method,'down_ramp')]
            overview.append([year,method,f'{a.coverage*100:.2f}',f'{a.width*100:.2f}',f'{a.IS:.4f}',
                             f'{u.upper_miss*100:.2f}',f'{z.coverage*100:.2f}',f'{d.coverage*100:.2f}',f'{q.false_alarm*100:.2f}'])
            for group in ['up_ramp','same_hour','nearby_only','none_nearby','quiet_actual']:
                a=macro.loc[(method,group)]
                signals.append([year,method,group,f'{a.predicted_delta*100:+.2f}',f'{a.upper_miss*100:.2f}',
                                f'{a.predicted_ramp*100:.2f}',f'{a.point_bias*100:+.2f}'])
        for a in pd.read_csv(OUT/f'{year}_paired_blocks.csv').query("group == 'all' or metric == 'upper_miss'").itertuples():
            scale=1 if a.metric=='IS' else 100
            blocks.append([year,a.group,a.metric,f'{a.difference*scale:+.4f}',f'[{a.low*scale:+.4f}, {a.high*scale:+.4f}]'])
    selected=json.loads((OUT/'selection.json').read_text())
    older_path=OUT/'older_nwp_2012.csv'
    older_note=''
    if older_path.exists():
        older=pd.read_csv(older_path)
        available=older[older.older_window_available]
        nearby_count=int((available.older_max_delta_pm2>=.5).sum())
        same_count=int((available.older_same_hour_delta>=.5).sum())
        older_note=f"""
在 GEFCom2012 原批次前后两小时均未达到 0.5 m/s 的 {len(older)} 个上爬坡上侧漏点中，有 {len(available)} 个可在提前 12 小时发布的旧批次中匹配完整局部窗口。按同一目标时间对齐，旧批次中 {nearby_count} 个在附近达到阈值，其中 {same_count} 个在同小时达到阈值。批次差异显示部分事件的信号对预报版本敏感。两批都是预报，判断风速误差仍需同址实测风速。原始配对见 older_nwp_2012.csv。
"""
    report_text=f"""# QRF 增加 NWP 风速变化特征

单场 QRF500、固定种子0。训练输入在原有 R2 基础上加入同一预报批次的 1、2、3 小时风速差。缺失边界使用训练段中位数和缺失标记。所有评价预测逐场核对发报日与标签到达，新增模型的区间由保存的原始上下界重新校准并核对。

2014 Q2 门槛偏好 **{selected['preferred']}**。各门槛见 selection.json。两套数据的所有预定候选均报告，结果属于单种子历史回放。

{table(['数据','方法','总体覆盖%','宽度%容量','IS','上爬坡上漏%','近零覆盖%','下爬坡覆盖%','预报平稳组误报%'],overview)}

预报平稳组以同小时 NWP 风速变化绝对值小于 0.25 m/s 界定，误报指中位数预测功率上升超过容量 10 个百分点、而实测没有达到该阈值。实测平稳组以实测功率变化绝对值不超过容量 5 个百分点界定。上爬坡信号组沿用 0.5 m/s 和前后 2 个时效窗口。

{table(['数据','方法','工况','中位数平均增量pp','上漏%','预测上爬坡%','点预测偏差pp'],signals)}

{table(['数据','工况','指标','新增减原始','95%配对区间'],blocks)}

时间区块按相同日历块同时抽取所有风场，14日移动块抽样2000次。覆盖、宽度、漏点的差值以百分点计。风速信号分组和统计条件与上轮事件汇总一致，表中采用逐场等权宏平均。该对照检验显式特征是否改善现有映射，输入均来自已有 NWP 曲线。
{older_note}
"""
    (OUT/'RESULTS.md').write_text(report_text,encoding='utf-8')
    write(OUT/'completion.json',dict(status='complete',farms=17,seed=0,selection=selected))
    print('REPORT COMPLETE',OUT/'RESULTS.md',flush=True)


if __name__=='__main__':
    report()
