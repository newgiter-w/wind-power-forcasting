"""NWP-conditioned residual velocity diffusion for GEFCom2014 (24h interval).

Anchor MLP: history(24) + future NWP curve(72) -> point mean + latent(64).
Diffusion: residual velocity DDIM conditioned on [latent, mean, NWP].
Train 2012, early-stop 2013 Q1, sample -> q05/q95 -> CQR -> clip -> metrics.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler

from gefcom2014_experiment import metrics
from gefcom_protocol_v2 import index, prepare
from online_calibration import simulate
from retrieval_diffusion import HistoryAnchor, ResidualDenoiser, VelocityDiffusion

OUT = Path('out_gefcom_diffusion_nwp')

CONFIG = dict(
    anchor_lr=1e-3, anchor_epochs=180, anchor_patience=25,
    denoiser_width=192, denoiser_blocks=4,   # V2: 96->192, 3->4
    diff_lr=3e-4, diff_epochs=300, diff_patience=40,  # V2: 5e-4->3e-4, 200->300, 30->40
    samples=200, steps=40,
)


def build_anchor_features(d):
    S = len(d['history'])
    w = d['nwp']  # (S,24,4) U10,V10,U100,V100
    u100 = w[:, :, 2]; v100 = w[:, :, 3]; ws100 = np.hypot(u100, v100)
    nwp = np.stack([u100, v100, ws100], axis=2).reshape(S, -1)  # (S,72)
    hist = d['history']  # (S,24)
    return np.hstack([hist, nwp]).astype('float32')  # (S,96)


def main():
    # All controls use one anchor and write to a new versioned directory.
    from run_revision_diffusion import main as revised_main
    revised_main()


if __name__ == '__main__':
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=2):
        main()
