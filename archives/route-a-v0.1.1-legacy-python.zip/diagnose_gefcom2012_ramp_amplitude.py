"""Separate insufficient ramp amplitude from local timing offsets in development."""
import numpy as np
import pandas as pd

from run_point_residual import ROOT, OUT as BASE, load_farms, feature_array, index
from revision_common import frozen_spec

OUT = ROOT/'out_gefcom2012_tail_split'
YEAR = 2012


def diagnose():
    frozen_spec(OUT/'diagnostic_protocol.json',dict(stage='2011 Q2',farm_count=7,
        ramp='actual hourly increment >.10; same and nearby NWP speed rise >=.50 m/s',
        classification='same-hour predicted increment at least actual; else within ±2h at least actual; else insufficient amplitude',
        sensitivity='replace actual amplitude threshold with fixed >.10; windows restricted to same issued day',
        rule='advance tail-split if amplitude不足 more common than displaced adequate amplitude in same-hour NWP group'))
    rows=[]
    for farm,d in load_farms(YEAR).items():
        ids=index(d,'validation',True)
        with np.load(BASE/f'gefcom2012/farm_{farm:02}/heads.npz') as z:
            np.testing.assert_array_equal(z['origins'],d['origins'])
            median=z['qrf'][ids]
        with np.load(BASE/f'gefcom2012/farm_{farm:02}/validation_direct_qrf.npz') as z:
            upper=z['hi'][np.searchsorted(z['ids'],ids)]
        last=d['history'][ids,-1,None]
        actual=np.diff(d['y'][ids],axis=1,prepend=last)
        pred=np.diff(median,axis=1,prepend=last)
        wind=feature_array(YEAR,farm,'GBM')[:,-14:-12].reshape(-1,24,2)[ids]
        speed=np.linalg.norm(wind,axis=-1)
        dw=np.diff(speed,axis=1,prepend=np.full((len(ids),1),np.nan))
        for i,h in zip(*np.where(actual>.10)):
            win=slice(max(0,h-2),min(24,h+3))
            s=dw[i,win]
            state='same' if dw[i,h]>=.5 else ('near_only' if (s>=.5).any() else 'no_near')
            best=pred[i,win].max()
            best1=pred[i,max(0,h-1):h+2].max()
            # When peaks tie, prefer the occurrence nearest the observed event.
            loc=np.flatnonzero(pred[i,win]==best)+win.start
            lag=loc[np.abs(loc-h).argmin()]-h
            label='same_hour' if pred[i,h]>=actual[i,h] else ('shifted' if best>=actual[i,h] else 'amplitude')
            fixed='same_hour' if pred[i,h]>.10 else ('shifted' if best>.10 else 'amplitude')
            rows.append(dict(farm=farm,origin=d['origins'][ids[i]],lead=h+1,nwp=state,
                observed=actual[i,h],predicted=pred[i,h],local_max=best,peak_lag=lag,
                class_actual=label,class_fixed=fixed,
                class_actual_w1='same_hour' if label=='same_hour' else ('shifted' if best1>=actual[i,h] else 'amplitude'),
                class_fixed_w1='same_hour' if fixed=='same_hour' else ('shifted' if best1>.10 else 'amplitude'),
                upper_miss=d['y'][ids[i],h]>upper[i,h]))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/'development_events.csv',index=False)
    for key in ('class_actual','class_fixed'):
        tab=pd.crosstab(frame.nwp,frame[key])
        tab.to_csv(OUT/f'{key}_counts.csv')
        print(key,tab.to_string(),flush=True)
    sensitivity=[]
    for window,suffix in ((1,'_w1'),(2,'')):
        for rule in ('actual','fixed'):
            sub=frame.rename(columns={f'class_{rule}{suffix}':'status'})
            sub=sub.groupby(['nwp','upper_miss','status']).size().rename('events').reset_index()
            sensitivity.append(sub.assign(window=window,rule=rule))
    pd.concat(sensitivity,ignore_index=True).to_csv(OUT/'timing_sensitivity.csv',index=False)
    same=frame[frame.nwp.eq('same')]
    advance=bool((same.class_actual=='amplitude').sum()>(same.class_actual=='shifted').sum() and
                 (same.class_fixed=='amplitude').sum()>(same.class_fixed=='shifted').sum())
    frozen_spec(OUT/'diagnostic_decision.json',dict(advance_tail_split=advance,same_hour_events=len(same)))
    return advance


if __name__=='__main__':
    diagnose()

