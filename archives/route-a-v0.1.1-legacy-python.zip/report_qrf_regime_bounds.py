"""Draw the frozen candidate trade-off and summarize the paired comparison."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from run_qrf_regime_bounds import OUT, METHODS, PARAMS, gates
from report_qrf_speed_delta import table

def main():
    status=json.loads((OUT/'completion.json').read_text())
    assert status['status']=='complete'
    decision=status['decision']
    chosen=decision['challenger']
    fig,axes=plt.subplots(1,3,figsize=(13,4.6),layout='constrained')
    rows,frontier_rows=[],[]
    for ax,(year,stage,title) in zip(axes,[(2014,'validation','2014 development'),
                         (2014,'evaluation','2014 evaluation'),(2012,'evaluation','2012 evaluation')]):
        m=pd.read_csv(OUT/f'{year}_{stage}_macro.csv').set_index(['method','group'])
        coordinates={k:(100*m.loc[(k,'all'),'width'],100*m.loc[(k,'up_ramp'),'upper_miss']) for k in METHODS}
        for k,(x,y) in coordinates.items():
            if k in ('original','guard_only'):
                continue
            feasible=all(gates(m,k).values())
            ax.scatter(x,y,color='#138574' if feasible else '#9ca9b2',s=23,alpha=.8)
            frontier_rows.append(dict(year=year,stage=stage,method=k,width_pct=x,upper_miss_pct=y,
                                      all_gates=feasible,**gates(m,k)))
        order=sorted(coordinates,key=coordinates.get)
        frontier=[]
        best=float('inf')
        for k in order:
            x,y=coordinates[k]
            if y<best:
                frontier.append((x,y))
                best=y
        ax.plot(*np.array(frontier).T,color='#637b8e',ls=':',lw=1,label='Candidate frontier')
        ax.scatter(*coordinates['original'],marker='X',s=85,color='#9c3744',label='Original QRF',zorder=4)
        ax.scatter(*coordinates['guard_only'],marker='s',facecolors='none',edgecolors='#b97923',s=65,label='Guard only',zorder=5)
        ax.scatter(*coordinates[chosen],marker='*',s=135,facecolors='none',edgecolors='#161b22',label='Frozen challenger',zorder=6)
        ax.axvline(coordinates['original'][0],color='#aaaaaa',lw=.7,ls='--')
        ax.axhline(coordinates['original'][1],color='#aaaaaa',lw=.7,ls='--')
        ax.set_title(title)
        ax.set_xlabel('Average width (% capacity)')
        ax.grid(alpha=.17)
        for method in ('original','guard_only',chosen):
            a=m.loc[method]
            rows.append([year,stage,method,f"{100*a.loc['all','coverage']:.2f}",
                         f"{100*a.loc['all','width']:.2f}",f"{100*a.loc['up_ramp','upper_miss']:.2f}",
                         f"{100*a.loc['near_zero','coverage']:.2f}",f"{100*a.loc['down_ramp','coverage']:.2f}",
                         f"{a.loc['all','IS']:.4f}"])
    axes[0].set_ylabel('Upper miss on observed up ramps (%)')
    axes[0].legend(fontsize=7)
    fig.savefig(OUT/'width_vs_ramp_upper_miss.png',dpi=180)
    plt.close(fig)
    pd.DataFrame(frontier_rows).to_csv(OUT/'tradeoff_points.csv',index=False)
    boot=pd.read_csv(OUT/'paired_blocks.csv')
    focus=[('all','width'),('all','coverage'),('all','IS'),('up_ramp','upper_miss'),
           ('near_zero','coverage'),('down_ramp','coverage')]
    intervals=[]
    for a in boot.itertuples():
        if (a.group,a.metric) in focus:
            s=1 if a.metric=='IS' else 100
            intervals.append([a.year,a.group,a.metric,f'{s*a.delta:+.4f}',f'[{s*a.low:+.4f}, {s*a.high:+.4f}]'])
    gate_rows=[]
    for year in ('2014','2012'):
        checks=status['evaluation_checks'][year]
        gate_rows.append([year,', '.join(k for k,v in checks.items() if all(v.values())) or '无',
                          ', '.join(k for k,v in checks[chosen].items() if not v) or '无'])
    text=f"""# 冻结 QRF 的分工况上下界校准

17 个风场，固定种子 0。原 QRF 和校准预测已逐场复算。根据发报时的 NWP 风速变化、原始区间宽度及已有的近零风险分数分组。上侧区分同小时、前后两小时、无风速上升信号。下侧区分近零风险。每个组在 6 小时时效段内合并过去 84 天已到达的有效分数。少于 40 个时效点时使用原校准修正，其余使用样本量收缩。候选使用原近零风险阈值 0.1 将高风险下界置零。guard_only 单独衡量这项保护。组内时效样本有相关性，样本数门槛仅用于稳定估计。

只在 2014 Q2 选择。要求总体覆盖至少 90%，平均宽度和上爬坡上侧漏点率均低于原模型，近零与下爬坡覆盖各下降不超过 1 个百分点，IS 不升。开发期通过的候选共 {len(decision['passing'])} 个，选定 **{decision['selected']}**，冻结对照候选 **{chosen}**。冻结候选参数为 {PARAMS.get(chosen,'guard only')}，依次是风险组上尾、平稳组上尾、下尾的校准尾概率和调整强度。

{table(['数据','阶段','规则','总体覆盖%','宽度%容量','上爬坡上漏%','近零覆盖%','下爬坡覆盖%','IS'],rows)}

{table(['数据','评价期满足全部门槛的候选','冻结候选未通过门槛'],gate_rows)}

评价期其他候选用于展示权衡。评价日期已经在此前实验中使用，事后通过门槛的其他候选属于探索发现。

{table(['数据','组','指标','冻结候选减原模型','95%配对区间'],intervals)}

除 IS 外，差值使用百分点。采用同步跨场 14 日移动块抽样 2000 次。组别使用发报时可见信息，真实爬坡和近零标签仅用于回放统计。每次校准的最新标签到达时间与原模型逐一匹配，逐场结果及配对区间均保留。

![宽度与上爬坡上漏权衡](width_vs_ramp_upper_miss.png)

各面板使用该阶段自身的坐标范围。绿色候选通过全部点估计门槛。虚线交点为原 QRF，左下方同时缩宽并减少上漏。
"""
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')

if __name__=='__main__':
    main()
