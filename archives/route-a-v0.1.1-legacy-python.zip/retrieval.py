"""Retrieval: feature shortlist + DTW re-ranking, and analog-feature construction.

The Retriever holds a *corpus slice* (a set of situations identified by global
indices) and answers "which situations are most similar to this query?".

Similarity uses two signals:
  1. Euclidean distance on standardized shape/weather/calendar features (fast NN),
  2. optional DTW on the z-scored condition window (phase-tolerant re-ranking).
"""
from __future__ import annotations

import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from config import Config


def zscore(x: np.ndarray) -> np.ndarray:
    s = x.std()
    return (x - x.mean()) / (s + 1e-6)


def dtw_distance(a: np.ndarray, b: np.ndarray, band: int = None) -> float:
    """Squared-error DTW with a Sakoe-Chiba band (correct cell-by-cell recurrence).

    The recurrence depends on the LEFT neighbor D[i, j-1] *within the current
    row*, so it cannot be vectorized row-wise in one shot (the left neighbor must
    already be filled). This is the correct reference implementation; it is
    O(n*band) and should be accelerated (Numba/C) before heavy use.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    n, m = len(a), len(b)
    band = band or max(n, m)
    D = np.full((n + 1, m + 1), np.inf)
    D[0, 0] = 0.0
    for i in range(1, n + 1):
        j0 = max(1, i - band)
        j1 = min(m, i + band)
        if j0 > j1:
            continue
        for j in range(j0, j1 + 1):
            cost = (a[i - 1] - b[j - 1]) ** 2
            D[i, j] = cost + min(D[i - 1, j], D[i, j - 1], D[i - 1, j - 1])
    return float(np.sqrt(D[n, m]))


class Retriever:
    def __init__(self, cond: np.ndarray, feat: np.ndarray, target: np.ndarray,
                 global_idx: np.ndarray, cfg: Config):
        self.cond = np.asarray(cond)        # (n, C)
        self.feat = np.asarray(feat)        # (n, F) raw
        self.target = np.asarray(target)    # (n, H)
        self.global_idx = np.asarray(global_idx)
        self.cfg = cfg

        self.scaler = StandardScaler().fit(self.feat)
        self.feat_scaled = self.scaler.transform(self.feat)

        n_neighbors = min(cfg.nn_candidates, len(self.feat))
        self.nn = NearestNeighbors(n_neighbors=n_neighbors, metric="euclidean")
        self.nn.fit(self.feat_scaled)

    def query(self, q_cond: np.ndarray, q_feat: np.ndarray,
              exclude_local: int = -1, top_k: int = None) -> "tuple[np.ndarray, np.ndarray, np.ndarray]":
        """Return (local_idx, distances, global_idx) of the top-k similar situations."""
        top_k = top_k or self.cfg.top_k
        qf = self.scaler.transform(np.asarray(q_feat).reshape(1, -1))
        cand_k = min(self.cfg.nn_candidates, len(self.feat))
        _, cand = self.nn.kneighbors(qf, n_neighbors=cand_k)
        cand = cand[0]
        if exclude_local >= 0:
            cand = cand[cand != exclude_local]

        if self.cfg.use_dtw:
            qz = zscore(np.asarray(q_cond))
            dists = np.array([dtw_distance(qz, zscore(self.cond[j]), self.cfg.dtw_band) for j in cand])
            order = np.argsort(dists)[:top_k]
            local = cand[order]
            dist = dists[order]
        else:
            # use feature distance (recompute via NN distances would be extra work; use nearest order)
            local = cand[:top_k]
            # feature-space distance as a proxy
            dist = np.linalg.norm(self.feat_scaled[local] - qf, axis=1)

        return local, dist, self.global_idx[local]


def analog_features(ret: Retriever, q_cond: np.ndarray, q_feat: np.ndarray,
                    exclude_local: np.ndarray, cfg: Config,
                    mode: str = "similar", noise_frac: float = 0.0,
                    rng: np.random.Generator = None) -> "tuple[np.ndarray, np.ndarray]":
    """Distance-weighted mean and top-1 neighbor target windows for each query.

    mode: "similar" (retrieve), "random" (k random corpus members, equal weight).
    noise_frac: train-time augmentation replacing a fraction of similar neighbors
    with random ones, weighted as the farthest similar neighbor (anti-copying).
    Returns (mean_block, top1_block), each (N, analog_dim).
    """
    rng = rng if rng is not None else np.random.default_rng(cfg.seed)
    n = len(q_cond)
    mean_block, top1_block = [], []
    for i in range(n):
        ex = int(exclude_local[i]) if exclude_local is not None else -1
        if mode == "random":
            local, dist = _random_neighbors(ret, ex, cfg.top_k, rng)
        else:  # similar
            local, dist, _ = ret.query(q_cond[i], q_feat[i], exclude_local=ex, top_k=cfg.top_k)
        if noise_frac > 0:
            local, dist = _inject_noise(ret, local, dist, ex, noise_frac, rng)
        tgt = ret.target[local]                       # (k, H)
        w = 1.0 / (np.asarray(dist) + 1e-6)
        w = w / w.sum()
        mean = (w[:, None] * tgt).sum(axis=0)
        if cfg.analog_bins:
            mean = _downsample(mean, cfg.analog_bins)
            top1 = _downsample(tgt[0], cfg.analog_bins)
        else:
            top1 = tgt[0]
        mean_block.append(mean)
        top1_block.append(top1)
    return np.vstack(mean_block), np.vstack(top1_block)


def _random_neighbors(ret: Retriever, exclude_local: int, k: int,
                      rng: np.random.Generator) -> "tuple[np.ndarray, np.ndarray]":
    pool = np.arange(len(ret.target))
    if exclude_local >= 0:
        pool = pool[pool != exclude_local]
    k = min(k, len(pool))
    local = rng.choice(pool, size=k, replace=False)
    return local, np.ones(k)


def _inject_noise(ret: Retriever, local: np.ndarray, dist: np.ndarray,
                  exclude_local: int, frac: float,
                  rng: np.random.Generator) -> "tuple[np.ndarray, np.ndarray]":
    k = len(local)
    n_noise = int(round(frac * k))
    if n_noise <= 0:
        return local, dist
    pool = np.arange(len(ret.target))
    if exclude_local >= 0:
        pool = pool[pool != exclude_local]
    noisy = rng.choice(pool, size=n_noise, replace=False)
    kept_local = local[:k - n_noise]
    kept_dist = dist[:k - n_noise]
    far = float(kept_dist.max()) if len(kept_dist) else 1.0
    local = np.concatenate([kept_local, noisy])
    dist = np.concatenate([kept_dist, np.full(n_noise, far)])
    return local, dist


def _downsample(v: np.ndarray, bins: int) -> np.ndarray:
    if len(v) <= bins:
        return v
    idx = np.linspace(0, len(v), bins + 1).astype(int)
    return np.array([v[idx[i]:idx[i + 1]].mean() for i in range(bins)])
