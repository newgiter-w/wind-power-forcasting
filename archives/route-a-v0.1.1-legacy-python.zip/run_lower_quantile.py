"""Retrain the LOWER quantile head at a lower level (0.02) to fix the near-zero bias.

Rigor: same 2019 training data (X_T, y_T from inputs.npz), same H0 package, same
scaler; ONLY the lower head's quantile changes. No new labels. The frozen upper
head (0.95) is reused unchanged. Compare near-zero / up-ramp / overall under the
same C0 rolling-84 calibration.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.multioutput import MultiOutputRegressor
from threadpoolctl import threadpool_limits

from data import build_situations, load_dataframe
from execute_x01 import cfg_for
from online_calibration import simulate
from run_c1 import group, masks_for
from run_calibration import cache_predictions, indices_for

ROOT = Path(__file__).parent
MODEL = ROOT / 'out_v3/x01/tasks/NH_H0'
OUT = ROOT / 'out_lower_quantile'
H0 = dict(max_iter=50, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, random_state=0)


def build_X_2020_2022():
    cfg = cfg_for()
    d = build_situations(load_dataframe(cfg), cfg)
    idx = np.flatnonzero((d['origin_ts'] >= '2020-01-01') & (d['origin_ts'] < '2023-01-01'))
    return np.hstack([d['feat'][idx], d['cond'][idx]]), idx


def retrain_lower(X_T, y_T, scaler, quantile):
    m = MultiOutputRegressor(HistGradientBoostingRegressor(loss='quantile', quantile=quantile, **H0))
    m.fit(scaler.transform(X_T), y_T)
    return m


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    with np.load(MODEL / 'inputs.npz') as z:
        X_T, y_T = z['X_T'], z['y_T']
    scaler = joblib.load(MODEL / 'scaler.joblib')
    X, idx = build_X_2020_2022()
    Xs = scaler.transform(X)
    data = cache_predictions()
    upper_frozen = data['raw_upper_original']  # frozen 0.95 head

    out = {}
    for q in (0.05, 0.02):
        head = retrain_lower(X_T, y_T, scaler, q)
        lower = head.predict(Xs)
        raw_lo = np.minimum(lower, upper_frozen)
        raw_hi = np.maximum(lower, upper_frozen)
        # sanity: at q=0.05 this should reproduce the frozen lower
        if q == 0.05:
            np.testing.assert_allclose(raw_lo, data['raw_lo'], rtol=1e-10, atol=1e-6,
                                       err_msg='q=0.05 lower head did not reproduce frozen model')
            print('[sanity] q=0.05 reproduces frozen lower head exactly', flush=True)
        print(f'[trained] lower head q={q} ({time.perf_counter()-began:.1f}s)', flush=True)
        year_rows = {}
        for year in ('2021', '2022'):
            seed, score = indices_for(data, year)
            res = simulate(data['origins'], data['target_end'], data['y'], raw_lo, raw_hi,
                           data['valid'], seed, score, 'rolling', 84)
            masks = masks_for(data, res)
            year_rows[year] = {g: group(data, res, masks[g]) for g in masks}
        out[f'q{q}'] = year_rows
    # print comparison
    for year in ('2021', '2022'):
        print(f'\n===== {year} =====')
        for g in ('all', 'ramp', 'up_ramp', 'near_zero'):
            r5 = out['q0.05'][year][g]
            r2 = out['q0.02'][year][g]
            def f(r): return ('n/a' if r is None else
                              f"{r['coverage']*100:5.1f}% w={r['width']*100:5.1f}% Lo={r['lower_miss']*100:4.1f}% Hi={r['upper_miss']*100:4.1f}%")
            print(f"  {g:9s} q0.05: {f(r5)}")
            print(f"  {'':9s} q0.02: {f(r2)}")
    (OUT / 'results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> out_lower_quantile/results.json ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
