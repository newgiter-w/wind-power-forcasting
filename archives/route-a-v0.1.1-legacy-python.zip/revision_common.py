"""Shared artifact/evaluation helpers for the 2026-11-04 revision runs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from gefcom_protocol_v2 import index
from gefcom2014_experiment import metrics
from online_calibration import simulate

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'out_gefcom_revision_20261104'
REFERENCE = ROOT / 'out_gefcom_factorial_20261103_v2'
METRIC_COLS = ['coverage', 'width', 'IS', 'lower_miss', 'upper_miss']


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def frozen_spec(path, value):
    path = Path(path)
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8')) == value, f'Changed protocol: {path}'
    else:
        write(path, value)


def evaluate(d, ids, lower, upper):
    out = metrics(d['y'][ids], lower, upper, d['valid'][ids], d['history'][ids, -1])
    y = d['y'][ids]
    valid = np.broadcast_to(d['valid'][ids, None], y.shape)
    for name, mask in [('exact_zero', y == 0), ('positive_near_zero', (y > 0) & (y <= .01)),
                       ('small_positive', (y > .01) & (y <= .05))]:
        mask = mask & valid
        if not mask.any():
            continue
        yy, ll, uu = y[mask], lower[mask], upper[mask]
        out[name] = dict(cells=int(mask.sum()), origins=int(mask.any(axis=1).sum()),
            coverage=float(((yy >= ll) & (yy <= uu)).mean()), width=float((uu-ll).mean()),
            IS=float((uu-ll+20*np.maximum(ll-yy, 0)+20*np.maximum(yy-uu, 0)).mean()),
            lower_miss=float((yy < ll).mean()), upper_miss=float((yy > uu).mean()))
    return out


def reference_intervals(year, farm, stage):
    with np.load(REFERENCE / f'gefcom{year}/farm_{farm:02d}/R2_shared_aug/{stage}.npz') as z:
        return z['indices'], np.clip(z['lo'], 0, 1), np.clip(z['hi'], 0, 1)


def calibration(d, lo, hi, stage):
    seed_phase, score_phase = ('validation_seed', 'validation') if stage == 'validation' else ('validation', 'evaluation')
    ids = index(d, score_phase)
    result = simulate(d['origins'], d['ends'], d['y'], lo, hi, d['valid'],
        index(d, seed_phase), ids, 'rolling', 84)
    assert (result['max_label_end_used'] <= d['origins'][ids]).all()
    return ids, result


def save_stage(folder, d, lo, hi, stage):
    ids, result = calibration(d, lo, hi, stage)
    np.savez_compressed(Path(folder) / f'{stage}.npz', indices=ids,
        raw_lo=lo[ids], raw_hi=hi[ids], lo=result['lo'], hi=result['hi'],
        clipped_lo=np.clip(result['lo'], 0, 1), clipped_hi=np.clip(result['hi'], 0, 1),
        q_signed=result['q_signed'], q_used=result['q_used'], n_cal=result['n_cal'],
        max_label_end=result['max_label_end_used'])
    pd.DataFrame(result['feedback']).to_csv(Path(folder) / f'{stage}_feedback.csv', index=False)
    return ids, result


def collect(rows, d, ids, lo, hi, **tags):
    for group, values in evaluate(d, ids, lo, hi).items():
        rows.append(dict(**tags, group=group, **values))


def save_metrics(folder, rows):
    df = pd.DataFrame(rows)
    df.to_csv(Path(folder) / 'metrics_per_farm.csv', index=False)
    keys = [k for k in ('year', 'method', 'seed', 'stage', 'group') if k in df]
    macro = df.groupby(keys)[METRIC_COLS].mean().reset_index()
    macro.to_csv(Path(folder) / 'metrics_macro.csv', index=False)
    return macro


def paired_daily_arrays(d, ids, lo, hi):
    """Sufficient daily sums for paired time-block resampling, with target masks."""
    from gefcom2014_experiment import masks
    y = d['y'][ids]
    valid = np.broadcast_to(d['valid'][ids, None], y.shape)
    score = hi-lo+20*np.maximum(lo-y, 0)+20*np.maximum(y-hi, 0)
    result = {}
    for group, mask in masks(y, d['history'][ids, -1]).items():
        m = mask & valid
        result[f'{group}_n'] = m.sum(axis=1)
        for name, a in [('IS', score), ('coverage', (y >= lo) & (y <= hi)), ('width', hi-lo)]:
            result[f'{group}_{name}'] = np.where(m, a, 0).sum(axis=1)
    return result
