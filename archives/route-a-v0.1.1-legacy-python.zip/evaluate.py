"""Interval evaluation: coverage, width, interval score, and regime breakdown."""
from __future__ import annotations

import numpy as np


def interval_score_values(y, lo, hi, alpha):
    """Elementwise IS; ordered finite bounds are a required metric contract."""
    y, lo, hi = (np.asarray(v, dtype=float) for v in (y, lo, hi))
    if y.shape != lo.shape or y.shape != hi.shape:
        raise ValueError("target and interval shapes must match")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie in (0, 1)")
    if not all(np.isfinite(v).all() for v in (y, lo, hi)):
        raise ValueError("IS requires finite observed targets and bounds")
    if np.any(lo > hi):
        raise ValueError("IS requires ordered bounds; do not score empty intervals as negative widths")
    return hi - lo + (2.0 / alpha) * (np.maximum(lo - y, 0) + np.maximum(y - hi, 0))


def coverage(y: np.ndarray, lo: np.ndarray, hi: np.ndarray) -> float:
    inside = (y >= lo) & (y <= hi)
    return float(inside.mean())


def mean_width(lo: np.ndarray, hi: np.ndarray, capacity: float) -> float:
    return float((hi - lo).mean() / capacity)


def interval_score(y: np.ndarray, lo: np.ndarray, hi: np.ndarray, alpha: float) -> float:
    """Winkler/interval score (lower is better). Combines sharpness + calibration."""
    return float(interval_score_values(y, lo, hi, alpha).mean())


def per_origin_score(y: np.ndarray, lo: np.ndarray, hi: np.ndarray, alpha: float,
                     capacity: float) -> np.ndarray:
    """Per-origin mean interval score (normalized by capacity), shape (n,)."""
    return interval_score_values(y, lo, hi, alpha).mean(axis=1) / capacity


def pinball_loss(y: np.ndarray, q_pred: np.ndarray, q: float) -> float:
    diff = y - q_pred
    return float(np.mean(np.maximum(q * diff, (q - 1) * diff)))


def ramp_mask(target: np.ndarray, capacity: float, frac: float, prev: np.ndarray = None) -> np.ndarray:
    """Boolean mask over (n, H) marking ramp points (large power change).

    prev: (n,) value just before the first target block (e.g. mean of the last
    observed hour for the hourly task). When None, the first block is never a
    ramp (backward-compatible but misses the boundary step).
    """
    first = prev[:, None] if prev is not None else target[:, :1]
    d = np.abs(np.diff(target, axis=1, prepend=first))
    return d > frac * capacity


def evaluate_intervals(y, lo, hi, capacity, alpha, mask=None):
    m = mask if mask is not None else np.ones_like(y, dtype=bool)
    return {
        "coverage": coverage(y[m], lo[m], hi[m]),
        "width": mean_width(lo[m], hi[m], capacity),
        "score": interval_score(y[m], lo[m], hi[m], alpha) / capacity,
    }


def format_table(results: dict, methods: list, confs: list) -> str:
    lines = []
    header = "method            " + "".join(
        f"{('%d%%' % (int(c*100))):>9s}" for c in confs
    ) + "  regime"
    lines.append(header)
    lines.append("=" * len(header) + "  (cov% / width% / score)")
    for mth in methods:
        for regime in results[mth]:
            row = f"{mth:<18s}"
            for c in confs:
                r = results[mth][regime][c]
                row += f"{r['coverage']*100:>6.1f}% {r['width']*100:>6.1f}% {r['score']:>6.2f}"
            row += f"  {regime}"
            lines.append(row)
    return "\n".join(lines)
