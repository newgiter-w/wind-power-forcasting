"""GEFCom2014 December retrospective replication (previously evaluated).

Trains on 2012 + Jan-Aug 2013, rolling CQR seeded Sep-Nov, evaluated on official
December test (TaskExpVars15 NWP + solution15_W answers, last 6h NA -> invalid).
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

import gefcom_data as gd
from online_calibration import simulate
from run_gefcom_abc import build_X, fit_q, metrics

ROOT = Path(__file__).parent
OUT = ROOT / 'out_gefcom_confirm_corrected'
TASKEXP15 = r"D:\Study\wind_datasets\nwp_benchmarks\gefcom2014_wind\data\Wind\Task 15\TaskExpVars15_W_Zone1_10\TaskExpVars15_W_Zone1_10\TaskExpVars15_W_Zone{}.csv"
SOLUTION15 = r"D:\Study\wind_datasets\nwp_benchmarks\gefcom2014_wind\data\Wind\Solution to Task 15\solution15_W.csv"


def load_full(zone):
    tr = gd.load_zone(zone)  # training through Nov 30
    te = pd.read_csv(TASKEXP15.format(zone))
    te['TIMESTAMP'] = pd.to_datetime(te['TIMESTAMP'], format='%Y%m%d %H:%M')
    sol = pd.read_csv(SOLUTION15)
    sol = sol[sol['ZONEID'] == zone]
    sol['TIMESTAMP'] = pd.to_datetime(sol['TIMESTAMP'], format='%Y%m%d %H:%M')
    sol['TARGETVAR'] = pd.to_numeric(sol['TARGETVAR'], errors='coerce')
    te = te.merge(sol[['TIMESTAMP', 'TARGETVAR']], on='TIMESTAMP', how='left', validate='one_to_one')
    full = pd.concat([tr, te], ignore_index=True).sort_values('TIMESTAMP').reset_index(drop=True)
    return full


def run_zone(zone):
    s = gd.build_samples(load_full(zone))
    origins = s['origin_ts']
    t = pd.DatetimeIndex(origins)
    train = (t.year == 2012) | ((t.year == 2013) & (t.month <= 8))
    seed = (t.year == 2013) & (t.month.isin([9, 10, 11]))
    test = (t.year == 2013) & (t.month == 12)
    tv = s['target_valid']
    inputs = s['history_valid'] & s['nwp_valid']
    train = train & tv & inputs; seed = seed & tv & inputs; test = test & inputs
    target_end = origins + np.timedelta64(24, 'h')
    y = s['target']; valid = s['target_valid']
    out = {}
    for c in ('A', 'B', 'C'):
        X = build_X(s, c)
        sc = StandardScaler().fit(X[train])
        Xs = sc.transform(X)
        lo_m = fit_q(Xs[train], y[train], 0.05)
        hi_m = fit_q(Xs[train], y[train], 0.95)
        lo_raw = lo_m.predict(Xs); hi_raw = hi_m.predict(Xs)
        lo = np.minimum(lo_raw, hi_raw); hi = np.maximum(lo_raw, hi_raw)
        res = simulate(origins, target_end, y, lo, hi, valid,
                       np.where(seed)[0], np.where(test)[0], 'rolling', 84)
        out[c] = {'rolling': metrics(y[test], res['lo'], res['hi'], last_power=s['history'][test, -1], target_valid=tv[test]),
                  'n_test': int(test.sum()), 'n_scored': int((test & tv).sum())}
    return out


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    results = {}
    for z in gd.ZONES:
        results[f'Zone{z}'] = run_zone(z)
        print(f'[done] Zone{z} ({time.perf_counter()-began:.1f}s) n_test={results[f"Zone{z}"]["A"]["n_test"]}',
              flush=True)
    print('\n===== December retrospective, rolling CQR, macro-average (10 zones) =====')
    for g in ('all', 'up_ramp', 'near_zero'):
        line = f'  {g:9s}'
        for c in ('A', 'B', 'C'):
            vals = [results[f'Zone{z}'][c]['rolling'][g] for z in range(1, 11)]
            cov = np.mean([v['coverage'] for v in vals if v])
            w = np.mean([v['width'] for v in vals if v])
            is_ = np.mean([v['IS'] for v in vals if v])
            line += f"  {c}: cov={cov*100:5.1f}% w={w*100:5.1f}% IS={is_:.3f}"
        print(line)
    (OUT / 'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> {OUT / "results.json"} ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
