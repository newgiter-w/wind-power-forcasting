"""Regression witnesses for first-hour ramps, hourly alignment and feedback timing."""
import unittest
import numpy as np
import pandas as pd
import gefcom_data
from run_gefcom_abc import metrics
from online_calibration import simulate

class ProtocolWitness(unittest.TestCase):
    def test_first_hour_ramps_are_counted(self):
        y=np.array([[.8,.6],[.1,.3]])
        m=metrics(y,np.zeros_like(y),np.ones_like(y),last_power=np.array([.1,.8]))
        self.assertEqual(m['up_ramp']['cells'],2)
        self.assertEqual(m['down_ramp']['cells'],2)
        self.assertEqual(m['ramp']['cells'],4)

    def test_future_missing_label_does_not_remove_an_input_sample(self):
        ts=pd.date_range('2012-01-01 01:00',periods=48,freq='h')
        f=pd.DataFrame(dict(TIMESTAMP=ts,TARGETVAR=np.repeat(.2,48),U10=1.,V10=1.,U100=2.,V100=2.))
        f.loc[30,'TARGETVAR']=np.nan
        s=gefcom_data.build_samples(f)
        self.assertEqual(len(s['history']),1)
        self.assertTrue(s['history_valid'][0] and s['nwp_valid'][0])
        self.assertFalse(s['target_valid'][0])
        self.assertEqual(pd.Timestamp(s['origin_ts'][0]),pd.Timestamp('2012-01-02'))
        with self.assertRaises(ValueError):gefcom_data.build_samples(f.drop(index=3))

    def test_future_truth_cannot_change_current_interval(self):
        origins=pd.date_range('2012-01-01',periods=110,freq='D').to_numpy()
        ends=origins+np.timedelta64(1,'D');y=np.repeat(.4,110*24).reshape(110,24)
        lo=np.full_like(y,.2);hi=np.full_like(y,.6);valid=np.ones(110,bool)
        seed=np.arange(90);score=np.arange(90,110)
        a=simulate(origins,ends,y,lo,hi,valid,seed,score,'rolling',84)
        altered=y.copy();altered[90]=.99
        b=simulate(origins,ends,altered,lo,hi,valid,seed,score,'rolling',84)
        np.testing.assert_equal(a['lo'][0],b['lo'][0]);np.testing.assert_equal(a['hi'][0],b['hi'][0])
        self.assertTrue((a['max_label_end_used']<=origins[score]).all())

if __name__=='__main__':unittest.main()
