"""Independent metrics, common calibration and honest example plots for new diffusion."""
from pathlib import Path
import json,importlib.util,time
import numpy as np
import pandas as pd
import torch,joblib
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.multioutput import MultiOutputRegressor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from online_calibration import simulate
from run_retrieval_diffusion import ROOT,OUT,write,SPEC

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def group_metrics(y,lo,hi,mask):
    if not mask.any():return {'cells':0}
    yy,l,u=y[mask],lo[mask],hi[mask]
    assert np.isfinite([yy,l,u]).all() and (l<=u).all()
    return {'cells':int(mask.sum()),'origins':int(mask.any(axis=1).sum()),
        'coverage':float(((yy>=l)&(yy<=u)).mean()),'width_kw':float((u-l).mean()),
        'width_capacity':float((u-l).mean()/12300.),
        'IS':float(((u-l)+20*np.maximum(l-yy,0)+20*np.maximum(yy-u,0)).mean()/12300.),
        'below_rate':float((yy<l).mean()),'above_rate':float((yy>u).mean())}

def samples_metrics(samples,y,valid):
    a=samples[valid]/12300.;yy=y[valid]/12300.;B=a.shape[1]
    order=np.sort(a,axis=1);weights=2*np.arange(1,B+1)-B-1
    crps=np.mean(abs(a-yy[:,None]),axis=1)-np.sum(order*weights[None,:,None],axis=1)/(B*B)
    # Pairwise horizon variogram score, p=0.5, inverse-lag weights.
    ij=np.array([(i,j) for i in range(24) for j in range(i+1,24)])
    w=1/(ij[:,1]-ij[:,0]);pred=np.sqrt(abs(a[:,:,ij[:,0]]-a[:,:,ij[:,1]])).mean(axis=1)
    obs=np.sqrt(abs(yy[:,ij[:,0]]-yy[:,ij[:,1]]))
    return {'raw_sample_CRPS_capacity':float(crps.mean()),'raw_sample_variogram_p05':float(np.mean(((pred-obs)**2*w).sum(axis=1)/w.sum())),
            'outside_physical_range_sample_rate':float(((a<0)|(a>1)).mean()),
            'scope':'raw generated samples only; CQR changes bounds, not this sample distribution'}

def baselines(d,indices):
    fit=d['fit'];yf=d['y'][fit]*12300.;n=len(indices);b={}
    b['climatology']=(np.tile(np.quantile(yf,.05,axis=0),(n,1)),np.tile(np.quantile(yf,.95,axis=0),(n,1)))
    p=np.tile(d['last_hour'][indices,None],(1,24));b['persistence']=(p,p)
    neigh=d['similar_targets'][indices]*12300.
    b['direct_analog']=(np.quantile(neigh,.05,axis=1),np.quantile(neigh,.95,axis=1))
    with np.load(OUT/'anchor_predictions.npz') as a:
        mean=a['mu_kw'][indices];res=a['normalized_residual'][fit]*a['residual_scale']*float(d['y_std'])*12300.
    b['anchor_residual_quantiles']=(mean+np.quantile(res,.05,axis=0),mean+np.quantile(res,.95,axis=0))
    # Same fit-only X/y, fixed package, no random internal early-stopping split.
    p=OUT/'quantile_history_baseline.npz'
    package={'max_iter':100,'max_leaf_nodes':15,'min_samples_leaf':20,'l2_regularization':1.,'early_stopping':False,'random_state':0}
    write(OUT/'quantile_baseline_protocol.json',{'package':package,'fit_segment':'same fit only','separate_from_diffusion':True})
    if not p.exists():
        preds=[]
        for q in [.05,.95]:
            m=MultiOutputRegressor(HistGradientBoostingRegressor(loss='quantile',quantile=q,**package),n_jobs=1)
            m.fit(d['history'][fit],yf);preds.append(m.predict(d['history'][indices]));joblib.dump(m,OUT/f'quantile_q{q}.joblib')
        np.savez_compressed(p,indices=indices,lo=np.minimum(*preds),hi=np.maximum(*preds),raw_crossings=int((preds[0]>preds[1]).sum()))
    with np.load(p) as p:
        np.testing.assert_array_equal(p['indices'],indices);b['quantile_history']=(p['lo'],p['hi'])
    return b

def evaluate(d,name,lo,hi,indices,samples=None):
    n=len(d['y']);rawlo=np.zeros((n,24));rawhi=np.zeros((n,24));rawlo[indices]=lo;rawhi[indices]=hi
    score=d['score'];y=d['y'][score]*12300.;valid=d['valid'][score]
    prev=np.c_[d['last_hour'][score],y[:,:-1]];delta=y-prev
    vm=np.broadcast_to(valid[:,None],y.shape)
    groups={'all':vm,'ramp':vm&(abs(delta)>1230),'up_ramp':vm&(delta>1230),'down_ramp':vm&(delta<-1230),
            'near_zero':vm&(abs(y)<=123),'predict_low':vm&np.broadcast_to((abs(d['last_hour'][score])<=615)[:,None],y.shape)}
    folder=OUT/'evaluation'/name;folder.mkdir(parents=True,exist_ok=True)
    summary=[];daily={}
    for cal in ['raw','global','rolling']:
        if cal=='raw':l,u=rawlo[score],rawhi[score];result=None
        else:
            result=simulate(d['origins'],d['target_end'],d['y']*12300.,rawlo,rawhi,d['valid'],d['cal'],score,cal,84)
            l,u=result['lo'],result['hi']
            assert np.all(result['max_label_end_used']<=d['origins'][score])
            pd.DataFrame(result['feedback']).to_csv(folder/f'{cal}_feedback.csv',index=False)
            np.savez_compressed(folder/f'{cal}_state.npz',**{k:result[k] for k in ['q_signed','q_used','max_label_end_used','n_cal']})
        metrics={g:group_metrics(y,l,u,m) for g,m in groups.items()}
        for h in range(24):metrics[f'lead_{h+1}']=group_metrics(y,l,u,vm&np.broadcast_to(np.arange(24)==h,y.shape))
        write(folder/f'{cal}_metrics.json',metrics)
        summary.append({'model':name,'calibration':cal,**metrics['all'],
                        'ramp_coverage':metrics['ramp']['coverage'],'up_ramp_coverage':metrics['up_ramp']['coverage'],
                        'down_ramp_coverage':metrics['down_ramp']['coverage'],'ramp_IS':metrics['ramp']['IS']})
        loss=(u-l)+20*np.maximum(l-y,0)+20*np.maximum(y-u,0)
        per_day=np.mean(loss,axis=1)/12300.;daily[cal]=per_day
        pd.DataFrame({'origin':np.repeat(d['origins'][score].astype(str),24),'timezone':'UTC',
                      'target_end':np.repeat(d['target_end'][score].astype(str),24),'lead':np.tile(np.arange(1,25),len(score)),
                      'valid':np.repeat(valid,24),'y':y.ravel(),'lo':l.ravel(),'hi':u.ravel(),
                      'raw_lo':rawlo[score].ravel(),'raw_hi':rawhi[score].ravel(),
                      'ramp':(abs(delta)>1230).ravel(),'IS_capacity':(loss/12300.).ravel()}).to_csv(folder/f'{cal}_forecasts.csv',index=False)
    np.savez_compressed(folder/'daily.npz',**daily,origins=d['origins'][score],valid=valid)
    if samples is not None:
        loc=pd.Index(indices).get_indexer(score);sm=samples_metrics(samples[loc],y,valid);write(folder/'sample_metrics.json',sm)
    return summary

def plots(d):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fdir=OUT/'figures';fdir.mkdir(exist_ok=True)
    ref=pd.read_csv(OUT/'evaluation/similar_s0/rolling_forecasts.csv',parse_dates=['origin'])
    last={pd.Timestamp(o):v for o,v in zip(d['origins'],d['last_hour'])}
    days=[]
    for origin,frame in ref.groupby('origin'):
        if not frame.valid.all():continue
        yy=frame.y.to_numpy();change=abs(np.diff(yy,prepend=last[origin]))
        days.append({'origin':origin,'ramps':int((change>1230).sum()),'max_change':float(change.max()),'variation':float(change.sum())})
    days=pd.DataFrame(days);days.to_csv(fdir/'eligible_days.csv',index=False);selection={}
    for regime,mask,key in [('ordinary',days.ramps.eq(0),'variation'),('ramp',days.ramps.gt(0),'max_change')]:
        pool=days[mask].copy()
        if not len(pool):continue
        pool['dist']=(pool[key]-pool[key].median()).abs();origin=pool.sort_values(['dist','origin']).iloc[0].origin
        selection[regime]={'origin_UTC':str(origin),'selection':'median observed '+key,'eligible_days':len(pool),'performance_used':False}
        fig,axes=plt.subplots(3,1,figsize=(9.3,7.2),sharex=True,sharey=True,layout='constrained')
        exports=[]
        for ax,mode,color in zip(axes,['none','random','similar'],['#0072B2','#999999','#D55E00']):
            f=pd.read_csv(OUT/f'evaluation/{mode}_s0/rolling_forecasts.csv',parse_dates=['origin']);f=f[f.origin.eq(origin)]
            x=f.lead.to_numpy();yy=f.y.to_numpy();l=f.lo.to_numpy();u=f.hi.to_numpy()
            ax.fill_between(x,l,u,color=color,alpha=.23,label='90% rolling-CQR interval')
            ax.plot(x,yy,color='black',lw=1.6,label='Observed hourly mean')
            ramp=f.ramp.to_numpy();ax.scatter(x[ramp],yy[ramp],s=15,color='#CC3311',zorder=4,label='Observed ramp')
            cov=((yy>=l)&(yy<=u)).mean()
            ax.text(.015,.94,f'{mode}, seed 0 | coverage {cov:.1%} | mean width {np.mean(u-l):.0f} kW',transform=ax.transAxes,va='top',fontsize=9)
            ax.axhline(0,color='gray',lw=.5);ax.set_ylabel('Power (kW)');ax.grid(alpha=.16)
            exports.append(f.assign(mode=mode))
        axes[0].legend(loc='upper right',fontsize=7);axes[-1].set_xlabel('Forecast horizon (hourly average, 1–24 h)')
        axes[-1].set_xticks([1,4,8,12,16,20,24]);fig.suptitle(f'{regime.capitalize()} example | origin {origin} UTC',fontsize=11)
        fig.savefig(fdir/f'{regime}_24h.png',dpi=180);fig.savefig(fdir/f'{regime}_24h.pdf');plt.close(fig)
        pd.concat(exports).to_csv(fdir/f'{regime}_plotted_data.csv',index=False)
    write(fdir/'selection.json',selection)

def main():
    torch.set_num_threads(4)
    with np.load(OUT/'data.npz') as p:d={k:p[k] for k in p.files}
    ids=np.r_[d['cal'],d['score']];rows=[]
    for name,(lo,hi) in baselines(d,ids).items():rows+=evaluate(d,name,lo,hi,ids)
    for seed in [0,1,2]:
        for mode in ['none','random','similar']:
            name=f'{mode}_s{seed}'
            with np.load(OUT/name/'predictions.npz') as p:
                np.testing.assert_array_equal(p['indices'],ids)
                rows+=evaluate(d,name,p['raw_lo'],p['raw_hi'],ids,p['samples_kw'])
    summary=pd.DataFrame(rows);summary.to_csv(OUT/'metrics.csv',index=False)
    # Seed means are descriptive averages, NOT an ensemble of predicted bounds.
    s=summary[summary.model.str.match(r'(none|random|similar)_s\d')].copy();s['mode']=s.model.str.replace(r'_s\d','',regex=True)
    means=s.groupby(['mode','calibration']).mean(numeric_only=True).reset_index();means.to_csv(OUT/'seed_mean_metrics.csv',index=False)
    stats=load_module('development_statistics',ROOT/'statistics.py');comparisons={}
    dates=d['origins'][d['score']];valid=d['valid'][d['score']]
    for a,b in [('similar','none'),('similar','random')]:
        da=[];db=[]
        for seed in [0,1,2]:
            with np.load(OUT/f'evaluation/{a}_s{seed}/daily.npz') as p:da.append(p['rolling'])
            with np.load(OUT/f'evaluation/{b}_s{seed}/daily.npz') as p:db.append(p['rolling'])
        comparisons[a+'_vs_'+b]={str(block):stats.paired_comparison(np.mean(da,axis=0)[valid],np.mean(db,axis=0)[valid],dates[valid],block,5000,0,'2021-04-01','2021-06-30') for block in [7,14]}
    write(OUT/'paired_comparisons.json',comparisons);plots(d)
    print(summary[summary.calibration.eq('rolling')][['model','coverage','width_capacity','IS','up_ramp_coverage']].to_string(index=False))
    print('SEED_MEANS\n',means.to_string(index=False))
    print(json.dumps(comparisons,indent=2))

if __name__=='__main__':main()
