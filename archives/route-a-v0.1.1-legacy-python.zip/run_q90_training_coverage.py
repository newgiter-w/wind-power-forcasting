"""Compare fixed-q90 configurations trained on one month versus a full year."""
from pathlib import Path
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits

import run_kelmarsh_gfs_q90 as prior
from run_kelmarsh_gfs_q90_expand import read_months,paired
from run_uncapped_alarm_new_site import models,calibrate,alarm
from run_gefcom2012_local_increment import score,summarize
from diagnose_gefcom2012_data_attribution import match_truth
from prepare_q90_training_coverage import OUT,TRAIN
from pair_penmanshiel_frozen_transfer import OUT as PEN,CAPACITY
from revision_common import frozen_spec,write

COLS=('events','hits','signed','absolute','quiet','false','hours','all_absolute')
ARMS=('old_short','latest_short','annual')


def apply(base,model):
    with threadpool_limits(limits=2):
        rec=score(model,[base],1.)
        r=rec[0]
        r['uncapped']=r['base'].copy()
        r['uncapped'][r['gate']]+=model.predict(r['features'][r['gate']])
    r['tie']=np.stack([np.random.default_rng(20261107+int(o.astype('datetime64[D]').astype(int))).random(24)
                      for o in r['origins']])
    return rec


def fit(base):
    r=base
    use=r['gate']
    m=HistGradientBoostingRegressor(loss='quantile',quantile=.90,max_iter=40,max_leaf_nodes=7,
        min_samples_leaf=50,l2_regularization=1,early_stopping=False,random_state=0)
    with threadpool_limits(limits=2):
        m.fit(r['features'][use],(r['actual']-r['base'])[use])
    return m


def table(records,cutoff,op):
    rows=[]
    for r in records:
        y=r['actual']
        for name in ('original','corrected'):
            p=r['base'] if name=='original' else r['candidate']
            al=r['base']>.1 if name=='original' else alarm(r,'uncapped',cutoff)
            hit=match_truth(y>.1,al)
            err=p-y
            for scope,keep in [('gated',r['gate']),('all',np.ones_like(r['gate']))]:
                u=keep&(y>.1);q=keep&(np.abs(y)<=.05)
                stats=[u,u&hit,np.where(u,err,0),np.where(u,np.abs(err),0),q,q&al,keep,np.where(keep,np.abs(err),0)]
                vals=np.column_stack([v.sum(axis=1) for v in stats])
                rows.append(pd.DataFrame(vals,columns=COLS).assign(origin=r['origins'],farm=1,
                    model=name,scope=scope,operation=op))
    return pd.concat(rows,ignore_index=True)


def independent():
    folder=PEN/'2024-01'
    a=pd.read_csv(folder/'paired_hourly.csv',parse_dates=['origin','target','cycle','archive_time'])
    sc=pd.read_csv(PEN/'scada_hourly_2024.csv',parse_dates=['target']).set_index('target')
    origins,history,y,wind=[],[],[],[]
    for o,g in a.groupby('origin',sort=True):
        if o<pd.Timestamp('2024-01-02',tz='UTC'):
            continue
        h=sc.reindex(pd.date_range(o-pd.Timedelta(hours=23),o,freq='h'))
        if len(g)!=24 or not g.paired.all() or not h.power_valid.eq(True).all():
            continue
        np.testing.assert_array_equal(g.lead,np.arange(1,25))
        assert (g.archive_time<=o).all()
        origins.append(o);history.append(h.power_pu.to_numpy());y.append(g.power_pu.to_numpy())
        wind.append(g[['u100','v100']].to_numpy())
    assert origins
    values=np.asarray(y)
    return dict(history=np.clip(history,0,1),y=np.clip(values,0,1),nwp=np.asarray(wind),
        origins=pd.DatetimeIndex(origins).tz_convert(None).to_numpy(),meta=pd.DataFrame(dict(nwp_age_hours=np.full(len(y),6))),
        total_origins=30,outside_target_hours=int(((values<0)|(values>1)).sum()))


def subset(base,months):
    keep=np.isin(pd.DatetimeIndex(base['origins']).month,months)
    return {k:(v[keep] if k!='farm' else v) for k,v in base.items()}


def evaluate(name,base,trained,cutoffs):
    folder=OUT/name
    folder.mkdir(exist_ok=True)
    span=int((base['origins'].max()-base['origins'].min())/np.timedelta64(1,'D'))+1
    blocks=[b for b in (7,14,28) if b<=span]
    write(folder/'bootstrap_availability.json',dict(calendar_span=span,computed=blocks,
        omitted=[b for b in (7,14,28) if b>span],reason='cannot draw a block longer than observed calendar span; no extension or change of evaluation window'))
    all_frames={}
    for arm,model in trained.items():
        rec=apply(base,model)
        exact=calibrate(rec,'uncapped')
        frozen=cutoffs[arm]
        data=pd.concat([table(rec,frozen,'frozen'),table(rec,exact,'exact_fpr')])
        all_frames[arm]=data
        af=folder/arm
        af.mkdir(exist_ok=True)
        data.to_csv(af/'daily.csv',index=False)
        m=summarize(data)
        m.to_csv(af/'summary.csv')
        ci=pd.concat([paired(data,b) for b in blocks],ignore_index=True)
        ci.to_csv(af/'paired_blocks.csv',index=False)
        write(af/'retrospective_cutoff.json',exact)
        a,b=(m.loc[('exact_fpr','gated',k)] for k in ('original','corrected'))
        assert a['false']==b['false']
        print(name,arm,'ramps',int(a.events),'hit',int(a.hits),int(b.hits),'MAE',a.mae,b.mae,'false',int(a['false']),flush=True)
    contrasts=[]
    for ref in ('old_short','latest_short'):
        a=all_frames[ref]
        b=all_frames['annual']
        pair=pd.concat([a[a.model.eq('corrected')].assign(model='original'),
                        b[b.model.eq('corrected')]])
        for block in blocks:
            contrasts.append(paired(pair,block).assign(reference=ref))
    pd.concat(contrasts,ignore_index=True).to_csv(folder/'annual_vs_short_paired.csv',index=False)
    return all_frames


def main():
    assert (OUT/'data_complete.json').exists()
    forest,imp,old=models()
    frozen_spec(OUT/'weights.json',dict(qrf_sha256=hashlib.sha256((prior.OUT/'q90_expanded_holdout'/'frozen_baseline.joblib').read_bytes()).hexdigest(),old_q90_sha256=hashlib.sha256((prior.DEST/'q90.joblib').read_bytes()).hexdigest()))
    annual_data=read_months(TRAIN)
    recent_data=read_months(('2023-07',))
    dev_data=read_months(('2023-12',))
    # None of the annual labels occur in or near the original QRF proper-training window.
    assert (annual_data['origins']+np.timedelta64(24,'h')).max()<np.datetime64('2023-08-02')
    assert max(annual_data['origins'])<np.datetime64('2023-09-01')
    with threadpool_limits(limits=2):
        annual_base=prior.record(annual_data,forest,imp)[0]
        recent_base=prior.record(recent_data,forest,imp)[0]
        dev_base=prior.record(dev_data,forest,imp)[0]
        old_base=prior.record(read_months(('2023-11',)),forest,imp)[0]
    trained={'old_short':old,'latest_short':fit(recent_base),'annual':fit(annual_base)}
    stats=[]
    training={'annual':annual_base,'latest_short':recent_base,'old_short':old_base}
    for name,model in trained.items():
        joblib.dump(model,OUT/f'{name}.joblib')
        if name in training:
            b=training[name]
            gate=b['gate'];y=b['actual']
            leaves=[int(tree.nodes['is_leaf'].sum()) for row in model._predictors for tree in row]
            stats.append(dict(arm=name,days=len(b['origins']),gated_hours=int(gate.sum()),
                true_ramps=int(((y>.1)&gate).sum()),quiet=int(((np.abs(y)<=.05)&gate).sum()),
                first_origin=str(b['origins'].min()),last_label=str(b['ends'].max()),
                mean_leaves=float(np.mean(leaves)),max_leaves=max(leaves)))
    pd.DataFrame(stats).to_csv(OUT/'training_counts.csv',index=False)
    for base in training.values():
        assert base['ends'].max()<=dev_base['origins'].min()
    cutoffs={name:calibrate(apply(dev_base,model),'uncapped') for name,model in trained.items()}
    frozen_spec(OUT/'thresholds.json',cutoffs)
    for name,model in trained.items():
        summarize(table(apply(dev_base,model),cutoffs[name],'frozen')).to_csv(OUT/f'development_{name}.csv')
    print('THRESHOLDS FROZEN',cutoffs,flush=True)
    # Only now load and score the independent January site observations.
    fresh=independent()
    with threadpool_limits(limits=2):
        fresh_base=prior.record(fresh,forest,imp)[0]
    evaluate('independent_penmanshiel_jan',fresh_base,trained,cutoffs)
    retrospective=read_months(tuple(f'2024-{m:02}' for m in range(2,13)))
    with threadpool_limits(limits=2):
        retrospective_base=prior.record(retrospective,forest,imp)[0]
    evaluate('retrospective_kelmarsh_year',retrospective_base,trained,cutoffs)
    for label,months in [('feb_mar',(2,3)),('apr_jun',(4,5,6)),('jul_sep',(7,8,9)),('oct_dec',(10,11,12))]:
        evaluate('retrospective_'+label,subset(retrospective_base,months),trained,cutoffs)
    monthly=pd.DatetimeIndex(annual_data['origins']).to_period('M').value_counts().sort_index()
    monthly.rename_axis('month').rename('complete_days').to_csv(OUT/'annual_complete_days_by_month.csv')
    write(OUT/'sample_counts.json',dict(annual=dict(days=len(annual_data['origins']),
        issued=annual_data['total_origins'],months=len(TRAIN),clipped_target_hours=annual_data['outside_target_hours']),
        development=dict(days=len(dev_data['origins']),issued=dev_data['total_origins'],clipped_target_hours=dev_data['outside_target_hours']),
        independent=dict(days=len(fresh['origins']),issued=fresh['total_origins'],clipped_target_hours=fresh['outside_target_hours']),
        retrospective=dict(days=len(retrospective['origins']),issued=retrospective['total_origins'],clipped_target_hours=retrospective['outside_target_hours'])))
    write(OUT/'completion.json',dict(status='complete',evaluation='independent January plus previously inspected retrospective year; review paired evidence before integration'))
    print('COMPLETE',flush=True)


if __name__=='__main__':
    main()

