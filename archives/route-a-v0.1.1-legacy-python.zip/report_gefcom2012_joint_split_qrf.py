"""Assess point ramps, freeze a split weight, and compare QRF intervals."""
import numpy as np
import pandas as pd

from run_gefcom2012_joint_split_qrf import OUT, YEAR, WEIGHTS, load_farms, index, feature_array
from run_point_residual import OUT as BASE
from revision_common import calibration, collect, METRIC_COLS, frozen_spec, write
from run_qrf_regime_bounds import GROUPS, bootstrap
from report_gefcom2012_dual_batch import adjust, match
from gefcom2014_experiment import masks

POINT = ('power_mae','increment_mae','up_increment_mae','up_increment_bias','signal_increment_mae',
         'signal_increment_bias','timing_recall','timing_precision','quiet_fpr')


def matches(actual, predicted):
    """Maximum one-to-one matches for ordered times within one hour."""
    truth, forecast = np.flatnonzero(actual), np.flatnonzero(predicted)
    i=j=hits=0
    while i<len(truth) and j<len(forecast):
        gap = forecast[j]-truth[i]
        if gap < -1:
            j += 1
        elif gap > 1:
            i += 1
        else:
            hits += 1
            i += 1
            j += 1
    return hits


def point(y, med, last, wind):
    actual = np.diff(y,axis=1,prepend=last[:,None])
    pred = np.diff(med,axis=1,prepend=last[:,None])
    up, alarm = actual>.10,pred>.10
    same = up & (wind>=.50)
    quiet = np.abs(actual)<=.05
    err = pred-actual
    hit = sum(matches(a,b) for a,b in zip(up,alarm))
    return dict(power_mae=np.abs(med-y).mean(),increment_mae=np.abs(err).mean(),
        up_increment_mae=np.abs(err[up]).mean(),up_increment_bias=err[up].mean(),
        signal_increment_mae=np.abs(err[same]).mean(),signal_increment_bias=err[same].mean(),
        timing_recall=hit/up.sum(),timing_precision=hit/alarm.sum(),quiet_fpr=alarm[quiet].mean(),
        up_events=int(up.sum()),signal_events=int(same.sum()),hits=int(hit),alarms=int(alarm.sum()),
        quiet=int(quiet.sum()),quiet_false=int(alarm[quiet].sum()))


def heads(farm,d,weights):
    with np.load(BASE/f'gefcom2012/farm_{farm:02}/heads.npz') as z:
        np.testing.assert_array_equal(z['origins'],d['origins'])
        result={'original':np.stack([z['direct_qrf'][0],z['qrf'],z['direct_qrf'][1]],axis=-1)}
    for weight in weights:
        with np.load(OUT/f'farm_{farm:02}/heads_{weight}.npz') as z:
            ids=z['ids']
            np.testing.assert_array_equal(z['origins'],d['origins'][ids])
            np.testing.assert_array_equal(z['train'],index(d,'train',True))
            pred=np.full((*d['y'].shape,3),np.nan)
            pred[ids]=z['heads']
            result[str(weight)]=pred
    return result


def replay(farms,stage,weights):
    records={}
    points=[]
    for farm,d in farms.items():
        base = BASE/f'gefcom2012/farm_{farm:02}'
        speed = np.linalg.norm(feature_array(YEAR,farm,'GBM')[:,-14:-12].reshape(-1,24,2),axis=-1)
        wind = np.diff(speed,axis=1,prepend=np.full((len(speed),1),np.nan))
        anchor=None
        for name,h in heads(farm,d,weights).items():
            ids,res=calibration(d,h[...,0],h[...,2],stage)
            arrival=(res['n_cal'],res['max_label_end_used'])
            if anchor is None:
                anchor=arrival
            for a,b in zip(anchor,arrival):
                np.testing.assert_array_equal(a,b)
            cal=np.clip([res['lo'],res['hi']],0,1)
            if name=='original':
                with np.load(base/f'{stage}_direct_qrf.npz') as z:
                    for a,b in ((ids,z['ids']),(cal[0],z['lo']),(cal[1],z['hi'])):
                        np.testing.assert_array_equal(a,b)
            valid=ids[d['valid'][ids]]
            points.append(dict(farm=farm,model=name,**point(d['y'][valid],h[valid,:,1],
                                                           d['history'][valid,-1],wind[valid])))
            records[farm,name]=(ids,np.clip(h[ids][:,:,[0,2]].transpose(2,0,1),0,1),cal)
    return records,pd.DataFrame(points)


def records_for(farms,records,name,arm):
    out=[]
    for farm,d in farms.items():
        ids,*ref=records[farm,'original']
        cid,*candidate=records[farm,name]
        np.testing.assert_array_equal(ids,cid)
        out.append((farm,d,ids,np.ones(len(ids),dtype=bool),ref[arm],candidate[arm]))
    return out


def score(pairs, rows, arm, operation, name, offset, daily=None):
    for farm,d,ids,batch,ref,candidate in pairs:
        for model,(lo,hi) in [('original',ref),(name,adjust(candidate,batch,offset))]:
            assert (lo<=hi).all() and np.isfinite([lo,hi]).all()
            collect(rows,d,ids,lo,hi,farm=farm,arm=arm,operation=operation,model=model,comparison=name)
            if daily is not None:
                y=d['y'][ids]
                width=hi-lo
                stats=[width,(y>=lo)&(y<=hi),width+20*np.maximum(lo-y,0)+20*np.maximum(y-hi,0),y>hi]
                for g,mask in masks(y,d['history'][ids,-1]).items():
                    if g not in GROUPS:
                        continue
                    use=mask&d['valid'][ids,None]
                    daily[model,farm,g]=(d['origins'][ids],np.column_stack(
                        [use.sum(axis=1)]+[np.where(use,s,0).sum(axis=1) for s in stats]))


def tables(farms, stage, weights, frozen=None):
    records,pts=replay(farms,stage,weights)
    pts.to_csv(OUT/f'{stage}_point_per_farm.csv',index=False)
    pm=pts.groupby('model')[list(POINT)].mean()
    pm.to_csv(OUT/f'{stage}_point_macro.csv')
    rows,ci,offsets=[],[],{}
    for w in weights:
        name=str(w)
        for arm,label in enumerate(('raw','calibrated')):
            pairs=records_for(farms,records,name,arm)
            offsets[name,label]=match(pairs,'full')
            policies={'nominal':0.,'exact_width':offsets[name,label]}
            if frozen is not None:
                policies['frozen_width']=frozen[name,label]
            for operation,offset in policies.items():
                daily={} if stage=='evaluation' and label=='calibrated' else None
                score(pairs,rows,label,operation,name,offset,daily)
                if daily:
                    ci.extend(dict(operation=operation,**r) for r in bootstrap(YEAR,daily,name))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{stage}_interval_per_farm.csv',index=False)
    im=frame.groupby(['comparison','arm','operation','model','group'])[METRIC_COLS].mean()
    im.to_csv(OUT/f'{stage}_interval_macro.csv')
    if ci:
        pd.DataFrame(ci).to_csv(OUT/'evaluation_interval_paired.csv',index=False)
    return pm,im,offsets


def checks(p,i,name,operation):
    a,b=(i.loc[(name,'calibrated',operation,k)] for k in ('original',name))
    p0,p1=(p.loc[k] for k in ('original',name))
    return dict(increment=bool(p1.signal_increment_mae<p0.signal_increment_mae),
        timing=bool(p1.timing_recall>=p0.timing_recall),
        quiet=bool(p1.quiet_fpr<=p0.quiet_fpr+.01),
        up_upper=bool(b.loc['up_ramp','upper_miss']<a.loc['up_ramp','upper_miss']),
        coverage=bool(b.loc['all','coverage']>=.90),
        near_zero=bool(b.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
        down_ramp=bool(b.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01),
        IS=bool(b.loc['all','IS']<=a.loc['all','IS']))


def main():
    frozen_spec(OUT/'analysis_protocol.json',dict(point='same-hour NWP speed rise>=.5 m/s; true/predicted ramp increment>.10; quiet |observed increment|<=.05; ±1 lead one-to-one within each issue; farm macro',
        selection='among all-gate passes and otherwise for diagnostic, minimize same-hour true ramp increment MAE, then maximize timing recall then minimize quiet FPR then weight',
        width='average macro width; half-width offset learned on development, exact evaluation width is retrospective; preserve single touched support edge on shrinking',
        bootstrap='synchronized 14-calendar-day intervals, 2000 paired draws for calibrated metrics'))
    farms=load_farms(YEAR)
    p,i,offsets=tables(farms,'validation',WEIGHTS)
    gates={str(w):checks(p,i,str(w),'exact_width') for w in WEIGHTS}
    passing=[w for w in WEIGHTS if all(gates[str(w)].values())]
    w=min(passing or WEIGHTS,key=lambda w:(p.loc[str(w),'signal_increment_mae'],-p.loc[str(w),'timing_recall'],p.loc[str(w),'quiet_fpr'],w))
    frozen_spec(OUT/'selection.json',dict(weight=w,development_pass=bool(passing),checks=gates,
        frozen_offsets={f'{m}_{a}':v for (m,a),v in offsets.items()}))
    print('FROZEN',w,gates,flush=True)
    p,i,eval_offsets=tables(farms,'evaluation',(w,),offsets)
    eval_gates={mode:checks(p,i,str(w),mode) for mode in ('frozen_width','exact_width')}
    write(OUT/'completion.json',dict(status='complete',farms=7,weight=w,development_pass=bool(passing),
        evaluation=eval_gates,retrospective_offsets={f'{m}_{a}':v for (m,a),v in eval_offsets.items()}))
    print(p.to_string(),flush=True)
    print(eval_gates,flush=True)


if __name__=='__main__':
    main()

