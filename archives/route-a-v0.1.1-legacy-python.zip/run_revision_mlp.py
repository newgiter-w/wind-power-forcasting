"""Versioned 3-seed MLP restoration and validation-only lower-bound protection."""
import os
for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[name] = '2'
from pathlib import Path
import argparse
import time
import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.isotonic import IsotonicRegression
from threadpoolctl import threadpool_limits
from gefcom_protocol_v2 import prepare, index
from strong_baselines import build_shared, order_quantile_bounds
from run_p2_2012 import build_shared_2012
from run_dl_baseline import train_model
from revision_common import OUT, METRIC_COLS, write, frozen_spec, collect, save_metrics, save_stage, reference_intervals

DEST = OUT / 'mlp'
THRESHOLDS = [.05, .1, .2, .3, .5, 0.0, 1.01]


def risk_model(d, X, tr, folder):
    """Prefix-OOF probability calibration, then full proper-training classifier."""
    path = folder / 'risk_probabilities.npz'
    if path.exists():
        return np.load(path)['probability']
    labels = (d['y'].ravel() <= .01).astype(int)
    train_days = np.zeros(len(d['y']), bool); train_days[tr] = True
    probabilities, targets, witnesses = [], [], []
    pkg = dict(max_iter=50, max_leaf_nodes=7, min_samples_leaf=100,
        l2_regularization=1., early_stopping=False, random_state=0)
    for fraction, end_fraction in [(.5, .75), (.75, 1.0)]:
        start = tr[int(len(tr)*fraction)]
        end = tr[min(int(len(tr)*end_fraction), len(tr))-1]
        fit_days = tr[d['ends'][tr] <= d['origins'][start]]
        val_days = tr[(tr >= start) & (tr <= end)]
        fit_mask = np.repeat(np.isin(np.arange(len(d['y'])), fit_days), 24)
        val_mask = np.repeat(np.isin(np.arange(len(d['y'])), val_days), 24)
        m = HistGradientBoostingClassifier(**pkg).fit(X[fit_mask], labels[fit_mask])
        probabilities.extend(m.predict_proba(X[val_mask])[:, 1]); targets.extend(labels[val_mask])
        witnesses.append(dict(train_end=str(d['ends'][fit_days].max()), first_origin=str(d['origins'][val_days].min())))
        assert d['ends'][fit_days].max() <= d['origins'][val_days].min()
    isotonic = IsotonicRegression(out_of_bounds='clip').fit(probabilities, targets)
    mask = np.repeat(train_days, 24)
    model = HistGradientBoostingClassifier(**pkg).fit(X[mask], labels[mask])
    p = isotonic.predict(model.predict_proba(X)[:, 1]).reshape(-1, 24)
    np.savez_compressed(path, probability=p, oof_probability=probabilities, oof_target=targets)
    joblib.dump(dict(classifier=model, calibrator=isotonic), folder / 'risk_model.joblib', compress=3)
    write(folder / 'risk_oof_checks.json', witnesses)
    return p


def diagnostics(d, ids, raw_lo, result, folder, stage):
    valid = np.broadcast_to(d['valid'][ids, None], (len(ids), 24))
    y = d['y'][ids]
    rows = []
    for name, mask in [('all', np.ones_like(y, bool)), ('exact_zero', y == 0),
        ('positive_near_zero', (y > 0) & (y <= .01)), ('small_positive', (y > .01) & (y <= .05))]:
        m = mask & valid
        if m.any():
            rows.append(dict(group=name, cells=int(m.sum()),
                raw_lower_miss=float((y[m] < raw_lo[ids][m]).mean()),
                cqr_lower_miss=float((y[m] < result['lo'][m]).mean()),
                negative_correction_fraction=float((result['q_signed'][m] < 0).mean()),
                mean_raw_lower=float(raw_lo[ids][m].mean()), mean_cqr_lower=float(result['lo'][m].mean()),
                mean_q=float(result['q_signed'][m].mean())))
    pd.DataFrame(rows).to_csv(folder / f'{stage}_boundary_diagnostics.csv', index=False)


def fit_farm(year, farm, d, seeds):
    root = DEST / f'gefcom{year}/farm_{farm:02d}'; root.mkdir(parents=True, exist_ok=True)
    X, y, _ = (build_shared if year == 2014 else build_shared_2012)(d, 'R2')
    # Preserve the old feature order/zero imputation to isolate q and seed effects.
    Xzero = np.nan_to_num(X, nan=0.)
    tr = index(d, 'train', True); stop = index(d, 'validation_seed', True)
    tm = np.repeat(np.isin(np.arange(len(d['y'])), tr), 24)
    sm = np.repeat(np.isin(np.arange(len(d['y'])), stop), 24)
    scaler = StandardScaler().fit(Xzero[tm]); xs = scaler.transform(Xzero)
    joblib.dump(scaler, root / 'scaler.joblib')
    np.savez_compressed(root / 'samples.npz', y=d['y'], valid=d['valid'], history=d['history'], origins=d['origins'], ends=d['ends'])
    p = risk_model(d, X, tr, root)
    for seed in seeds:
        sf = root / f'seed_{seed}'; sf.mkdir(exist_ok=True)
        predictions = {}
        for q in [.95, .05, .02]:
            cache = sf / f'q{q:.2f}.npz'
            if cache.exists():
                predictions[q] = np.load(cache)['prediction']; continue
            start = time.perf_counter()
            model = train_model(xs[tm], y[tm], xs[sm], y[sm], q, seed=seed)
            with torch.no_grad():
                pred = model(torch.tensor(xs, dtype=torch.float32)).numpy().reshape(-1, 24)
            torch.save(model.state_dict(), sf / f'q{q:.2f}.pt')
            np.savez_compressed(cache, prediction=pred, origins=d['origins'])
            write(sf / f'q{q:.2f}_fit.json', dict(seed=seed, quantile=q, **model.fit_summary,
                elapsed_seconds=time.perf_counter()-start, features=X.shape[1]))
            predictions[q] = pred
            print(f'MLP {year} farm{farm:02d} seed{seed} q{q:.2f} {time.perf_counter()-start:.1f}s', flush=True)
        for q in [.05, .02]:
            folder = sf / f'lower_{q:.2f}'; folder.mkdir(exist_ok=True)
            lo, hi = order_quantile_bounds(predictions[q], predictions[.95])
            write(folder / 'crossings.json', dict(all=int((predictions[q] > predictions[.95]).sum())))
            np.savez_compressed(folder / 'heads.npz', qlo=predictions[q], qhi=predictions[.95], lo=lo, hi=hi, origins=d['origins'])
            # Evaluation is intentionally postponed until validation selection is written.
            save_stage(folder, d, lo, hi, 'validation')


def stage_rows(year, farms, seeds, stage, selection=None):
    rows = []; slices = []
    for farm, d in farms.items():
        root = DEST / f'gefcom{year}/farm_{farm:02d}'
        p = np.load(root / 'risk_probabilities.npz')['probability']
        for seed in seeds:
            for q in [.05, .02]:
                folder = root / f'seed_{seed}/lower_{q:.2f}'
                with np.load(folder / 'heads.npz') as z:
                    lo, hi = z['lo'], z['hi']
                ids, result = save_stage(folder, d, lo, hi, stage)
                diagnostics(d, ids, lo, result, folder, stage)
                L, U = np.clip(result['lo'], 0, 1), np.clip(result['hi'], 0, 1)
                qlabel = f'MLP_q{q:.2f}'
                variants = {'raw': (lo[ids], hi[ids]),
                    'sorted_clipped': (np.clip(lo[ids], 0, 1), np.clip(hi[ids], 0, 1)),
                    'signed': (L, U),
                    'nonshrinking': (np.clip(lo[ids]-np.maximum(result['q_signed'], 0), 0, 1),
                                     np.clip(hi[ids]+np.maximum(result['q_signed'], 0), 0, 1))}
                if stage == 'validation':
                    for threshold in THRESHOLDS:
                        variants[f'protect_{threshold:g}'] = (np.where(p[ids] >= threshold, 0., L), U)
                else:
                    threshold = selection[str(q)]['threshold']
                    variants['protected'] = (np.where(p[ids] >= threshold, 0., L), U)
                    assert np.all(variants['protected'][0] <= L)
                    np.savez_compressed(folder / 'evaluation_protected.npz', indices=ids,
                        lo=variants['protected'][0], hi=U, probability=p[ids], threshold=threshold)
                for variant, (ll, uu) in variants.items():
                    collect(rows, d, ids, ll, uu, year=year, farm=farm, seed=seed, stage=stage, method=qlabel+'_'+variant)
                    if variant in ('signed', 'nonshrinking', 'protected'):
                        for h in range(24):
                            m = d['valid'][ids]
                            yy = d['y'][ids, h][m]; l = ll[:, h][m]; u = uu[:, h][m]
                            slices.append(dict(year=year, farm=farm, seed=seed, stage=stage, method=qlabel+'_'+variant,
                                slice=f'lead_{h+1:02d}', cells=len(yy), coverage=float(((yy>=l)&(yy<=u)).mean()),
                                width=float((u-l).mean()), IS=float((u-l+20*np.maximum(l-yy,0)+20*np.maximum(yy-u,0)).mean())))
                        for month in np.unique(d['origins'][ids].astype('datetime64[M]')):
                            m = (d['origins'][ids].astype('datetime64[M]') == month) & d['valid'][ids]
                            yy, l, u = d['y'][ids][m], ll[m], uu[m]
                            if len(yy):
                                slices.append(dict(year=year, farm=farm, seed=seed, stage=stage, method=qlabel+'_'+variant,
                                    slice=str(month), cells=yy.size, coverage=float(((yy>=l)&(yy<=u)).mean()),
                                    width=float((u-l).mean()), IS=float((u-l+20*np.maximum(l-yy,0)+20*np.maximum(yy-u,0)).mean())))
        ids, L, U = reference_intervals(year, farm, stage)
        collect(rows, d, ids, L, U, year=year, farm=farm, seed=-1, stage=stage, method='R2_reference')
    pd.DataFrame(slices).to_csv(DEST / f'{year}_{stage}_slices.csv', index=False)
    return rows


def select(validation_rows):
    df = pd.DataFrame(validation_rows)
    means = df.groupby(['method', 'group'])[METRIC_COLS].mean()
    r2near = means.loc[('R2_reference', 'near_zero'), 'coverage']
    decision = {}
    for q in [.05, .02]:
        label = f'MLP_q{q:.2f}'
        base = means.loc[(label+'_signed', 'all')]
        baseup = means.loc[(label+'_signed', 'up_ramp'), 'coverage']
        candidates = []
        for threshold in THRESHOLDS:
            method = label+f'_protect_{threshold:g}'
            allm = means.loc[(method, 'all')]
            near = means.loc[(method, 'near_zero'), 'coverage']
            up = means.loc[(method, 'up_ramp'), 'coverage']
            eligible = bool(allm.coverage >= max(.90, base.coverage-.005) and near >= r2near-.005 and up >= baseup-.005)
            candidates.append(dict(threshold=threshold, IS=float(allm.IS), coverage=float(allm.coverage), near_zero=float(near), eligible=eligible))
        good = [r for r in candidates if r['eligible']]
        chosen = min(good, key=lambda r:(r['IS'], -r['threshold'])) if good else dict(threshold=1.01)
        decision[str(q)] = dict(threshold=chosen['threshold'], eligible_found=bool(good), candidates=candidates,
            reason='minimum validation IS subject to prespecified coverage gates' if good else 'no candidate passed; retain signed interval')
    return decision


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--seeds', nargs='+', type=int, default=[0,1,2]); args = parser.parse_args()
    DEST.mkdir(parents=True, exist_ok=True)
    spec = dict(seeds=args.seeds, quantiles=[.02,.05,.95], imputation='legacy zero; same interleaved 122/123 feature order as original MLP',
        train='proper training only; Q1 early stopping, Q2 threshold selection', thresholds=THRESHOLDS,
        gates='all >= max(.90, unprotected-.005); near_zero >= R2-.005; up_ramp >= unprotected-.005; minimize IS',
        evaluation='previously inspected dates; retrospective; all seeds retained', reference='factorial_20261103_v2',
        risk='train-prefix OOF isotonic, full proper-training HGB classifier; no target group at forecast time',
        calibration='signed rolling84; no-shrink diagnostic; clip[0,1]', torch_version=torch.__version__)
    frozen_spec(DEST / 'protocol.json', spec)
    torch.set_num_threads(2)
    began = time.perf_counter()
    farms14, _ = prepare(2014)
    for farm, d in farms14.items(): fit_farm(2014, farm, d, args.seeds)
    rows = stage_rows(2014, farms14, args.seeds, 'validation')
    decision = select(rows); write(DEST / 'selection.json', decision)
    save_metrics(DEST, rows)
    rows += stage_rows(2014, farms14, args.seeds, 'evaluation', decision)
    save_metrics(DEST, rows)
    farms12, _ = prepare(2012)
    for farm, d in farms12.items(): fit_farm(2012, farm, d, args.seeds)
    rows += stage_rows(2012, farms12, args.seeds, 'validation')
    rows += stage_rows(2012, farms12, args.seeds, 'evaluation', decision)
    save_metrics(DEST, rows)
    write(DEST / 'completion.json', dict(status='complete', years=[2014,2012], seeds=args.seeds, elapsed_seconds=time.perf_counter()-began))


if __name__ == '__main__':
    with threadpool_limits(limits=2): main()
