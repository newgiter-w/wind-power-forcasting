"""Paired shared-lead HistGBR versus the frozen single-farm QRF."""
import json

import joblib
import numpy as np
import pandas as pd

from pooling_common import ROOT, OUT as INPUT, REVISION, load_farms, feature_array
from revision_common import collect, calibration, frozen_spec, write, METRIC_COLS
from gefcom_protocol_v2 import index, prepare
from run_gefcom_tail_dynamic import base_matrix
from strong_baselines import PKG, fit_predict
from online_calibration import simulate_independent
from run_qrf_regime_bounds import BASE, GROUPS, bootstrap
from gefcom2014_experiment import masks

OUT = ROOT / 'out_gefcom_shared_gbm_qrf_A'
YEARS = (2014, 2012)
ARMS = ('raw', 'independent84')
LEVELS = (.05, .5, .95)
MATCH = dict(coverage=('all', 'coverage'), width=('all', 'width'))


def heads(year, farm, d, original):
    folder = OUT / f'gefcom{year}/farm_{farm:02d}'
    folder.mkdir(parents=True, exist_ok=True)
    qrf = REVISION / f'qrf/gefcom{year}/farm_{farm:02d}/leaf_10/seed_0'
    tr = index(d, 'train', True)
    tm = np.repeat(np.isin(np.arange(len(d['y'])), tr), 24)
    forecast = np.flatnonzero(~d['meta'].phase.eq('train').to_numpy())
    assert d['ends'][tr].max() <= d['origins'][forecast].min()
    for key in ('origins', 'ends', 'valid', 'y', 'history'):
        np.testing.assert_equal(d[key], original[key])
    np.testing.assert_array_equal(d['meta'].phase, original['meta'].phase)
    np.testing.assert_array_equal(tr, index(original, 'train', True))
    x = feature_array(year, farm, 'GBM')
    np.testing.assert_equal(x, base_matrix(original, year))
    imputer = joblib.load(INPUT / f'inputs/gefcom{year}/farm_{farm:02d}/preprocessing.joblib')['QRF_imputer']
    dense = imputer.transform(x)
    np.testing.assert_array_equal(dense.astype('float32'), feature_array(year, farm, 'QRF'))
    fit = json.loads((qrf / 'fit.json').read_text())
    assert (fit['train_cells'], fit['features']) == (int(tm.sum()), dense.shape[1])
    with np.load(qrf / 'heads.npz') as z:
        np.testing.assert_array_equal(z['origins'], d['origins'])
        np.testing.assert_array_equal(z['forecast_indices'], forecast)
        qlo, qhi = z['lo'], z['hi']
    path = folder / 'gbm_heads.npz'
    if not path.exists():
        pred = np.stack([fit_predict(dense, d['y'].ravel(), tm, q)[0] for q in LEVELS], axis=-1)
        pred[d['meta'].phase.eq('train').to_numpy()] = np.nan
        np.savez_compressed(path, heads=pred, origins=d['origins'])
    with np.load(path) as z:
        np.testing.assert_array_equal(z['origins'], d['origins'])
        pred = z['heads']
    assert np.isfinite(pred[forecast]).all()
    write(folder / 'witness.json', dict(train_days=len(tr), features=dense.shape[1],
        first_train_origin=str(d['origins'][tr[0]]), last_train_end=str(d['ends'][tr[-1]]),
        first_forecast=str(d['origins'][forecast[0]]),
        endpoint_crossings=int((pred[..., 0] > pred[..., 2]).sum())))
    return {'QRF': (qlo, qhi), 'GBM': (np.minimum(pred[..., 0], pred[..., 2]),
                                      np.maximum(pred[..., 0], pred[..., 2]))}


def calibrated(d, ids, raw, stage):
    lo, hi = raw
    seed = index(d, 'validation_seed' if stage == 'validation' else 'validation')
    result = simulate_independent(d['origins'], d['ends'], d['y'], lo, hi,
                                  d['valid'], seed, ids, 'rolling', 84)
    assert (result['max_label_end_used'] <= d['origins'][ids]).all()
    return result


def replay(year, stage, farms, all_heads, rows):
    pairs = {arm: [] for arm in ARMS}
    for farm, d in farms.items():
        ids = index(d, stage)
        endpoints = {}
        arrivals = []
        for model, raw in all_heads[farm].items():
            lo, hi = raw
            res = calibrated(d, ids, raw, stage)
            arrivals.append((res['max_label_end_used'], res['n_cal']))
            endpoints[model] = dict(raw=np.clip([lo[ids], hi[ids]], 0, 1),
                                    independent84=np.clip([res['lo'], res['hi']], 0, 1))
            folder = OUT / f'gefcom{year}/farm_{farm:02d}'
            np.savez_compressed(folder / f'{stage}_{model}.npz', ids=ids, origins=d['origins'][ids],
                raw=endpoints[model]['raw'], independent84=endpoints[model]['independent84'],
                max_label_end=res['max_label_end_used'], n_cal=res['n_cal'],
                q_lower=res['q_lower'], q_upper=res['q_upper'])
        for left, right in zip(*arrivals):
            np.testing.assert_array_equal(left, right)
        _, signed = calibration(d, *all_heads[farm]['QRF'], stage)
        signed_lo, signed_hi = np.clip([signed['lo'], signed['hi']], 0, 1)
        with np.load(BASE / f'gefcom{year}/farm_{farm:02d}/{stage}_direct_qrf.npz') as z:
            np.testing.assert_array_equal(ids, z['ids'])
            np.testing.assert_array_equal(signed_lo, z['lo'])
            np.testing.assert_array_equal(signed_hi, z['hi'])
        collect(rows, d, ids, signed_lo, signed_hi, year=year, stage=stage, arm='signed84',
                model='QRF', operating_point='nominal', farm=farm)
        for arm in ARMS:
            ref, gbm = endpoints['QRF'][arm], endpoints['GBM'][arm]
            for lo, hi in (ref, gbm):
                assert np.isfinite(lo).all() and np.isfinite(hi).all() and (lo <= hi).all()
            pairs[arm].append((farm, d, ids, ref, gbm))
    return pairs


def shifted(bounds, offset, preserve_support=False):
    lo, hi = bounds
    center = (lo + hi) / 2
    if preserve_support and offset < 0:
        lower_edge, upper_edge = (lo == 0) & (hi < 1), (hi == 1) & (lo > 0)
        return (np.where(lower_edge, lo, np.minimum(lo - offset * (1 + upper_edge), np.where(upper_edge, hi, center))),
                np.where(upper_edge, hi, np.maximum(hi + offset * (1 + lower_edge), np.where(lower_edge, lo, center))))
    return (np.clip(np.minimum(lo - offset, center), 0, 1),
            np.clip(np.maximum(hi + offset, center), 0, 1))


def value(pairs, metric, offset=None, preserve_support=False):
    values = []
    for _, d, ids, ref, gbm in pairs:
        valid = d['valid'][ids]
        lo, hi = ref if offset is None else shifted(gbm, offset, preserve_support)
        if metric == 'coverage':
            y = d['y'][ids]
            values.append(((y >= lo) & (y <= hi))[valid].mean())
        else:
            values.append((hi - lo)[valid].mean())
    return float(np.mean(values))


def match(pairs, metric, preserve_support=False):
    target = value(pairs, metric)
    left, right = -1., 1.
    assert value(pairs, metric, left, preserve_support) <= target <= value(pairs, metric, right, preserve_support)
    for _ in range(42):
        mid = (left + right) / 2
        if value(pairs, metric, mid, preserve_support) < target:
            left = mid
        else:
            right = mid
    return right


def score(pairs, rows, year, stage, arm, point, offset):
    daily = {}
    for farm, d, ids, ref, gbm in pairs:
        y = d['y'][ids]
        group_masks = masks(y, d['history'][ids, -1])
        for model, (lo, hi) in [('QRF', ref), ('GBM', shifted(gbm, offset, point == 'retrospective_width_support'))]:
            collect(rows, d, ids, lo, hi, year=year, stage=stage, arm=arm,
                    model=model, operating_point=point, farm=farm)
            if stage != 'evaluation' or point.startswith('retrospective'):
                continue
            width = hi - lo
            stats = [width, (y >= lo) & (y <= hi),
                     width + 20*np.maximum(lo-y, 0) + 20*np.maximum(y-hi, 0), y > hi]
            for group in GROUPS:
                keep = group_masks[group] & d['valid'][ids, None]
                daily[model, farm, group] = (d['origins'][ids], np.column_stack(
                    [keep.sum(axis=1)] + [np.where(keep, s, 0).sum(axis=1) for s in stats]))
    if daily:
        return [dict(stage=stage, arm=arm, operating_point=point, **row)
                for row in bootstrap(year, daily, 'GBM')]
    return []


def main():
    frozen_spec(OUT / 'protocol.json', dict(
        years=list(YEARS), qrf='frozen local 500 trees, leaf10, seed0',
        gbm=dict(PKG, quantiles=list(LEVELS)),
        input='identical canonical R2 and QRF median/indicator preprocessing; local per farm, all 24 leads share each head',
        arms=list(ARMS), reference='original QRF signed84',
        calibration='existing C1, independent .05 each side, rolling84, identical per-farm per-lead arrived labels, clip [0,1]',
        matching='add common signed offset to GBM interval half-width, collapse at midpoint, clip support; per arm against nominal QRF',
        selection='offsets fitted on 2014 Q2 then frozen for both evaluation windows; within-window matches are explicitly retrospective',
        inference='farm-macro, synchronous paired 14-day moving blocks 2000 for nominal and frozen offsets, conditional on fitted forecasts'))
    frozen_spec(OUT / 'sensitivity_protocol.json', dict(
        retrospective_width_support='width match with identical per-cell width reduction as symmetric shrink; preserve touched physical boundary when exactly one endpoint is on it'))
    rows, paired, offsets, frozen = [], [], [], {}
    for year in YEARS:
        farms = load_farms(year)
        originals, _ = prepare(year)
        assert set(farms) == set(originals) and len(farms) == (10 if year == 2014 else 7)
        all_heads = {}
        for farm, d in farms.items():
            all_heads[farm] = heads(year, farm, d, originals[farm])
            print('HEADS', year, farm, flush=True)
        for stage in (('validation', 'evaluation') if year == 2014 else ('evaluation',)):
            for arm, pairs in replay(year, stage, farms, all_heads, rows).items():
                points = {'nominal': 0.}
                for metric in MATCH:
                    if stage == 'validation':
                        frozen[arm, metric] = match(pairs, metric)
                    points[f'frozen_{metric}'] = frozen[arm, metric]
                    if stage == 'evaluation':
                        points[f'retrospective_{metric}'] = match(pairs, metric)
                if stage == 'evaluation':
                    points['retrospective_width_support'] = match(pairs, 'width', preserve_support=True)
                for point, offset in points.items():
                    offsets.append(dict(year=year, stage=stage, arm=arm, operating_point=point,
                                        gbm_half_width_offset=offset))
                    paired.extend(score(pairs, rows, year, stage, arm, point, offset))
            if stage == 'validation':
                frozen_spec(OUT / 'selection.json', {f'{arm}_{metric}': offset
                                                       for (arm, metric), offset in frozen.items()})
            print('SCORED', year, stage, flush=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / 'per_farm.csv', index=False)
    keys = ['year', 'stage', 'arm', 'operating_point', 'group']
    macro = frame.groupby(keys + ['model'])[METRIC_COLS].mean()
    macro.to_csv(OUT / 'macro.csv')
    wide = macro.unstack('model')
    (wide.xs('GBM', axis=1, level=1) - wide.xs('QRF', axis=1, level=1)).dropna().to_csv(OUT / 'deltas.csv')
    pd.DataFrame(paired).to_csv(OUT / 'paired_blocks.csv', index=False)
    pd.DataFrame(offsets).to_csv(OUT / 'offsets.csv', index=False)
    write(OUT / 'completion.json', dict(status='complete', farms=17))
    print('COMPLETE', flush=True)


if __name__ == '__main__':
    main()



