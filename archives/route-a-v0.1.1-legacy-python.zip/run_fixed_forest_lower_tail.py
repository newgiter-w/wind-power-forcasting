"""Compare lower quantiles using the same saved trees and chronological feedback."""
from concurrent.futures import ProcessPoolExecutor
from copy import copy
import json
import joblib
import numpy as np
import pandas as pd
from run_qrf_regime_bounds import (BASE, ROOT, REVISION, OUT as R15_OUT, GROUPS, METRIC_COLS,
    load_farms, feature_array, index, local_heads, calibration, variants, collect, masks,
    added_features, frozen_spec, write, quantile, bootstrap)
from run_point_residual import SparseLeafQRF, cells
from report_qrf_speed_delta import table

OUT = ROOT/'out_gefcom_fixed_forest_lower_tail_20261106'
LEVELS = (.02,.025,.05,.95)
NAMES = ('q02','q025','q05')
BRANCHES = ('symmetric','fixed_R15_upper')


def extract(job):
    year,farm = job
    d=load_farms(year)[farm]
    days=np.r_[index(d,'validation_seed'),index(d,'validation'),index(d,'evaluation')]
    train=index(d,'train',True)
    assert d['ends'][train].max()<=d['origins'][days].min()
    x=feature_array(year,farm,'QRF')
    path=REVISION/f'qrf/gefcom{year}/farm_{farm:02}/leaf_10/seed_0/model.joblib'
    original=joblib.load(path)['model']
    sparse=SparseLeafQRF(n_jobs=2)
    sparse.forest=copy(original)
    sparse.forest.forest_=None
    sparse.forest.n_jobs=2
    del original
    sparse.build_responses(x[cells(train)],d['y'][train].ravel())
    result=sparse.predict(x[cells(days)],LEVELS).reshape(-1,24,4)
    lo,hi=local_heads(year,farm,'QRF',0)
    np.testing.assert_allclose(result[:,:,[2,3]],np.stack([lo[days],hi[days]],axis=-1),atol=1e-12,rtol=1e-12)
    assert np.isfinite(result).all() and (np.diff(result,axis=2)>=-1e-12).all()
    folder=OUT/f'gefcom{year}/farm_{farm:02}'
    folder.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(folder/'quantiles.npz',days=days,values=result,levels=LEVELS,origins=d['origins'][days])
    print('QUANTILES',year,farm,flush=True)


def lower_replay(d,ids,seed,raw,base_q,groups,risk,upper):
    result=np.empty((len(ids),24))
    arrival=[]
    history=np.r_[seed,ids]
    for k,day in enumerate(ids):
        origin=d['origins'][day]
        past=history[:len(seed)+k]
        ends=d['ends'][past]
        use=past[(ends<=origin)&(ends>origin-np.timedelta64(84,'D'))]
        use=use[d['valid'][use]]
        assert len(use)>=9 and day not in use and (d['ends'][use]<=origin).all()
        arrival.append(d['ends'][use].max())
        score=raw[use]-d['y'][use]
        q=base_q[k].copy()
        for start in range(0,24,6):
            band=slice(start,start+6)
            for state in np.unique(groups[day,band]):
                target=np.flatnonzero(groups[day,band]==state)+start
                values=score[:,band][groups[use,band]==state]
                n=len(values)
                if n>=40:
                    weight=.5*n/(n+80)
                    q[target]=(1-weight)*q[target]+weight*quantile(values,.075)
        result[k]=np.minimum(upper[k],np.where(risk[day]>=.1,0,np.clip(raw[day]-q,0,1)))
    return result,np.array(arrival)


def compare(year,stage,chosen=None):
    rows,changes,daily=[],[],{}
    seed_phase='validation_seed' if stage=='validation' else 'validation'
    for farm,d in load_farms(year).items():
        folder=OUT/f'gefcom{year}/farm_{farm:02}'
        ids,seed=index(d,stage),index(d,seed_phase)
        oldlo,hi=local_heads(year,farm,'QRF',0)
        with np.load(folder/'quantiles.npz') as z:
            days=z['days']
            np.testing.assert_array_equal(z['origins'],d['origins'][days])
            raws={name:np.full_like(oldlo,np.nan) for name in NAMES}
            for j,name in enumerate(NAMES):
                raws[name][days]=z['values'][:,:,j]
        raws['q05']=oldlo
        _,base=calibration(d,oldlo,hi,stage)
        lo0,hi0=np.clip(base['lo'],0,1),np.clip(base['hi'],0,1)
        with np.load(BASE/f'gefcom{year}/farm_{farm:02}/{stage}_direct_qrf.npz') as z:
            for a,b in [(ids,z['ids']),(lo0,z['lo']),(hi0,z['hi'])]:
                np.testing.assert_array_equal(a,b)
        risk=np.load(REVISION/f'mlp/gefcom{year}/farm_{farm:02}/risk_probabilities.npz')['probability']
        if stage=='evaluation':
            with np.load(R15_OUT/f'gefcom{year}/farm_{farm:02}/R15.npz') as z:
                np.testing.assert_array_equal(z['ids'],ids)
                np.testing.assert_array_equal(z['max_calibration_end'],base['max_label_end_used'])
                rlo,rhi=z['lo'],z['hi']
        else:
            wind=added_features(feature_array(year,farm,'GBM'))[:,0].reshape(-1,24)
            rlo,rhi=next((l,u) for name,l,u,_ in variants(d,ids,seed,oldlo,hi,lo0,hi0,base['q_signed'],wind,risk) if name=='R15')
        lower_group=2*(risk>=.1).astype(int)+(hi-oldlo>=.45)
        y=d['y'][ids]
        gm=masks(y,d['history'][ids,-1])
        endpoints={}
        for name in NAMES:
            raw=raws[name]
            _,sym=calibration(d,raw,hi,stage)
            np.testing.assert_array_equal(sym['max_label_end_used'],base['max_label_end_used'])
            fixed,arrival=lower_replay(d,ids,seed,raw,base['q_signed'],lower_group,risk,rhi)
            np.testing.assert_array_equal(arrival,base['max_label_end_used'])
            endpoints[('symmetric',name)]=(np.clip(sym['lo'],0,1),np.clip(sym['hi'],0,1))
            endpoints[('fixed_R15_upper',name)]=(fixed,rhi)
        np.testing.assert_allclose(endpoints[('fixed_R15_upper','q05')][0],rlo,rtol=0,atol=1e-12)
        for (branch,name),(l,u) in endpoints.items():
            assert np.isfinite(l).all() and np.isfinite(u).all() and (l<=u).all()
            collect(rows,d,ids,l,u,year=year,farm=farm,stage=stage,branch=branch,method=name)
            bl,bu=endpoints[(branch,'q05')]
            valid=d['valid'][ids]
            changes.append(dict(year=year,farm=farm,branch=branch,method=name,
                raw_lower_delta=float((raws[name][ids]-oldlo[ids])[valid].mean()),
                final_lower_delta=float((l-bl)[valid].mean()),final_upper_delta=float((u-bu)[valid].mean())))
            if stage=='evaluation' and chosen[branch]==name:
                np.savez_compressed(folder/f'{branch}_selected.npz',ids=ids,lo=l,hi=u,max_label_end=arrival)
            if stage=='evaluation' and name in ('q05',chosen[branch]):
                for group in GROUPS:
                    keep=gm[group]&valid[:,None]
                    values=[u-l,(y>=l)&(y<=u),u-l+20*np.maximum(l-y,0)+20*np.maximum(y-u,0),y>u]
                    daily[branch,name,farm,group]=(d['origins'][ids],np.column_stack(
                        [keep.sum(axis=1)]+[np.where(keep,v,0).sum(axis=1) for v in values]))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{year}_{stage}_per_farm.csv',index=False)
    m=frame.groupby(['branch','method','group'])[METRIC_COLS].mean()
    m.to_csv(OUT/f'{year}_{stage}_macro.csv')
    pd.DataFrame(changes).to_csv(OUT/f'{year}_{stage}_endpoint_changes.csv',index=False)
    return m,daily


def gates(m,branch,name):
    b,c=(m.loc[(branch,k)] for k in ('q05',name))
    o=m.loc[('symmetric','q05')]
    return dict(down_lower_miss=bool(c.loc['down_ramp','lower_miss']<b.loc['down_ramp','lower_miss']),
        down_coverage=bool(c.loc['down_ramp','coverage']>=max(b.loc['down_ramp','coverage'],o.loc['down_ramp','coverage']-.01)),
        near_zero=bool(c.loc['near_zero','coverage']>=max(b.loc['near_zero','coverage'],o.loc['near_zero','coverage'])-.01),
        coverage=bool(c.loc['all','coverage']>=.9),
        width=bool(c.loc['all','width']<=b.loc['all','width']+.005),
        score=bool(c.loc['all','IS']<=b.loc['all','IS']),
        up_upper=bool(c.loc['up_ramp','upper_miss']<=b.loc['up_ramp','upper_miss']+.005))


def main():
    frozen_spec(OUT/'protocol.json',dict(seed=0,levels=list(LEVELS),branches=list(BRANCHES),
        lower='frozen R15 upper, original q05/q95 grouping and signed correction fallback; replace only lower raw quantile in local lower score; frozen .075 tail and risk guard',
        select='2014 Q2, minimum IS among passing within each branch, else q05; retain all candidate results as retrospective diagnostics',
        gates='lower down miss, no down coverage loss versus branch q05 and within 1pp of original, near-zero within 1pp of both, overall >=90%, width increase <=0.5pp, IS no worse, up upper miss increase <=0.5pp vs branch q05',
        pair='fixed seed 0, 2000 synchronous 14-day blocks'))
    jobs=[(year,farm) for year in (2014,2012) for farm in load_farms(year)]
    with ProcessPoolExecutor(max_workers=4) as pool:
        list(pool.map(extract,jobs))
    dev,_=compare(2014,'validation')
    checks={branch:{name:gates(dev,branch,name) for name in NAMES[:2]} for branch in BRANCHES}
    chosen={}
    for branch in BRANCHES:
        passing=[name for name,c in checks[branch].items() if all(c.values())]
        chosen[branch]=min(passing,key=lambda n:dev.loc[(branch,n,'all'),'IS']) if passing else 'q05'
    frozen_spec(OUT/'selection.json',dict(chosen=chosen,checks=checks))
    print('FROZEN',chosen,flush=True)
    paired=[]
    tables=[]
    for year,stage in [(2014,'validation'),(2014,'evaluation'),(2012,'evaluation')]:
        m=dev
        if stage=='evaluation':
            m,daily=compare(year,stage,chosen)
            for branch in BRANCHES:
                name=chosen[branch]
                if name=='q05':
                    continue
                pair={('original' if k=='q05' else name,f,g):v for (arm,k,f,g),v in daily.items() if arm==branch}
                paired.extend(dict(branch=branch,**r) for r in bootstrap(year,pair,name))
        for branch in BRANCHES:
            for name in NAMES:
                a=m.loc[(branch,name)]
                tables.append([year,stage,branch,name,f"{100*a.loc['all','coverage']:.2f}",
                    f"{100*a.loc['down_ramp','lower_miss']:.2f}",f"{100*a.loc['down_ramp','coverage']:.2f}",
                    f"{100*a.loc['near_zero','coverage']:.2f}",f"{100*a.loc['up_ramp','upper_miss']:.2f}",
                    f"{100*a.loc['all','width']:.2f}",f"{a.loc['all','IS']:.4f}",
                    ', '.join(k for k,v in gates(m,branch,name).items() if not v) if name!='q05' else 'reference'])
    if paired:
        pd.DataFrame(paired).to_csv(OUT/'selected_paired_blocks.csv',index=False)
    text=f"""# 固定 QRF 森林的下尾回放

两套 GEFCom 共 17 个场，种子 0。同一批保存树重新查询 q02、q025、q05、q95，覆盖 Q1 校准种子、Q2 和评价期。q05/q95 与历史预测核对一致。两条路线均使用 84 天已到达标签。对称路线重新计算整个 CQR；固定 R15 上界路线保留原分组、原校准回退、近零保护与 R15 上界，仅替换下侧原始分位数和对应的一侧误差分数。两个 q05 参考分别复现原 QRF 与 R15。

2014 Q2 冻结选择为 **{chosen}**。开发门槛及每项结果见 protocol.json 和 selection.json。宽度容忍为相对各自 q05 参考最多增加 0.5 个容量百分点，上爬坡上漏最多增加 0.5 个百分点。各候选的评价结果用于回溯诊断，选择依据只来自 2014 Q2。

{table(['数据','阶段','校准','原始下分位','总体覆盖%','下爬坡下漏%','下爬坡覆盖%','近零覆盖%','上爬坡上漏%','宽度%容量','IS','未过门槛'],tables)}

逐场结果和端点变化见对应 CSV。选中的非基准方案另给出同步跨场 14 日配对区块统计。所有结果为风场等权宏平均、单种子历史回放。
"""
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')
    write(OUT/'completion.json',dict(status='complete',farms=len(jobs),chosen=chosen))
    print('COMPLETE',chosen,flush=True)

if __name__=='__main__':
    main()
