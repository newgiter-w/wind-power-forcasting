import unittest
import numpy as np

from run_kelmarsh_nwp_context_factorial import context_features,calibrations,daily
from diagnose_kelmarsh_ramp_bottleneck import nearby


class ContextAndBudgetWitness(unittest.TestCase):
    def test_same_issue_local_window_does_not_wrap_or_use_targets(self):
        speed=np.tile(np.arange(24,dtype=float),(2,1))
        speed[1]+=100
        f=np.zeros((2,24,9));f[:,:,3]=speed;f[:,:,4]=1;f[:,0,4]=np.nan
        d=dict(nwp=np.stack([speed,np.zeros_like(speed)],axis=-1),y=np.zeros_like(speed))
        x,names=context_features(d,dict(features=f))
        self.assertEqual(x.shape,(2,24,25))
        prev=x[:,:,names.index('nwp_speed_offset_-2')]
        nxt=x[:,:,names.index('nwp_speed_offset_+2')]
        self.assertTrue(np.isnan(prev[:,:2]).all())
        self.assertTrue(np.isnan(nxt[:,-2:]).all())
        np.testing.assert_array_equal(prev[:,2:],speed[:,:-2])
        np.testing.assert_array_equal(nxt[:,:-2],speed[:,2:])
        altered=dict(d,y=np.ones_like(speed)*999)
        np.testing.assert_array_equal(x,context_features(altered,dict(features=f))[0])
        np.testing.assert_array_equal(x[:,2:,names.index('nwp_speed_rise_previous2')],np.full((2,22),2.))

    def test_different_gates_match_same_full_hour_false_budget(self):
        shape=(2,24);same=np.zeros(shape,bool);same[:,[5,10,15]]=True
        near=nearby(same,2);near[:,0]=False
        base=np.zeros(shape);base[:,[0,5,7,10,19]]=.2
        rng=np.random.default_rng(12)
        r=dict(base=base,actual=np.zeros(shape),same=same,near=near,
            eligible=np.broadcast_to(np.arange(24)>0,shape),
            origins=np.array(['2024-01-01','2024-01-02'],dtype='datetime64[D]'),tie=rng.random(shape))
        for k in ('q90','old','point','context'):r[k]=rng.random(shape)
        cuts=calibrations(r)
        data=daily(r,cuts,'matched_development')
        total=data[data.scope.eq('all')].groupby('model')['false'].sum()
        self.assertEqual(total.nunique(),1)
        self.assertEqual(total.iloc[0],10)


if __name__=='__main__':
    unittest.main()
