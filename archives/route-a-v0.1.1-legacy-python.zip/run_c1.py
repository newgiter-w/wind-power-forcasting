"""C1 (independent upper/lower tails) vs C0 (symmetric rolling CQR) on 2021/2022.

Reuses the frozen NH_H0 raw predictions from out_calibration_v1/raw_predictions.npz
and the rolling-84 window. No model training. Output to out_c1/.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

import evaluate as ev
from online_calibration import simulate, simulate_independent
from run_calibration import cache_predictions, indices_for, PERIODS

ROOT = Path(__file__).parent
OUT = ROOT / 'out_c1'
MODEL = ROOT / 'out_v3/x01/tasks/NH_H0'


def signed_change(y, prev):
    """Signed hour-to-hour change; first step vs last observed hour mean."""
    d = np.diff(y, axis=1, prepend=prev[:, None])
    return d


def group(data, result, mask):
    idx = result['indices']
    y = data['y'][idx]
    lo, hi = result['lo'], result['hi']
    inside = (y >= lo) & (y <= hi)
    vmask = np.broadcast_to(data['valid'][idx, None], y.shape)
    m = mask & vmask
    if not m.any():
        return None
    width = np.maximum(hi - lo, 0) / 12300.0
    return {'cells': int(m.sum()), 'origins': int(m.any(axis=1).sum()),
            'coverage': float(inside[m].mean()), 'width': float(width[m].mean()),
            'lower_miss': float(((y < lo) & m).mean()),
            'upper_miss': float(((y > hi) & m).mean())}


def masks_for(data, result):
    idx = result['indices']
    y = data['y'][idx]
    prev = data['last_hour'][idx]
    chg = signed_change(y, prev)
    return {
        'all': np.ones_like(y, dtype=bool),
        'ramp': np.abs(chg) > 1230.0,
        'up_ramp': chg > 1230.0,
        'down_ramp': chg < -1230.0,
        'near_zero': np.abs(y) <= 123.0,
    }


def run_year(data, year):
    seed, score = indices_for(data, year)
    c0 = simulate(data['origins'], data['target_end'], data['y'], data['raw_lo'], data['raw_hi'],
                  data['valid'], seed, score, 'rolling', 84)
    c1 = simulate_independent(data['origins'], data['target_end'], data['y'], data['raw_lo'],
                              data['raw_hi'], data['valid'], seed, score, 'rolling', 84)
    masks = masks_for(data, c0)
    row = {}
    for name, res in (('C0_symmetric', c0), ('C1_independent', c1)):
        row[name] = {g: group(data, res, masks[g]) for g in masks}
    return row


def fmt(g):
    if g is None:
        return '  n/a  '
    return (f"{g['coverage']*100:5.1f}% w={g['width']*100:5.1f}% "
            f"LoMiss={g['lower_miss']*100:4.1f}% HiMiss={g['upper_miss']*100:4.1f}% "
            f"(n={g['origins']})")


def main():
    OUT.mkdir(exist_ok=True)
    data = cache_predictions()
    out = {}
    for year in ('2021', '2022'):
        out[year] = run_year(data, year)
        print(f"\n===== {year} =====")
        for g in ('all', 'ramp', 'up_ramp', 'down_ramp', 'near_zero'):
            c0, c1 = out[year]['C0_symmetric'][g], out[year]['C1_independent'][g]
            print(f"  {g:11s} C0: {fmt(c0)}")
            print(f"  {'':11s} C1: {fmt(c1)}")
    (OUT / 'results.json').write_text(
        json.dumps(out, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(f"\n[done] -> out_c1/results.json")


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
