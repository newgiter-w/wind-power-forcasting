"""Extend the locked Kelmarsh QRF/q90 holdout without selecting new parameters."""
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from threadpoolctl import threadpool_limits

import run_kelmarsh_gfs_q90 as prior
from pair_kelmarsh_gfs import OUT as DATA, month
from revision_common import frozen_spec,write
from run_gefcom_tail_dynamic import base_matrix
from sparse_leaf_qrf import SparseLeafQRF
from run_gefcom2012_local_increment import score,threshold,daily,summarize

OUT=DATA/'q90_expanded_holdout'
MONTHS=tuple(f'2024-{m:02}' for m in range(4,13))
SUBSETS={
    'new_apr_dec':MONTHS,
    'cumulative_feb_dec':('2024-02','2024-03',*MONTHS),
    'quarter_apr_jun':MONTHS[:3],
    'quarter_jul_sep':MONTHS[3:6],
    'quarter_oct_dec':MONTHS[6:],
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_months(months):
    # The original reader performs identical complete-day screening and clipping.
    saved=prior.PERIODS.copy()
    try:
        prior.PERIODS={'requested':months}
        return prior.read('requested')
    finally:
        prior.PERIODS=saved


def restore():
    original=prior.DEST
    model=joblib.load(original/'q90.joblib')
    selection=json.loads((original/'selection.json').read_text())
    path=OUT/'frozen_baseline.joblib'
    if path.exists():
        bundle=joblib.load(path)
        forest,imp=bundle['forest'],bundle['imputer']
    else:
        train=read_months(('2023-09','2023-10'))
        tx=base_matrix(train,2012)
        imp=SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True).fit(tx)
        forest=SparseLeafQRF(500,10,0,n_jobs=4).fit(imp.transform(tx),train['y'].ravel())
        joblib.dump(dict(forest=forest,imputer=imp),path,compress=1)
    with threadpool_limits(limits=2):
        development=score(model,prior.record(read_months(('2023-12',)),forest,imp),1.)
        test=score(model,prior.record(read_months(('2024-02','2024-03')),forest,imp),1.)
    np.testing.assert_allclose(threshold(development),selection['threshold'],rtol=0,atol=1e-12)
    exact=threshold(test)
    reproduction=pd.concat([daily(test,selection['threshold'],'frozen'),daily(test,exact,'exact_fpr')])
    expected=pd.read_csv(original/'evaluation_daily.csv',parse_dates=['origin'])
    keys=['operation','scope','model','farm','origin']
    counts=['events','hits','signed','absolute','quiet','false','hours','all_absolute']
    a=reproduction.sort_values(keys).reset_index(drop=True)
    b=expected.sort_values(keys).reset_index(drop=True)
    pd.testing.assert_frame_equal(a[keys],b[keys],check_dtype=False)
    np.testing.assert_allclose(a[counts],b[counts],rtol=0,atol=1e-12)
    frozen_spec(OUT/'reconstruction_check.json',dict(original_qrf_checkpoint='not saved in original run; deterministically reconstructed from original Sep–Oct training only',
        matches='original Dec threshold and every Feb–Mar daily count/error sum within 1e-12',
        q90_sha256=digest(original/'q90.joblib'),selection_sha256=digest(original/'selection.json')))
    print('FROZEN MODELS VERIFIED against old holdout',flush=True)
    return forest,imp,model,selection['threshold']


def paired(df,block=14):
    columns=prior.COLS if hasattr(prior,'COLS') else ('events','hits','signed','absolute','quiet','false','hours','all_absolute')
    metrics=('recall','bias','mae','quiet_fpr','all_mae')
    from run_gefcom2012_local_increment import rates
    dates=pd.date_range(df.origin.min(),df.origin.max())
    rng=np.random.default_rng(20120516)
    n=len(dates)
    assert n>=block
    starts=rng.integers(0,n-block+1,size=(2000,int(np.ceil(n/block))))
    take=(starts[:,:,None]+np.arange(block)).reshape(2000,-1)[:,:n]
    rows=[]
    for (op,scope),group in df.groupby(['operation','scope']):
        a=np.stack([group[group.model.eq(name)].groupby('origin')[list(columns)].sum()
                    .reindex(dates,fill_value=0).to_numpy() for name in ('original','corrected')])
        simulations=rates(a[:,take].sum(axis=2))
        draws=simulations[1]-simulations[0]
        point=rates(a.sum(axis=1))
        low,high=np.quantile(draws,[.025,.975],axis=0)
        rows.extend(dict(operation=op,scope=scope,block=block,metric=k,delta=d,low=l,high=h)
                    for k,d,l,h in zip(metrics,point[1]-point[0],low,high))
    return pd.DataFrame(rows)


def exact_daily(records, cutoff, folder):
    """Resolve a threshold tie using an outcome-independent fixed random order."""
    frame=daily(records,cutoff,'exact_fpr')
    gated=frame.query("scope=='gated'").groupby('model')['false'].sum()
    if gated['original']==gated['corrected']:
        return frame
    from diagnose_gefcom2012_data_attribution import match_truth
    rng=np.random.default_rng(20261107)
    tie=[rng.random(r['candidate'].shape) for r in records]
    scores=[]
    for r,u in zip(records,tie):
        quiet=r['gate']&(np.abs(r['actual'])<=.05)
        scores.extend(zip(r['candidate'][quiet],u[quiet]))
    ranked=sorted(scores,reverse=True)
    target=int(gated['original'])
    assert 0<target<len(ranked)
    boundary,boundary_tie=ranked[target-1]
    for r,u in zip(records,tie):
        alarm=np.where(r['gate'],(r['candidate']>boundary)|((r['candidate']==boundary)&(u>=boundary_tie)),r['candidate']>.10)
        hit=match_truth(r['actual']>.10,alarm)
        for scope,keep in [('gated',r['gate']),('all',np.ones_like(r['gate']))]:
            select=(frame.model=='corrected')&(frame.scope==scope)&(frame.farm==r['farm'])
            expected=frame.loc[select,'origin'].to_numpy()
            np.testing.assert_array_equal(expected,r['origins'])
            frame.loc[select,'hits']=((r['actual']>.10)&keep&hit).sum(axis=1)
            frame.loc[select,'false']=((np.abs(r['actual'])<=.05)&keep&alarm).sum(axis=1)
    out=frame.query("scope=='gated'").groupby('model')['false'].sum()
    assert out['original']==out['corrected']
    write(folder/'exact_fpr_tie.json',dict(seed=20261107,threshold=boundary,tie_cutoff=boundary_tie,
        matched_false=int(out['original']),purpose='retrospective equal-FPR tie handling; labels choose cutoff only'))
    return frame

def evaluate(name,months,forest,imp,model,frozen):
    d=read_months(months)
    with threadpool_limits(limits=2):
        records=score(model,prior.record(d,forest,imp),1.)
    exact=threshold(records)
    folder=OUT/name
    folder.mkdir(exist_ok=True)
    frame=pd.concat([daily(records,frozen,'frozen'),exact_daily(records,exact,folder)])
    frame.to_csv(folder/'daily.csv',index=False)
    result=summarize(frame)
    result.to_csv(folder/'summary.csv')
    ci=pd.concat([paired(frame,b) for b in (7,14,28)],ignore_index=True)
    ci.to_csv(folder/'paired_blocks.csv',index=False)
    # Record identical future-power clipping and sample exclusions explicitly.
    counts=dict(months=list(months),days=len(d['origins']),issued=d['total_origins'],
                outside_target_hours=d['outside_target_hours'],exact_fpr_threshold=exact)
    write(folder/'sample_counts.json',counts)
    a,b=(result.loc[('exact_fpr','gated',m)] for m in ('original','corrected'))
    fa,fb=(result.loc[('frozen','gated',m)] for m in ('original','corrected'))
    recall_ci=ci.query("block==14 and scope=='gated' and operation=='exact_fpr' and metric=='recall'").iloc[0]
    gates=dict(same_false_count=bool(a['false']==b['false']),recall_gain=bool(b.recall>a.recall),
        recall_ci_positive=bool(recall_ci.low>0),bias_better=bool(abs(b.bias)<abs(a.bias)),
        mae_better=bool(b.mae<a.mae),frozen_quiet_not_higher=bool(fb.quiet_fpr<=fa.quiet_fpr))
    write(folder/'checks.json',gates)
    print(name,counts,flush=True)
    print(result.xs('gated',level='scope')[['events','hits','false','recall','bias','mae','quiet_fpr','all_mae']].round(6).to_string(),flush=True)
    return gates


def main():
    frozen_spec(OUT/'protocol.json',dict(months=list(MONTHS),subsets={k:list(v) for k,v in SUBSETS.items()},
        base='reuse q90 and December alarm threshold; original QRF reconstructed only if original checkpoint missing and must reproduce old daily counts/errors',
        model_selection='none; fixed cap and gate, unchanged previous preprocessing and 24-hour complete-day policy',
        confidence='2000 synchronous calendar-block paired draws;14d primary,7/28 sensitivity; retrospective exact-FPR threshold conditional',
        advance='both new-period and cumulative primary equal-false recall intervals strictly above zero, bias and ramp MAE improve, frozen quiet FPR not higher; quarterly results descriptive'))
    forest,imp,model,frozen=restore()
    for m in MONTHS:
        if not (DATA/m/'completion.json').exists():
            month(m)
    checks={name:evaluate(name,months,forest,imp,model,frozen) for name,months in SUBSETS.items()}
    passed=all(all(checks[k].values()) for k in ('new_apr_dec','cumulative_feb_dec'))
    write(OUT/'completion.json',dict(status='complete',checks=checks,advance_to_upper=passed))
    print('COMPLETE advance',passed,flush=True)


if __name__=='__main__':
    main()

