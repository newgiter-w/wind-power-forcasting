"""Saved-weight replay, independent interval reconstruction and synchronous blocks."""
import json
import time
import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from retraining_common import OUT,METHODS,split_month,split_witness,schedule,folder_for,load_farms,feature_array,local_heads,write,frozen_spec
from revision_common import collect,METRIC_COLS,paired_daily_arrays,OUT as REVISION
from gefcom_protocol_v2 import index
from online_calibration import simulate

GROUPS=['all','ramp','up_ramp','down_ramp','near_zero']


def load_stage(year,farm,method,seed,stage,verify=False):
    d=load_farms(year)[farm];pieces=[];checks=[]
    X=feature_array(year,farm,'GBM') if verify and method!='frozen' else None
    for month in schedule(year,stage):
        folder=folder_for(year,farm,method,seed,month)
        with np.load(folder/'predictions.npz') as z:part={k:z[k] for k in z.files}
        if verify:
            tr,ca,sc=split_month(d,month,method)
            for name,expected in [('train_indices',tr),('seed_indices',ca),('indices',sc),('queries',np.r_[ca,sc])]:np.testing.assert_equal(part[name],expected)
            lo=np.full_like(d['y'],np.nan);hi=lo.copy();lo[part['queries']]=part['query_lo'];hi[part['queries']]=part['query_hi']
            result=simulate(d['origins'],d['ends'],d['y'],lo,hi,d['valid'],ca,sc,'rolling',84)
            np.testing.assert_equal(part['lo'],np.clip(result['lo'],0,1));np.testing.assert_equal(part['hi'],np.clip(result['hi'],0,1))
            for name in ['q_signed','q_used','n_cal']:np.testing.assert_equal(part[name],result[name])
            np.testing.assert_equal(part['max_label_end'],result['max_label_end_used'])
            assert np.all(part['max_label_end']<=d['origins'][sc])
            error=0.
            if method!='frozen':
                bundle=joblib.load(folder/'model.joblib');model=bundle['model'];imputer=bundle['imputer']
                tm=(tr[:,None]*24+np.arange(24)).ravel()
                fresh=SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True).fit(X[tm])
                np.testing.assert_equal(imputer.statistics_,fresh.statistics_);np.testing.assert_equal(imputer.indicator_.features_,fresh.indicator_.features_)
                np.testing.assert_equal(model.sorted_y,np.sort(d['y'][tr].ravel()))
                query=np.array([ca[0],sc[0]]);cells=(query[:,None]*24+np.arange(24)).ravel()
                predicted=model.predict(imputer.transform(X[cells])).reshape(2,24,2)
                expected=np.stack([lo[query],hi[query]],axis=-1)
                error=float(np.abs(predicted-expected).max());np.testing.assert_allclose(predicted,expected,atol=1e-12,rtol=1e-12)
            else:
                a,b=local_heads(year,farm,'QRF',seed)
                np.testing.assert_equal(lo[part['queries']],a[part['queries']]);np.testing.assert_equal(hi[part['queries']],b[part['queries']])
            checks.append(dict(year=year,farm=farm,method=method,seed=seed,month=month,
                train_calibration_disjoint=True,labels_arrived=True,imputer_train_only=True,
                calibration_replayed=True,model_replay_max_error=error,**split_witness(d,tr,ca,sc)))
        pieces.append(part)
    keys=['indices','raw_lo','raw_hi','lo','hi','q_signed','q_used','n_cal','max_label_end']
    combined={k:np.concatenate([a[k] for a in pieces]) for k in keys}
    np.testing.assert_equal(combined['indices'],index(d,stage))
    if verify and method=='frozen':
        path=REVISION/f'qrf/gefcom{year}/farm_{farm:02d}/leaf_10/seed_{seed}/{stage}.npz'
        with np.load(path) as z:
            np.testing.assert_equal(combined['indices'],z['indices'])
            np.testing.assert_allclose(combined['lo'],np.clip(z['lo'],0,1),atol=1e-12,rtol=1e-12)
            np.testing.assert_allclose(combined['hi'],np.clip(z['hi'],0,1),atol=1e-12,rtol=1e-12)
    assert np.isfinite(combined['lo']).all() and np.isfinite(combined['hi']).all()
    assert (combined['lo']<=combined['hi']).all()
    return d,combined,checks


def analyze_development():
    protocol=json.loads((OUT/'protocol.json').read_text());rows=[]
    for farm in load_farms(2014):
        for method in METHODS:
            for seed in protocol['seeds']:
                d,a,_=load_stage(2014,farm,method,seed,'validation')
                collect(rows,d,a['indices'],a['lo'],a['hi'],year=2014,farm=farm,method=method,seed=seed,stage='validation')
    df=pd.DataFrame(rows);df.to_csv(OUT/'validation_per_farm.csv',index=False)
    mean=df.groupby(['method','group'])[METRIC_COLS].mean();mean.to_csv(OUT/'validation_macro.csv')
    base=mean.loc[('frozen','all')];decisions=[]
    for method in METHODS[1:]:
        row=mean.loc[(method,'all')]
        groups=all(mean.loc[(method,g),'coverage']>=mean.loc[('frozen',g),'coverage']-.01 for g in ['near_zero','up_ramp','down_ramp'])
        passed=bool(row.coverage>=max(.9,base.coverage-.005) and row.width<=.97*base.width and row.IS<=base.IS and groups)
        decisions.append(dict(method=method,passed=passed,coverage=float(row.coverage),width=float(row.width),IS=float(row.IS),groups_within_1pp=bool(groups)))
    frozen_spec(OUT/'development_decision.json',dict(source='2014Q2 only, written before evaluation fitting',
        candidates=decisions,prefer=min((a for a in decisions if a['passed']),key=lambda a:a['IS'])['method'] if any(a['passed'] for a in decisions) else 'frozen',
        interpretation='all predeclared arms still evaluated, no hyperparameter or gate revision'))
    print('DEVELOPMENT',decisions,flush=True)


def main():
    start=time.perf_counter();protocol=json.loads((OUT/'protocol.json').read_text());seeds=protocol['seeds']
    assert json.loads((OUT/'training_complete.json').read_text())['status']=='complete'
    rows=[];monthly=[];diagnostics=[];checks=[];boot=[];leadrows=[]
    for year,stage in [(2014,'validation'),(2014,'evaluation'),(2012,'evaluation')]:
        farms=load_farms(year)
        dates=pd.date_range('2013-07-01' if year==2014 else '2011-07-01','2013-12-31' if year==2014 else '2012-06-27').to_numpy()
        daily=np.zeros((3,len(farms),len(dates),len(GROUPS),4))
        for f,farm in enumerate(farms):
            for m,method in enumerate(METHODS):
                for seed in seeds:
                    d,a,witness=load_stage(year,farm,method,seed,stage,verify=True);checks.extend(witness)
                    ids=a['indices'];valid=d['valid'][ids];y=d['y'][ids]
                    for variant,lo,hi in [('raw',np.clip(a['raw_lo'],0,1),np.clip(a['raw_hi'],0,1)),('signed',a['lo'],a['hi'])]:
                        collect(rows,d,ids,lo,hi,year=year,farm=farm,method=method,seed=seed,stage=stage,variant=variant)
                    lowdiff=y-a['raw_lo'];hidiff=y-a['raw_hi']
                    loss=np.maximum(.05*lowdiff,-.95*lowdiff)+np.maximum(.95*hidiff,-.05*hidiff)
                    rawwidth=np.clip(a['raw_hi'],0,1)-np.clip(a['raw_lo'],0,1)
                    diagnostics.append(dict(year=year,farm=farm,method=method,seed=seed,stage=stage,
                        raw_mean_pinball=float(loss[valid].mean()/2),mean_signed_correction=float(a['q_signed'][valid].mean()),
                        negative_correction_fraction=float((a['q_signed'][valid]<0).mean()),
                        raw_clipped_width=float(rawwidth[valid].mean()),final_width=float((a['hi']-a['lo'])[valid].mean()),
                        clipped_width_change=float(((a['hi']-a['lo'])-rawwidth)[valid].mean()),calibration_count_mean=float(a['n_cal'].mean())))
                    monthvalues=d['origins'][ids].astype('datetime64[M]')
                    for month in np.unique(monthvalues):
                        mask=monthvalues==month
                        collect(monthly,d,ids[mask],a['lo'][mask],a['hi'][mask],year=year,farm=farm,method=method,seed=seed,stage=stage,month=str(month))
                    if stage=='evaluation':
                        stats=paired_daily_arrays(d,ids,a['lo'],a['hi']);pos=np.searchsorted(dates,d['origins'][ids]);np.testing.assert_equal(dates[pos],d['origins'][ids])
                        for g,group in enumerate(GROUPS):
                            daily[m,f,pos,g,:]+=np.stack([stats[group+'_n'],stats[group+'_IS'],stats[group+'_coverage'],stats[group+'_width']],axis=1)/len(seeds)
                        for h in range(24):
                            yy=y[valid,h];ll=a['lo'][valid,h];uu=a['hi'][valid,h]
                            leadrows.append(dict(year=year,farm=farm,method=method,seed=seed,lead=h+1,
                                coverage=float(((yy>=ll)&(yy<=uu)).mean()),width=float((uu-ll).mean()),
                                IS=float((uu-ll+20*np.maximum(ll-yy,0)+20*np.maximum(yy-uu,0)).mean())))
                print('VERIFIED',year,stage,farm,method,flush=True)
        if stage=='evaluation':
            np.savez_compressed(OUT/f'daily_{year}.npz',daily=daily,dates=dates)
            def macro(a):
                total=a.sum(axis=2)
                return np.nanmean(np.divide(total[:,:,:,1:],total[:,:,:,0,None],out=np.full(total[:,:,:,1:].shape,np.nan),where=total[:,:,:,0,None]>0),axis=1)
            point=macro(daily);n=len(dates)
            for block in [7,14]:
                rng=np.random.default_rng(20261105+year+block);samples=[]
                for _ in range(2000):
                    begin=rng.integers(0,n-block+1,size=int(np.ceil(n/block)));ix=(begin[:,None]+np.arange(block)).ravel()[:n]
                    samples.append(macro(daily[:,:,ix,:,:]))
                samples=np.stack(samples)
                for m,method in enumerate(METHODS[1:],1):
                    for g,group in enumerate(GROUPS):
                        for k,metric in enumerate(['IS','coverage','width']):
                            delta=samples[:,m,g,k]-samples[:,0,g,k];low,high=np.quantile(delta,[.025,.975]);al,ah=np.quantile(samples[:,m,g,k],[.025,.975])
                            boot.append(dict(year=year,method=method,group=group,metric=metric,block_days=block,
                                frozen=float(point[0,g,k]),refit=float(point[m,g,k]),difference=float(point[m,g,k]-point[0,g,k]),low=float(low),high=float(high),absolute_low=float(al),absolute_high=float(ah)))
    frame=pd.DataFrame(rows);frame.to_csv(OUT/'metrics_per_farm.csv',index=False)
    keys=['year','stage','method','variant','group'];seedmean=frame.groupby(keys+['farm'])[METRIC_COLS].mean().reset_index()
    seedmean.to_csv(OUT/'seed_mean_per_farm.csv',index=False)
    finalmacro=seedmean.groupby(keys)[METRIC_COLS].mean().reset_index()
    preview=OUT/'2014_evaluation_preliminary.csv'
    if preview.exists():
        first=pd.read_csv(preview).set_index(['method','group'])[METRIC_COLS].sort_index()
        last=finalmacro[(finalmacro.year==2014)&(finalmacro.stage=='evaluation')&(finalmacro.variant=='signed')].set_index(['method','group'])[METRIC_COLS].sort_index()
        pd.testing.assert_frame_equal(first,last,check_exact=False,rtol=1e-12,atol=1e-12)
    finalmacro.to_csv(OUT/'metrics_macro.csv',index=False)
    frame.groupby(keys+['seed'])[METRIC_COLS].mean().reset_index().to_csv(OUT/'macro_per_seed.csv',index=False)
    pd.DataFrame(monthly).to_csv(OUT/'monthly_per_farm.csv',index=False)
    pd.DataFrame(monthly).groupby(['year','stage','method','month','group'])[METRIC_COLS].mean().reset_index().to_csv(OUT/'monthly_macro.csv',index=False)
    pd.DataFrame(diagnostics).to_csv(OUT/'raw_calibration_diagnostics.csv',index=False)
    pd.DataFrame(leadrows).to_csv(OUT/'per_lead.csv',index=False)
    pd.DataFrame(boot).to_csv(OUT/'paired_bootstrap.csv',index=False)
    write(OUT/'verification.json',dict(status='passed',monthly_combinations=len(checks),checks=checks,
        all_frozen_arrays_match_original=True,full_refit_training_targets_checked=True,
        all_imputers_refitted_on_proper_training=True,model_replay='first held-out calibration and forecast day, all 24 leads, every refit',
        elapsed_seconds=time.perf_counter()-start))
    print('RETRAINING VERIFIED',len(checks),'monthly combinations',flush=True)


if __name__=='__main__':main()
