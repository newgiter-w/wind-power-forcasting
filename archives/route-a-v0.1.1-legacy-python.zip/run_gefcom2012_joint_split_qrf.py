"""Fit same-input QRF trees with a joint level/increment split target."""
from concurrent.futures import ProcessPoolExecutor
import os

from run_point_residual import ROOT, cells, load_farms, feature_array, index
from revision_common import frozen_spec, write
from sparse_leaf_qrf import SparseLeafQRF, RandomForestRegressor
import numpy as np

OUT = ROOT/'out_gefcom2012_joint_split_qrf'
YEAR = 2012
WEIGHTS = (.25,.50)


def fit(job):
    farm, weight = job
    dest = OUT/f'farm_{farm:02}'
    dest.mkdir(exist_ok=True)
    path = dest/f'heads_{weight}.npz'
    if path.exists():
        print('REUSE',farm,weight,flush=True)
        return
    d = load_farms(YEAR)[farm]
    tr = index(d,'train',True)
    query = np.concatenate([index(d,s) for s in ('validation_seed','validation','evaluation')])
    assert d['ends'][tr].max()<=d['origins'][query].min()
    x = feature_array(YEAR,farm,'QRF')
    y = d['y'][tr]
    change = np.diff(y,axis=1,prepend=d['history'][tr,-1,None])
    target = np.column_stack([y.ravel(),change.ravel()])
    mean,scale = target.mean(axis=0),target.std(axis=0)
    assert (scale>0).all()
    target = (target-mean)/scale
    # Multioutput squared error averages the two variances. sqrt(weight) gives
    # an increment impurity coefficient of weight relative to level.
    target[:,1] *= np.sqrt(weight)
    model = SparseLeafQRF(500,10,0,n_jobs=2)
    train_x = x[cells(tr)]
    model.forest = RandomForestRegressor(n_estimators=500,min_samples_leaf=10,max_features=1.,
        bootstrap=True,random_state=0,n_jobs=2).fit(train_x,target)
    print('TREES',farm,weight,flush=True)
    model.build_responses(train_x,y.ravel())
    np.testing.assert_array_equal(model.sorted_y,np.sort(y.ravel()))
    pred = model.predict(x[cells(query)],(.05,.50,.95)).reshape(-1,24,3)
    assert np.isfinite(pred).all() and (np.diff(pred,axis=2)>=0).all()
    assert (pred>=0).all() and (pred<=1).all()
    tmp = dest/f'pending_{weight}.npz'
    np.savez_compressed(tmp,heads=pred,ids=query,origins=d['origins'][query],train=tr,mean=mean,scale=scale)
    os.replace(tmp,path)
    print('HEADS',farm,weight,flush=True)


def main():
    frozen_spec(OUT/'protocol.json',dict(year=YEAR,farms=list(range(1,8)),base='frozen QRF500 leaf10 seed0',
        inputs='identical imputed R2 array, same proper-training and issuance rows; full bootstrap leaf responses remain power level',
        split_targets='standardized power and hourly change; squared impurity, relative change weight .25 or .50; first lead uses last observed power',
        weights=list(WEIGHTS), selection='2011 Q2, prioritize passing interval+point gates, otherwise predeclared point-ranking diagnostic challenger; no evaluation tuning',
        calibration='same signed rolling84 per farm and lead, complete labels only after arrival',
        gate='same-width up upper miss decreases, overall >=90%, IS<=base, near-zero/down coverage drop <=1pp; same-hour NWP-signal ramp increment MAE improves, ±1h recall not lower, quiet FPR increase <=1pp',
        matching='Q2 calibrated half-width offset frozen; additionally evaluate exact width retrospectively for raw and calibrated; preserve physical boundary on shrinking',
        evaluation='existing 2011H2–2012H1 historical evaluation, one selected weight only'))
    farms = load_farms(YEAR)
    assert list(farms)==list(range(1,8))
    with ProcessPoolExecutor(max_workers=7) as pool:
        list(pool.map(fit,[(farm,w) for w in WEIGHTS for farm in farms]))
    write(OUT/'training_complete.json',dict(farms=7,weights=list(WEIGHTS)))


if __name__=='__main__':
    main()
