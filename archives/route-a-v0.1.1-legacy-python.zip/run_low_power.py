"""Add low-power indicator features to fix near-zero under-coverage.

Appends 4 per-origin features (fraction of last 24h <=0.01/<=0.05, and last-hour
<=0.01/<=0.05 indicators) to the R2 122-dim input, then re-runs BOTH the GBM
(config A) and the DL MLP on 2014. Compares near-zero coverage.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from gefcom2014_experiment import metrics
from gefcom_protocol_v2 import index, prepare, PKG
from online_calibration import simulate
from run_dl_baseline import QuantileMLP, pinball_loss, train_model
from strong_baselines import build_shared

OUT = Path('out_gefcom_revision_20261104/low_power_corrected')
PKG_A = dict(PKG)


def low_power_features(history):
    return np.array([
        float(np.mean(history <= 0.01)),
        float(np.mean(history <= 0.05)),
        float(history[-1] <= 0.01),
        float(history[-1] <= 0.05),
    ])


def extended_X(d):
    X, y, S = build_shared(d, 'R2')
    low = np.array([low_power_features(h) for h in d['history']])
    low_rep = np.repeat(low, 24, axis=0)
    return np.c_[X, low_rep], y, S


def fit_gbm(X, y, tr_unf, q):
    sc = StandardScaler().fit(X[tr_unf]); xs = sc.transform(X)
    m = HistGradientBoostingRegressor(loss='quantile', quantile=q, **PKG_A)
    m.fit(xs[tr_unf], y[tr_unf])
    return m.predict(xs).reshape(-1, 24)


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    began = time.perf_counter()
    farms, _ = prepare(2014)
    rows = []
    for farm, d in farms.items():
        tr = index(d, 'train', True); vseed = index(d, 'validation_seed', True)
        vi = index(d, 'validation'); ei = index(d, 'evaluation')
        tr_unf = np.repeat(np.isin(np.arange(len(d['origins'])), tr), 24)
        vseed_unf = np.repeat(np.isin(np.arange(len(d['origins'])), vseed), 24)
        X_aug, y, S = extended_X(d)
        X_base, _, _ = build_shared(d, 'R2')
        # GBM
        for method in ('GBM_base', 'GBM_aug', 'DL_base', 'DL_aug'):
            X = X_aug if method.endswith('aug') else X_base
            if method.startswith('GBM'):
                lo = fit_gbm(X, y, tr_unf, 0.05)
                hi = fit_gbm(X, y, tr_unf, 0.95)
            else:
                X = np.nan_to_num(X, nan=0.0)
                sc = StandardScaler().fit(X[tr_unf]); xs = sc.transform(X)
                lo_m = train_model(xs[tr_unf], y[tr_unf], xs[vseed_unf], y[vseed_unf], 0.05)
                hi_m = train_model(xs[tr_unf], y[tr_unf], xs[vseed_unf], y[vseed_unf], 0.95)
                with torch.no_grad():
                    Xall = torch.tensor(xs, dtype=torch.float32)
                    lo = lo_m(Xall).numpy().reshape(-1, 24)
                    hi = hi_m(Xall).numpy().reshape(-1, 24)
            q05, q95 = lo, hi
            lo = np.minimum(q05, q95); hi = np.maximum(q05, q95)
            folder = OUT / f'farm_{farm:02d}' / method; folder.mkdir(parents=True)
            np.savez_compressed(folder / 'heads.npz', q05=q05, q95=q95, origins=d['origins'])
            res = simulate(d['origins'], d['ends'], d['y'], lo, hi, d['valid'], vi, ei, 'rolling', 84)
            L = np.clip(res['lo'], 0, 1); U = np.clip(res['hi'], 0, 1)
            np.savez_compressed(folder / 'evaluation.npz', indices=ei, lo=L, hi=U,
                                q_signed=res['q_signed'], max_label_end=res['max_label_end_used'])
            met = metrics(d['y'][ei], L, U, d['valid'][ei], d['history'][ei, -1])
            for g, v in met.items():
                rows.append(dict(farm=farm, method=method, group=g, **v))
        print(f'  farm{farm:02d} done ({time.perf_counter()-began:.0f}s)', flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(OUT / 'eval_per_farm.csv', index=False)
    macro = df.groupby(['method', 'group'])[['coverage', 'width', 'IS', 'lower_miss', 'upper_miss']].mean().reset_index()
    macro.to_csv(OUT / 'eval_macro.csv', index=False)
    print('\n===== +低功率特征 (2014 eval, clipped CQR) =====')
    for g in ('all', 'up_ramp', 'near_zero'):
        line = f'  {g:9s}'
        for m in ('GBM_base', 'GBM_aug', 'DL_base', 'DL_aug'):
            r = macro[(macro.method == m) & (macro.group == g)].iloc[0]
            line += f"  {m}: cov={r['coverage']*100:5.1f}% w={r['width']*100:5.2f}% IS={r['IS']:.4f}"
        print(line)
    print('  Both base and augmented models above were re-fitted with identical missing-value rules.')
    print(f'\n[done] ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
