"""Compare upper-tail gradient-split forest against original QRF."""
import numpy as np
import pandas as pd

from run_gefcom2012_tail_split import OUT, YEAR, BASE, load_farms, index, feature_array
from pooling_common import local_heads
from revision_common import calibration, collect, frozen_spec, write, METRIC_COLS
from report_gefcom2012_dual_batch import adjust, match
from run_qrf_regime_bounds import bootstrap, GROUPS
from gefcom2014_experiment import masks

STAGES = ('validation','evaluation')


def predictions(farm,d):
    lo,hi=local_heads(YEAR,farm,'QRF',0)
    q=hi.copy()
    with np.load(OUT/f'farm_{farm:02}/heads.npz') as z:
        ids=z['ids']
        np.testing.assert_array_equal(ids,np.concatenate([index(d,s) for s in ('validation_seed',*STAGES)]))
        np.testing.assert_array_equal(z['origins'],d['origins'][ids])
        np.testing.assert_array_equal(z['train'],index(d,'train',True))
        q[ids]=z['upper']
    with np.load(BASE/f'gefcom2012/farm_{farm:02}/heads.npz') as z:
        np.testing.assert_array_equal(z['origins'],d['origins'])
        np.testing.assert_array_equal(z['direct_qrf'],[lo,hi])
        floor=np.where(np.isfinite(z['qrf']),z['qrf'],lo)
    projected=int((q[ids]<floor[ids]).sum())
    q[ids]=np.maximum(q[ids],floor[ids])
    return lo,hi,q,projected


def raw_metrics(farms,stage):
    rows, guard=[],[]
    for farm,d in farms.items():
        lo,hi,q,projected=predictions(farm,d)
        guard.append(dict(farm=farm,projected=projected))
        ids=index(d,stage)
        y=d['y'][ids]
        gm=masks(y,d['history'][ids,-1])
        speed=np.linalg.norm(feature_array(YEAR,farm,'GBM')[:,-14:-12].reshape(-1,24,2)[ids],axis=-1)
        dw=np.diff(speed,axis=1,prepend=np.full((len(ids),1),np.nan))
        gm['same_signal']=gm['up_ramp']&(dw>=.5)
        for name,u in [('original',hi),('tail_split',q)]:
            for group,mask in gm.items():
                use=mask&d['valid'][ids,None]
                err=(y-u[ids])[use]
                over=np.maximum(err,0)
                rows.append(dict(farm=farm,model=name,group=group,n=len(err),
                    pinball=float((.95*over+.05*np.maximum(-err,0)).mean()),
                    upper_miss=float((err>0).mean()),mean_exceedance=float(over.mean())))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{stage}_raw_per_farm.csv',index=False)
    macro=frame.groupby(['model','group'])[['pinball','upper_miss','mean_exceedance']].mean()
    macro.to_csv(OUT/f'{stage}_raw_macro.csv')
    pd.DataFrame(guard).to_csv(OUT/'head_projection_counts.csv',index=False)
    return macro


def raw_gate(m):
    a,b=(m.loc[k] for k in ('original','tail_split'))
    return dict(pinball=bool(b.loc['all','pinball']<=a.loc['all','pinball']),
        ramp_upper_miss=bool(b.loc['up_ramp','upper_miss']<a.loc['up_ramp','upper_miss']),
        ramp_exceedance=bool(b.loc['up_ramp','mean_exceedance']<=a.loc['up_ramp','mean_exceedance']))


def replay(farms,stage):
    pairs=[]
    for farm,d in farms.items():
        lo,hi,q,_=predictions(farm,d)
        ids,a=calibration(d,lo,hi,stage)
        _,b=calibration(d,lo,q,stage)
        for key in ('max_label_end_used','n_cal'):
            np.testing.assert_array_equal(a[key],b[key])
        ref=np.clip([a['lo'],a['hi']],0,1)
        with np.load(BASE/f'gefcom2012/farm_{farm:02}/{stage}_direct_qrf.npz') as z:
            np.testing.assert_array_equal(ids,z['ids'])
            np.testing.assert_array_equal(ref,[z['lo'],z['hi']])
        pairs.append((farm,d,ids,np.ones(len(ids),dtype=bool),ref,np.clip([b['lo'],b['hi']],0,1)))
    return pairs


def calibrated(pairs,stage,frozen=None):
    offset=match(pairs,'full')
    ops={'nominal':0.,'exact_width':offset}
    if frozen is not None:
        ops['frozen_width']=frozen
    rows,ci=[],[]
    for op,shift in ops.items():
        daily={}
        for farm,d,ids,mask,ref,candidate in pairs:
            for name,(lo,hi) in [('original',ref),('tail_split',adjust(candidate,mask,shift))]:
                collect(rows,d,ids,lo,hi,farm=farm,model=name,operation=op)
                y=d['y'][ids]
                w=hi-lo
                values=[w,(y>=lo)&(y<=hi),w+20*np.maximum(lo-y,0)+20*np.maximum(y-hi,0),y>hi]
                for group,g in masks(y,d['history'][ids,-1]).items():
                    if group not in GROUPS:
                        continue
                    use=g&d['valid'][ids,None]
                    daily[name,farm,group]=(d['origins'][ids],np.column_stack(
                        [use.sum(axis=1)]+[np.where(use,v,0).sum(axis=1) for v in values]))
        if stage=='evaluation':
            ci.extend(dict(operation=op,**r) for r in bootstrap(YEAR,daily,'tail_split'))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{stage}_calibrated_per_farm.csv',index=False)
    macro=frame.groupby(['operation','model','group'])[METRIC_COLS].mean()
    macro.to_csv(OUT/f'{stage}_calibrated_macro.csv')
    if ci:
        pd.DataFrame(ci).to_csv(OUT/'evaluation_paired_blocks.csv',index=False)
    return macro,offset


def checks(m,mode):
    a,b=(m.loc[(mode,k)] for k in ('original','tail_split'))
    return dict(up=bool(b.loc['up_ramp','upper_miss']<a.loc['up_ramp','upper_miss']),
        coverage=bool(b.loc['all','coverage']>=.90),IS=bool(b.loc['all','IS']<=a.loc['all','IS']),
        near=bool(b.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
        down=bool(b.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01))


def main():
    farms=load_farms(YEAR)
    raw=raw_metrics(farms,'validation')
    gates=raw_gate(raw)
    print(raw.to_string(),flush=True)
    print('RAW GATE',gates,flush=True)
    if not all(gates.values()):
        frozen_spec(OUT/'selection.json',dict(raw=gates,advance=False))
        write(OUT/'completion.json',dict(status='complete',decision='stop_at_raw_development'))
        return
    dev,offset=calibrated(replay(farms,'validation'),'validation')
    dev_checks=checks(dev,'exact_width')
    frozen_spec(OUT/'selection.json',dict(raw=gates,advance=True,dev_calibrated=dev_checks,frozen_offset=offset))
    raw_metrics(farms,'evaluation')
    ev,actual=calibrated(replay(farms,'evaluation'),'evaluation',offset)
    write(OUT/'completion.json',dict(status='complete',decision='evaluated',dev_calibrated=dev_checks,
        evaluation={op:checks(ev,op) for op in ('frozen_width','exact_width')},retrospective_offset=actual))
    print(ev.to_string(),flush=True)


if __name__=='__main__':
    main()
