"""NWP-conditioned residual diffusion trained on ALL 10 GEFCom2014 farms.

Pool all farms' 2012 data + a farm-id one-hot. Shared anchor + shared denoiser.
Legacy pooled runner. Compare velocity loss to its measured zero predictor,
not to a universal threshold of 1. Use run_revision_diffusion.py for controls.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler

from gefcom2014_experiment import metrics
from gefcom_protocol_v2 import index, prepare
from online_calibration import simulate
from retrieval_diffusion import HistoryAnchor, ResidualDenoiser, VelocityDiffusion
from run_diffusion_nwp import build_anchor_features

OUT = Path('out_gefcom_revision_20261104/legacy_multi_diagnostic')


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    began = time.perf_counter()
    farms, _ = prepare(2014)
    # ---- pool features + per-farm normalization + farm-id ----
    X_list, yn_list, y_list, fid_list, farm_list = [], [], [], [], []
    tr_mask_list, stop_mask_list, vi_list, ei_list = [], [], [], []
    for farm, d in farms.items():
        tr = index(d, 'train', True); stop = index(d, 'validation_seed', True)
        vi = index(d, 'validation'); ei = index(d, 'evaluation')
        X = build_anchor_features(d)  # (S, 96)
        y = d['y'].astype('float32')
        ymu = float(y[tr].mean()); ysd = float(y[tr].std())
        yn = ((y - ymu) / ysd).astype('float32')
        fid = np.zeros((len(y), 10), dtype='float32'); fid[:, farm - 1] = 1.0
        X_list.append(X); yn_list.append(yn); y_list.append(y)
        fid_list.append(fid)
        farm_list.extend([farm] * len(y))
        tr_mask_list.append(np.isin(np.arange(len(y)), tr))
        stop_mask_list.append(np.isin(np.arange(len(y)), stop))
        vi_list.append(vi); ei_list.append(ei)
    X = np.concatenate(X_list); yn = np.concatenate(yn_list); y = np.concatenate(y_list)
    fid = np.concatenate(fid_list)
    tr_mask = np.concatenate(tr_mask_list); stop_mask = np.concatenate(stop_mask_list)
    farm_arr = np.array(farm_list)
    print(f'pooled: {len(X)} origins, train={int(tr_mask.sum())}, stop={int(stop_mask.sum())}')

    # scale the 96-dim features (not farm-id)
    sc = StandardScaler().fit(X[tr_mask])
    xs = np.hstack([sc.transform(X), fid]).astype('float32')
    nwp_ctx = X[:, 24:]  # (N,72) future wind

    # ---- anchor ----
    torch.manual_seed(0)
    anchor = HistoryAnchor(xs.shape[1])
    opt = torch.optim.AdamW(anchor.parameters(), lr=1e-3, weight_decay=1e-4)
    xt = torch.from_numpy(xs); yt = torch.from_numpy(yn)
    best = float('inf'); wait = 0
    for epoch in range(180):
        anchor.train()
        perm = torch.randperm(int(tr_mask.sum()))
        tr_idx = torch.nonzero(torch.from_numpy(tr_mask)).squeeze(1)
        for ids in tr_idx[perm].split(256):
            opt.zero_grad()
            mu, _ = anchor(xt[ids])
            loss = (mu - yt[ids]).square().mean()
            loss.backward(); nn.utils.clip_grad_norm_(anchor.parameters(), 1); opt.step()
        anchor.eval()
        with torch.no_grad():
            val = (anchor(xt[stop_mask])[0] - yt[stop_mask]).square().mean().item()
        if val < best - 1e-6:
            best = val; wait = 0; best_state = {k: v.clone() for k, v in anchor.state_dict().items()}
        else:
            wait += 1
            if wait >= 25:
                break
        if (epoch + 1) % 40 == 0:
            print(f'  anchor ep{epoch+1} stop_mse={val:.4f}', flush=True)
    anchor.load_state_dict(best_state); anchor.eval()
    with torch.no_grad():
        mu, latent = anchor(xt)
    mu = mu.numpy(); latent = latent.numpy()
    residual = yn - mu
    scale = residual[tr_mask].std(axis=0).clip(min=0.1)
    clean = (residual / scale).astype('float32')
    print(f'anchor best_stop_mse={best:.4f} ({time.perf_counter()-began:.0f}s)', flush=True)

    # ---- diffusion ----
    ctx = np.hstack([latent, mu, nwp_ctx, fid]).astype('float32')  # 64+24+72+10=170
    context = torch.from_numpy(ctx); clean_t = torch.from_numpy(clean)
    torch.manual_seed(0)
    denoiser = ResidualDenoiser(context=ctx.shape[1], width=192, blocks=4, dropout=0.1)
    diffusion = VelocityDiffusion()
    opt = torch.optim.AdamW(denoiser.parameters(), lr=3e-4, weight_decay=3e-4)
    vg = torch.Generator().manual_seed(9821)
    val_idx = torch.nonzero(torch.from_numpy(stop_mask)).squeeze(1)
    val_ids = val_idx.repeat(4)
    vs = torch.randint(1000, (len(val_ids),), generator=vg)
    vn = torch.randn((len(val_ids), 24), generator=vg)
    vz, vtarget = diffusion.noisy(clean_t[val_ids], vs, vn)
    zero_v_mse = vtarget.square().mean().item()
    best = float('inf'); wait = 0; dtrace = []
    for epoch in range(300):
        denoiser.train()
        train_total = 0.; train_count = 0
        tr_idx = torch.nonzero(torch.from_numpy(tr_mask)).squeeze(1)
        perm = torch.randperm(len(tr_idx))
        for ids in tr_idx[perm].split(256):
            opt.zero_grad()
            loss = diffusion.loss(denoiser, clean_t[ids], context[ids])
            loss.backward(); nn.utils.clip_grad_norm_(denoiser.parameters(), 1); opt.step()
            train_total += loss.item() * len(ids); train_count += len(ids)
        denoiser.eval()
        with torch.no_grad():
            val = (denoiser(vz, vs, context[val_ids]) - vtarget).square().mean().item()
        dtrace.append({'epoch': epoch + 1, 'train_epoch_v_mse': train_total/train_count,
                       'stop_v_mse': val, 'zero_v_mse': zero_v_mse, 'skill': 1-val/zero_v_mse})
        if val < best - 1e-6:
            best = val; wait = 0; best_state = {k: v.clone() for k, v in denoiser.state_dict().items()}
        else:
            wait += 1
            if epoch >= 49 and wait >= 40:
                break
        if (epoch + 1) % 50 == 0:
            print(f'  diff ep{epoch+1} train={loss.item():.4f} stop={val:.4f}', flush=True)
    denoiser.load_state_dict(best_state); denoiser.eval()
    import json
    (OUT / 'diffusion_curve.json').write_text(json.dumps(dtrace), encoding='utf-8')
    torch.save(dict(anchor=anchor.state_dict(), denoiser=denoiser.state_dict()), OUT / 'models.pt')
    np.savez_compressed(OUT / 'anchor_residuals.npz', residual=residual, scale=scale, mu=mu,
                       farm=farm_arr, train_mask=tr_mask, stop_mask=stop_mask)
    print(f'actual_zero_v_mse={zero_v_mse:.4f}, relative_skill={1-best/zero_v_mse:.4f}', flush=True)
    print(f'diffusion best_stop_mse={best:.4f} n_iter={len(dtrace)} ({time.perf_counter()-began:.0f}s)', flush=True)

    # ---- sample + evaluate per farm ----
    sampled = diffusion.sample(denoiser, context, samples=200, steps=40, seed=8101)  # (N,200,24)
    print(f'\n===== Diffusion multi-farm (2014 eval, clipped CQR) =====')
    rows = []
    for farm, d in farms.items():
        ei = index(d, 'evaluation'); vi = index(d, 'validation')
        f = farm_arr == farm
        # un-normalize this farm's samples using its own ymu/ysd
        tr = index(d, 'train', True)
        ymu = float(d['y'][tr].mean()); ysd = float(d['y'][tr].std())
        s_farm = (mu[f, None, :] + sampled[f] * scale[None, None, :]) * ysd + ymu
        lo = np.quantile(s_farm, 0.05, axis=1); hi = np.quantile(s_farm, 0.95, axis=1)
        q05, q95 = lo, hi
        lo = np.minimum(q05, q95); hi = np.maximum(q05, q95)
        res = simulate(d['origins'], d['ends'], d['y'], lo, hi, d['valid'], vi, ei, 'rolling', 84)
        L = np.clip(res['lo'], 0, 1); U = np.clip(res['hi'], 0, 1)
        met = metrics(d['y'][ei], L, U, d['valid'][ei], d['history'][ei, -1])
        for g, v in met.items():
            rows.append(dict(farm=farm, group=g, **v))
    import pandas as pd
    df = pd.DataFrame(rows); df.to_csv(OUT / 'eval_per_farm.csv', index=False)
    macro = df.groupby('group')[['coverage', 'width', 'IS', 'lower_miss', 'upper_miss']].mean().reset_index()
    macro.to_csv(OUT / 'eval_macro.csv', index=False)
    for g in ('all', 'up_ramp', 'down_ramp', 'near_zero'):
        r = macro[macro.group == g].iloc[0]
        print(f"  {g:9s}: cov={r['coverage']*100:5.1f}% w={r['width']*100:5.2f}% IS={r['IS']:.4f}")
    print('  Compare only with matched farms/dates from factorial v2; no single-farm/macro comparison.')
    print(f'\n[done] ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    main()
