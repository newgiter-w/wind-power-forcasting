"""Describe existing source/target predictions; no local model fitting."""
from pathlib import Path
import numpy as np
from sklearn.metrics import brier_score_loss,roc_auc_score,average_precision_score
from revision_common import write

ROOT=Path(__file__).resolve().parent
EXP=ROOT/'out_kelmarsh_nwp_context_factorial'
OUT=EXP/'transfer_diagnosis'


def main():
    result={}
    for name,path in [('Kelmarsh_dev',EXP/'expanded_development'/'scores.npz'),
                      ('Hill_holdout',EXP/'independent_hill_of_towie'/'scores.npz')]:
        z=np.load(path);truth=z['actual'];error=z['base']-truth
        # Both increment trajectories share the same observed issue-time anchor.
        level_error=np.cumsum(error,axis=1)
        use=z['eligible'];y=(truth[use]>.1).astype(int)
        d=dict(days=len(truth),QRF_power_MAE_pp=float(abs(level_error).mean()*100),
            QRF_power_bias_pp=float(level_error.mean()*100),QRF_increment_MAE_pp=float(abs(error).mean()*100),
            event_prevalence_leads2_24=float(y.mean()))
        for field in ('point','context'):
            p=z[field][use]
            d[field]=dict(mean_probability=float(p.mean()),Brier=float(brier_score_loss(y,p)),
                AUC=float(roc_auc_score(y,p)),AP=float(average_precision_score(y,p)))
        result[name]=d
    write(OUT/'existing_prediction_diagnostics.json',result)
    lines=['# 零样本权重迁移与方法复现的区分｜2026-11-07','',
        '本次只读分析，不重训，不读取2026独立候选目标。上轮失败的范围是整条Kelmarsh权重及阈值零样本迁移，不能升级为本地训练后的2×2方法无效。','',
        '| 范围 | QRF功率MAE pp | QRF功率偏差pp | h2–24正例率 | 单时刻平均概率 | 轨迹平均概率 | 单时刻AUC | 轨迹AUC |',
        '|---|---:|---:|---:|---:|---:|---:|---:|']
    for name,d in result.items():
        lines.append(f'| {name} | {d["QRF_power_MAE_pp"]:.2f} | {d["QRF_power_bias_pp"]:.2f} | {100*d["event_prevalence_leads2_24"]:.2f}% | {100*d["point"]["mean_probability"]:.2f}% | {100*d["context"]["mean_probability"]:.2f}% | {d["point"]["AUC"]:.4f} | {d["context"]["AUC"]:.4f} |')
    lines.extend(['',
        '功率误差由同锚点增幅误差累计恢复，等于QRF中位数功率减实测功率；未按预测最大值归一化。两组站点、年份、天气和完整样本分布都不同，上述差异是描述性证据，不是迁移造成误差的因果估计。AP在不同正例率下也不能直接当作跨站可比提升量。',
        '源QRF输出增幅、功率水平和中位数是分类器输入，因此基础QRF迁移偏差会传到概率分支。按装机容量归一化不能统一不同机型、轮毂高度、地形及运行状态下的风功率响应。',
        '同时，新站轨迹模型AUC仍略优于单时刻模型，说明总体排序未完全失去信息；但它未转化为当前低误报预算下的±1h命中净收益。事后同误报仍未通过，排除了“仅调阈值就能完整修复”的解释。','',
        '## 建议：本地训练复现与权重来源对照（尚未执行）','',
        '| 路径 | QRF来源 | 分类器训练数据 | 目的 |','|---|---|---|---|',
        '| S0 | Kelmarsh | Kelmarsh | 源权重对照；与原零样本实验分开记录阈值本地化 |',
        '| S1 | Kelmarsh | 新站历史；特征由该冻结源QRF产生 | 观察概率分支本地化能否恢复收益 |',
        '| S2 | 新站 | 新站历史；特征由该冻结本地QRF产生 | 测试同一方法在新站本地训练后能否复现 |','',
        '每条路径内完整比较A/B/C/D，统一训练小时池、同小时标签、树配置、同一评价样本和误报预算。比较各路径内部D−A及特征/门控效应，不能只比较S2-D和S0-D绝对命中。原站外失败的冻结权重结果保留，不在看过2025后改写原评价。',
        '建议时间顺序：QRF proper training2022–2023；概率/q90分支训练2024；已查看2025作为开发和阈值期；新2026-01至04作为尚未评分的前向留出。所有分类训练特征必须来自不包含该标签的冻结QRF，或严格前向OOF；禁止QRF训练内拟合预测充当泛化残差。',
        '正式权重来源对照尽量匹配源/目标训练年份、长度、样本数及模型配置；否则S2相对S0只能说明本地训练整条策略更好，不能将差异全部归为站点适配。S1与S2也必须各自重训兼容的分类器，不能把本地QRF直接插入只见过源QRF输出的分类器后归因为QRF好坏。',
        '所有路径均只在同一新站开发段定报警阈值，以区分权重迁移和阈值迁移；原源阈值另列冻结参照。评价期同误报匹配仍只作排序诊断。',
        '2025已用，不能恢复独立身份。2026官方数据仅覆盖1–4月，且存在Dynamic Yaw控制试验；应在读取评价目标前固定全样本及控制状态分层规则，不按效果删时段。该留出也不足以独立确认全年四季稳定性。',
        '若S2内D−A在新留出有稳定收益，支持本地训练后的方法复现；若只有本地QRF使A和D都提高而D−A不提高，支持基础模型本地化而非轨迹机制；S2仍无增益才更直接削弱该方法在这个站点的效果，仍不能否定所有模型或数据集。',''])
    (OUT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print('TRANSFER DIAGNOSIS WRITTEN; no model fitting')


if __name__=='__main__':main()
