"""Repair the fixed V3 controls, then run the single predeclared X01 backtest.

No search, no confirmation-year access. Completed task artifacts are reused.
Launch with OMP/MKL/OPENBLAS thread counts set before importing NumPy.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import shutil
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_info, threadpool_limits

import baselines as bm
import evaluate as ev
import intervals as iv
from config import default_config
from data import build_situations, load_dataframe
from experiment import PACKAGES, analog_quantiles, build_features, neighbor_stats, run_task
from retrieval import Retriever

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out_v3"
B, R = "NH_H0", "R0_dtw_H1"
CONF = .9
FOLDS = {
    "repair": {"M": ("2018-01-01", "2019-01-01"),
               "T": ("2019-01-01", "2021-01-01"),
               "Cal": ("2021-01-01", "2021-04-01"),
               "Score": ("2021-04-01", "2021-07-01")},
    "x01": {"M": ("2018-01-01", "2019-01-01"),
            "T": ("2019-01-01", "2020-01-01"),
            "Cal": ("2020-01-01", "2020-04-01"),
            "Score": ("2020-04-01", "2020-07-01")},
}
spec = importlib.util.spec_from_file_location("kelmarsh_inference", ROOT / "statistics.py")
inference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inference)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def cfg_for(distance="dtw"):
    return default_config(points_per_day=144, stride_points=144, horizon_days=1, condition_days=1,
                          horizon_bins=24, analog_bins=24, top_k=20, nn_candidates=40, dtw_band=12,
                          kelmarsh_root=r"D:\Study\wind_datasets\kelmarsh",
                          kelmarsh_cache=r"D:\Study\wind_datasets\kelmarsh\farm_cache_2018_2022.csv",
                          weather_cols=["wind_speed", "wind_dir_sin", "wind_dir_cos", "temperature"],
                          capacity=12300., use_dtw=distance == "dtw")


def fold_indices(d, name, directory):
    dates = d["origin_ts"]
    indices, rows, excluded = {}, [], []
    previous_end = None
    for phase, (start, end) in FOLDS[name].items():
        eligible = (dates >= start) & (dates < end)
        idx = np.flatnonzero(eligible & d["target_valid"])
        if not len(idx):
            raise ValueError(f"Empty segment {name}/{phase}")
        if previous_end is not None and previous_end > dates.iloc[idx[0]]:
            raise ValueError(f"Label arrival violation at {name}/{phase}")
        previous_end = d["target_end_ts"].iloc[idx].max()
        for key in ("cond", "feat", "target"):
            if not np.isfinite(d[key][idx]).all():
                raise ValueError(f"Invalid retained {key} in {name}/{phase}")
        indices[phase] = idx
        for i in idx:
            rows.append({"phase": phase, "global_index": int(i), "origin": str(dates.iloc[i]),
                         "target_start": str(d["target_start_ts"].iloc[i]),
                         "target_end": str(d["target_end_ts"].iloc[i]), "timezone": "UTC"})
        for i in np.flatnonzero(eligible & ~d["target_valid"]):
            excluded.append({"phase": phase, "global_index": int(i), "origin": str(dates.iloc[i]),
                             "reason": "incomplete_144_point_observed_target"})
    directory.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(directory / "split_manifest.csv", index=False)
    pd.DataFrame(excluded).to_csv(directory / "exclusions.csv", index=False)
    return indices


class NeighborCache:
    def __init__(self, d, memory, queries, distance, directory):
        self.d, self.memory, self.queries = d, memory, np.sort(queries)
        self.lookup = {int(v): i for i, v in enumerate(self.queries)}
        self.path = directory / f"neighbors_{distance}.npz"
        if self.path.exists():
            with np.load(self.path) as stored:
                for key, expected in (("memory", memory), ("queries", self.queries),
                                      ("memory_cond", d["cond"][memory]),
                                      ("memory_feat", d["feat"][memory]),
                                      ("memory_targets", d["target"][memory]),
                                      ("query_cond", d["cond"][self.queries]),
                                      ("query_feat", d["feat"][self.queries])):
                    if not np.array_equal(stored[key], expected):
                        raise ValueError(f"Neighbor cache mismatch: {key}")
                self.local = stored["local"]
                self.distances = stored["distances"]
                self.query_seconds = stored["query_seconds"]
                self.bank_seconds = float(stored["bank_seconds"])
            print(f"[cache] loaded {distance}: {len(self.queries)} queries", flush=True)
        else:
            began = time.perf_counter()
            ret = Retriever(d["cond"][memory], d["feat"][memory], d["target"][memory], memory,
                            cfg_for(distance))
            self.bank_seconds = time.perf_counter() - began
            local, distances, seconds = [], [], []
            for count, idx in enumerate(self.queries, 1):
                began = time.perf_counter()
                ids, dist, _ = ret.query(d["cond"][idx], d["feat"][idx], top_k=20)
                seconds.append(time.perf_counter() - began)
                local.append(ids); distances.append(dist)
                if count % 25 == 0 or count == len(self.queries):
                    elapsed = sum(seconds)
                    print(f"[retrieve {distance}] {count}/{len(self.queries)} elapsed={elapsed:.1f}s "
                          f"estimated_remaining={elapsed/count*(len(self.queries)-count):.1f}s", flush=True)
            self.local, self.distances = np.asarray(local), np.asarray(distances)
            self.query_seconds = np.asarray(seconds)
            np.savez_compressed(self.path, memory=memory, queries=self.queries,
                                memory_cond=d["cond"][memory], memory_feat=d["feat"][memory],
                                memory_targets=d["target"][memory], query_cond=d["cond"][self.queries],
                                query_feat=d["feat"][self.queries], local=self.local,
                                distances=self.distances, query_seconds=self.query_seconds,
                                bank_seconds=self.bank_seconds)

    def get(self, indices):
        rows = np.array([self.lookup[int(i)] for i in indices])
        local, distance = self.local[rows], self.distances[rows]
        targets = self.d["target"][self.memory][local]
        mean, top1, std, q10, q90 = neighbor_stats(targets, distance)
        return {"mean": mean, "top1": top1, "std": std, "q10": q10, "q90": q90,
                "targets": targets, "local": local, "global": self.memory[local],
                "distances": distance}

    def accounted_seconds(self, indices):
        return self.bank_seconds + float(sum(self.query_seconds[self.lookup[int(i)]] for i in indices))


def export_predictions(directory, d, idx, result):
    with np.load(directory / "predictions.npz") as arrays:
        h = d["target"].shape[1]
        lead = np.tile(np.arange(1, h + 1), len(idx["Score"]))
        origin = np.repeat(d["origin_ts"].iloc[idx["Score"]].astype(str).values, h)
        block_start = (np.repeat(d["target_start_ts"].iloc[idx["Score"]].values, h)
                       + np.tile(np.arange(h) * np.timedelta64(60, "m"), len(idx["Score"])))
        raw_values = ev.interval_score_values(arrays["y_score"], arrays["lo_score"], arrays["hi_score"], .1) / 12300.
        final_values = ev.interval_score_values(arrays["y_score"], arrays["lo_cqr"], arrays["hi_cqr"], .1) / 12300.
        ramp = ev.ramp_mask(arrays["y_score"], 12300., .1,
                            prev=d["cond"][idx["Score"], -6:].mean(axis=1))
        pd.DataFrame({"origin": origin, "timezone": "UTC", "lead_block": lead,
                      "target_block_start": block_start,
                      "target_block_end": block_start + np.timedelta64(50, "m"),
                      "target_valid": True, "y": arrays["y_score"].ravel(),
                      "q_lower_original": arrays["lo_raw_score"].ravel(),
                      "q_upper_original": arrays["hi_raw_score"].ravel(),
                      "lo_ordered": arrays["lo_score"].ravel(), "hi_ordered": arrays["hi_score"].ravel(),
                      "q_signed": np.tile(arrays["q_signed"], len(idx["Score"])),
                      "lo_cqr": arrays["lo_cqr"].ravel(), "hi_cqr": arrays["hi_cqr"].ravel(),
                      "raw_IS": raw_values.ravel(), "cqr_IS": final_values.ravel(),
                      "ramp": ramp.ravel()}).to_csv(directory / "forecasts.csv", index=False)
        pd.DataFrame({"origin": np.repeat(d["origin_ts"].iloc[idx["Cal"]].astype(str).values, h),
                      "lead_block": np.tile(np.arange(1, h + 1), len(idx["Cal"])),
                      "y": arrays["y_cal"].ravel(), "lo": arrays["lo_cal"].ravel(),
                      "hi": arrays["hi_cal"].ravel(),
                      "signed_score": np.maximum(arrays["lo_cal"]-arrays["y_cal"],
                                                   arrays["y_cal"]-arrays["hi_cal"]).ravel()
                      }).to_csv(directory / "calibration.csv", index=False)
        result["regimes"] = {phase: ev.evaluate_intervals(
            arrays["y_score"], arrays["lo_cqr"], arrays["hi_cqr"], 12300., .1, mask)
            for phase, mask in (("ramp", ramp), ("non_ramp", ~ramp))}
        result["monthly"] = {}
        months = d["origin_ts"].iloc[idx["Score"]].dt.month.to_numpy()
        for month in np.unique(months):
            m = months == month
            result["monthly"][str(month)] = {"origins": int(m.sum()), **ev.evaluate_intervals(
                arrays["y_score"][m], arrays["lo_cqr"][m], arrays["hi_cqr"][m], 12300., .1)}
    pd.DataFrame({"origin": result["origin_ids"], "raw_IS": result["raw_per_origin"],
                  "cqr_IS": result["cqr_per_origin"]}).to_csv(directory / "per_origin.csv", index=False)


def train_one(name, rep, pkg_name, d, idx, neighbors, directory, random_seed=None):
    task_dir = directory / "tasks" / name
    expected_spec = {"task": name, "representation": rep, "package": PACKAGES[pkg_name],
                     "model_seed": 0, "random_neighbor_seed": random_seed,
                     "confidence": CONF, "retrieval": {"k": 20, "distance": "dtw", "shortlist": 40, "band": 12},
                     "origins_by_phase": {k: d["origin_ts"].iloc[v].astype(str).tolist() for k,v in idx.items()}}
    if (task_dir / "result.json").exists():
        if json.loads((task_dir / "effective_spec.json").read_text(encoding="utf-8")) != expected_spec:
            raise ValueError(f"Completed task spec changed: {name}")
        print(f"[resume] {directory.name}/{name}", flush=True)
        return json.loads((task_dir / "result.json").read_text(encoding="utf-8"))
    task_dir.mkdir(parents=True, exist_ok=True)
    write_json(task_dir / "effective_spec.json", expected_spec)
    rng = np.random.default_rng(random_seed)
    features = {}
    began = time.perf_counter()
    for phase in ("T", "Cal", "Score"):
        nr = neighbors.get(phase)
        if random_seed is not None:
            local = np.array([rng.choice(len(idx["M"]), size=20, replace=False) for _ in idx[phase]])
            targets = d["target"][idx["M"]][local]
            mean, top1, std, q10, q90 = neighbor_stats(targets, nr["distances"])
            nr = {"mean": mean, "top1": top1, "std": std, "q10": q10, "q90": q90,
                  "global": idx["M"][local], "distances": nr["distances"]}
        features[phase] = build_features(rep, d["feat"][idx[phase]], d["cond"][idx[phase]], nr)
        if nr is not None and rep not in ("N0", "NH"):
            np.savez_compressed(task_dir / f"neighbors_{phase}.npz", query_indices=idx[phase],
                                global_neighbor_indices=nr["global"], distances=nr["distances"],
                                weights=(1/(nr["distances"]+1e-6)) /
                                        (1/(nr["distances"]+1e-6)).sum(axis=1, keepdims=True))
    scaler = StandardScaler().fit(features["T"])
    joblib.dump(scaler, task_dir / "scaler.joblib")
    np.savez_compressed(task_dir / "inputs.npz", X_T=features["T"], X_Cal=features["Cal"],
                        X_Score=features["Score"], y_T=d["target"][idx["T"]],
                        train_indices=idx["T"], cal_indices=idx["Cal"], score_indices=idx["Score"])
    feature_seconds = time.perf_counter() - began
    print(f"[train] {directory.name}/{name} T={len(idx['T'])} Cal={len(idx['Cal'])} "
          f"Score={len(idx['Score'])} features={features['T'].shape[1]}", flush=True)
    result = run_task(scaler.transform(features["T"]), d["target"][idx["T"]],
                      scaler.transform(features["Cal"]), d["target"][idx["Cal"]],
                      scaler.transform(features["Score"]), d["target"][idx["Score"]],
                      12300., CONF, PACKAGES[pkg_name], 0, artifact_dir=task_dir)
    result["origin_ids"] = d["origin_ts"].iloc[idx["Score"]].astype(str).tolist()
    result["origin_identity_source"] = "saved_at_prediction_time"
    result["random_neighbor_seed"] = random_seed
    result["feature_persist_seconds"] = feature_seconds
    export_predictions(task_dir, d, idx, result)
    write_json(task_dir / "result.json", result)
    print(f"[done] {name} IS={result['cqr']['score']:.6f} coverage={result['cqr']['coverage']:.4%} "
          f"fit={result['fit_seconds']:.1f}s", flush=True)
    return result


def analog_one(distance, d, idx, cache, directory):
    task_dir = directory / "baselines" / f"analog_{distance}"
    if (task_dir / "result.json").exists():
        return json.loads((task_dir / "result.json").read_text(encoding="utf-8"))
    task_dir.mkdir(parents=True, exist_ok=True)
    began = time.perf_counter()
    cal, score = cache.get(idx["Cal"]), cache.get(idx["Score"])
    lc, hc = analog_quantiles(cal["targets"], CONF)
    ls, hs = analog_quantiles(score["targets"], CONF)
    yc, ys = d["target"][idx["Cal"]], d["target"][idx["Score"]]
    q = iv.fit_cqr(yc, lc, hc, CONF)
    lower, upper = ls-q, hs+q
    np.savez_compressed(task_dir / "predictions.npz", y_cal=yc, y_score=ys,
                        lo_raw_cal=lc, hi_raw_cal=hc, lo_raw_score=ls, hi_raw_score=hs,
                        lo_cal=lc, hi_cal=hc, lo_score=ls, hi_score=hs,
                        q_signed=q, lo_cqr=lower, hi_cqr=upper)
    for phase, nr in (("Cal", cal), ("Score", score)):
        np.savez_compressed(task_dir / f"neighbors_{phase}.npz", query_indices=idx[phase],
                            global_neighbor_indices=nr["global"], distances=nr["distances"])
    result = {"raw": ev.evaluate_intervals(ys, ls, hs, 12300., .1),
              "cqr": ev.evaluate_intervals(ys, lower, upper, 12300., .1),
              "raw_per_origin": ev.per_origin_score(ys, ls, hs, .1, 12300.).tolist(),
              "cqr_per_origin": ev.per_origin_score(ys, lower, upper, .1, 12300.).tolist(),
              "origin_ids": d["origin_ts"].iloc[idx["Score"]].astype(str).tolist(),
              "q_signed": q.tolist(), "negative_correction_steps": int((q<0).sum()),
              "quantile_levels": [(1-CONF)/2, 1-(1-CONF)/2], "k": 20,
              "empty_rate": float((lower>upper).mean()), "distance": distance,
              "origin_identity_source": "saved_at_prediction_time",
              "quantile_calibrate_seconds": time.perf_counter()-began,
              "accounted_retrieval_seconds": cache.accounted_seconds(np.concatenate([idx['Cal'],idx['Score']]))}
    export_predictions(task_dir, d, idx, result)
    write_json(task_dir / "result.json", result)
    print(f"[analog {directory.name}/{distance}] raw IS={result['raw']['score']:.6f} "
          f"CQR IS={result['cqr']['score']:.6f} coverage={result['cqr']['coverage']:.4%}", flush=True)
    return result


def report_fold(directory, tasks, baselines, dates, thresholds):
    random_names = [f"R0_dtw_random{seed}_H1" for seed in range(3)]
    start, end = FOLDS[directory.name]['Score']
    calendar_end = str((pd.Timestamp(end)-pd.Timedelta(days=1)).date())
    analysis = inference.analyze_tasks(tasks, dates, B, R, random_names, thresholds,
                                       (start, calendar_end))
    analysis["analog_vs_B"] = {}
    for name, result in baselines.items():
        analysis["analog_vs_B"][name] = {str(length): inference.paired_comparison(
            result["cqr_per_origin"], tasks[B]["cqr_per_origin"], dates, length,
            calendar_start=start, calendar_end=calendar_end) for length in (7,14)}
    write_json(directory / "analysis.json", analysis)
    (directory / "DECISION.md").write_text(inference.render_analysis(analysis), encoding="utf-8")
    lines = ["# 实际运行结果", "", "| 系统 | raw IS | CQR IS | CQR覆盖 | CQR宽度 |",
             "|---|---:|---:|---:|---:|"]
    for name, result in {**tasks, **baselines}.items():
        lines.append(f"| {name} | {result['raw']['score']:.6f} | {result['cqr']['score']:.6f} | "
                     f"{result['cqr']['coverage']:.2%} | {result['cqr']['width']:.2%} |")
    lines += ["", "校准为有序原始分位数后的标准 signed CQR；负修正保留。未使用确认年份。",
              "", "repair中的旧12个模型沿用原已保存损失；其原点从当前相同分段重建，逐步预测无法补造。"]
    (directory / "RESULTS.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    write_json(directory / "results.json", {"tasks": tasks, "baselines": baselines})
    return analysis


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["all", "repair", "x01"], default="all")
    args = parser.parse_args()
    began = time.perf_counter()
    repair, x01 = OUT/"repair", OUT/"x01"
    repair.mkdir(parents=True, exist_ok=True)
    cfg = cfg_for()
    d = build_situations(load_dataframe(cfg), cfg)
    indices = {name: fold_indices(d, name, OUT/name) for name in FOLDS}
    original_protocol = json.loads((OUT/"protocol.json").read_text(encoding="utf-8"))
    thresholds = original_protocol["decision_thresholds"]
    protocol = {"task": "repair three H1 controls and nominal analog, then unique X01",
                "B": B, "R": R, "packages": PACKAGES, "folds_UTC": FOLDS,
                "effective_config": cfg.as_dict(), "thresholds": thresholds,
                "random_seeds": [0,1,2], "model_seed": 0,
                "postprocessing": "ordered raw quantiles; signed CQR; fail closed on empty metric intervals",
                "selection": "frozen before X01; no further search",
                "block_sensitivity_rule": "continuation needs lower>0 for both block lengths; stop for useful-gain exclusion in both",
                "core_training_tasks": {"repair": 3, "x01": 5},
                "counts": {f: {p:len(v) for p,v in ids.items()} for f,ids in indices.items()}}
    if (repair/"execution_protocol.json").exists():
        if json.loads((repair/"execution_protocol.json").read_text(encoding="utf-8")) != protocol:
            raise ValueError("Execution protocol changed after freeze")
    else:
        write_json(repair/"execution_protocol.json", protocol)
    write_json(repair/"runtime.json", {"python":sys.version,"executable":sys.executable,
                                      "numpy":np.__version__,"pandas":pd.__version__,"sklearn":sklearn.__version__,
                                      "joblib":joblib.__version__,"platform":platform.platform(),
                                      "threadpools":threadpool_info(),"threads":{k:os.environ.get(k) for k in
                                      ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS")}})
    snapshot = repair/"source_executed"
    snapshot.mkdir(exist_ok=True)
    for name in ("execute_x01.py","experiment.py","statistics.py","evaluate.py","intervals.py",
                 "models.py","retrieval.py","data.py","kelmarsh.py","config.py","run.py","baselines.py"):
        if not (snapshot/name).exists():
            shutil.copy2(ROOT/name, snapshot/name)
    memory = indices['repair']['M']
    queries = np.unique(np.concatenate([v for phase,v in indices['repair'].items() if phase!='M']))
    dtw = NeighborCache(d, memory, queries, "dtw", repair)
    if args.stage in ("all", "repair"):
        ids = indices['repair']
        euclidean = NeighborCache(d, memory, np.concatenate([ids['Cal'],ids['Score']]), "euclid", repair)
        original = json.loads((OUT/"b12_results.json").read_text(encoding="utf-8"))
        tasks = {k:v.copy() for k,v in original['results']['tasks'].items() if 'random' not in k}
        for k,v in tasks.items():
            v['package'] = PACKAGES[k.rsplit('_',1)[1]]
            v['origin_ids'] = d['origin_ts'].iloc[ids['Score']].astype(str).tolist()
            v['origin_identity_source'] = 'reconstructed_current_split_for_legacy_losses'
        nbr = {phase:dtw.get(ids[phase]) for phase in ('T','Cal','Score')}
        for seed in range(3):
            name=f'R0_dtw_random{seed}_H1'
            tasks[name]=train_one(name,'R0','H1',d,ids,nbr,repair,random_seed=seed)
        baselines={f'analog_{dist}':analog_one(dist,d,ids,cache,repair)
                   for dist,cache in (('euclid',euclidean),('dtw',dtw))}
        analysis=report_fold(repair,tasks,baselines,d['origin_ts'].iloc[ids['Score']],thresholds)
        print('[repair decision]',analysis['decision'],flush=True)
    if args.stage in ('all','x01'):
        ids=indices['x01']
        nbr={phase:dtw.get(ids[phase]) for phase in ('T','Cal','Score')}
        tasks={B:train_one(B,'NH','H0',d,ids,{},x01),
               R:train_one(R,'R0','H1',d,ids,nbr,x01)}
        for seed in range(3):
            name=f'R0_dtw_random{seed}_H1'
            tasks[name]=train_one(name,'R0','H1',d,ids,nbr,x01,random_seed=seed)
        baselines={'analog_dtw':analog_one('dtw',d,ids,dtw,x01)}
        analysis=report_fold(x01,tasks,baselines,d['origin_ts'].iloc[ids['Score']],thresholds)
        print('[X01 decision]',analysis['decision'],flush=True)
    write_json(repair/'execution_elapsed.json',{'this_invocation_seconds':time.perf_counter()-began,
                                               'stage':args.stage,'completion':'complete'})
    print(f'[complete] stage={args.stage} elapsed={time.perf_counter()-began:.1f}s',flush=True)


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
