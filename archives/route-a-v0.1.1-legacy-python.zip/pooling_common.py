"""Fixed-date, within-dataset pooling experiment and artifact helpers."""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='2'
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from gefcom_protocol_v2 import prepare,index
from strong_baselines import build_shared
from run_p2_2012 import build_shared_2012
from run_gefcom_tail_dynamic import base_matrix
from revision_common import ROOT,REFERENCE,OUT as REVISION,write,frozen_spec,save_stage,collect,METRIC_COLS

OUT=ROOT/'out_gefcom_pooling_20261105'
FAMILIES=['GBM','MLP','QRF']
ANALYSIS_FAMILIES=['GBM','GBM_budget','MLP','MLP_global','QRF']


def prepare_inputs():
    OUT.mkdir(exist_ok=True)
    frozen_spec(OUT/'protocol.json',dict(date='2026-11-05',datasets=[2014,2012],families=FAMILIES,
        seeds={'GBM':[0],'MLP':[0,1,2],'QRF':[0,1,2]},
        pooling='within each dataset; proper-training labels only; one-hot farm identity; each farm uses own history/NWP',
        GBM='same canonical R2, native NaN, train scaler; quantiles .05/.95; frozen50/31/20/L2=0',
        MLP='same legacy122/123 features, per-farm train-only zero imputation/scaler; 256/128/64; same optimizer/early stop',
        QRF='same per-farm train-only median+missing indicators;500 trees,leaf10,max_features1,full leaf responses',
        calibration='identical per-farm per-lead signed rolling84; labels only after complete target arrival; clip[0,1]',
        protection='secondary diagnostic: same previously frozen per-farm risk classifier and threshold .1 on BOTH local/pooled',
        selection='no new hyperparameter tuning; select pooling per family on 2014Q2 only, then freeze preference for 2012',
        validation_gate='macro coverage>=.90 and >=local-.005; width at least3% lower; IS not worse; diagnostic group gates separate',
        evaluation='all regimes retained; previous evaluation periods are retrospective; no independent-site assumption',
        resource='CPU;Torch/HGB2 threads, QRF8 tree workers, one pooled forest at a time; memory pilot before full QRF',
        caveats=['known farms only, not unseen-farm generalization','pooling changes total model capacity and effective regularization',
                  'per-farm preprocessing is identical between local and pooled; farm ID implicit in local model selection']))
    counts=[]
    for year in [2014,2012]:
        farms,_=prepare(year)
        for farm,d in farms.items():
            folder=OUT/f'inputs/gefcom{year}/farm_{farm:02d}';folder.mkdir(parents=True,exist_ok=True)
            tr=index(d,'train',True)
            counts.append(dict(year=year,farm=farm,train_days=len(tr),train_cells=len(tr)*24,
                first_train=str(d['origins'][tr[0]]),last_train_label=str(d['ends'][tr[-1]]),
                validation_days=int(d['valid'][index(d,'validation')].sum()),evaluation_days=int(d['valid'][index(d,'evaluation')].sum())))
            if all((folder/name).exists() for name in ['features.npz','samples.npz','meta.csv','preprocessing.joblib']):continue
            tm=np.repeat(np.isin(np.arange(len(d['y'])),tr),24)
            canonical=base_matrix(d,year)
            legacy,_,_=(build_shared if year==2014 else build_shared_2012)(d,'R2')
            zero=np.nan_to_num(legacy,nan=0.);sc=StandardScaler().fit(zero[tm]);scaled=sc.transform(zero).astype('float32')
            imputer=SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True).fit(canonical[tm])
            dense=imputer.transform(canonical).astype('float32')
            np.savez_compressed(folder/'features.npz',GBM=canonical,MLP=scaled,QRF=dense)
            np.savez_compressed(folder/'samples.npz',y=d['y'],valid=d['valid'],history=d['history'],origins=d['origins'],ends=d['ends'])
            d['meta'].to_csv(folder/'meta.csv',index=False)
            joblib.dump(dict(MLP_scaler=sc,QRF_imputer=imputer),folder/'preprocessing.joblib')
    if counts:pd.DataFrame(counts).to_csv(OUT/'training_counts.csv',index=False)
    print('pooling inputs prepared',flush=True)


def load_farms(year):
    farms={}
    for folder in sorted((OUT/f'inputs/gefcom{year}').glob('farm_*')):
        farm=int(folder.name.split('_')[-1])
        with np.load(folder/'samples.npz') as z:d={k:z[k] for k in z.files}
        d['meta']=pd.read_csv(folder/'meta.csv');farms[farm]=d
    return farms


def feature_array(year,farm,family):
    with np.load(OUT/f'inputs/gefcom{year}/farm_{farm:02d}/features.npz') as z:return z[family]


def pooled_data(year,family):
    farms=load_farms(year)
    if family!='MLP_global':
        matrices={farm:feature_array(year,farm,'GBM' if family=='GBM_budget' else family) for farm in farms}
        return assemble_pool(farms,matrices)
    matrices={}
    for farm in farms:
        canonical=feature_array(year,farm,'GBM');raw=canonical.copy()
        raw[:,35:107]=canonical[:,35:107].reshape(-1,3,24).transpose(0,2,1).reshape(-1,72)
        matrices[farm]=np.nan_to_num(raw,nan=0.)
    result=list(assemble_pool(farms,matrices));X=result[1];tm=result[3];nbase=X.shape[1]-len(farms)
    path=OUT/f'MLP_global/gefcom{year}/global_scaler.joblib';path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():scaler=joblib.load(path)
    else:
        scaler=StandardScaler().fit(X[tm,:nbase]);joblib.dump(scaler,path)
    np.testing.assert_allclose(scaler.mean_,X[tm,:nbase].mean(axis=0),atol=1e-10)
    result[1]=np.c_[scaler.transform(X[:,:nbase]),X[:,nbase:]].astype('float32')
    return tuple(result)


def assemble_pool(farms,matrices):
    arrays=[];targets=[];train=[];stop=[];forecast=[];slices={};offset=0
    for position,(farm,d) in enumerate(farms.items()):
        X=matrices[farm];onehot=np.zeros((len(X),len(farms)),dtype=X.dtype);onehot[:,position]=1
        assert len(X)==len(d['y'])*24
        arrays.append(np.c_[X,onehot]);targets.append(d['y'].ravel())
        train.append(np.repeat(np.isin(np.arange(len(d['y'])),index(d,'train',True)),24))
        stop.append(np.repeat(np.isin(np.arange(len(d['y'])),index(d,'validation_seed',True)),24))
        forecast.append(np.repeat(~d['meta'].phase.eq('train').to_numpy(),24))
        slices[farm]=slice(offset,offset+len(X));offset+=len(X)
        assert d['ends'][index(d,'train',True)].max()<=d['origins'][index(d,'validation_seed')].min()
    # No contemporary labels from other farms enter any fitted forecaster.
    last=max(d['ends'][index(d,'train',True)].max() for d in farms.values())
    first=min(d['origins'][index(d,'validation_seed')].min() for d in farms.values())
    assert last<=first
    return farms,np.ascontiguousarray(np.concatenate(arrays)),np.concatenate(targets),np.concatenate(train),np.concatenate(stop),np.concatenate(forecast),slices


def local_heads(year,farm,family,seed):
    if family=='MLP_global':family='MLP'
    if family=='GBM_budget':family='GBM'
    if family=='GBM':
        path=REFERENCE/f'gefcom{year}/farm_{farm:02d}/R2_shared_aug/heads.npz'
        with np.load(path) as z:return np.minimum(z['q05'],z['q95']),np.maximum(z['q05'],z['q95'])
    if family=='MLP':
        folder=REVISION/f'mlp/gefcom{year}/farm_{farm:02d}/seed_{seed}'
        lo=np.load(folder/'q0.05.npz')['prediction'];hi=np.load(folder/'q0.95.npz')['prediction']
        return np.minimum(lo,hi),np.maximum(lo,hi)
    with np.load(REVISION/f'qrf/gefcom{year}/farm_{farm:02d}/leaf_10/seed_{seed}/heads.npz') as z:return z['lo'],z['hi']


def evaluate_family(year,family,seeds,stages):
    rows=[];farms=load_farms(year)
    for farm,d in farms.items():
        p=np.load(REVISION/f'mlp/gefcom{year}/farm_{farm:02d}/risk_probabilities.npz')['probability']
        for seed in seeds:
            for regime in ['local','pooled']:
                folder=OUT/f'{family}/gefcom{year}/{regime}/seed_{seed}/farm_{farm:02d}';folder.mkdir(parents=True,exist_ok=True)
                if regime=='local':lo,hi=local_heads(year,farm,family,seed)
                else:
                    with np.load(folder/'heads.npz') as z:lo,hi=z['lo'],z['hi']
                for stage in stages:
                    ids,res=save_stage(folder,d,lo,hi,stage)
                    L,U=np.clip(res['lo'],0,1),np.clip(res['hi'],0,1)
                    for variant,ll,uu in [('raw',np.clip(lo[ids],0,1),np.clip(hi[ids],0,1)),
                        ('signed',L,U),('protected',np.where(p[ids]>=.1,0.,L),U)]:
                        collect(rows,d,ids,ll,uu,year=year,farm=farm,seed=seed,stage=stage,method=family+'_'+regime+'_'+variant)
                        if variant=='protected':
                            assert np.all(ll<=L)
                            np.savez_compressed(folder/f'{stage}_protected.npz',indices=ids,lo=ll,hi=uu,probability=p[ids],threshold=.1,
                                max_label_end=res['max_label_end_used'])
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/family/f'{year}_{"_".join(stages)}_per_farm.csv',index=False)
    return rows


def choose_pooling(family,rows):
    df=pd.DataFrame(rows);m=df[df.group=='all'].groupby('method')[METRIC_COLS].mean()
    local=m.loc[family+'_local_signed'];pooled=m.loc[family+'_pooled_signed']
    passed=bool(pooled.coverage>=max(.90,local.coverage-.005) and pooled.width<=.97*local.width and pooled.IS<=local.IS)
    decision=dict(family=family,prefer='pooled' if passed else 'local',passed=passed,
        local=local.to_dict(),pooled=pooled.to_dict(),source='2014Q2 only; same decision retained for 2012',
        scope='overall selection gate; conditional coverage is separately reported, not silently guaranteed')
    write(OUT/f'{family}/selection.json',decision)
    return decision


def save_family_metrics(family,rows):
    frame=pd.DataFrame(rows);frame.to_csv(OUT/f'{family}/metrics_per_farm.csv',index=False)
    frame.groupby(['year','method','seed','stage','group'])[METRIC_COLS].mean().reset_index().to_csv(OUT/f'{family}/metrics_macro.csv',index=False)


if __name__=='__main__':prepare_inputs()
