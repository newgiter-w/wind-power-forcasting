"""Score nominal, development-frozen, and retrospective width matches."""
import numpy as np
import pandas as pd

from run_gefcom2012_dual_batch import OUT, BASE, folder, load_farms, index
from revision_common import calibration, collect, METRIC_COLS, frozen_spec, write
from run_qrf_regime_bounds import bootstrap, GROUPS
from gefcom2014_experiment import masks

SCOPES = ('paired', 'full')
YEAR = 2012


def replay(stage, farms):
    records = []
    for farm, d in farms.items():
        with np.load(BASE/f'gefcom2012/farm_{farm:02}/heads.npz') as z:
            a_raw = z['direct_qrf']
            a_med = z['qrf']
        with np.load(folder(farm)/'heads.npz') as z:
            np.testing.assert_array_equal(z['origins'], d['origins'])
            np.testing.assert_array_equal(z['train_days'], index(d, 'train', True))
            raw = z['heads']
            paired = z['paired']
        ids, a = calibration(d, *a_raw, stage)
        _, b = calibration(d, raw[..., 0], raw[..., 2], stage)
        for key in ('n_cal', 'max_label_end_used'):
            np.testing.assert_array_equal(a[key], b[key])
        ref = np.clip([a['lo'], a['hi']], 0, 1)
        ref_raw = np.clip(a_raw[:, ids], 0, 1)
        batch = paired[ids]
        candidate = np.where(batch[None, :, None], np.clip([b['lo'], b['hi']], 0, 1), ref)
        candidate_raw = np.clip(raw[ids][:, :, [0, 2]].transpose(2, 0, 1), 0, 1)
        np.testing.assert_array_equal(candidate_raw[:, ~batch], ref_raw[:, ~batch])
        with np.load(BASE/f'gefcom2012/farm_{farm:02}/{stage}_direct_qrf.npz') as z:
            np.testing.assert_array_equal(ids, z['ids'])
            np.testing.assert_array_equal(ref, [z['lo'], z['hi']])
        np.savez_compressed(folder(farm)/f'{stage}_replay.npz', ids=ids, paired=batch, a=ref, b=candidate,
            a_raw=ref_raw, b_raw=candidate_raw, a_median=a_med[ids], b_median=raw[ids, :, 1],
            max_label_end=b['max_label_end_used'])
        records.append((farm, d, ids, batch, ref, candidate, ref_raw, candidate_raw))
    return records


def adjust(bounds, batch, offset):
    lo, hi = bounds
    if offset >= 0:
        shifted = np.clip([lo-offset, hi+offset], 0, 1)
    else:
        center = (lo+hi)/2
        keep_lo = (lo == 0) & (hi < 1)
        keep_hi = (hi == 1) & (lo > 0)
        lower = np.minimum(lo-offset*(1+keep_hi), np.where(keep_hi, hi, center))
        upper = np.maximum(hi+offset*(1+keep_lo), np.where(keep_lo, lo, center))
        shifted = [np.where(keep_lo, lo, lower), np.where(keep_hi, hi, upper)]
    return np.where(batch[None, :, None], shifted, bounds)


def width(records, scope, offset=None):
    means = []
    for _, d, ids, batch, ref, candidate, *_ in records:
        keep = d['valid'][ids] & (batch if scope == 'paired' else True)
        lo, hi = ref if offset is None else adjust(candidate, batch, offset)
        means.append((hi-lo)[keep].mean())
    return float(np.mean(means))


def match(records, scope):
    target = width(records, scope)
    lo, hi = -1., 1.
    assert width(records, scope, lo) <= target <= width(records, scope, hi)
    for _ in range(40):
        mid = (lo+hi)/2
        if width(records, scope, mid) < target:
            lo = mid
        else:
            hi = mid
    assert abs(width(records, scope, hi)-target) < 1e-10
    return hi


def score(records, rows, stage, scope, policy, offset=0):
    daily = {}
    for farm, d, ids, batch, ref, candidate, ref_raw, candidate_raw in records:
        if policy == 'raw':
            ref, candidate = ref_raw, candidate_raw
        else:
            candidate = adjust(candidate, batch, offset)
        np.testing.assert_array_equal(candidate[:, ~batch], ref[:, ~batch])
        use = batch if scope == 'paired' else np.ones(len(batch), dtype=bool)
        score_ids = ids[use]
        y = d['y'][ids]
        groups = masks(y, d['history'][ids, -1])
        for model, (lo, hi) in [('A', ref), ('B', candidate)]:
            assert np.isfinite(lo).all() and np.isfinite(hi).all() and (lo <= hi).all()
            collect(rows, d, score_ids, lo[use], hi[use],
                    farm=farm, model=model, stage=stage, scope=scope, policy=policy)
            if stage == 'evaluation' and policy != 'raw':
                w = hi-lo
                stats = [w, (y >= lo) & (y <= hi),
                         w+20*np.maximum(lo-y, 0)+20*np.maximum(y-hi, 0), y > hi]
                for group in GROUPS:
                    keep = groups[group] & (d['valid'][ids] & use)[:, None]
                    daily[model, farm, group] = (d['origins'][ids], np.column_stack(
                        [keep.sum(axis=1)] + [np.where(keep, s, 0).sum(axis=1) for s in stats]))
    return [dict(stage=stage, scope=scope, policy=policy, **r)
            for r in bootstrap(YEAR, daily, 'B')] if daily else []


def ramp_errors(farms):
    rows = []
    for farm, d in farms.items():
        for stage in ('validation','evaluation'):
            with np.load(folder(farm)/f'{stage}_replay.npz') as z:
                ids, paired = z['ids'], z['paired']
                y = d['y'][ids]
                last = d['history'][ids, -1, None]
                actual = np.diff(y, axis=1, prepend=last)
                for scope in SCOPES:
                    keep = d['valid'][ids] & (paired if scope == 'paired' else True)
                    for model in ('A','B'):
                        predicted = np.diff(z[f'{model.lower()}_median'], axis=1, prepend=last)
                        for group, mask in [('all', np.ones_like(actual, dtype=bool)), ('up_ramp', actual > .1)]:
                            used = mask & keep[:, None]
                            error = (predicted-actual)[used]
                            rows.append(dict(farm=farm,stage=stage,scope=scope,model=model,group=group,
                                cells=int(used.sum()), increment_mae=float(np.abs(error).mean()),
                                increment_bias=float(error.mean())))
    return pd.DataFrame(rows)


def summarize(frame, offsets):
    macro = frame.groupby(['stage','scope','policy','model','group'])[METRIC_COLS].mean()
    macro.to_csv(OUT/'macro.csv')
    frame.to_csv(OUT/'per_farm.csv', index=False)
    selected = ['all','up_ramp','near_zero','down_ramp']
    metrics = [('all','coverage'),('all','width'),('up_ramp','upper_miss'),
               ('near_zero','coverage'),('down_ramp','coverage'),('all','IS')]
    rows, gates = [], []
    for stage, scope, policy in macro.index.droplevel(['model','group']).unique():
        a, b = (macro.loc[(stage,scope,policy,model)].loc[selected] for model in ('A','B'))
        va, vb = ([x.loc[g,m] for g,m in metrics] for x in (a,b))
        if policy != 'raw':
            gates.append(dict(stage=stage, scope=scope, policy=policy,
                width_delta=vb[1]-va[1], up_upper_delta=vb[2]-va[2],
                coverage_pass=bool(vb[0]>=.9), up_upper_pass=bool(vb[2]<va[2]),
                near_zero_pass=bool(vb[3]>=va[3]-.01), down_ramp_pass=bool(vb[4]>=va[4]-.01),
                IS_pass=bool(vb[5]<=va[5])))
        if stage == 'evaluation':
            for model, values in [('A', va), ('B', vb)]:
                rows.append([scope,policy,model,*[f'{x*100:.2f}' for x in values[:-1]],f'{values[-1]:.4f}'])
    pd.DataFrame(gates).to_csv(OUT/'gates.csv',index=False)
    rows.insert(0,['样本','方案','模型','覆盖 %','宽度 %容量','上爬坡上漏 %','近零覆盖 %','下爬坡覆盖 %','IS'])
    rows.insert(1,['---']*len(rows[0]))
    table = '\n'.join('| '+' | '.join(r)+' |' for r in rows)
    availability = pd.read_csv(OUT/'batch_coverage_per_farm.csv').query("phase == 'evaluation'")
    total, pairs = availability[['issued','paired']].sum()
    same_time = availability.latest_at_origin.sum()
    text = f"""# GEFCom2012 七场双批次 NWP 配对实验

A 使用发报时最新的完整 NWP 批次。B 保持 QRF500、叶大小10、种子0及相同训练行，增加早12小时批次的风矢量、风速以及新旧预报差值。各场用同样的分位数和原有逐场逐时效 signed rolling84 校准。B 的历史误差来自实际回放的混合原始预测。缺少完整旧批次的日子，原始及最终区间逐元素回退 A。最新批次的旧基线端点逐场复现。

原始文件核对了同一有效小时、原生预报时效和两个批次不晚于原点。源数据只有批次时刻，沿用零发布延迟假设。评价期七场共 {total} 个风场日，{pairs} 个完整配对，{total-pairs} 个风场日回退。共有 {same_time} 个风场日的最新批次与发报时刻相同，结果对零发布延迟假设存在依赖。

## 评价期指标

{table}

raw 为未经校准的区间。nominal 为同一滚动校准。frozen 为在 2011 Q2 匹配各自样本口径的平均宽度并冻结调整量，其中全样本口径是运行候选。frozen_full 表示把这一全样本运行规则原样应用到配对子集。retrospective 为评价期利用预测宽度和事后评分样本作同宽度诊断，只调整有完整旧批次的日期，不以评价标签结果择优。所有缩宽操作在单侧贴边时保留物理边界。

冻结的半宽调整量为 {offsets}。逐场分数、日期分块配对差、上爬坡增幅误差与各门槛分别见 per_farm.csv、paired_blocks.csv、increment_errors.csv、gates.csv。区块为同步跨场14日，回顾同宽度的区间以匹配调整量为条件。评价期已用于此前回顾实验。
"""
    (OUT/'RESULTS.md').write_text(text, encoding='utf-8')
    print(pd.DataFrame(gates).query("stage == 'evaluation'").to_string(index=False),flush=True)


def main():
    farms = load_farms(YEAR)
    rows, paired = [], []
    dev = replay('validation', farms)
    offsets = {scope: match(dev, scope) for scope in SCOPES}
    frozen_spec(OUT/'selection.json', dict(operational_scope='full', offsets=offsets,
        source='2011 Q2 only', rule='minimum B half-width adjustment to match A width; no target-outcome optimization'))
    for scope in SCOPES:
        for policy, offset in [('raw',0.), ('nominal',0.), ('frozen',offsets[scope])]:
            score(dev, rows, 'validation', scope, policy, offset)
    evaluation = replay('evaluation', farms)
    retrospective = {}
    for scope in SCOPES:
        retrospective[scope] = match(evaluation, scope)
        points = [('raw',0.), ('nominal',0.), ('frozen',offsets[scope]), ('retrospective',retrospective[scope])]
        if scope == 'paired':
            points.append(('frozen_full',offsets['full']))
        for policy, offset in points:
            paired.extend(score(evaluation, rows, 'evaluation', scope, policy, offset))
    write(OUT/'retrospective_offsets.json', retrospective)
    pd.DataFrame(paired).to_csv(OUT/'paired_blocks.csv', index=False)
    ramp_errors(farms).to_csv(OUT/'increment_errors.csv',index=False)
    summarize(pd.DataFrame(rows), offsets)
    write(OUT/'completion.json', dict(status='complete', farms=7))


if __name__ == '__main__':
    main()


