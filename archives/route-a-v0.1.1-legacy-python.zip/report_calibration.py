"""Render the completed calibration comparisons without additional selection."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).parent
OUT=ROOT/'out_calibration_v1'
NAMES={'global_cqr':'Global CQR','rolling_cqr':'Rolling CQR','aci_projected':'ACI'}
COLORS=['#64748b','#0f766e','#b45309']


def read(path):return json.loads(path.read_text(encoding='utf-8'))


def comparison_line(label,c):
    p=c['estimate'];lo,hi=c['ci95']
    return f'| {label} | {p:.2%} | [{lo:.2%}, {hi:.2%}] |'


def figures(results):
    fig,axes=plt.subplots(2,3,figsize=(11,6),layout='constrained')
    for row,year in enumerate(('2021','2022')):
        for col,kind in enumerate(('coverage','width','ramp')):
            ax=axes[row,col]
            vals=[]
            for method in NAMES:
                m=results['years'][year][method]['metrics']
                vals.append(100*(m['ramp']['coverage'] if kind=='ramp' else m['all'][kind]))
            if kind=='width':
                ax.barh(np.arange(3),vals,color=COLORS,height=.45);ax.set_xlim(0,82)
            else:
                ax.scatter(vals,np.arange(3),c=COLORS,s=65,zorder=3)
                ax.axvline(90,color='#b91c1c',linestyle='--',linewidth=1)
                ax.set_xlim(80,100)
            for i,value in enumerate(vals):ax.text(value+.45,i,f'{value:.2f}%',va='center',fontsize=9)
            ax.set_yticks(np.arange(3),NAMES.values());ax.invert_yaxis()
            ax.set_title(f'{year}: '+{'coverage':'Overall coverage','width':'Width / capacity','ramp':'Ramp coverage'}[kind])
            ax.set_xlabel('Percent');ax.grid(axis='x',alpha=.2)
    fig.suptitle('Same frozen NH_H0 | 24 hourly blocks | window 84 days | gamma 0.01',fontsize=12)
    fig.savefig(OUT/'comparison.png',dpi=170);plt.close(fig)
    fig,axes=plt.subplots(2,1,figsize=(11,5.7),layout='constrained')
    for ax,year in zip(axes,('2021','2022')):
        for method,color in zip(NAMES,COLORS):
            with np.load(OUT/year/method/'daily.npz') as p:
                index=pd.DatetimeIndex(p['origins']).normalize()
                frame=pd.DataFrame({'count':p['values'][:,0],'hit':p['values'][:,1]},index=index)
            frame=frame.reindex(pd.date_range(f'{year}-01-01',f'{year}-12-31',freq='D'),fill_value=0)
            value=100*frame.hit.rolling(28,min_periods=28).sum()/frame['count'].rolling(28,min_periods=28).sum()
            ax.plot(value.index,value,color=color,label=NAMES[method],linewidth=1.3)
        ax.axhline(90,color='#b91c1c',linestyle='--',linewidth=1)
        ax.set_ylim(70,100);ax.set_ylabel('28-day coverage (%)');ax.set_title(year+' (retrospective, by origin date)')
        ax.grid(alpha=.2);ax.legend(ncol=3,loc='lower left',fontsize=8)
    fig.savefig(OUT/'local_coverage.png',dpi=170);plt.close(fig)


def main():
    results=read(OUT/'results.json');verification=read(OUT/'verification.json')
    assert verification['status']=='PASS'
    figures(results)
    lines=['# 固定完整历史模型：global / rolling / ACI 校准结果','',
           '日期：2026-11-01（Asia/Shanghai）；所有实验时间按UTC。', '',
           '**结论：rolling和ACI改善了总体过覆盖与宽度，但没有同时解决爬坡可靠性；ACI相对rolling没有稳定的区间得分优势。当前优先保留更简单的rolling作为总体校准基线，不能宣布已解决极端工况。**','',
           '## 实验与时间顺序','',
           '- 直接复用X01的NH_H0模型及scaler，2019训练、167维完整历史输入，所有年份权重固定。新增模型训练任务为0。',
           '- 2020 Q1初始化，2020 Q2选窗口/步长；不使用2021/2022选型。',
           '- rolling候选28/56/84日，ACI候选gamma=0.002/0.005/0.01；冻结选择为84日、0.01。',
           '- 所有验证候选都未通过覆盖+ramp联合筛选，按预定fallback选择距90%最近者。不能把这写成验证门槛已通过；没有扩大搜索补救。',
           '- 2021/2022分别用前一年Q4初始化所有方法，global每年重置后冻结；rolling/ACI只用完整目标已到达的反馈。每日先反馈、后预测。',
           '- 缺测日仍发预测，完整日反馈到达后才跳过无效标签；2021发365条、评价334条，2022发364条、评价342条。',
           '- 2021/2022是冻结参数后的历史外推评价，项目此前已看过这些年份，不称全新untouched确认。2023/2024未访问。',
           '- 任务为24个小时均值点的逐lead区间，不是144个十分钟点或整段同时覆盖。', '',
           '## 主结果','',
           '| 年份 | 方法 | 总体覆盖 | 宽度/容量 | IS | 爬坡覆盖 | 爬坡IS |',
           '|---|---|---:|---:|---:|---:|---:|']
    for year in ('2021','2022'):
        for method in ('raw_reference','global_cqr','rolling_cqr','aci_projected'):
            m=results['years'][year][method]['metrics'];a=m['all'];r=m['ramp']
            label='Raw' if method=='raw_reference' else NAMES[method]
            lines.append(f"| {year} | {label} | {a['coverage']:.2%} | {a['width']:.2%} | {a['score']:.6f} | {r['coverage']:.2%} | {r['score']:.6f} |")
    lines += ['', '宽度按容量归一；同一年所有方法使用同一有效原点。爬坡为小时平均功率相邻变化>额定10%，包含最后历史小时到首预测小时的边界。', '',
              '## 配对证据：7天日历块、5000次（14天敏感性另存）','']
    gates={}
    for year in ('2021','2022'):
        comp=read(OUT/year/'comparisons.json')
        lines += [f'### {year}','', '| 对照/指标 | 点估计 | 95%区间 |','|---|---:|---:|']
        gates[year]={}
        global_m=results['years'][year]['global_cqr']['metrics']
        for method in ('rolling_cqr','aci_projected'):
            c=comp[method+'_vs_global']['7']['metrics']
            for key,description in (('width_relative_reduction','宽度相对下降'),('IS_relative_gain','IS相对改善'),
                                    ('coverage_error_reduction','总体绝对覆盖误差下降'),('ramp_coverage_change','爬坡覆盖变化')):
                lines.append(comparison_line(NAMES[method]+' vs Global / '+description,c[key]))
            m=results['years'][year][method]['metrics']
            checks={
                'overall_coverage_in_88_92':.88<=m['all']['coverage']<=.92,
                'coverage_error_reduced':m['all']['coverage_error']<global_m['all']['coverage_error'],
                'width_reduction_at_least_2pct':c['width_relative_reduction']['estimate']>=.02,
                'IS_not_worse_by_more_than_2pct':c['IS_relative_gain']['estimate']>=-.02,
                'ramp_coverage_drop_not_more_than_2pp':c['ramp_coverage_change']['estimate']>=-.02}
            gates[year][method]={'checks':checks,'all_point_estimate_gates_passed':all(checks.values())}
        lines.append(comparison_line('ACI vs Rolling / IS相对改善',comp['aci_vs_rolling']['7']['metrics']['IS_relative_gain']))
        lines.append('')
    lines += ['解释：百分比形式的coverage变化/误差变化应按百分点理解；宽度与IS为相对变化。CI是有依赖历史数据的块bootstrap近似，不是条件覆盖保证。', '',
              '## 如何解释','',
              '1. **总体校准与效率有实证收益。** rolling在2021/2022分别收窄约4.51%/10.97%；总体覆盖90.27%/90.80%。2022 IS改善4.33%，7天95%区间[2.42%,6.50%]，14天也保持正向证据。2021 IS改善仅0.68%，区间跨零，不能把两年说成同等强度的得分改善。',
              '2. **爬坡目标未实现。** 2021各校准方法ramp覆盖仍约85%–86%；2022 global为90.76%，rolling/ACI降到88.10%/87.50%。两种自适应方案的下降均超过预定2pp点估计门槛；虽然ramp IS接近，但没有明确改善证据。覆盖下降的区间与绝对校准误差变化的区间须分开解释，不能把后者也宣称显著恶化。',
              '3. **ACI的额外价值尚未显示。** 2021/2022对rolling的IS点估计均稍差，区间跨零；2022 ACI更接近90%且再收窄约0.78%，不足以证明总体风险—效率折中更好。',
              '4. **预定保护没有影响结果。** 两年ACI状态/分位点支持投影、共同空集扩张触发均为0。无投影ACI诊断与投影版逐步区间完全一致，且没有无限/空区间；本轮结果不是靠保护规则获得。',
              '5. **只达到部分目标。** 2021两种自适应方法通过总体/宽度与不大幅损害ramp的点估计门槛；2022因ramp下降而未通过联合门槛。因此不称“三目标同时解决”。', '',
              '## 下一步判断','',
              '保留rolling CQR（84日）作为简单的总体校准对照；ACI不替代它成为默认最佳。真正缺口是风险条件下的覆盖，而不是继续盲调全局alpha。后续若研究风险分层/尺度校准，风险只能从发报时可得历史中构造，并另行冻结选型与新确认集；本轮未加入这些新方法，也没有为改善2022指标重新调参。', '',
              '## 核查与复现','',
              '- 6项在线测试通过：未来标签/质量扰动不影响过去预测；miss更新方向；gamma=0等价rolling；有限分位点支持；缺测反馈；未来种子拒绝。',
              '- 完整回放两个年度8个算法案例的每次alpha、每个阈值、分数库计数和来源时间；全部通过。',
              '- 用独立pinball表达式重算IS、覆盖、宽度、ramp；模型raw预测精确复现旧X01。selection文件先于年度评价落盘。',
              '- 所有新预测/反馈/状态位于各年度各方法目录；raw_predictions.npz保存共同原始预测，model_identity.json记录固定模型。',
              '- 结果为完整有效目标日上的经验覆盖；原始SCADA质量字段与历史无限ffill仍为既有数据限制。', '',
              '方法依据：[ACI原论文](https://arxiv.org/html/2106.00170v3)给出alpha反馈更新；[作者代码](https://github.com/isgibbs/AdaptiveConformal/blob/main/ACCode.R)用于核对更新方向。本实验的有限次序统计、逐lead与完整日延迟反馈规则已单独定义，不直接声称原论文长期保证适用于当前所有条件。', '',
              '![总体与爬坡对比](comparison.png)', '', '![28日局部覆盖](local_coverage.png)']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (OUT/'decision.json').write_text(json.dumps({'conclusion':'partial_success_global_efficiency_but_ramp_tradeoff',
                     'preferred_simple_reference':'rolling_cqr_84days','ACI_incremental_IS_advantage_supported':False,
                     'model_training_tasks':0,'yearly_gates':gates,'verification':'PASS'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(OUT/'RESULTS.md')


if __name__=='__main__':main()
