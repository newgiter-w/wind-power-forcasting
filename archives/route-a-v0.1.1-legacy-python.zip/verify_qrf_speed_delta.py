"""Check saved model replay and draw identical-date before/after examples."""
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from run_qrf_speed_delta import OUT, BASE, load_farms, index, feature_array, added_features, cells, write

def verify():
    checks=[]
    for year in (2014,2012):
        for farm,d in load_farms(year).items():
            path=OUT/f'gefcom{year}/farm_{farm:02}'
            saved=joblib.load(path/'model.joblib')
            extra=added_features(feature_array(year,farm,'GBM'))
            tr=index(d,'train',True)
            np.testing.assert_allclose(saved['imputer'].statistics_,np.nanmedian(extra[cells(tr)],axis=0))
            model=saved['model']
            np.testing.assert_array_equal(model.sorted_y,np.sort(d['y'][tr].ravel()))
            days=np.r_[index(d,'validation')[:2],index(d,'evaluation')[:2]]
            ids=cells(days)
            x=np.column_stack([feature_array(year,farm,'QRF')[ids],saved['imputer'].transform(extra[ids])])
            pred=model.predict(x,(.05,.5,.95)).reshape(-1,24,3)
            with np.load(path/'heads.npz') as z:
                expected=z['heads'][days]
            np.testing.assert_allclose(pred,expected,atol=1e-12,rtol=1e-12)
            checks.append(dict(year=year,farm=farm,queries=len(ids),maximum_difference=float(abs(pred-expected).max())))
    write(OUT/'verification.json',dict(status='passed',checks=checks))

def plot():
    old=BASE/'gefcom2012/farm_01'
    new=OUT/'gefcom2012/farm_01'
    d=load_farms(2012)[1]
    days=np.searchsorted(d['origins'],np.array(['2011-09-02','2012-03-02'],dtype='datetime64[ns]'))
    date_strings=[str(d['origins'][i])[:10] for i in days]
    assert date_strings==['2011-09-02','2012-03-02']
    with np.load(old/'heads.npz') as z:
        p0=z['qrf'][days]
    with np.load(new/'heads.npz') as z:
        p1=z['heads'][days,:,1]
    upper=[]
    for file in [old/'evaluation_direct_qrf.npz',new/'evaluation.npz']:
        with np.load(file) as z:
            positions=np.searchsorted(z['ids'],days)
            np.testing.assert_array_equal(z['ids'][positions],days)
            upper.append(z['hi'][positions])
    fig,axes=plt.subplots(1,2,figsize=(11,4.4),sharey=True,layout='constrained')
    lead=np.arange(1,25)
    for i,ax in enumerate(axes):
        ax.plot(lead,d['y'][days[i]],color='#b52c2c',lw=2,label='Observed')
        for p,h,c,name in [(p0,upper[0],'#586673','Original'),(p1,upper[1],'#138574','Speed delta')]:
            ax.plot(lead,p[i],color=c,label=f'{name} median')
            ax.plot(lead,h[i],color=c,ls='--',label=f'{name} 90% upper')
        ax.set_title(date_strings[i])
        ax.set_ylim(0,.75)
        ax.set_xticks([1,6,12,18,24])
        ax.set_xlabel('Forecast lead (h)')
        ax.grid(alpha=.2)
    axes[0].set_ylabel('Power / capacity')
    axes[0].legend(fontsize=8,loc='upper left')
    fig.savefig(OUT/'paired_examples.png',dpi=170)
    plt.close(fig)

if __name__=='__main__':
    verify()
    plot()
