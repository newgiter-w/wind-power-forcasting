"""Prepare the fixed retrospective annual-training and untouched-site windows."""
from pathlib import Path
import json

from pair_kelmarsh_gfs import OUT as KEL,month
from pair_penmanshiel_frozen_transfer import OUT as PEN,weather,pair,scada
from revision_common import frozen_spec,write

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_q90_training_coverage'
TRAIN=tuple([f'2022-{m:02}' for m in range(8,13)]+[f'2023-{m:02}' for m in range(1,8)])


def main():
    frozen_spec(OUT/'protocol.json',dict(annual_train=list(TRAIN),same_endpoint_short=['2023-07'],
        old_short=['2023-11'],development=['2023-12'],
        retrospective_test=[f'2024-{m:02}' for m in range(2,13)],
        independent_test=dict(site='Penmanshiel fixed cohort11–15',month='2024-01',earliest_origin='2024-01-02',
                              reason='January omitted from all preceding site evaluations; day1 lacks 2023 history in cache'),
        weights='original frozen Kelmarsh QRF and original preprocessing; new q90 fits use identical target and model config',
        residuals='annual residuals computed offline using fixed QRF; annual targets disjoint from QRF proper-training targets, all labels available before December development and January validation',
        status='2024 Kelmarsh and Penmanshiel Feb–Dec have been inspected; only Penmanshiel January is independent here',
        revision='initial prospective-only plan Nov2023–Oct2024 superseded before fitting; earlier disjoint meta-training is valid offline and allows seasonal retrospective evaluation',
        selection='none among models; all three fixed arms reported, all alarm cutoffs calibrated on same December2023 only',
        inference='exact quiet false-count retrospective contrasts and frozen cutoffs;14d primary,7/28 sensitivity; seasonal retrospective groups; no heldout threshold tuning'))
    for m in TRAIN:
        if not (KEL/m/'completion.json').exists():
            month(m)
    weather('2024-01')
    pair('2024-01',scada())
    write(OUT/'data_complete.json',dict(status='complete',months=len(TRAIN)))
    print('DATA COMPLETE',flush=True)


if __name__=='__main__':
    main()
