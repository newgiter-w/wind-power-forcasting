import unittest
import numpy as np
from strong_baselines import order_quantile_bounds

class SortingWitness(unittest.TestCase):
    def test_crossed_bounds_are_swapped_without_mutation(self):
        a=np.array([[.8,.1],[.4,.5]]);b=np.array([[.2,.9],[.4,.3]])
        before_a=a.copy();before_b=b.copy()
        lo,hi=order_quantile_bounds(a,b)
        np.testing.assert_equal(lo,[[.2,.1],[.4,.3]])
        np.testing.assert_equal(hi,[[.8,.9],[.4,.5]])
        np.testing.assert_equal(a,before_a);np.testing.assert_equal(b,before_b)

if __name__=='__main__':unittest.main()
