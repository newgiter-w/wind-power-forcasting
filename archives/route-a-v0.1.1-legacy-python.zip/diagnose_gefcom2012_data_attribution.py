"""Attribute development-period errors by issue-time NWP and lead without refitting."""
import numpy as np
import pandas as pd

from run_point_residual import ROOT, OUT as BASE, load_farms, feature_array, index
from pooling_common import local_heads
from revision_common import calibration, frozen_spec, write

YEAR = 2012
OUT = ROOT/'out_gefcom2012_data_attribution'
MODELS = ('qrf','last_value','previous_day')


def match_truth(up, alarm):
    """Return observed ramp hours matched one-to-one within one issued day."""
    out = np.zeros_like(up)
    for i,(a,b) in enumerate(zip(up,alarm)):
        true, pred = np.flatnonzero(a), np.flatnonzero(b)
        j=k=0
        while j<len(true) and k<len(pred):
            gap = pred[k]-true[j]
            if gap < -1:
                k+=1
            elif gap > 1:
                j+=1
            else:
                out[i,true[j]]=True
                j+=1
                k+=1
    return out


def farm_data(farm,d):
    h = d['history']
    with np.load(BASE/f'gefcom2012/farm_{farm:02}/heads.npz') as z:
        np.testing.assert_array_equal(z['origins'],d['origins'])
        qrf = z['qrf']
    ids,result = calibration(d,*local_heads(YEAR,farm,'QRF',0),'validation')
    assert d['valid'][ids].all()
    assert (result['max_label_end_used']<=d['origins'][ids]).all()
    with np.load(BASE/f'gefcom2012/farm_{farm:02}/validation_direct_qrf.npz') as z:
        np.testing.assert_array_equal(ids,z['ids'])
        upper=z['hi']
        np.testing.assert_array_equal(upper,np.clip(result['hi'],0,1))
        np.testing.assert_array_equal(z['lo'],np.clip(result['lo'],0,1))
    y=d['y'][ids]
    last=h[ids,-1,None]
    actual=np.diff(y,axis=1,prepend=last)
    up=actual>.10
    quiet=np.abs(actual)<=.05
    wind=feature_array(YEAR,farm,'GBM')[:,-14:-12].reshape(-1,24,2)[ids]
    speed=np.linalg.norm(wind,axis=2)
    dw=np.diff(speed,axis=1,prepend=np.full((len(ids),1),np.nan))
    nearby=np.column_stack([np.nanmax(dw[:,max(0,j-2):j+3],axis=1) for j in range(24)])
    signal=np.select([~np.isfinite(dw),dw<0,dw<.5,dw<1],['unknown_h1','fall','0_to_0.5','0.5_to_1'],default='1_or_more')
    state=np.select([~np.isfinite(dw),dw>=.5,nearby>=.5],['unknown_h1','same','near_only'],default='none')
    origin=d['origins'][ids]
    issue=pd.to_datetime(d['meta'].nwp_issue.iloc[ids]).to_numpy()
    age=(origin-issue)/np.timedelta64(1,'h')
    assert np.isin(age,[0,12,24]).all()
    np.testing.assert_array_equal(age,d['meta'].nwp_age_hours.to_numpy()[ids])
    lead=np.tile(np.arange(1,25),len(ids))
    target=origin[:,None]+np.arange(1,25)*np.timedelta64(1,'h')
    previous_target=target-np.timedelta64(24,'h')
    np.testing.assert_array_equal(previous_target,origin[:,None]+np.arange(-23,1)*np.timedelta64(1,'h'))
    assert (previous_target<=origin[:,None]).all()
    rows=[]
    for name,pred in zip(MODELS,(qrf[ids],np.broadcast_to(last,y.shape),h[ids])):
        assert np.isfinite(pred).all()
        inc=np.diff(pred,axis=1,prepend=last)
        alarm=inc>.10
        hit=match_truth(up,alarm)
        rows.append(pd.DataFrame(dict(farm=farm,model=name,origin=np.repeat(origin,24),
            issue=np.repeat(issue,24),nwp_age=np.repeat(age.astype(int),24),lead=lead,
            lead_group=np.select([lead<=6,lead<=12],['01-06','07-12'],default='13-24'),
            wind_group=signal.ravel(),wind_state=state.ravel(),wind_delta=dw.ravel(),
            observed=y.ravel(),predicted=pred.ravel(),upper=upper.ravel(),actual_increment=actual.ravel(),
            predicted_increment=inc.ravel(),up=up.ravel(),quiet=quiet.ravel(),alarm=alarm.ravel(),hit=hit.ravel(),
            upper_miss=(y>upper).ravel(),upper_excess=np.maximum(y-upper,0).ravel())))
    return pd.concat(rows,ignore_index=True)


def summarize(frame,keys):
    rows=[]
    for k,g in frame.groupby(keys,sort=True):
        if not isinstance(k,tuple):
            k=(k,)
        a=g[g.up]
        q=g[g.quiet]
        e=a.predicted_increment-a.actual_increment
        misses=a[a.upper_miss]
        rows.append(dict(zip(keys,k),hours=len(g),up_events=len(a),hits=int(a.hit.sum()),quiet_hours=len(q),
            quiet_false=int(q.alarm.sum()),power_mae=float((g.predicted-g.observed).abs().mean()),
            actual_up_mean=a.actual_increment.mean(),predicted_up_mean=a.predicted_increment.mean(),
            increment_bias=e.mean(),increment_mae=e.abs().mean(),recall=a.hit.mean(),quiet_fpr=q.alarm.mean(),
            upper_misses=int(a.upper_miss.sum()),up_upper_miss_rate=a.upper_miss.mean(),
            up_mean_excess=a.upper_excess.mean(),miss_only_mean_excess=misses.upper_excess.mean(),
            all_mean_excess=g.upper_excess.mean()))
    return pd.DataFrame(rows)


def main():
    frozen_spec(OUT/'protocol.json',dict(year=YEAR,stage='2011 Q2 only',farms=list(range(1,8)),
        base='frozen original QRF median and signed rolling84 upper; original intervals identical across point-model comparisons',
        comparators='repeat latest observed power; copy previous-day same-valid-hour values from issued 24h history',
        events='observed and predicted hourly change >.10 of capacity; first lead anchored at last observed; quiet |observed change|<=.05',
        timing='greedy maximum one-to-one ±1 hour on full issued day before stratification; assign matched hit to true event group',
        strata='latest native NWP issue ages 0/12/24h, leads 1–6/7–12/13–24, same-hour NWP change <0/[0,.5)/[.5,1)/>=1 m/s; lead 1 unknown; separate nearby-state and joint tables',
        uncertainty='descriptive development diagnosis; micro counts across farms and per-farm tables; NWP age confounded with calendar, no actual wind or release timestamps'))
    farms=load_farms(YEAR)
    assert list(farms)==list(range(1,8))
    frame=pd.concat([farm_data(f,d) for f,d in farms.items()],ignore_index=True)
    frame.to_csv(OUT/'aligned_hours.csv',index=False)
    for name,keys in [('overall',[]),('age',['nwp_age']),('lead',['lead_group']),
                      ('wind',['wind_group']),('wind_state',['wind_state']),
                      ('joint',['nwp_age','lead_group','wind_group']),('farm',['farm'])]:
        s=summarize(frame,['model',*keys])
        s.to_csv(OUT/f'{name}.csv',index=False)
        if name in ('overall','age','lead','wind','wind_state'):
            print(name,s.round(5).to_string(index=False),flush=True)
    ages=frame.loc[frame.model.eq('qrf'),['farm','origin','nwp_age']].drop_duplicates()
    ages['weekday']=ages.origin.dt.day_name()
    ages.groupby(['nwp_age','weekday']).size().rename('farm_days').to_csv(OUT/'age_weekday.csv')
    write(OUT/'completion.json',dict(status='complete',farms=7,issued_farm_days=len(ages),hours=len(frame)//3))


if __name__=='__main__':
    main()
