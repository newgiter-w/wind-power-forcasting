"""Render the factorial development experiment and locked independent follow-up."""
import json
import pandas as pd

from run_kelmarsh_nwp_context_factorial import OUT,ARMS,LABELS,FACTOR_NAMES
from prepare_hill_of_towie_holdout import OUT as HOLDOUT

NAMES=dict(QRF='原QRF',q90_frozen='冻结年度q90',probability_old_frozen='冻结旧概率模型',**LABELS)
GROUPS={'feb_mar':'2–3月','apr_jun':'4–6月','jul_sep':'7–9月','oct_dec':'10–12月',
    'spring_MAM':'春3–5月','summer_JJA':'夏6–8月','autumn_SON':'秋9–11月','winter_partial_DF':'不完整冬季2月及12月'}


def summary(path,operation,scope='all'):
    d=pd.read_csv(path/'summary.csv')
    return d[(d.operation==operation)&(d.scope==scope)].set_index('model')


def ci(path,contrast,operation='matched_development',scope='all',block=14):
    d=pd.read_csv(path/'paired_blocks.csv')
    return d[(d.operation==operation)&(d.scope==scope)&(d.metric=='recall')&(d.contrast==contrast)&(d.block==block)].iloc[0]


def fmt(r,kind=''):
    lo=r['low' if not kind else kind+'_low'];hi=r['high' if not kind else kind+'_high']
    return f'{100*r.delta:+.2f} [{100*lo:+.2f}, {100*hi:+.2f}]'


def main():
    train=json.loads((OUT/'training_counts.json').read_text())
    decision=json.loads((OUT/'decision.json').read_text())
    year=OUT/'expanded_development'
    m=summary(year,'matched_development')
    independent_done=(HOLDOUT/'completion.json').exists()
    independent_passed=bool(json.loads((HOLDOUT/'completion.json').read_text())['passed']) if independent_done else None
    lines=['# 局部NWP轨迹特征×门控范围2×2｜2026-11-07','',
        f'开发比较完成，选中候选{decision["selected"]}。独立验证状态：'+('已完成，见下文。' if independent_done else '正在获取此前未用的Hill of Towie六机组群2025年数据，尚无独立验证结果。'),
        ('**独立验证未通过：相同64次平稳误报时，D命中104/613，A为112/613、年度q90为99/613；D−q90召回差+0.82pp，95%CI[−2.07,+3.90]。冻结阈值下D误报77次，高于QRF的64次。开发收益未复现为跨场站净收益，不接入区间。**' if independent_done and not independent_passed else ''),
        '所有结果仍是报警分支的证据；原QRF点预测、区间端点及校准没有改变。','',
        '## 设计与训练控制','',
        '- 训练年份保持2022-08至2023-07，共297个完整发报日。共同训练池为第2–24小时6831行，其中624个上爬坡正例、6207个负例；第一时效保留QRF。两个分类器共用完全相同的行与标签，不按门控筛选训练行。',
        '- 原QRF及预处理、年度q90、旧门控训练概率模型权重冻结。新A组使用扩大后的共同小时池，不能冒充旧概率模型的精确复现；旧模型单列为参照。',
        '- 只训练两个HistGB分类器：单时刻9特征、局部轨迹25特征，交叉两个门控形成四组。目标仍为同小时实际功率增幅>0.10容量，log_loss、40轮、7叶、最小叶样本50、L2=1、seed0、无早停；没有重采样、调参或改目标。',
        '- 局部轨迹新增前后1/2小时NWP风速、U/V，前后2小时风速累计变化、局部最大单小时增速及其相对位置，均来自发报时已可用的同一完整24h预报。边界不跨日，缺失为NaN交给固定模型处理。未输入未来实测风或功率。',
        '- 同小时门控：该小时NWP风速增加≥0.5m/s。邻域门控：前后2个时效内任一增速达到阈值。门控外保留原QRF报警。首时效所有组均不使用新分支。',
        '- 原开发期2023-12；扩展开发期2024-02至12为已查看过的Kelmarsh数据，明确作开发/回顾。所有组使用同一批全部625个真实爬坡和4193个平稳小时，平稳误报预算均80次。',
        '- 相同误报匹配是事后开发排序诊断；不同门控内需要匹配的误报数可不同，但加上原QRF门控外误报后总预算相同。所有非爬坡小时误报另行报告，不把它混称平稳误报。',
        '- ±1小时命中按24小时发报日内一对一匹配；分组按真实事件所在小时归属。','',
        '## 开发期主结果','',
        '| 方案 | ±1h命中/真实爬坡 | 召回% | 平稳误报/小时 | 全部非爬坡误报/小时 |',
        '|---|---:|---:|---:|---:|']
    for arm in ARMS:
        r=m.loc[arm]
        lines.append(f'| {arm}：{NAMES[arm]} | {int(r.hits)}/{int(r.events)} | {100*r.recall:.2f} | {int(r["false"])}/{int(r.quiet)} | {int(r.false_nonramps)}/{int(r.nonramps)} |')
    lines.extend(['','| 开发净收益 | 召回差pp [95%CI] | 九项候选比较家族校正区间 |','|---|---:|---:|'])
    for contrast in ('D_vs_A','D_vs_q90_frozen','D_vs_QRF','D_vs_probability_old_frozen'):
        r=ci(year,contrast)
        family=fmt(r,'family9') if contrast!='D_vs_probability_old_frozen' else '非预定九项家族成员，仅作描述'
        lines.append(f'| {contrast} | {fmt(r)} | {family} |')
    lines.extend(['','## 特征、门控及交互','',
        '| 预定效应 | 召回差pp [95%CI] | 五项效应家族校正区间 |','|---|---:|---:|'])
    for name in FACTOR_NAMES:
        r=ci(year,name);lines.append(f'| {name} | {fmt(r)} | {fmt(r,"family5")} |')
    lines.extend(['',
        'feature_same=B−A，feature_near=D−C，gate_point=C−A，gate_context=D−B，interaction=D−C−B＋A。五项效应各报99%边际区间，对该家族按Bonferroni控制95%同时覆盖；与九项候选比较分别定义家族，不能合称所有分析共同95%。',
        '1. 局部轨迹在邻域门控下D−C仍通过五项校正区间，支持已有NWP时间结构的利用存在余量。B−A的普通95%区间高于零，但校正后跨零，证据弱一些。',
        '2. 单独扩大门控C−A的普通区间跨零；D−B普通区间为正，但校正后跨零。不能宣称门控扩大本身已得到稳健确认。',
        '3. 交互点估计为正，区间跨零，没有确认交互效应。不能把D组最好写成显著协同机制。',
        '4. A相对旧概率模型并无点估计改善，说明这轮D的收益不能简单归为训练小时池扩大。','',
        '## 开发期季节稳定性','',
        '| 分组 | 真爬坡 | A命中 | B命中 | C命中 | D命中 | q90命中 | D−A召回差pp [CI] | D−q90召回差pp [CI] |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|'])
    for g,label in GROUPS.items():
        d=summary(OUT/g,'matched_development')
        vals=' | '.join(str(int(d.loc[a,'hits'])) for a in ('A','B','C','D','q90_frozen'))
        lines.append(f'| {label} | {int(d.loc["D","events"])} | {vals} | {fmt(ci(OUT/g,"D_vs_A"))} | {fmt(ci(OUT/g,"D_vs_q90_frozen"))} |')
    lines.extend(['',
        '每个子组单独匹配自身全小时QRF平稳误报数，因此季度命中不必加总为全年工作点命中。各组summary.csv同时保存整期开发工作点原样应用的结果，供检查误报漂移。完整气象季与季度分别报告，冬季只含2月及12月且跨很长间隔，不作为完整冬季确认。',
        '', '## 收益发生在哪里','',
        '| 真实事件分组 | 事件数 | A命中 | B命中 | C命中 | D命中 | q90命中 |','|---|---:|---:|---:|---:|---:|---:|'])
    for scope,label in [('same_signal','原同小时信号'),('nearby_only','仅邻域有信号'),('no_nearby','无邻域信号'),('first_lead','首时效')]:
        d=summary(year,'matched_development',scope)
        vals=' | '.join(str(int(d.loc[a,'hits'])) for a in ('A','B','C','D','q90_frozen'))
        lines.append(f'| {label} | {int(d.loc["D","events"])} | {vals} |')
    lines.extend(['',
        '分组事件互斥且总数等于625；由于全日一对一匹配，分组收益也可来自邻近小时报警变化，不应把所有变化都解释为该小时直接改判。',
        '', '## 冻结与独立验证','',
        '拟合前规则允许B/C/D三个候选，主要召回比较分别对A、QRF、年度q90，共九项，使用Bonferroni家族校正；季度、完整气象季、非爬坡误报及12月守门也预先锁定。只有D通过。D部署概率阈值0.2712544223308311及并列次序均来自Kelmarsh2023-12，不使用2024或新场站标签重新设定。',
        '新独立来源：[RES发布的Hill of Towie数据](https://zenodo.org/records/22662930)。在读取目标前固定2025全年、编号T01–T06六台机组、13.8MW。它不是整个21台风场；无新站拟合或标准化适配，直接迁移Kelmarsh模型。SCADA时间戳按官方说明为UTC区间终点，小时聚合使用ceil(h)，与Kelmarsh的起点标记处理不同。',''])
    if independent_done:
        samples=json.loads((HOLDOUT/'sample_counts.json').read_text())
        verdict=json.loads((HOLDOUT/'decision.json').read_text())
        lines.extend(['独立样本与纳入情况：','', '```json',json.dumps(samples,ensure_ascii=False,indent=2),'```','',
            '实际为2025年中的238/364个合格候选日（65.4%），不是完整无缺测全年。9月仅9/30日、12月8/31日、4月14/30日。所有NWP逐时值和归档时间均完整；排除来自SCADA目标或历史不完整，原因可重叠。逐月纳入表见coverage_by_month.csv，排除原因见exclusion_counts.json。缺测选择可能影响代表性，结论限于完整样本。','',
            '| 独立操作口径 | 方案 | 命中/真爬坡 | 召回% | 平稳误报/小时 | 非爬坡误报/小时 |','|---|---|---:|---:|---:|---:|'])
        for op,label in [('retrospective_same_fpr','事后同误报排序'),('frozen_december','12月冻结规则')]:
            d=summary(HOLDOUT/'all',op)
            for arm in ARMS:
                r=d.loc[arm]
                lines.append(f'| {label} | {arm} | {int(r.hits)}/{int(r.events)} | {100*r.recall:.2f} | {int(r["false"])}/{int(r.quiet)} | {int(r.false_nonramps)}/{int(r.nonramps)} |')
        lines.extend(['','| 独立对比 | 事后同误报召回差pp [95%CI] | 冻结规则召回差pp [95%CI] |','|---|---:|---:|'])
        for ref in ('A','q90_frozen','QRF'):
            lines.append(f'| D−{ref} | {fmt(ci(HOLDOUT/"all",f"D_vs_{ref}",operation="retrospective_same_fpr"))} | {fmt(ci(HOLDOUT/"all",f"D_vs_{ref}",operation="frozen_december"))} |')
        lines.extend(['','| 独立气象季 | D同误报命中/事件 | q90同误报命中 | D−q90召回差pp [CI] | D冻结命中/事件 | D冻结误报/平稳小时 |','|---|---:|---:|---:|---:|---:|'])
        for g in ('winter_DJF','spring_MAM','summer_JJA','autumn_SON'):
            a=summary(HOLDOUT/g,'retrospective_same_fpr');b=summary(HOLDOUT/g,'frozen_december').loc['D'];r=a.loc['D']
            lines.append(f'| {g} | {int(r.hits)}/{int(r.events)} | {int(a.loc["q90_frozen","hits"])} | {fmt(ci(HOLDOUT/g,"D_vs_q90_frozen",operation="retrospective_same_fpr"))} | {int(b.hits)}/{int(b.events)} | {int(b["false"])}/{int(b.quiet)} |')
        lines.extend(['','独立门槛判定：','', '```json',json.dumps(verdict,ensure_ascii=False,indent=2),'```','',
            '独立数据上的same_fpr用到了独立标签来匹配预算，只能确认分数排序的迁移；实际运行验证必须同时看frozen_december，不能把两者混称部署效果。新场站为不同机型、轮毂高度和地形，结论只适用于这组固定机组的零样本迁移。',''])
        lines.extend(['D冻结规则相对QRF多命中29次，也多13次平稳误报；误报率点差+0.37pp，95%CI[−0.17,+0.77]。它违反预定“不增加误报”的点守门，但不能称为统计上显著增加。相同预算下的微小净增益仍未确认，不能拿冻结工作点更多命中替代同误报比较。','',
            '| 独立效应 | 召回差pp [95%CI] | 五项效应校正区间 |','|---|---:|---:|'])
        for effect in FACTOR_NAMES:
            r=ci(HOLDOUT/'all',effect,operation='retrospective_same_fpr')
            lines.append(f'| {effect} | {fmt(r)} | {fmt(r,"family5")} |')
        lines.extend(['',
            '独立数据的特征效应点估计转为负；即使交互项为正，也不能抵消D相对A的负净收益。交互项显著不等于联合方案优于基线，不据此重新选模型或包装跨站成功。','',
            '| D−q90召回差pp | 7日块95%CI | 14日块95%CI | 28日块95%CI |','|---|---:|---:|---:|',
            '| 开发 | '+' | '.join(fmt(ci(year,'D_vs_q90_frozen',block=b)) for b in (7,14,28))+' |',
            '| 独立事后同预算 | '+' | '.join(fmt(ci(HOLDOUT/'all','D_vs_q90_frozen',operation='retrospective_same_fpr',block=b)) for b in (7,14,28))+' |','',
            '开发D−q90的九项校正下界在14日主分析为+0.19pp，28日敏感性为−0.17pp。主门槛按事先锁定的14日执行，但不能宣称所有区块长度下均通过比较校正。',''])
    lines.extend(['## 不确定性和核验','',
        '- 2000次配对非循环日历移动区块，14日为主，7/28日敏感性；模型、分数及诊断阈值条件固定，重采样内不重新估计阈值，不包含重训不确定性。家族校正尾部仅约若干次重采样，分位数有Monte Carlo误差，不应过度解释贴近零的边界。',
        '- 分组比较是预定的描述性开发检查；此前多轮查看的2024数据不能升格为独立确认。',
        '- 真正核验了共同训练行/标签、模型配置、特征不依赖未来目标、局部窗不跨发报日、不同门控的全小时预算一致、区域互斥、冻结权重哈希不变以及三条旧基线全计数精确复现。',
        '- 辅助审查独立复算了模型输出、逐日计数、配对区间和SCADA聚合，确认真实观测标签。按固定物理容量裁剪改变0个独立爬坡标签、4个平稳标签。审查为同模型家族、provisional，完整性WARN不等于性能通过；见EXPERIMENT_AUDIT.md。',
        '- 原始独立守门未包含跨年初/年末两段的DJF；审查后按冻结协议字面补入冬季核验，D/q90均31/207，结论完全不变。补强完整QRF/预处理/q90/旧分类器/新分类器/阈值哈希链，post_audit_verification.json记录无重评分、无重训、无判定变化。source_executed.py保留原执行版本。',
        '- NOAA归档对象时间支持名义发报前可用性，但不是历史API送达或SCADA入库延迟的证据。Kelmarsh起点标记仍是原研究假定；Hill of Towie终点标记有官方定义。应称离线名义发报回放，不能声称已验证实时上线效果。',
        '- 源码、模型、逐小时评分、逐日计数、诊断工作点和配对区间均保存，完整性记录见verification.json。区间端点未改，本实验没有产生新的区间覆盖、宽度或IS结果。','',
        '## 复现','', '```powershell','python -m unittest test_kelmarsh_nwp_context_factorial -v','python -u run_kelmarsh_nwp_context_factorial.py',
        'python -u prepare_hill_of_towie_holdout.py scada','python -u prepare_hill_of_towie_holdout.py weather','python prepare_hill_of_towie_holdout.py pair',
        'python -u validate_hill_of_towie_context_factorial.py','python report_kelmarsh_nwp_context_factorial.py','```','',
        '独立来源的README、字段字典、静态表与metadata.json已保存在independent_hill_of_towie；源ZIP按HTTP Range只取相关表，ZipFile验证表CRC。原数据仍按源CC-BY-4.0许可归属RES/TRIG。',''])
    (OUT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print('REPORT',OUT/'RESULTS.md')


if __name__=='__main__':main()
