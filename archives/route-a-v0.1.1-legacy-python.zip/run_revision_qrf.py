"""True leaf-response QRF, selected on 2014 Q2 then transferred unchanged."""
import os
for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[name] = '2'
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / '.aris/qrf-packages'))
import gc
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from quantile_forest import RandomForestQuantileRegressor
from threadpoolctl import threadpool_limits
from gefcom_protocol_v2 import prepare, index
from run_gefcom_tail_dynamic import base_matrix
from revision_common import OUT, collect, write, frozen_spec, save_stage, save_metrics, reference_intervals

DEST = OUT / 'qrf'


def fit_predict(year, farm, d, leaf, seed):
    folder = DEST / f'gefcom{year}/farm_{farm:02d}/leaf_{leaf}/seed_{seed}'
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / 'heads.npz'
    if path.exists() and (folder / 'model.joblib').exists() and (folder / 'fit.json').exists():
        with np.load(path) as z: return folder, z['lo'], z['hi']
    began = time.perf_counter()
    X = base_matrix(d, year)
    tr = index(d, 'train', True)
    tm = np.repeat(np.isin(np.arange(len(d['y'])), tr), 24)
    imputer = SimpleImputer(strategy='median', add_indicator=True, keep_empty_features=True).fit(X[tm])
    xx = imputer.transform(X)
    model = RandomForestQuantileRegressor(n_estimators=500, min_samples_leaf=leaf,
        max_features=1., max_samples_leaf=None, random_state=seed, n_jobs=2)
    model.fit(xx[tm], d['y'].ravel()[tm])
    fit_seconds = time.perf_counter()-began
    # Proper training dates never enter calibration or comparison metrics.
    forecast = np.flatnonzero(~d['meta'].phase.eq('train').to_numpy())
    ids = (forecast[:, None]*24+np.arange(24)).ravel()
    pred = np.full((len(X), 2), np.nan)
    for chunk in np.array_split(ids, max(1, int(np.ceil(len(ids)/512)))):
        pred[chunk] = model.predict(xx[chunk], quantiles=[.05,.95], weighted_quantile=True,
            weighted_leaves=True, aggregate_leaves_first=True)
    lo, hi = pred[:, 0].reshape(-1,24), pred[:,1].reshape(-1,24)
    np.savez_compressed(path, lo=lo, hi=hi, origins=d['origins'], forecast_indices=forecast)
    joblib.dump(dict(model=model, imputer=imputer), folder / 'model.joblib', compress=3)
    write(folder / 'fit.json', dict(seed=seed, min_samples_leaf=leaf, n_estimators=500,
        train_cells=int(tm.sum()), features=xx.shape[1], fit_seconds=fit_seconds,
        total_seconds=time.perf_counter()-began, max_samples_leaf=None, weighted_leaves=True,
        train_predictions='not generated; training entries explicitly NaN'))
    del model, xx, X; gc.collect()
    print(f'QRF {year} farm{farm:02d} leaf{leaf} seed{seed} {time.perf_counter()-began:.1f}s', flush=True)
    return folder, lo, hi


def score(rows, year, farm, d, leaf, seed, stage):
    folder, lo, hi = fit_predict(year, farm, d, leaf, seed)
    ids, result = save_stage(folder, d, lo, hi, stage)
    for name, ll, uu in [('raw',np.clip(lo[ids],0,1),np.clip(hi[ids],0,1)),
                         ('signed',np.clip(result['lo'],0,1),np.clip(result['hi'],0,1))]:
        collect(rows,d,ids,ll,uu,year=year,farm=farm,seed=seed,stage=stage,method=f'QRF_leaf{leaf}_{name}')


def score_job(year, farm, d, leaf, seed, stages):
    rows = []
    for stage in stages:
        score(rows, year, farm, d, leaf, seed, stage)
    return rows


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    frozen_spec(DEST / 'protocol.json', dict(seeds=[0,1,2], n_estimators=500, leaves=[10,30,60],
        max_features=1., max_samples_leaf=None, weighted_quantile=True, weighted_leaves=True,
        aggregate_leaves_first=True, input='factorial_v2 canonical R2 122/123; training median plus missing indicators',
        selection='2014Q2 seed0 macro IS minimum subject coverage>=.90; fallback highest coverage then IS',
        transfer='same leaf for all farms, seeds and datasets; no 2012 selection',
        calibration='per-lead signed rolling84, clip[0,1]', evaluation='retrospective, previously inspected dates',
        package='quantile-forest 1.4.2 project-local --no-deps'))
    began = time.perf_counter(); rows = []
    farms14,_ = prepare(2014)
    for leaf in [10,30,60]:
        with ThreadPoolExecutor(max_workers=6) as pool:
            jobs=[pool.submit(score_job,2014,farm,d,leaf,0,['validation']) for farm,d in farms14.items()]
            for future in as_completed(jobs): rows.extend(future.result())
        save_metrics(DEST,rows)
    macro = pd.DataFrame(rows).groupby(['method','group'])[['coverage','IS']].mean()
    candidates = []
    for leaf in [10,30,60]:
        row = macro.loc[(f'QRF_leaf{leaf}_signed','all')]
        candidates.append(dict(leaf=leaf,coverage=float(row.coverage),IS=float(row.IS)))
    good = [c for c in candidates if c['coverage']>=.90]
    chosen = min(good,key=lambda c:c['IS']) if good else min(candidates,key=lambda c:(-c['coverage'],c['IS']))
    leaf = chosen['leaf']
    write(DEST/'selection.json',dict(selected_leaf=leaf,candidates=candidates,source='2014Q2 seed0 only'))
    for year,farms in [(2014,farms14),(2012,prepare(2012)[0])]:
        with ThreadPoolExecutor(max_workers=6) as pool:
            jobs=[pool.submit(score_job,year,farm,d,leaf,seed,
                ['evaluation'] if year==2014 and seed==0 else ['validation','evaluation'])
                for seed in [0,1,2] for farm,d in farms.items()]
            for future in as_completed(jobs):
                rows.extend(future.result());save_metrics(DEST,rows)
        for farm,d in farms.items():
            for stage in ['validation','evaluation']:
                ids,L,U=reference_intervals(year,farm,stage)
                collect(rows,d,ids,L,U,year=year,farm=farm,seed=-1,stage=stage,method='R2_reference')
        save_metrics(DEST,rows)
    write(DEST/'completion.json',dict(status='complete',selected_leaf=leaf,elapsed_seconds=time.perf_counter()-began))


if __name__ == '__main__':
    with threadpool_limits(limits=2): main()
