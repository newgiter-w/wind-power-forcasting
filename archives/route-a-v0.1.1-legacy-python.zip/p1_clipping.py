"""P1: physical clipping [0,1] as unified post-processing on frozen B_speed.

Loads the already-saved B_speed raw predictions + rolling-CQR intervals, applies
clip(L,0,1)/clip(U,0,1), and reports 4 variants (raw/cqr x unclipped/clipped).
No retraining. Baseline for P2 = B_speed + CQR + clipping (~IS 0.7432).
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from gefcom2014_experiment import metrics

ROOT = Path(__file__).parent
SRC = ROOT / 'out_gefcom_protocol_v2' / 'gefcom2014'
OUT = ROOT / 'out_gefcom_strong_baselines_v1'


def clip(lo, hi):
    return np.clip(lo, 0.0, 1.0), np.clip(hi, 0.0, 1.0)


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    records = []
    for farm in range(1, 11):
        sp = SRC / f'farm_{farm:02d}'
        with np.load(sp / 'samples.npz') as z:
            y, valid, history = z['y'], z['valid'], z['history']
        with np.load(sp / 'B_speed' / 'raw_predictions.npz') as z:
            raw_lo, raw_hi = z['lo'], z['hi']
        with np.load(sp / 'B_speed' / 'evaluation_intervals.npz') as z:
            cqr_lo, cqr_hi, idx = z['lo'], z['hi'], z['indices']
        yy = y[idx]; vv = valid[idx]; last = history[idx, -1]
        variants = {
            'raw_unclipped': (raw_lo[idx], raw_hi[idx]),
            'raw_clipped': clip(raw_lo[idx], raw_hi[idx]),
            'cqr_unclipped': (cqr_lo, cqr_hi),
            'cqr_clipped': clip(cqr_lo, cqr_hi),
        }
        # out-of-bounds proportion (on cqr, the primary variant)
        oob = float(np.mean((cqr_lo < 0) | (cqr_hi > 1) | (cqr_lo > 1) | (cqr_hi < 0)))
        for name, (L, U) in variants.items():
            met = metrics(yy, L, U, vv, last)
            for g, v in met.items():
                records.append(dict(farm=farm, variant=name, group=g, oob=oob if name == 'cqr_unclipped' else None, **v))
    df = pd.DataFrame(records)
    df.to_csv(OUT / 'p1_clipping_metrics_per_farm.csv', index=False)
    macro = df.groupby(['variant', 'group'])[['coverage', 'width', 'IS', 'lower_miss', 'upper_miss']].mean().reset_index()
    macro.to_csv(OUT / 'p1_clipping_metrics_macro.csv', index=False)
    print('\n===== P1 clipping macro (10 farms, B_speed) =====')
    for g in ('all', 'up_ramp', 'near_zero'):
        for v in ('raw_unclipped', 'raw_clipped', 'cqr_unclipped', 'cqr_clipped'):
            r = macro[(macro.variant == v) & (macro.group == g)].iloc[0]
            print(f"  {g:9s} {v:15s} cov={r['coverage']*100:5.1f}% w={r['width']*100:5.2f}% IS={r['IS']:.4f} "
                  f"Lo={r['lower_miss']*100:4.1f}% Hi={r['upper_miss']*100:4.1f}%")
    (OUT / 'p1_summary.json').write_text(json.dumps(
        {'note': 'physical clipping [0,1] on frozen B_speed', 'macro': macro.to_dict('records')},
        ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(f'\n[done] -> out_gefcom_strong_baselines_v1/ ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    main()
