"""Array verification, paired temporal uncertainty, and causal-feature diagnostics."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.isotonic import IsotonicRegression
from gefcom_protocol_v2 import BASE,DATA,metrics,masks,write,load_raw,sha

def verify_sources(year,out):
    spec=json.loads((out/'protocol.json').read_text(encoding='utf-8'))
    for path,expected in spec['source_sha256'].items():assert sha(Path(path))==expected
    if year==2014:
        raw,_=load_raw();power={int(z):g.set_index('timestamp').TARGETVAR for z,g in raw.groupby('ZONEID')}
        weather={int(z):g.set_index('timestamp')[['U10','V10','U100','V100']] for z,g in raw.groupby('ZONEID')}
    else:
        raw=pd.read_csv(DATA/'gefcom2012_wind/data/windpowermeasurements.csv')
        raw.index=pd.to_datetime(raw.date.astype(str),format='%Y%m%d%H')
        power={i:raw[f'wp{i}'] for i in range(1,8)};weather={}
    count=0
    for folder in sorted(out.glob('farm_*')):
        farm=int(folder.name.split('_')[-1]);md=pd.read_csv(folder/'issued_manifest.csv')
        with np.load(folder/'samples.npz') as z:hist=z['history'];y=z['y'];w=z['nwp']
        if year==2012:
            native=pd.read_csv(DATA/f'gefcom2012_wind/data/windforecasts_wf{farm}.csv')
            native['issue']=pd.to_datetime(native.date.astype(str),format='%Y%m%d%H')
            groups={t:g.set_index('hors') for t,g in native.groupby('issue')}
        for k,r in md.iterrows():
            origin=pd.Timestamp(r.origin)
            ti=pd.date_range(origin+pd.Timedelta(hours=1),periods=24,freq='h')
            hi=pd.date_range(origin-pd.Timedelta(hours=23),periods=24,freq='h')
            np.testing.assert_equal(y[k],power[farm].reindex(ti).to_numpy())
            np.testing.assert_equal(hist[k],power[farm].reindex(hi).to_numpy())
            if year==2014:expected=weather[farm].reindex(ti).to_numpy()
            else:
                issue=pd.Timestamp(r.nwp_issue);age=int(r.nwp_age_hours)
                assert issue<=origin and issue+pd.Timedelta(hours=age)==origin
                expected=groups[issue].reindex(np.arange(age+1,age+25))[['u','v']].to_numpy()
            np.testing.assert_equal(w[k],expected);count+=1
    write(out/'source_array_verification.json',dict(raw_sha256_match=True,all_histories_targets_and_nwp_matched=True,
          checked_origins=count,native_issue_lead_checked=year==2012))

def verify_dataset(year,selected):
    out=BASE/f'gefcom{year}'
    done=json.loads((out/'completion.json').read_text(encoding='utf-8'))
    assert done['status']=='complete'
    verify_sources(year,out)
    methods=done['methods'];farms=done['farms'];computed=[];diag=[];service=[]
    all_dates=None;daily=None;checks=[];bootstrap_groups=['all','up_ramp','near_zero']
    for farm in range(1,farms+1):
        folder=out/f'farm_{farm:02d}'
        md=pd.read_csv(folder/'issued_manifest.csv')
        with np.load(folder/'samples.npz') as z:
            y=z['y'];h=z['history'];w=z['nwp'];v=z['valid'];origins=z['origins'];ends=z['ends']
        train=(md.phase=='train').to_numpy()&v
        # Wind-to-power proxy is fitted only on training labels, for diagnostics.
        ws=np.hypot(w[:,:,-2],w[:,:,-1])
        iso=IsotonicRegression(y_min=0,y_max=1,out_of_bounds='clip')
        iso.fit(ws[train].ravel(),y[train].ravel())
        mapped=iso.predict(ws.ravel()).reshape(ws.shape)
        proxy_change=np.diff(mapped,axis=1,prepend=h[:,-1,None])
        for j,method in enumerate(methods):
            sub=folder/method
            with np.load(sub/'evaluation_intervals.npz') as z:
                idx=z['indices'];lo=z['lo'];hi=z['hi'];maxlabel=z['max_label_end']
            with np.load(sub/'raw_predictions.npz') as z:rawlo=z['lo'][idx];rawhi=z['hi'][idx]
            assert np.array_equal(idx,np.flatnonzero(md.phase.eq('evaluation')))
            assert (maxlabel<=origins[idx]).all()
            assert (ends[train].max()<=origins[np.flatnonzero(md.phase.eq('validation_seed'))[0]])
            assert np.isfinite(lo).all() and np.isfinite(hi).all() and (lo<=hi).all()
            if j==0:refidx=idx.copy()
            else:assert np.array_equal(refidx,idx)
            met=metrics(y[idx],lo,hi,v[idx],h[idx,-1])
            for group,m in met.items():computed.append(dict(farm=farm,method=method,stage='evaluation_cqr',group=group,**m))
            if all_dates is None:
                start='2013-07-01' if year==2014 else '2011-07-01'
                end=pd.to_datetime(pd.read_csv(out/'calendar_manifest.csv').origin).max()
                all_dates=pd.date_range(start,end,freq='D')
                daily=np.zeros((len(methods),farms,len(all_dates),3,4))
            yy=y[idx];hit=(yy>=lo)&(yy<=hi);width=hi-lo
            score=width+20*np.maximum(lo-yy,0)+20*np.maximum(yy-hi,0)
            gs=masks(yy,h[idx,-1])
            for k,o in enumerate(origins[idx]):
                pos=all_dates.get_indexer([pd.Timestamp(o)])[0];assert pos>=0
                for g,group in enumerate(bootstrap_groups):
                    mask=gs[group][k]&v[idx[k]]
                    daily[j,farm-1,pos,g]=[mask.sum(),hit[k,mask].sum(),width[k,mask].sum(),score[k,mask].sum()]
            checks.append(dict(farm=farm,method=method,issued=len(idx),scored=int(v[idx].sum()),labels_arrived=True,
                               targets_finite_when_scored=bool(np.isfinite(y[idx][v[idx]]).all())))
            if method!=selected:continue
            dactual=np.diff(yy,axis=1,prepend=h[idx,-1,None])
            for k,global_i in enumerate(idx):
                if not v[global_i]:continue
                for lead in range(24):
                    diag.append(dict(farm=farm,origin=str(origins[global_i]),lead=lead+1,
                         lead_bin='01-06' if lead<6 else ('07-12' if lead<12 else '13-24'),
                         y=float(yy[k,lead]),actual_change=float(dactual[k,lead]),
                         up_ramp=bool(dactual[k,lead]>.1),near_zero=bool(abs(yy[k,lead])<=.01),
                         predicted_ws=float(ws[global_i,lead]),training_curve_power=float(mapped[global_i,lead]),
                         forecast_power_change=float(proxy_change[global_i,lead]),
                         forecast_up_signal=bool(proxy_change[global_i,lead]>.05),
                         raw_upper_miss=bool(yy[k,lead]>rawhi[k,lead]),raw_lower_miss=bool(yy[k,lead]<rawlo[k,lead]),
                         upper_miss=bool(yy[k,lead]>hi[k,lead]),lower_miss=bool(yy[k,lead]<lo[k,lead]),
                         covered=bool(hit[k,lead]),width=float(width[k,lead]),IS=float(score[k,lead])))
    table=pd.DataFrame(computed)
    saved=pd.read_csv(out/'metrics_per_farm.csv').query("stage=='evaluation_cqr'")
    joined=table.merge(saved,on=['farm','method','stage','group'],suffixes=('_recomputed','_saved'),validate='one_to_one')
    for k in ['coverage','width','IS','lower_miss','upper_miss','cells','origins']:
        assert np.allclose(joined[k+'_recomputed'],joined[k+'_saved'],equal_nan=True)
    write(out/'array_recheck.json',dict(all_saved_metrics_recomputed=True,paired_origins=True,checks=checks))
    def aggregate(a):
        t=a.sum(axis=2)
        divided=np.divide(t[:,:,:,1:],t[:,:,:,0,None],out=np.full(t[:,:,:,1:].shape,np.nan),where=t[:,:,:,0,None]>0)
        return np.nanmean(divided,axis=1)
    point=aggregate(daily);rng=np.random.default_rng(20261102);brows=[]
    # Same calendar draw for ALL farms and models; preserve spatial dependence.
    for block in [7,14]:
        boots=[]
        for _ in range(1000):
            starts=rng.integers(0,len(all_dates)-block+1,size=int(np.ceil(len(all_dates)/block)))
            idx=np.concatenate([np.arange(s,s+block) for s in starts])[:len(all_dates)]
            boots.append(aggregate(daily[:,:,idx]))
        boots=np.array(boots)
        pairs=[(m,'A_history') for m in methods if m!='A_history']
        if 'B_speed' in methods:pairs.append(('B_speed','B_uv'))
        if 'C_speed' in methods:pairs.extend([('C_speed','C_uv'),('C_speed','B_speed')])
        for method,base in pairs:
            a=methods.index(method);b=methods.index(base)
            for g,group in enumerate(bootstrap_groups):
                for k,metric in enumerate(['coverage','width','IS']):
                    dif=boots[:,a,g,k]-boots[:,b,g,k]
                    brows.append(dict(method=method,baseline=base,group=group,metric=metric,block_days=block,
                                      delta=float(point[a,g,k]-point[b,g,k]),low95=float(np.quantile(dif,.025)),high95=float(np.quantile(dif,.975))))
    pd.DataFrame(brows).to_csv(out/'paired_bootstrap.csv',index=False)
    cells=pd.DataFrame(diag);cells.to_csv(out/'diagnostic_cells.csv',index=False)
    def summarize(frame):
        return pd.Series(dict(cells=len(frame),coverage=frame.covered.mean(),upper_miss=frame.upper_miss.mean(),
              lower_miss=frame.lower_miss.mean(),raw_upper_miss=frame.raw_upper_miss.mean(),
              raw_lower_miss=frame.raw_lower_miss.mean(),width=frame.width.mean(),IS=frame.IS.mean()))
    ups=cells[cells.up_ramp]
    bycue=ups.groupby('forecast_up_signal').apply(summarize,include_groups=False).reset_index()
    bycue.to_csv(out/'up_ramp_by_forecast_signal.csv',index=False)
    bylead=ups.groupby('lead_bin').apply(summarize,include_groups=False).reset_index()
    bylead.to_csv(out/'up_ramp_by_lead.csv',index=False)
    write(out/'diagnostic_protocol.json',dict(selected=selected,forecast_proxy='training-only isotonic wind-speed-to-power map',
             signal='proxy power at h minus h-1 > .05; first hour vs observed last power',
             caveat='Absent signal does not prove NWP itself is wrong; actual ramp grouping is post-hoc diagnosis, never predictor input'))
    # Per-lead plots use normalized capacity percentage for coverage and width.
    leads=pd.read_csv(out/'metrics_per_lead.csv').groupby(['method','lead'])[['coverage','width','IS']].mean().reset_index()
    fig,axes=plt.subplots(1,3,figsize=(13,3.7))
    for method in methods:
        d=leads[leads.method.eq(method)]
        for ax,k in zip(axes,['coverage','width','IS']):ax.plot(d.lead,d[k]*(100 if k!='IS' else 1),label=method)
    axes[0].axhline(90,color='gray',ls='--',lw=1)
    for ax,title in zip(axes,['Coverage (%)','Width (% capacity)','Interval score']):
        ax.set_title(title);ax.set_xlabel('Forecast hour');ax.grid(alpha=.2)
    axes[-1].legend(fontsize=7);fig.suptitle(f'GEFCom{year}: frozen protocol v2, macro over {farms} farms')
    fig.tight_layout();fig.savefig(out/'per_lead.png',dpi=180);fig.savefig(out/'per_lead.pdf');plt.close(fig)
    return pd.read_csv(out/'metrics_macro.csv')

def main():
    policy=json.loads((BASE/'frozen_transfer_policy.json').read_text(encoding='utf-8'))
    results={}
    for year,method in [(2014,policy['method']),(2012,policy['transfer_choice'])]:
        results[year]=verify_dataset(year,method)
    lines=['# GEFCom 协议修正、风速表示与跨数据验证','',
           '日期：2026-11-02。顺序：修正首小时爬坡/输入质量/日志；2014内部验证选表示；冻结后评价2014并验证2012。原始DeepSeek输出保留。','',
           '## 冻结选择','',f"2014选择 `{policy['method']}`，迁移到2012的单层风场为 `{policy['transfer_choice']}`。只依据2014 Apr-Jun验证，覆盖>=88%后按IS选取，1%近最佳范围按较少特征优先；该简化规则不是等效性证明。",'',
           '2014训练2012；Jan-Mar2013作验证种子、Apr-Jun作表示验证；Jul-Dec为已接触过的内部回溯评价。2012训练2009H2+2010，2011Q1作种子、Q2作诊断、2011H2至2012H1作冻结评价。2012测试未用于重新选型。','',
           '## 总体评价结果（校准后，各场宏平均）','',
           '| 数据 | 输入 | 覆盖率 | 宽度/容量 | IS |','|---|---|---:|---:|---:|']
    for year,df in results.items():
        for _,r in df[(df.stage=='evaluation_cqr')&(df.group=='all')].iterrows():
            lines.append(f'| {year} | {r.method} | {100*r.coverage:.2f}% | {100*r.width:.2f}% | {r.IS:.4f} |')
    for year,method in [(2014,policy['method']),(2012,policy['transfer_choice'])]:
        df=results[year];lines+=['',f'## {year} 冻结方案的分工况','',
                  '| 工况 | 历史基线：覆盖/宽度/IS | 冻结NWP方案：覆盖/宽度/IS |','|---|---|---|']
        for g in ['all','up_ramp','down_ramp','near_zero']:
            vs=[]
            for m in ['A_history',method]:
                r=df[(df.stage=='evaluation_cqr')&(df.group==g)&(df.method==m)].iloc[0]
                vs.append(f'{r.coverage*100:.2f}% / {r.width*100:.2f}% / {r.IS:.4f}')
            lines.append('| '+g+' | '+' | '.join(vs)+' |')
        out=BASE/f'gefcom{year}';counts=pd.read_csv(out/'calendar_manifest.csv')
        counts=counts[counts.phase.eq('evaluation')]
        issued=counts[counts.input_valid];scored=issued[issued.target_valid]
        lines+=['',f'评价日历：{len(counts)}场日，发预测{len(issued)}（服务率{len(issued)/len(counts):.2%}），其中完整目标评分{len(scored)}。未发日原因及预报年龄见calendar_manifest.csv；A与所有NWP组在相同可服务子集比较。',
                '', '上升爬坡按训练期拟合的风速—功率代理是否给出>0.05上升信号分组（单元格加权诊断）：','',
                '| 有预报上升信号 | 单元格 | 覆盖 | 上尾漏点 | 校准前上尾漏点 |','|---|---:|---:|---:|---:|']
        for _,r in pd.read_csv(out/'up_ramp_by_forecast_signal.csv').iterrows():
            lines.append(f'| {r.forecast_up_signal} | {int(r.cells)} | {r.coverage*100:.2f}% | {r.upper_miss*100:.2f}% | {r.raw_upper_miss*100:.2f}% |')
    lines+=['','## 解释与限制','',
           '- 修正后的历史完整性规则与DeepSeek保留NaN的旧协议不同，因此新旧绝对数值不直接归因风速表示；本轮各表示严格同样本、同训练与校准。',
           '- 校准前/后、上下尾、逐场和时效指标已保存；首小时相对最后观测功率计算爬坡。没有填补目标，没有根据未来标签质量取消发预测。',
           '- 2012按起报时间选择完整24h预报，候选批次年龄0/12/24h，选最新可用；native lead为age+1..age+24。NWP组增加年龄特征。它只有一个风场高度，不称100m高度复现。',
           '- 确定性风速模长由已有U/V计算，增加的是表示而非外部信息。GEFCom2012内仍报告uv与uv+speed两个固定对照，但不根据测试重新选型。',
           '- 7/14日移动区块bootstrap同步抽日期给全部风场与方法，1000次；描述本回溯时期的配对不确定性，未作多重比较校正。',
           '- 历史/NWP缺失引起可服务子集选择，服务率与未发原因单独报告；不能把子集精度当作全日历服务能力。',
           '- 区间未按[0,1]裁剪，与旧CQR一致；不把裁剪收益归功于NWP。整体约90%不保证条件工况90%，时序非交换性下不声称严格覆盖保证。',
           '- 风速到功率的isotonic代理只在训练期拟合，能提示预报轨迹是否提供上升信号；不能据此唯一判定NWP误差或真实物理原因。',
           '- 2014按竞赛有效时间协议，没有原生起报字段；2012按档案起报时间。均假设无额外功率/NWP发布延迟。',
           '', '## 可复现产物','',
           '- gefcom_protocol_v2.py / analyze_gefcom_protocol_v2.py：运行与分析入口；test_gefcom_protocol_v2.py：3项关键时序/分组回归检查。',
           '- frozen_transfer_policy.json：在2014评价和2012测试指标生成前冻结的规则。',
           '- gefcom2014/ 与 gefcom2012/：protocol.json、原始文件SHA-256、模型/Scaler、预测数组、服务日历、反馈日志、逐场/宏平均/逐时效指标、配对bootstrap和诊断。',
           '- source_before_changes.zip：修正前原代码与叙述存档。','']
    (BASE/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print('VERIFICATION AND REPORT COMPLETE',flush=True)

if __name__=='__main__':main()
