"""Acquire a prelocked new site/year, keeping operational forecasts genuine."""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import io
import json
from pathlib import Path
import zipfile

import numpy as np
import pandas as pd

from pair_kelmarsh_gfs import request,fetch_weather
from revision_common import frozen_spec,write
from run_kelmarsh_nwp_context_factorial import OUT as EXPERIMENT,sha

OUT=EXPERIMENT/'independent_hill_of_towie'
URL='https://zenodo.org/records/22662930/files/2025.zip'
SIZE=1596220683
TURBINES=tuple(f'T{i:02}' for i in range(1,7))
STATIONS=tuple(range(2304510,2304516))
CAPACITY=13800
MONTHS=tuple(f'2025-{m:02}' for m in range(1,13))


def lock():
    frozen_spec(OUT/'protocol.json',dict(site='Hill of Towie,T01–T06 fixed first6 IDs,13.8MW,not entire21-turbine farm',
        record='https://zenodo.org/records/22662930',year=2025,months=list(MONTHS),turbines=list(TURBINES),stations=list(STATIONS),
        selection='IDs and entire year fixed from source metadata only, before reading power targets; no performance-based date filtering',
        trained='frozen Kelmarsh QRF,preprocessing,annual q90,old classifier,point/context common-pool classifiers; no fitting or adaptation at new site',
        selected='D context25 with ±2h NWP gate; probability threshold0.2712544223308311 from Kelmarsh December2023 only',
        forecast='same100m GFS prior18UTC cycle,00UTC issuance,native leads7–30; actual GRIB LastModified<=issue required',
        wind_location='mean latitude/longitude of T01–T06; same nearest0.25degree GFS grid selection as prior studies',
        scada='source timestamps explicitly UTC interval-end; target hour=ceil(timestamp,h),unlike Kelmarsh start-labeled convention;6turbines x6 readings per field; finite consistent duplicates only',
        quality='complete24 future targets with valid wind/power and24 observed power history; power normalized by13.8MW then same[0,1] clip; no filling; report omissions and out-of-support range',
        boundary='Jan1 issue excluded because2024 history not acquired; other365-year dates retained only if complete; no performance choice',
        validation='D versus A,q90,QRF on all real events;14d paired blocks primary,7/28 sensitivity; report all four cells and seasonal descriptors without reselecting model',
        inference='frozen December cutoffs are prospective operating rules; same-FPR cutoffs estimated on independent labels are ranking diagnostics only',
        pass_gate='same-FPR recall gain95%CI lower>0 vs A,q90,QRF; frozen D recall not lower than A or q90 and quiet FPR not above QRF;no full-season point loss beyond5pp vs q90',
        scope='zero-shot transfer to a new6-turbine cohort and a later calendar year;different manufacturer,hub height and terrain; not proof for entire farm or interval endpoints',
        weights={k:sha(EXPERIMENT/p) for k,p in [('point','point.joblib'),('context','context.joblib'),('thresholds','thresholds.json')]}))


class RangeFile:
    def __init__(self):self.position=0
    def seek(self,offset,whence=0):
        self.position=offset if whence==0 else self.position+offset if whence==1 else SIZE+offset
        return self.position
    def tell(self):return self.position
    def read(self,n=-1):
        if n<0:n=SIZE-self.position
        n=min(n,SIZE-self.position)
        if n<=0:return b''
        start=self.position;end=start+n-1
        r=request('GET',URL,headers={'Range':f'bytes={start}-{end}'})
        assert r.status_code==206 and r.headers['Content-Range']==f'bytes {start}-{end}/{SIZE}'
        content=r.content;assert len(content)==n
        self.position+=n
        return content
    def seekable(self):return True


def table(month,kind):
    folder=OUT/month;folder.mkdir(exist_ok=True)
    path=folder/f'{kind}_selected.csv.gz'
    if path.exists():return
    name=f'{kind}_2025_{month[-2:]}.csv'
    fields=['TimeStamp','StationId','wtc_ActPower_mean' if kind=='tblSCTurGrid' else 'wtc_AcWindSp_mean']
    with zipfile.ZipFile(RangeFile()) as z:
        raw=z.read(name) # CRC validated by ZipFile; only selected table downloaded.
    head=raw[:500].decode('utf-8-sig',errors='replace').splitlines()[0]
    sep=';' if head.count(';')>head.count(',') else ','
    # Siemens export schemas use StationId or StationNr in different releases.
    cols=pd.read_csv(io.BytesIO(raw),sep=sep,nrows=0).columns
    station=next(c for c in cols if c.lower() in ('stationid','stationnr'))
    timestamp=next(c for c in cols if c.lower()=='timestamp')
    value=fields[2]
    d=pd.read_csv(io.BytesIO(raw),sep=sep,usecols=[timestamp,station,value],na_values=['NULL','(null)'])
    d=d.rename(columns={timestamp:'timestamp',station:'station',value:'power' if kind=='tblSCTurGrid' else 'wind_speed'})
    d=d[d.station.isin(STATIONS)].copy()
    assert len(d)>0
    d.to_csv(path,index=False,compression='gzip')
    print('SCADA TABLE',month,kind,'rows',len(d),'compressed_bytes',path.stat().st_size,flush=True)


def scada():
    if (OUT/'scada_complete.json').exists():return
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs=[pool.submit(table,m,k) for m in MONTHS for k in ('tblSCTurGrid','tblSCTurbine')]
        for j in as_completed(jobs):j.result()
    parts={};quality=[]
    for kind,col in [('tblSCTurGrid','power'),('tblSCTurbine','wind_speed')]:
        d=pd.concat([pd.read_csv(OUT/m/f'{kind}_selected.csv.gz') for m in MONTHS],ignore_index=True)
        d['timestamp']=pd.to_datetime(d.timestamp,utc=True)
        aligned=d.timestamp.eq(d.timestamp.dt.floor('10min'))
        d.loc[~np.isfinite(d[col]),col]=np.nan
        if col=='wind_speed':d.loc[d[col]<0,col]=np.nan
        off=int((~aligned).sum());d=d[aligned]
        g=d.groupby(['timestamp','station'])[col]
        lo,hi=g.min(),g.max();conflict=lo.ne(hi)&lo.notna()&hi.notna()
        unique=lo.mask(conflict).reset_index()
        unique['target']=unique.timestamp.dt.ceil('h')
        h=unique.groupby('target')[col].agg(['sum','mean','count'])
        quality.append(dict(field=col,rows=len(d),duplicates=int(d.duplicated(['timestamp','station']).sum()),
            conflicts=int(conflict.sum()),off_grid=off,minimum=float(d[col].min()),maximum=float(d[col].max())))
        if col=='power':parts[col]=pd.DataFrame(dict(power_pu=(h['sum']/6/CAPACITY).where(h['count'].eq(36)),power_valid=h['count'].eq(36),power_count=h['count']))
        else:parts[col]=pd.DataFrame(dict(wind_speed=h['mean'].where(h['count'].eq(36)),wind_valid=h['count'].eq(36),wind_count=h['count']))
    h=parts['power'].join(parts['wind_speed'],how='outer').reindex(pd.date_range('2025-01-01T00:00Z','2026-01-01T00:00Z',freq='h'))
    h.index.name='target';h.to_csv(OUT/'scada_hourly_2025.csv')
    write(OUT/'scada_quality.json',quality);write(OUT/'scada_complete.json',dict(status='complete'))
    print('SCADA COMPLETE',quality,flush=True)


def weather():
    static=pd.read_csv(OUT/'Hill_of_Towie_turbine_metadata.csv')
    static=static[static['Turbine Name'].isin(TURBINES)]
    assert len(static)==6 and static['Rated power (kW)'].sum()==CAPACITY
    def one(m):
        folder=OUT/m;folder.mkdir(exist_ok=True);path=folder/'gfs_hourly.csv'
        if path.exists():return
        first=pd.Timestamp(m+'-01',tz='UTC')
        origins=pd.date_range(first,first+pd.offsets.MonthBegin(),inclusive='left',freq='D')
        temporary=path.with_suffix('.csv.partial')
        fetch_weather(origins,static.Latitude.mean(),static.Longitude.mean()).to_csv(temporary,index=False)
        temporary.replace(path)
        print('WEATHER COMPLETE',m,flush=True)
    with ThreadPoolExecutor(max_workers=3) as pool:
        for job in as_completed([pool.submit(one,m) for m in MONTHS]):job.result()
    write(OUT/'weather_complete.json',dict(status='complete'))


def pair():
    assert (OUT/'scada_complete.json').exists() and (OUT/'weather_complete.json').exists()
    from pair_penmanshiel_frozen_transfer import pair as old_pair
    import pair_penmanshiel_frozen_transfer as module
    original=module.OUT
    try:
        module.OUT=OUT
        h=pd.read_csv(OUT/'scada_hourly_2025.csv',parse_dates=['target']).set_index('target')
        for m in MONTHS:old_pair(m,h)
    finally:module.OUT=original
    write(OUT/'data_complete.json',dict(status='complete'))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['lock','scada','weather','pair']);args=p.parse_args()
    lock()
    if args.stage!='lock':globals()[args.stage]()
