"""Causal monthly QRF refits with a model-specific held-out calibration buffer."""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='2'
from pathlib import Path
import numpy as np
import pandas as pd
from pooling_common import load_farms,feature_array,local_heads
from revision_common import ROOT,write,frozen_spec
from gefcom_protocol_v2 import index

OUT=ROOT/'out_gefcom_retraining_20261105'
METHODS=['frozen','expanding','rolling365']


def split_month(d,month,method):
    """Disjoint label-end windows, evaluated at the first calendar day of month."""
    now=np.datetime64(str(month)+'-01','ns')
    end=(pd.Timestamp(now)+pd.offsets.MonthBegin(1)).to_datetime64()
    cutoff=now-np.timedelta64(84,'D')
    good=d['valid'];ends=d['ends'];origins=d['origins']
    train=good&(ends<=cutoff)
    if method=='rolling365':train&=ends>cutoff-np.timedelta64(365,'D')
    elif method=='frozen':
        train=np.zeros(len(good),bool);train[index(d,'train',True)]=True
    elif method!='expanding':raise ValueError(method)
    cal=good&(ends>cutoff)&(ends<=now)&(origins<now)
    score=(origins>=now)&(origins<end)
    tr,ca,sc=map(np.flatnonzero,(train,cal,score))
    assert len(tr)>100 and len(ca)>=9 and len(sc)>0
    assert not np.intersect1d(tr,ca).size and not np.intersect1d(tr,sc).size
    assert d['ends'][tr].max()<=cutoff and d['ends'][ca].max()<=now
    assert np.all(d['origins'][ca]<now)
    return tr,ca,sc


def schedule(year,stage):
    if year==2014:
        return pd.period_range('2013-04' if stage=='validation' else '2013-07',
            '2013-06' if stage=='validation' else '2013-12',freq='M').astype(str).tolist()
    if stage!='evaluation':raise ValueError('No extra 2012 model selection')
    return pd.period_range('2011-07','2012-06',freq='M').astype(str).tolist()


def folder_for(year,farm,method,seed,month):
    return OUT/f'gefcom{year}/farm_{farm:02d}/{method}/seed_{seed}/{month}'


def split_witness(d,tr,ca,sc):
    return dict(train_days=len(tr),train_cells=len(tr)*24,calibration_days=len(ca),forecast_days=len(sc),
        first_train_origin=str(d['origins'][tr[0]]),last_train_target_end=str(d['ends'][tr].max()),
        first_calibration_origin=str(d['origins'][ca[0]]),first_calibration_target_end=str(d['ends'][ca].min()),
        last_calibration_target_end=str(d['ends'][ca].max()),first_forecast_origin=str(d['origins'][sc[0]]),
        last_forecast_origin=str(d['origins'][sc[-1]]))
