"""Pair Kelmarsh SCADA with archived hourly GFS point forecasts."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import threading
import time
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import requests

from kelmarsh import read_turbine
from revision_common import frozen_spec, write

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_kelmarsh_gfs'
SCADA=ROOT.parent/'wind_datasets'/'kelmarsh'
AWS='https://noaa-gfs-bdp-pds.s3.amazonaws.com'
API='https://api.dynamical.org/v1/forecasts'
LOCAL=threading.local()
PILOT='2024-01'
FIELDS=('wind_u_100m','wind_v_100m')


def session():
    if not hasattr(LOCAL,'session'):
        LOCAL.session=requests.Session()
    return LOCAL.session


def request(method,url,**kwargs):
    for attempt in range(4):
        try:
            response=session().request(method,url,timeout=(12,60),**kwargs)
            if response.status_code in (429,500,502,503,504) and attempt<3:
                time.sleep(max(float(response.headers.get('Retry-After',0)),2**attempt))
                continue
            response.raise_for_status()
            return response
        except (requests.Timeout,requests.ConnectionError):
            if attempt==3:
                raise
            time.sleep(2**attempt)


def archive_times(origin):
    cycle=origin-pd.Timedelta(hours=6)
    prefix=f'gfs.{cycle:%Y%m%d}/18/atmos/gfs.t18z.pgrb2.0p25.f0'
    response=request('GET',AWS,params={'list-type':2,'prefix':prefix})
    root=ET.fromstring(response.content)
    assert root.findtext('{*}IsTruncated')=='false'
    stamps={}
    for item in root.findall('{*}Contents'):
        key=item.findtext('{*}Key')
        if key.endswith('.idx'):
            continue
        lead=int(key.rsplit('.f',1)[1])
        if int(item.findtext('{*}Size'))>0:
            stamps[lead]=pd.Timestamp(item.findtext('{*}LastModified'))
    return stamps


def point_batch(origins,lat,lon):
    cycles=[o-pd.Timedelta(hours=6) for o in origins]
    q=[dict(queryId=c.isoformat(),dataProductId='noaa-gfs-forecast',
            location=dict(latitude=lat,longitude=lon),initTime=c.isoformat(),
            maxLeadTimeHours=30,variables=list(FIELDS)) for c in cycles]
    response=request('POST',API,json={'queries':q}).json()['results']
    by_cycle={}
    for result in response:
        assert result['dataProduct']['id']=='noaa-gfs-forecast'
        chosen=result['point']['selected']
        for run in result['forecasts']:
            cycle=pd.Timestamp(run['initTime'])
            assert cycle in cycles and cycle not in by_cycle
            values={}
            for lead,target,u,v in zip(run['leadTimeHours'],run['validTimes'],*[run['data'][k] for k in FIELDS],strict=True):
                assert lead==int(lead) and pd.Timestamp(target)==cycle+pd.Timedelta(hours=lead)
                values[int(lead)]=(u,v)
            by_cycle[cycle]=dict(values=values,grid_lat=chosen['latitude'],grid_lon=chosen['longitude'],
                snapshot=result['snapshotId'],version=result['dataProduct']['version'])
    assert set(by_cycle)==set(cycles)
    return by_cycle


def fetch_weather(origins,lat,lon):
    with ThreadPoolExecutor(max_workers=10) as pool:
        metadata={o:pool.submit(archive_times,o) for o in origins}
        batches=[origins[i:i+6] for i in range(0,len(origins),6)]
        points={}
        for batch in batches:
            points.update(point_batch(batch,lat,lon))
            print('GFS point runs',len(points),'/',len(origins),flush=True)
        stamps={o:job.result() for o,job in metadata.items()}
    rows=[]
    for o in origins:
        cycle=o-pd.Timedelta(hours=6)
        p=points[cycle]
        for h in range(1,25):
            native=h+6
            u,v=p['values'].get(native,(None,None))
            stamp=stamps[o].get(native,pd.NaT)
            decoded=u is not None and v is not None and np.isfinite([u,v]).all()
            rows.append(dict(origin=o,target=o+pd.Timedelta(hours=h),cycle=cycle,lead=h,native_lead=native,
                u100=u,v100=v,archive_time=stamp,available=bool(pd.notna(stamp) and cycle<=stamp<=o),
                decoded=bool(decoded),**{k:v for k,v in p.items() if k!='values'}))
    return pd.DataFrame(rows)


def scada_year(year):
    cache=OUT/f'scada_hourly_{year}.csv'
    if cache.exists():
        return pd.read_csv(cache,parse_dates=['target']).set_index('target')
    frames=[]
    quality=[]
    start=pd.Timestamp(f'{year}-01-01',tz='UTC')
    stop=pd.Timestamp(f'{year+1}-01-01',tz='UTC')
    for turbine in range(1,7):
        files=list((SCADA/'extracted').glob(f'Kelmarsh_SCADA_{year}_*/Turbine_Data_Kelmarsh_{turbine}_*.csv'))
        assert len(files)==1, files
        d=read_turbine(str(files[0]))[['timestamp','power','wind_speed']]
        d['timestamp']=d.timestamp.dt.tz_localize('UTC')
        d=d[d.timestamp.ge(start)&d.timestamp.lt(stop)].copy()
        on_grid=d.timestamp.eq(d.timestamp.dt.floor('10min'))
        off_grid=int((~on_grid).sum())
        d=d[on_grid]
        dupe=d.timestamp.duplicated(keep=False)
        duplicate_rows=int(dupe.sum())
        grouped=d.loc[dupe].groupby('timestamp')[['power','wind_speed']]
        lo,hi=grouped.min(),grouped.max()
        conflicting=(lo.ne(hi)&lo.notna()&hi.notna())
        unique=lo.mask(conflicting).reset_index()
        d=pd.concat([d.loc[~dupe],unique],ignore_index=True)
        assert not d.timestamp.duplicated().any()
        quality.append(dict(turbine=turbine,off_grid=off_grid,duplicate_rows=duplicate_rows,
                            power_conflict=int(conflicting.power.sum()),wind_conflict=int(conflicting.wind_speed.sum())))
        frames.append(d)
    t=pd.concat(frames,ignore_index=True)
    t.loc[~np.isfinite(t.power),'power']=np.nan
    t.loc[~np.isfinite(t.wind_speed)|(t.wind_speed<0),'wind_speed']=np.nan
    t['target']=t.timestamp.dt.floor('h')+pd.Timedelta(hours=1)
    h=t.groupby('target').agg(power_kw=('power','sum'),power_count=('power','count'),
                              wind_speed=('wind_speed','mean'),wind_count=('wind_speed','count'))
    h=h.reindex(pd.date_range(start+pd.Timedelta(hours=1),stop,freq='h'))
    h.index.name='target'
    h['power_valid']=h.power_count.eq(36)
    h['wind_valid']=h.wind_count.eq(36)
    h['power_pu']=(h.power_kw/6/12300).where(h.power_valid)
    h['wind_speed']=h.wind_speed.where(h.wind_valid)
    h=h.drop(columns='power_kw')
    pd.DataFrame(quality).to_csv(OUT/f'scada_quality_{year}.csv',index=False)
    h.to_csv(cache)
    print('SCADA cached',year,flush=True)
    return h


def month(month_text):
    start=pd.Timestamp(month_text+'-01',tz='UTC')
    stop=start+pd.offsets.MonthBegin()
    origins=pd.date_range(start,stop,inclusive='left',freq='D')
    static=pd.read_csv(SCADA/'Kelmarsh_WT_static.csv')
    assert static['Rated power (kW)'].sum()==12300
    lat,lon=static.Latitude.mean(),static.Longitude.mean()
    folder=OUT/month_text
    folder.mkdir(parents=True,exist_ok=True)
    csv=folder/'gfs_hourly.csv'
    if not csv.exists():
        fetch_weather(origins,lat,lon).to_csv(csv,index=False)
    weather=pd.read_csv(csv,parse_dates=['origin','target','cycle','archive_time'])
    assert len(weather)==24*len(origins) and not weather.duplicated(['origin','lead']).any()
    measured=pd.concat([scada_year(y) for y in range((start-pd.Timedelta(days=1)).year,(stop-pd.Timedelta(hours=1)).year+1)])
    p=weather.merge(measured.reset_index(),on='target',validate='one_to_one')
    assert len(p)==len(weather)
    p['paired']=p.decoded & p.available & p.power_valid & p.wind_valid
    p['target_valid']=p.power_valid & p.wind_valid
    p.to_csv(folder/'paired_hourly.csv',index=False)
    audit=p.groupby('origin').agg(forecast_hours=('decoded','sum'),available_hours=('available','sum'),
        paired_hours=('paired','sum'),power_hours=('power_valid','sum'),wind_hours=('wind_valid','sum'))
    audit['history_power_complete']=[measured.reindex(pd.date_range(o-pd.Timedelta(hours=23),o,freq='h')).power_valid.eq(True).all()
                                     for o in audit.index]
    audit.to_csv(folder/'issue_audit.csv')
    n=len(origins)
    count=dict(month=month_text,origins=n,hours=len(p),forecast_hours=int(p.decoded.sum()),
        available_hours=int(p.available.sum()),power_hours=int(p.power_valid.sum()),wind_hours=int(p.wind_valid.sum()),
        paired_hours=int(p.paired.sum()),full_forecast_days=int(audit.forecast_hours.eq(24).sum()),
        full_available_days=int(audit.available_hours.eq(24).sum()),
        full_pair_days=int(audit.paired_hours.eq(24).sum()),
        full_pair_with_history_days=int((audit.paired_hours.eq(24)&audit.history_power_complete).sum()))
    count['pass']=bool(count['power_hours']/len(p)>=.95 and count['wind_hours']/len(p)>=.95 and
                       count['full_pair_with_history_days']/n>=.90)
    write(folder/'completion.json',count)
    print(count,flush=True)
    return count


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('months',nargs='*',default=[PILOT])
    args=parser.parse_args()
    frozen_spec(OUT/'point_protocol.json',dict(pilot=PILOT,
        source='dynamical.org noaa-gfs-forecast from NOAA AWS; hourly 0.25deg 100m U/V nearest point; archive values rounded by provider',
        clock='00 UTC issuance; prior day 18 UTC cycle; forecast leads 7–30 map to issuance leads 1–24',
        availability='NOAA AWS source GRIB LastModified must be between cycle and issue; historical live serving and SCADA latency unverified',
        scada='UTC 10-minute start-labeled assumption, hour ending at target, all 6 turbines x 6 readings per variable; no target filling',
        pilot_gate='both SCADA fields >=95% hours and >=90% days with 24 available paired targets plus 24 valid history power hours'))
    frozen_spec(OUT/'scada_quality_protocol.json',dict(duplicate='collapse same turbine and timestamp; retain one finite value only if all finite duplicates agree per field; conflicts become missing',off_grid='exclude timestamps not on UTC 10-min grid'))
    for m in args.months:
        month(m)


if __name__=='__main__':
    main()

