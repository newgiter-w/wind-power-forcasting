"""Matched CPU inference timing after training finishes, including preprocessing."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='2'
import json
from pathlib import Path
import sys
import time
import joblib
import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits
from gefcom_protocol_v2 import prepare,index
from strong_baselines import build_shared
from run_gefcom_tail_dynamic import base_matrix
from run_dl_baseline import QuantileMLP
from revision_common import OUT,REFERENCE


def main():
    sys.path.insert(0,str(OUT.parent/'.aris/qrf-packages'));torch.set_num_threads(2)
    d=prepare(2014)[0][1];ids=index(d,'evaluation');cells=(ids[:,None]*24+np.arange(24)).ravel()
    canonical=base_matrix(d,2014)[cells]
    legacy=build_shared(d,'R2')[0][cells]
    r2path=REFERENCE/'gefcom2014/farm_01/R2_shared_aug/models.joblib'
    r2=joblib.load(r2path)
    root=OUT/'mlp/gefcom2014/farm_01'
    scaler=joblib.load(root/'scaler.joblib');nets=[]
    for q in [.05,.95]:
        m=QuantileMLP(legacy.shape[1]);m.load_state_dict(torch.load(root/f'seed_0/q{q:.2f}.pt',weights_only=True));m.eval();nets.append(m)
    leaf=json.loads((OUT/'qrf/selection.json').read_text())['selected_leaf']
    qpath=OUT/f'qrf/gefcom2014/farm_01/leaf_{leaf}/seed_0/model.joblib';qrf=joblib.load(qpath)
    risk=joblib.load(root/'risk_model.joblib')
    def r2_predict():
        return np.column_stack([bundle['model'].predict(bundle['scaler'].transform(np.ascontiguousarray(canonical[:,bundle['keep']]))) for bundle in r2])
    @torch.no_grad()
    def mlp_predict():
        x=torch.tensor(scaler.transform(np.nan_to_num(legacy,nan=0.)),dtype=torch.float32)
        return np.stack([m(x).numpy() for m in nets],axis=1)
    def qrf_predict():
        return qrf['model'].predict(qrf['imputer'].transform(canonical),quantiles=[.05,.95],weighted_quantile=True,
            weighted_leaves=True,aggregate_leaves_first=True)
    def risk_predict():
        return risk['calibrator'].predict(risk['classifier'].predict_proba(legacy)[:,1])
    rows=[]
    for name,func,size in [('R2',r2_predict,r2path.stat().st_size),('MLP',mlp_predict,
        sum((root/f'seed_0/q{q:.2f}.pt').stat().st_size for q in [.05,.95])+(root/'scaler.joblib').stat().st_size),
        ('QRF',qrf_predict,qpath.stat().st_size),('risk_guard',risk_predict,(root/'risk_model.joblib').stat().st_size)]:
        expected=func();times=[]
        for _ in range(3):
            start=time.perf_counter();pred=func();times.append(time.perf_counter()-start)
            np.testing.assert_allclose(pred,expected,atol=1e-8,rtol=1e-8)
        rows.append(dict(method=name,forecast_origins=len(ids),lead_cells=len(cells),median_seconds=float(np.median(times)),
            seconds_per_origin=float(np.median(times)/len(ids)),stored_model_MB=size/1e6,
            scope='farm1 seed0, 2 CPU threads, preprocessing+raw endpoints, warmed3 repeats; shared CQR excluded'))
    pd.DataFrame(rows).to_csv(OUT/'inference_benchmark.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
