"""Generate B0 artifacts: split_manifest.csv, exclusions.csv, protocol.json."""
import json
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import default_config
from data import build_situations, load_dataframe
from run import segment_split, assert_time_boundaries

OUT = "out_v3"
os.makedirs(OUT, exist_ok=True)

cfg = default_config(
    points_per_day=144, stride_points=144, horizon_days=1, condition_days=1,
    horizon_bins=24, analog_bins=24,
    kelmarsh_root=r"D:\Study\wind_datasets\kelmarsh",
    kelmarsh_cache=r"D:\Study\wind_datasets\kelmarsh\farm_cache_2018_2022.csv",
    weather_cols=["wind_speed", "wind_dir_sin", "wind_dir_cos", "temperature"],
    capacity=12300.0,
)

df = load_dataframe(cfg)
d = build_situations(df, cfg)
seg = segment_split(d["origin_ts"])
assert_time_boundaries(d, seg)

order = ["M", "T", "V_cal", "V_score", "C_old", "E_old"]
valid = d["target_valid"]

# ---- split manifest ----
rows = []
for s in order:
    m = seg[s]
    tv = m & valid
    rows.append({
        "segment": s,
        "n_origins_raw": int(m.sum()),
        "n_origins_valid": int(tv.sum()),
        "n_excluded": int(m.sum() - tv.sum()),
        "first_origin": str(d["origin_ts"][m].min()) if m.any() else "",
        "last_origin": str(d["origin_ts"][m].max()) if m.any() else "",
        "last_target_end": str(d["target_end_ts"][m].max()) if m.any() else "",
    })
pd.DataFrame(rows).to_csv(os.path.join(OUT, "split_manifest.csv"), index=False)

# ---- exclusions ----
ex = ~valid
ex_rows = []
for i in np.where(ex)[0]:
    seg_i = next(s for s in order if seg[s].iloc[i])
    n_invalid = int((d["target"][i] != d["target"][i]).sum()) if False else None
    ex_rows.append({
        "origin_ts": str(d["origin_ts"].iloc[i]),
        "target_end_ts": str(d["target_end_ts"].iloc[i]),
        "segment": seg_i,
        "reason": "target window not fully valid (< 6 turbines observed in >=1 step)",
    })
pd.DataFrame(ex_rows).to_csv(os.path.join(OUT, "exclusions.csv"), index=False)

# ---- protocol.json ----
protocol = {
    "task": "24h ahead, 24 hourly-mean blocks; condition=144 x 10min; capacity=12300 kW",
    "confidence_levels": [0.90],
    "decision_thresholds": {
        "min_relative_IS_improvement": 0.02,      # delta = 2%
        "equivalence_band": 0.02,                  # +/- 2%
        "coverage_tolerance": [0.88, 0.92],        # 88% - 92%
    },
    "segments": {s: {"origins_valid": int((seg[s] & valid).sum())} for s in order},
    "candidates": {
        "parameter_packages": {
            "H0": {"max_iter": 50, "max_leaf_nodes": 31, "min_samples_leaf": 20, "l2_regularization": 0},
            "H1": {"max_iter": 100, "max_leaf_nodes": 15, "min_samples_leaf": 40, "l2_regularization": 1},
        },
        "representations": ["R0_mean_top1", "RD_distribution"],
        "distances": ["euclidean", "dtw"],
    },
    "random_seeds": [0, 1, 2],
    "retrieval": {"top_k": 20, "dtw_shortlist": 40, "dtw_band": 12},
    "config": cfg.as_dict(),
}
with open(os.path.join(OUT, "protocol.json"), "w") as f:
    json.dump(protocol, f, indent=2, default=str)

print("manifest:")
print(pd.DataFrame(rows).to_string(index=False))
print(f"\nwritten: split_manifest.csv ({len(rows)} rows), exclusions.csv ({len(ex_rows)} rows), protocol.json")
