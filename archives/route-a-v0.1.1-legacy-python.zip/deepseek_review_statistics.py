"""Paired descriptive uncertainty for the reproduced December experiment."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from gefcom2014_experiment import masks

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'review_deepseek_gefcom_20261102'

def main():
    assert json.loads((OUT/'completion.json').read_text())['original_results_matched']
    dates=pd.date_range('2013-12-01','2013-12-31',freq='D')
    groups=['all','ramp','up_ramp','down_ramp','near_zero']
    daily=np.zeros((3,10,31,5,4));dropped=[]
    for farm in range(1,11):
        for j,m in enumerate('ABC'):
            with np.load(OUT/f'zone{farm:02d}_{m}.npz') as z:
                y=z['y'];lo=z['lo'];hi=z['hi'];origins=z['origins'];last=z['last_power']
            hit=(y>=lo)&(y<=hi);w=hi-lo;score=w+20*np.maximum(lo-y,0)+20*np.maximum(y-hi,0)
            masks_correct=masks(y,last)
            first=np.diff(y,axis=1,prepend=last[:,None])[:,0]
            dropped.append(dict(farm=farm,method=m,first_hour_up=int((first>.1).sum()),first_hour_down=int((first<-.1).sum())))
            for k,o in enumerate(origins):
                pos=dates.get_indexer([pd.Timestamp(o)])[0]
                for g,group in enumerate(groups):
                    mask=masks_correct[group][k]
                    daily[j,farm-1,pos,g]=[mask.sum(),hit[k,mask].sum(),w[k,mask].sum(),score[k,mask].sum()]
    def aggregate(a):
        t=a.sum(axis=2)
        values=np.divide(t[:,:,:,1:],t[:,:,:,0,None],out=np.full(t[:,:,:,1:].shape,np.nan),where=t[:,:,:,0,None]>0)
        return np.nanmean(values,axis=1)
    point=aggregate(daily);rng=np.random.default_rng(20261102);draws=[]
    for _ in range(2000):
        starts=rng.integers(0,25,size=5)
        idx=np.concatenate([np.arange(s,s+7) for s in starts])[:31]
        draws.append(aggregate(daily[:,:,idx]))
    draws=np.array(draws);rows=[]
    for a,b in [(1,0),(2,0),(2,1)]:
        for g,group in enumerate(groups):
            for k,metric in enumerate(['coverage','width','IS']):
                diff=draws[:,a,g,k]-draws[:,b,g,k]
                rows.append(dict(method='ABC'[a],baseline='ABC'[b],group=group,metric=metric,
                                 delta=float(point[a,g,k]-point[b,g,k]),low95=float(np.quantile(diff,.025)),
                                 high95=float(np.quantile(diff,.975)),block_days=7,resamples=2000))
    pd.DataFrame(rows).to_csv(OUT/'paired_december_bootstrap.csv',index=False)
    pd.DataFrame(dropped).to_csv(OUT/'omitted_first_hour_ramps.csv',index=False)
    print(pd.DataFrame(rows).query("group in ['all','up_ramp','near_zero']").to_string(index=False))

if __name__=='__main__':main()
