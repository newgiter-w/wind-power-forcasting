"""Saved-array width/tail/ramp diagnosis. No fits, tuning or new forecasts."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'out_gefcom_factorial_20261103_v2'
OUT=ROOT/'analysis/gefcom_width_ramp_20261103'
METHODS=['R0_ind_base','R2_shared_aug']

def summarize(y,L,U,mask):
    yy=y[mask];l=L[mask];u=U[mask];w=u-l
    if not len(yy):return dict(cells=0)
    lp=20*np.maximum(l-yy,0);up=20*np.maximum(yy-u,0)
    return dict(cells=len(yy),coverage=float(((yy>=l)&(yy<=u)).mean()),width=float(w.mean()),
        IS=float((w+lp+up).mean()),lower_miss=float((yy<l).mean()),upper_miss=float((yy>u).mean()),
        lower_penalty=float(lp.mean()),upper_penalty=float(up.mean()),lower_at_zero=float((l==0).mean()),
        upper_at_one=float((u==1).mean()),near_zero_fraction=float((yy<=.01).mean()),
        above_20pct_fraction=float((yy>.2).mean()))

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    rows=[];widths=[];traces=[];shift=[];sources=[];checks=[]
    for year in [2014,2012]:
        cuepath=ROOT/f'out_gefcom_protocol_v2/gefcom{year}/diagnostic_cells.csv'
        cues=pd.read_csv(cuepath,parse_dates=['origin']);sources.extend([cuepath,cuepath.with_name('diagnostic_protocol.json')])
        for folder in sorted((BASE/f'gefcom{year}').glob('farm_*')):
            farm=int(folder.name.split('_')[-1]);source=folder/'samples.npz';sources.append(source)
            with np.load(source) as z:
                y=z['y'];history=z['history'];valid=z['valid'];origins=z['origins']
            sources.append(folder/'issued_manifest.csv');manifest=pd.read_csv(folder/'issued_manifest.csv')
            np.testing.assert_array_equal(pd.to_datetime(manifest.origin).to_numpy(),origins)
            for method in METHODS:
                headpath=folder/method/'heads.npz';sources.append(headpath)
                with np.load(headpath) as z:q05=z['q05'];q95=z['q95']
                rlo=np.minimum(q05,q95);rhi=np.maximum(q05,q95)
                for stage in ['train','validation','evaluation']:
                    ix=np.flatnonzero(manifest.phase.eq(stage).to_numpy()&valid)
                    lo=np.clip(rlo[ix],0,1);hi=np.clip(rhi[ix],0,1)
                    a=y[ix]-q05[ix];b=y[ix]-q95[ix]
                    shift.append(dict(year=year,farm=farm,method=method,stage=stage,days=len(ix),
                        pinball05=float(np.maximum(.05*a,-.95*a).mean()),
                        pinball95=float(np.maximum(.95*b,-.05*b).mean()),
                        **summarize(y[ix],lo,hi,np.ones_like(lo,dtype=bool))))
                path=folder/method/'evaluation.npz';sources.append(path)
                with np.load(path) as z:
                    ix=z['indices'];L=z['lo'];U=z['hi']
                    assert (z['max_label_end']<=origins[ix]).all()
                ok=valid[ix];yy=y[ix];last=history[ix,-1]
                delta=np.diff(yy,axis=1,prepend=last[:,None]);lead=np.broadcast_to(np.arange(1,25),yy.shape)
                cc=pd.MultiIndex.from_product([pd.to_datetime(origins[ix]),np.arange(1,25)],names=['origin','lead'])
                cf=cues[cues.farm==farm].set_index(['origin','lead']).reindex(cc)
                # The old diagnostic proxy was fitted on proper training labels only.
                np.testing.assert_allclose(cf.y.to_numpy().reshape(yy.shape)[ok],yy[ok],atol=1e-12,rtol=0)
                signal=cf.forecast_power_change.to_numpy().reshape(yy.shape)>.05
                proxy=cf.training_curve_power.to_numpy().reshape(yy.shape)
                assert np.isfinite(proxy[ok]).all()
                stable=(np.max(np.abs(history[ix,-6:]),axis=1)<=.05)&(np.max(np.abs(np.diff(history[ix,-6:],axis=1)),axis=1)<=.05)
                predicted_low=stable[:,None]&(proxy<=.05)&(np.abs(cf.forecast_power_change.to_numpy().reshape(yy.shape))<=.02)
                basegroups={'all':np.ones_like(yy,dtype=bool),'up_ramp':delta>.1,'down_ramp':delta<-.1,
                    'near_zero':yy<=.01,'not_ramp':np.abs(delta)<=.1,
                    'forecast_up_signal':signal,'no_forecast_up_signal':~signal,
                    'up_with_signal':(delta>.1)&signal,'up_without_signal':(delta>.1)&~signal,
                    'predictable_stable_low':predicted_low}
                for name,mask in basegroups.items():
                    for block,lm in [('all',lead>0),('01-06',lead<=6),('07-12',(lead>=7)&(lead<=12)),('13-24',lead>=13)]:
                        mask2=mask&lm&ok[:,None]
                        for kind,ll,uu in [('raw',np.clip(rlo[ix],0,1),np.clip(rhi[ix],0,1)),('cqr',np.clip(L,0,1),np.clip(U,0,1))]:
                            rows.append(dict(year=year,farm=farm,method=method,kind=kind,group=name,lead_block=block,
                                origins=int(mask2.any(axis=1).sum()),**summarize(yy,ll,uu,mask2)))
                ll=np.clip(rlo[ix],0,1);uu=np.clip(rhi[ix],0,1);cl=np.clip(L,0,1);cu=np.clip(U,0,1)
                widths.append(dict(year=year,farm=farm,method=method,
                    raw_width_unclipped=float((rhi[ix][ok]-rlo[ix][ok]).mean()),
                    raw_width_clipped=float((uu[ok]-ll[ok]).mean()),
                    cqr_width_unclipped=float((U[ok]-L[ok]).mean()),cqr_width_clipped=float((cu[ok]-cl[ok]).mean()),
                    calibration_add=float(((cu-cl)-(uu-ll))[ok].mean()),
                    lower_add=float((ll-cl)[ok].mean()),upper_add=float((cu-uu)[ok].mean()),
                    clipped_away=float(((U-L)-(cu-cl))[ok].mean())))
                for month in sorted(set(pd.DatetimeIndex(origins[ix]).strftime('%Y-%m'))):
                    mask=np.broadcast_to((pd.DatetimeIndex(origins[ix]).strftime('%Y-%m')==month)[:,None]&ok[:,None],yy.shape)
                    for kind,l,u in [('raw',ll,uu),('cqr',cl,cu)]:
                        traces.append(dict(year=year,farm=farm,method=method,kind=kind,month=month,**summarize(yy,l,u,mask)))
                checks.append(dict(year=year,farm=farm,method=method,paired_source_proxy=True,causal_feedback=True,
                    scored_days=int(ok.sum()),up_cells=int(((delta>.1)&ok[:,None]).sum()),
                    up_with_signal_cells=int(((delta>.1)&signal&ok[:,None]).sum()),
                    all_cells=int(ok.sum()*24),signal_cells=int((signal&ok[:,None]).sum())))
        print(year,'saved-array diagnostics complete',flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(OUT/'group_lead_per_farm.csv',index=False)
    cols=[c for c in frame.select_dtypes('number').columns if c not in ['year','farm','cells','origins']]
    macro=frame.groupby(['year','method','kind','group','lead_block'])[cols].mean().reset_index()
    macro.to_csv(OUT/'group_lead_macro.csv',index=False)
    reference=pd.read_csv(BASE/'metrics_macro.csv');sources.append(BASE/'metrics_macro.csv')
    reference=reference[(reference.stage=='evaluation')&(reference.support=='clipped')&reference.method.isin(METHODS)&reference.group.isin(['all','up_ramp','down_ramp','near_zero'])]
    joined=macro[macro.lead_block=='all'].merge(reference,on=['year','method','kind','group'],suffixes=('_new','_saved'),validate='one_to_one')
    assert len(joined)==32
    for metric in ['coverage','width','IS','lower_miss','upper_miss']:
        np.testing.assert_allclose(joined[metric+'_new'],joined[metric+'_saved'],rtol=1e-10,atol=1e-12)
    pd.DataFrame(widths).to_csv(OUT/'width_decomposition_per_farm.csv',index=False)
    pd.DataFrame(widths).groupby(['year','method']).mean(numeric_only=True).drop(columns='farm').reset_index().to_csv(OUT/'width_decomposition_macro.csv',index=False)
    pd.DataFrame(shift).to_csv(OUT/'raw_generalization_per_farm.csv',index=False)
    pd.DataFrame(shift).groupby(['year','method','stage']).mean(numeric_only=True).drop(columns='farm').reset_index().to_csv(OUT/'raw_generalization_macro.csv',index=False)
    pd.DataFrame(traces).to_csv(OUT/'monthly_per_farm.csv',index=False)
    pd.DataFrame(traces).groupby(['year','method','kind','month']).mean(numeric_only=True).drop(columns='farm').reset_index().to_csv(OUT/'monthly_macro.csv',index=False)
    # Cell-weighted signal recall/precision is explicitly separate from farm-macro metrics.
    ck=pd.DataFrame(checks);sig=ck.groupby(['year','method'])[['up_cells','up_with_signal_cells','all_cells','signal_cells']].sum().reset_index()
    sig['signal_recall_for_actual_up']=sig.up_with_signal_cells/sig.up_cells
    sig['signal_precision_for_actual_up']=sig.up_with_signal_cells/sig.signal_cells
    sig.to_csv(OUT/'proxy_signal_detection.csv',index=False)
    meta=dict(status='complete',model_fits=0,new_forecasts=0,checks=checks,original_metric_rows_reverified=32,
        analysis_scope='retrospective descriptive diagnosis of existing fixed datasets; not a new confirmation',
        aggregation='farm macro except explicitly cell-weighted signal precision/recall; empty farm subsets omitted and per-farm counts retained',
        predicted_low_rule='last6 power all<=.05, adjacent changes<=.05; training-only isotonic proxy current power<=.05, abs proxy change<=.02',
        limitations=['single training-only isotonic proxy cannot establish NWP information limits or physical forecast errors','no new hyperparameter or calibration candidate evaluated'],
        source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dict.fromkeys(sources)},
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        versions=dict(numpy=np.__version__,pandas=pd.__version__))
    (OUT/'audit.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':main()
