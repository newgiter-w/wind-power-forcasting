"""Summarize the frozen point/residual comparison and draw its QRF fan chart."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from run_point_residual import OUT, METHODS, load_farms, index

def table(columns, rows):
    return '\n'.join(['| '+' | '.join(columns)+' |', '| '+' | '.join(['---']*len(columns))+' |']
                     + ['| '+' | '.join(map(str,row))+' |' for row in rows])

def main():
    status = json.loads((OUT/'completion.json').read_text())
    assert status['status'] == 'complete'
    intervals = pd.read_csv(OUT/'interval_macro.csv')
    farms = pd.read_csv(OUT/'interval_per_farm.csv')
    points = pd.read_csv(OUT/'point_macro.csv')
    boot = pd.read_csv(OUT/'paired_bootstrap.csv')
    selected = json.loads((OUT/'selection.json').read_text())['preferred']
    records, point_records, changes, raw_records = [], [], [], []
    for year in (2014,2012):
        signed = intervals.query("year == @year and stage == 'evaluation' and variant == 'signed'").set_index(['method','group'])
        raw = intervals.query("year == @year and stage == 'evaluation' and variant == 'raw'").set_index(['method','group'])
        base = signed.loc[('direct_qrf','all')]
        for method in METHODS:
            a = signed.loc[(method,'all')]
            f = farms.query("year == @year and stage == 'evaluation' and variant == 'signed' and group == 'all' and method == @method")
            records.append([year,method,f'{a.coverage*100:.2f}',f'{a.width*100:.2f}',
                            f'{100*(a.width/base.width-1):+.2f}%',f'{a.IS:.4f}',
                            f"{signed.loc[(method,'near_zero'),'coverage']*100:.2f}",
                            f"{signed.loc[(method,'up_ramp'),'coverage']*100:.2f}",
                            f"{signed.loc[(method,'down_ramp'),'coverage']*100:.2f}",
                            f'{sum(f.coverage>=.90)}/{len(f)}'])
            r = raw.loc[(method,'all')]
            raw_records.append([year,method,f'{r.coverage*100:.2f}',f'{r.width*100:.2f}',f'{r.IS:.4f}',
                                f'{(a.width-r.width)*100:+.2f}'])
        for model in ('qrf','gbm'):
            p = points.query("year == @year and stage == 'evaluation' and model == @model and lead == 0").set_index('group')
            point_records.append([year,model,f"{p.loc['all','MAE']*100:.2f}",
                                  f"{p.loc['up_ramp','bias']*100:+.2f}",f"{p.loc['peak_time_hours','MAE']:.2f}"])
    for row in boot.query("group == 'all'").itertuples():
        factor = 1 if row.metric=='IS' else 100
        changes.append([row.year,row.method,row.metric,f'{row.difference*factor:+.4f}',
                        f'[{row.low*factor:+.4f}, {row.high*factor:+.4f}]'])
    d = load_farms(2012)[1]
    with np.load(OUT/'gefcom2012/farm_01/fan.npz') as z:
        days,quantiles = z['days'],z['quantiles']
    with np.load(OUT/'gefcom2012/farm_01/evaluation_direct_qrf.npz') as z:
        pos = np.searchsorted(z['ids'],days)
        np.testing.assert_equal(z['ids'][pos],days)
        lo,hi = z['lo'][pos],z['hi'][pos]
    fig,axes = plt.subplots(2,2,figsize=(11,7),sharex=True,sharey=True)
    x = np.arange(1,25)
    for i,(ax,season) in enumerate(zip(axes.flat,['Spring','Summer','Autumn','Winter'])):
        for j,color in enumerate(['#dceaf5','#b7d5ed','#88b8e0','#5998cf','#2e72ad']):
            ax.fill_between(x,quantiles[i,:,j],quantiles[i,:,-j-1],color=color,label=f'{90-j*20}% raw')
        ax.plot(x,lo[i],color='#555555',ls='--',lw=1,label='90% after CQR')
        ax.plot(x,hi[i],color='#555555',ls='--',lw=1)
        ax.plot(x,quantiles[i,:,5],color='#102d63',lw=1.6,label='QRF median')
        ax.plot(x,d['y'][days[i]],color='#b52c2c',lw=1.6,label='Observed')
        ax.set_title(f'{season} · {str(d["origins"][days[i]])[:10]}')
        ax.set_ylim(0,1)
        ax.set_xticks([1,6,12,18,24])
        ax.grid(alpha=.18)
    handles,labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=4,frameon=False)
    fig.supxlabel('Forecast lead (h)',y=.11)
    fig.supylabel('Power / installed capacity')
    fig.suptitle('GEFCom2012 · farm 1 · first valid evaluation day in each season')
    fig.tight_layout(rect=(.03,.14,1,.95))
    fig.savefig(OUT/'qrf_fan_2012_farm01.png',dpi=180)
    plt.close(fig)
    text = f"""# 日前点预测与条件残差区间对照

使用两套 GEFCom 数据的 17 个已知风电场。固定种子 0，沿用原有训练、开发、回溯评价日期和发报条件。2014 Q2 预设门槛所选方案为 **{selected}**。所有候选均进入评价表。开发期选择要求总体覆盖达到 90%，相对 QRF 覆盖下降不超过 0.5 个百分点，宽度相对缩窄至少 3%，IS 不升，近零和两类爬坡覆盖各下降不超过 1 个百分点。

点预测使用原始单场 QRF 的中位数和同一套 R2 特征训练的 GBM 中位数。峰时误差取每日 24 小时内首次最大值的时间差绝对值，平峰与多峰时该值也会受并列及峰值排序影响。功率 MAE 和偏差使用装机容量百分比。

{table(['数据','点模型','总体 MAE%','上爬坡偏差%','日峰时 MAE h'],point_records)}

残差使用 proper-training 后半段三个向前折的样本外预测构造。全量训练的同一 GBM 中位数作为两种残差模型的发报锚点。条件变量为原始 R2 特征、锚点和锚点相邻时效变化。对称模型用 GBM 拟合平方残差，以开方结果作为零中心高斯尺度，并设容量 1% 的尺度下限。它沿用先前条件尺度高斯的思路，改用直接平方误差回归与解析分位数。非对称模型对同一批残差拟合上下分位数。二者都使用原有逐场逐时效 rolling84 CQR。残差模型学习时的锚点来自较短时间前缀，这与发报锚点的训练长度有差异。

{table(['数据','方法','覆盖率%','宽度%容量','相对宽度变化','IS','近零覆盖%','上爬坡覆盖%','下降覆盖%','覆盖≥90%场数'],records)}

{table(['数据','方法','原始覆盖%','原始宽度%','原始IS','校准增加宽度pp'],raw_records)}

{table(['数据','方法','指标','相对QRF差值','95%区间'],changes)}

覆盖率与宽度的差值以百分点计。配对区间由 2000 次同步 14 日移动块抽样得到，条件于固定拟合结果。直接 QRF 的原始上下界已逐元素核对。结果属于单种子回溯筛查。

![四季预测扇形图](qrf_fan_2012_farm01.png)

图中五层彩色带来自原始 QRF 等尾分位数，灰色虚线是滚动校准后的 90% 上下界。展示日按各季第一个有效评价原点选取。两条点预测的逐时效误差、逐场覆盖、上下侧漏点和配对结果见对应 CSV。
"""
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')
    print(OUT/'RESULTS.md')

if __name__ == '__main__':
    main()
