"""2x2 factorial: lower-quantile level x training data (near-zero bias isolation).

Variants: L00 (q.05, 2019), L10 (q.02, 2019), L01 (q.05, 2019+2020H1),
          L11 (q.02, 2019+2020H1).
Fixed: frozen upper head (0.95), frozen scaler (fit 2019), H0 package, rolling CQR84.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.multioutput import MultiOutputRegressor
from threadpoolctl import threadpool_limits

from data import build_situations, load_dataframe
from execute_x01 import cfg_for
from online_calibration import simulate
from run_c1 import group, masks_for
from run_calibration import cache_predictions, indices_for

ROOT = Path(__file__).parent
MODEL = ROOT / 'out_v3/x01/tasks/NH_H0'
OUT = ROOT / 'out_base_retrain'
H0 = dict(max_iter=50, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, random_state=0)


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    cfg = cfg_for()
    d = build_situations(load_dataframe(cfg), cfg)
    X_all = np.hstack([d['feat'], d['cond']])
    y_all = d['target']
    origins = d['origin_ts']
    valid = d['target_valid']

    m19 = (origins >= '2019-01-01') & (origins < '2020-01-01') & valid
    mmore = (origins >= '2019-01-01') & (origins < '2020-07-01') & valid
    near_zero = np.abs(y_all) <= 123.0
    print(f'[data] 2019 train origins={int(m19.sum())}, near-zero cells={int(near_zero[m19].sum())}')
    print(f'[data] 2019+2020H1 origins={int(mmore.sum())}, near-zero cells={int(near_zero[mmore].sum())}')

    scaler = joblib.load(MODEL / 'scaler.joblib')
    Xs_all = scaler.transform(X_all)
    data = cache_predictions()
    assert np.array_equal(data['global_indices'],
                          np.flatnonzero((origins >= '2020-01-01') & (origins < '2023-01-01')))
    pred_idx = data['global_indices']
    upper_frozen = data['raw_upper_original']

    def train_and_predict(q, mask):
        m = MultiOutputRegressor(HistGradientBoostingRegressor(loss='quantile', quantile=q, **H0))
        m.fit(Xs_all[mask], y_all[mask])
        lower = m.predict(Xs_all[pred_idx])
        return np.minimum(lower, upper_frozen), np.maximum(lower, upper_frozen)

    variants = [('L00', 0.05, m19), ('L10', 0.02, m19), ('L01', 0.05, mmore), ('L11', 0.02, mmore)]
    raws = {}
    for name, q, mask in variants:
        lo, hi = train_and_predict(q, mask)
        raws[name] = (lo, hi)
        print(f'[trained] {name} q={q} ({time.perf_counter()-began:.1f}s)', flush=True)

    out = {}
    for year in ('2021', '2022'):
        seed, score = indices_for(data, year)
        print(f'\n===== {year} =====')
        year_rows = {}
        for name, (lo, hi) in raws.items():
            res = simulate(data['origins'], data['target_end'], data['y'], lo, hi,
                           data['valid'], seed, score, 'rolling', 84)
            masks = masks_for(data, res)
            year_rows[name] = {g: group(data, res, masks[g]) for g in ('near_zero', 'up_ramp', 'all', 'ramp')}
        out[year] = year_rows
        for g in ('near_zero', 'up_ramp', 'all'):
            line = f"  {g:9s}"
            for name in ('L00', 'L10', 'L01', 'L11'):
                r = year_rows[name][g]
                line += f"  {name}={r['coverage']*100:5.1f}%" if r else f"  {name}= n/a "
            print(line)
    (OUT / 'results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> out_base_retrain/results.json ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
