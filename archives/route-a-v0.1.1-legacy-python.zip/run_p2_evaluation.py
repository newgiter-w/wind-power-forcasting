"""P2 evaluation on frozen R2 (selected on validation): 2014 Jul-Dec + 2012 re-verify.

R0 reused from saved protocol_v2 arrays; R1/R2 retrained on train phase.
Same rolling-84 CQR (seed=validation, score=evaluation), clip[0,1] after CQR.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from gefcom2014_experiment import metrics
from gefcom_protocol_v2 import index, prepare
from strong_baselines import build_shared, fit_predict, order_quantile_bounds

ROOT = Path(__file__).parent
OUT = ROOT / 'out_gefcom_strong_baselines_v1'
SRC = ROOT / 'out_gefcom_protocol_v2' / 'gefcom2014'


def eval_2014():
    assert json.loads((OUT / 'selection.json').read_text())['selected_method'] == 'R2'
    farms, _ = prepare(2014)
    rows = []
    for farm, d in farms.items():
        tr = index(d, 'train', True); es = index(d, 'validation'); ei = index(d, 'evaluation')
        tr_unfolded = np.repeat(np.isin(np.arange(len(d['origins'])), tr), 24)
        yy = d['y'][ei]; vv = d['valid'][ei]; last = d['history'][ei, -1]
        # R0 from saved
        with np.load(SRC / f'farm_{farm:02d}' / 'B_speed' / 'evaluation_intervals.npz') as z:
            assert np.array_equal(z['indices'], ei)
            L0 = np.clip(z['lo'], 0, 1); U0 = np.clip(z['hi'], 0, 1)
        for g, v in metrics(yy, L0, U0, vv, last).items():
            rows.append(dict(farm=farm, method='R0', group=g, **v))
        # R1, R2 retrain
        for method in ('R1', 'R2'):
            X, y, S = build_shared(d, method)
            lo, _, _ = fit_predict(X, y, tr_unfolded, 0.05)
            hi, _, _ = fit_predict(X, y, tr_unfolded, 0.95)
            lo, hi = order_quantile_bounds(lo, hi)
            res = simulate_eval(d, lo, hi, es, ei)
            L = np.clip(res['lo'], 0, 1); U = np.clip(res['hi'], 0, 1)
            for g, v in metrics(yy, L, U, vv, last).items():
                rows.append(dict(farm=farm, method=method, group=g, **v))
        print(f'  farm{farm:02d} done', flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(OUT / 'p2_2014_eval_per_farm.csv', index=False)
    macro = df.groupby(['method', 'group'])[['coverage', 'width', 'IS', 'lower_miss', 'upper_miss']].mean().reset_index()
    macro.to_csv(OUT / 'p2_2014_eval_macro.csv', index=False)
    return macro


def simulate_eval(d, lo, hi, seed, score):
    from online_calibration import simulate
    return simulate(d['origins'], d['ends'], d['y'], lo, hi, d['valid'], seed, score, 'rolling', 84)


def main():
    began = time.perf_counter()
    macro = eval_2014()
    print('\n===== P2 evaluation 2014 (Jul-Dec, clipped CQR) =====')
    for g in ('all', 'up_ramp', 'near_zero'):
        line = f'  {g:9s}'
        for m in ('R0', 'R1', 'R2'):
            r = macro[(macro.method == m) & (macro.group == g)].iloc[0]
            line += f"  {m}: cov={r['coverage']*100:5.1f}% w={r['width']*100:5.2f}% IS={r['IS']:.4f}"
        print(line)
    print(f'\n[done] ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=2):
        main()
