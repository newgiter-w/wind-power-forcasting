"""Readable pooling comparison and fixed-example interval plots from verified arrays."""
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pooling_common import OUT,ROOT,ANALYSIS_FAMILIES as FAMILIES,write,load_farms
from analyze_pooling import load_stage


def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+
        ['| '+' | '.join(map(str,r))+' |' for r in rows])


def plot_figures(macro):
    dest=OUT/'figures';dest.mkdir(exist_ok=True)
    for year in [2014,2012]:
        data=macro[(macro.year==year)&(macro.stage=='evaluation')&(macro.variant=='signed')].set_index(['family','regime','group'])
        fig,axes=plt.subplots(1,3,figsize=(12,4));x=np.arange(len(FAMILIES))
        for ax,metric,title in zip(axes,['coverage','width','IS'],['Coverage (%)','Width (% capacity)','Interval score']):
            scale=100 if metric!='IS' else 1
            for r,label,color in [('local','Per-farm','#d58a42'),('pooled','Pooled + farm ID','#347ca5')]:
                values=np.array([data.loc[(family,r,'all'),metric] for family in FAMILIES])*scale
                ax.bar(x+(-.18 if r=='local' else .18),values,.36,label=label,color=color)
            ax.set_xticks(x,FAMILIES,rotation=15);ax.set_title(title);ax.grid(axis='y',alpha=.2)
            if metric=='coverage':ax.set_ylim(0,100);ax.axhline(90,color='gray',ls='--',lw=.8)
        handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=2)
        fig.tight_layout(rect=(0,0,1,.88));fig.savefig(dest/f'overall_{year}.png',dpi=170);plt.close(fig)
        # Same origin for all families/regimes, selected before checking forecast errors.
        d=load_farms(year)[1]
        ids,_,_,_=load_stage(year,1,'GBM','local',0,'evaluation','signed');k=int(np.flatnonzero(d['valid'][ids])[0])
        fig,axes=plt.subplots(len(FAMILIES),1,figsize=(10,10),sharex=True,sharey=True)
        for ax,family in zip(axes,FAMILIES):
            for regime,label,color in [('local','Per-farm','#d58a42'),('pooled','Pooled + farm ID','#347ca5')]:
                ix,L,U,_=load_stage(year,1,family,regime,0,'evaluation','signed');np.testing.assert_equal(ids,ix)
                ax.fill_between(np.arange(1,25),L[k],U[k],alpha=.25,color=color,
                    label=f'{label}; mean width={100*(U[k]-L[k]).mean():.1f}%')
            ax.plot(np.arange(1,25),d['y'][ids[k]],color='black',lw=1.3,label='Observed')
            ax.set_ylim(0,1);ax.set_title(family+'; seed0');ax.set_ylabel('Power / capacity');ax.grid(alpha=.2);ax.legend(fontsize=8,loc='upper right')
        axes[-1].set_xlabel('Lead (h)');fig.suptitle(f'{year} farm1; first valid evaluation origin {str(d["origins"][ids[k]])[:10]}')
        fig.tight_layout(rect=(0,0,1,.96));fig.savefig(dest/f'intervals_{year}_farm01.png',dpi=170);plt.close(fig)
        write(dest/f'intervals_{year}_sources.json',dict(year=year,farm=1,seed=0,origin=str(d['origins'][ids[k]]),
            rule='first valid evaluation origin; same date, capacity axis0..1 for all models; not performance-selected',
            preprocessing='saved artifacts only, no retraining',variant='signed rolling CQR, no risk guard'))


def main():
    verification=json.loads((OUT/'verification.json').read_text());assert verification['status']=='passed'
    macro=pd.read_csv(OUT/'metrics_macro.csv');boot=pd.read_csv(OUT/'paired_bootstrap.csv')
    target=pd.read_csv(OUT/'target_checks.csv').fillna('');counts=pd.read_csv(OUT/'training_counts.csv')
    plot_figures(macro)
    results=[];groups=[];cirows=[]
    for year in [2014,2012]:
        for family in FAMILIES:
            m=macro[(macro.year==year)&(macro.family==family)&(macro.stage=='evaluation')&(macro.variant=='signed')].set_index(['regime','group'])
            local,pooled=m.loc[('local','all')],m.loc[('pooled','all')]
            gate=target[(target.year==year)&(target.family==family)&(target.variant=='signed')].iloc[0]
            results.append([year,family,f'{100*local.coverage:.2f}',f'{100*pooled.coverage:.2f}',f'{100*local.width:.2f}',f'{100*pooled.width:.2f}',
                f'{100*(pooled.width/local.width-1):+.2f}%',f'{local.IS:.4f}',f'{pooled.IS:.4f}',gate.target_pass,
                f'{gate.local_farms_ge90}/{gate.farms} → {gate.pooled_farms_ge90}/{gate.farms}'])
            for group in ['near_zero','up_ramp','down_ramp']:
                a,b=m.loc[('local',group)],m.loc[('pooled',group)]
                groups.append([year,family,group,f'{100*a.coverage:.2f}',f'{100*b.coverage:.2f}',f'{100*(b.coverage-a.coverage):+.2f}',f'{a.IS:.4f}',f'{b.IS:.4f}'])
    main_table=table(['数据','模型','单场覆盖%','联合覆盖%','单场宽度%','联合宽度%','宽度相对变化','单场IS','联合IS','≥3%实用门槛通过','保90场数'],results)
    group_table=table(['数据','模型','工况','单场覆盖%','联合覆盖%','变化pp','单场IS','联合IS'],groups)
    for r in boot[(boot.block_days==14)&(boot.variant=='signed')&(boot.group=='all')].itertuples():
        scale=100 if r.metric!='IS' else 1
        cirows.append([r.year,r.family,r.metric+(' (pp)' if scale==100 else ''),f'{scale*r.difference:+.4f}',
            f'[{scale*r.low:+.4f}, {scale*r.high:+.4f}]',f'[{scale*r.pooled_low:.4f}, {scale*r.pooled_high:.4f}]'])
    ci_table=table(['数据','模型','指标','联合−单场','差值95%区间','联合绝对指标95%区间'],cirows)
    secondary=[]
    for year in [2014,2012]:
        for family in FAMILIES:
            d=macro[(macro.year==year)&(macro.family==family)&(macro.stage=='evaluation')&(macro.variant=='protected')].set_index(['regime','group'])
            for regime in ['local','pooled']:
                r=d.loc[(regime,'all')];near=d.loc[(regime,'near_zero')]
                secondary.append([year,family,regime,f'{100*r.coverage:.2f}',f'{100*r.width:.2f}',f'{r.IS:.4f}',f'{100*near.coverage:.2f}'])
    guard_table=table(['数据','模型','训练方式','覆盖%','宽度%','IS','近零覆盖%'],secondary)
    monthly=pd.read_csv(OUT/'monthly_macro.csv');monthrows=[]
    for year in [2014,2012]:
        for family in FAMILIES:
            part=monthly[(monthly.year==year)&(monthly.family==family)&(monthly.group=='all')]
            local=part[part.regime=='local'].sort_values('coverage').iloc[0]
            pooled=part[part.regime=='pooled'].sort_values('coverage').iloc[0]
            monthrows.append([year,family,local.month,f'{100*local.coverage:.2f}',pooled.month,f'{100*pooled.coverage:.2f}'])
    monthtable=table(['数据','模型','单场最弱月份','覆盖%','联合最弱月份','覆盖%'],monthrows)
    mixrows=[]
    for year in [2014,2012]:
        mix=pd.read_csv(OUT/f'{year}_QRF_leaf_farm_mix.csv')
        for r in mix.itertuples():mixrows.append([r.year,r.farm,r.queries,f'{100*r.mean_own_farm_weight:.1f}',f'{100*r.minimum_own_farm_weight:.1f}'])
    mixtable=table(['数据','预测场','抽样目标小时数','自身训练场响应平均权重%','最小权重%'],mixrows)
    choices=[]
    for family in FAMILIES:
        s=json.loads((OUT/f'{family}/selection.json').read_text());choices.append(f'- {family}：2014Q2选择保留 **{s["prefer"]}**；是否通过预设联合门槛：{s["passed"]}。该选择不因2012或评价段结果改变。')
    decisions=[]
    for year in [2014,2012]:
        basic=target[(target.year==year)&(target.variant=='signed')&target.coverage_width_pass]
        passed=target[(target.year==year)&(target.variant=='signed')&target.target_pass]
        if len(basic):decisions.append(f'- {year}：总体覆盖点估计≥90%且宽度小于单场的方案为'+', '.join(basic.family)+'。其中通过预设≥3%缩宽/IS/覆盖变化实用门槛的为'+(', '.join(passed.family) if len(passed) else '无')+'；仍需结合工况、场级覆盖及区间判断。')
        else:decisions.append(f'- {year}：本轮固定配置的联合模型均未同时满足总体覆盖、缩宽和IS门槛。')
    text=f'''# 同一数据集多风场联合训练对照

日期：2026-11-05，Asia/Shanghai。状态：全部模型训练、独立数组复算、保存权重重放与配对区块统计已完成。

## 结论

{chr(10).join(decisions)}

这比较的是已知风场在后续时间的预测，不是7场训练后预测10场，也不是对新风场的零样本泛化。联合训练是否有益取决于模型，不能只因训练记录更多就预先断言区间会更窄。

## 1. 公平对照规则

- GEFCom2014：10场各365个训练原点，共3650场日/87600时效行；2012：7场各548原点，共3836场日/92064时效行。风场共享部分天气，不视作3650/3836个独立天气日。
- 两套数据分别训练，不跨数据集合并；训练/验证/评价日期、目标与发报资格与既有单场实验逐元素一致。
- 时间切分：2014为2012训练、2013Q1早停/校准种子、Q2验证、H2评价；2012为2009H2+2010训练、2011Q1早停/种子、Q2诊断验证、2011-07至2012-06-27评价。每天一次原点、历史24h、未来1–24h，测试期间基础模型不重训。
- 局部模型每场单独拟合。联合模型合并同一数据集所有proper-training标签，加入one-hot场标识；发报仍只用该场自身历史24h和同原点NWP，不读其他场未来真实功率。
- 输出仍是指定风场的24小时容量归一功率区间；合并的是训练样本，不改变预测目标为全场群总功率。
- GBM与单场R2同50轮/31叶/最小叶20/L2=0，种子0。MLP使用相同256/128/64结构、q=.05/.95、Q1早停、种子0/1/2；每场训练段归一化与单场完全一致，再附ID。
- GBM_budget为探索性容量对照：全局迭代数=50×风场数，即2014为500轮、2012为350轮，近似匹配全部局部模型的总树/叶预算。它改变了单模型迭代数，不把收益归为纯粹数据合并。该臂在看到默认50轮联合模型失败后加入，规则不根据2012或其H2结果调整。
- QRF保持500树、叶样本10、max_features=1，完整叶响应、按叶大小加权，种子0/1/2。每场训练中位数+缺失指示与旧单场一致。
- MLP_global为探索性补充：看到2014逐场归一化联合MLP结果后，增加“合并proper-training后全局归一化”对照，不增加网络模块，不改量纲或ID；原MLP使用逐场归一化。该臂不作为事前独立确认，详见normalization_arm.json。
- 所有方案均按场、按时效独立rolling84 CQR，clip[0,1]。没有合并校准误差来掩盖场间异质性。
- 主对照不改超参数。2014Q2总体覆盖≥90%、相对单场下降≤.5pp、宽度相对至少降低3%、IS不增时才选择联合；否则保留单场。选择固定迁移2012。所有候选仍报告。
- 测试期均已在项目开发中查看，所以这些是回溯比较。点估计通过不等于严格概率保证，种子平均不是可部署的集成区间。

## 2. 验证阶段选择

{chr(10).join(choices)}

## 3. 评价期主结果：不加风险保护

{main_table}

“保90场数”按每场种子均值计算。总体宏平均≥90%不代表每个风场或每个工况≥90%；所有逐场与逐种子数值见seed_mean_per_farm.csv及macro_per_seed.csv。

用户提出的“保90并缩宽”和预设“至少缩宽3%且IS不增”的实用门槛分开判断；未通过3%门槛不意味着点估计绝对没有缩宽。3%规则只用于验证选择，不根据评价结果改变。

## 4. 条件工况

{group_table}

近零、爬坡标签只用于事后评价，不用于运行时读取未来状态。某些组覆盖增加可能只是组内加宽，须同时检查IS和宽度；不能只按总体宽度称全面改进。

各方案最弱月份的总体覆盖如下，月份按发报原点分组；月份不同不是配对差值，只是压力诊断。所有月份、逐场样本数与工况指标均保存在monthly_per_farm.csv和monthly_macro.csv。

{monthtable}

## 5. 配对时间区块不确定性

{ci_table}

每次同步抽取所有风场、两种训练方式的相同7/14日历日移动块，各2000次。先平均拟合种子再宏平均风场，保留共享天气的依赖。区间条件于这些已训练模型，未覆盖完整训练随机性；数据反复查看和多比较仍限制推断。绝对覆盖区间若跨90%，不能宣称已统计保证90%覆盖。完整各组区间见paired_bootstrap.csv。

## 6. 统一风险保护的次要诊断

{guard_table}

两种训练方式都使用此前冻结的同一个逐场风险模型及阈值0.1，只在CQR之后将高风险下界降为0，上界不变；不重新选择阈值、不重新训练风险模型。因此保护对照不与联合训练混为一项。主选择仍依据未保护的Q2结果。

## 7. 区间图

所有图固定选择风场1首个有效评价原点，seed0，统一纵轴[0,1]，只从保存数组作图。

![2014总体](figures/overall_2014.png)

![2014同一天单场/联合区间](figures/intervals_2014_farm01.png)

![2012总体](figures/overall_2012.png)

![2012同一天单场/联合区间](figures/intervals_2012_farm01.png)

## 8. QRF内存修正与数值一致性

原full-response QRF用“树×节点×最大叶样本数”填充数组。2014八树试跑形状8×8577×1×500，预计完整模型含裕量约26GB，超过可用内存。没有截断叶响应或改成树均值分位数：新后端用CSR存储全部bootstrap训练响应，使用完全相同的逆叶大小权重和quantile-forest 1.4.2加权线性分位数内核。

小样本连续/零与1质量点/重复值/常数叶检查通过；两套真实500树单场模型对照误差约1e−15。详见sparse_qrf_equivalence.json。稀疏存储是实现改动，不作为方法贡献。所有联合模型随后又从保存权重重放并与区间原始预测核对。

执行资源另见execution_resource_note.json：最初单森林8线程，之后按独立seed最多三个进程、每森林4线程调度；已完成模型复用，模型超参数和随机种子不变。该调度变化不用于挑选预测结果。

## 9. 范围与局限

默认联合GBM/MLP的总参数明显少于所有单场模型之和。QRF虽然从5000棵局部树变成500棵全局树，但没有固定最大深度，单树节点会随训练量增长，不能仅凭树数断言总容量下降。GBM_budget补充近似总树预算匹配，仍不是每模型参数完全相同的纯合并对照。全局MLP每轮看到更多样本，优化步数也不同，Q1早停只作共同开发规则。

本轮只补充一个确定性的GBM总预算对照和一个MLP全局归一化对照，没有扩大容量网格、增加其他场实时功率输入、共享校准池或改业务门槛。补充臂为探索性，全部结果保留。若某方法失败，应如实报告当前配置下的负迁移；若成功，也只支持这些已知场与日期，不能推广为跨新场或所有年份有效。

QRF叶响应的场间混合诊断如下。每7个发报原点取一次，固定时效1/12/24，不按真实误差挑选；表中权重是该次预测分布来自自身场训练标签的比例，局部模型按定义为100%。加入场ID不强制每个叶子只含一个场。混合比例可作为场间异质性解释的线索，不能单独证明它是性能变化的唯一原因。

{mixtable}

## 10. 复现与交付

- pooling_common.py：冻结协议、相同单场预处理、one-hot合并与逐场校准。
- run_pooling_models.py：GBM/MLP/QRF联合拟合及验证阶段选择；MLP多进程隔离各seed随机状态。
- sparse_leaf_qrf.py、verify_sparse_qrf_real.py、test_pooling.py：完整叶响应稀疏后端与一致性/时序回归检查。
- analyze_pooling.py：全数组重算、权重重放、逐场/逐时效及同步区块统计。
- report_pooling.py：本报告和保存数组区间图。
- 原单场结果不改写，source_snapshot保存本轮源码；verification.json记录具体数值和时间检查。
'''
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')
    snap=OUT/'source_snapshot';snap.mkdir(exist_ok=True)
    for name in ['pooling_common.py','run_pooling_models.py','sparse_leaf_qrf.py','verify_sparse_qrf_real.py','verify_pooling_inputs.py','test_pooling.py','analyze_pooling.py','report_pooling.py','finish_pooling.py']:
        shutil.copy2(ROOT/name,snap/name)
    status=ROOT/'COMPLETE_STATUS.md';backup=OUT/'source_before';backup.mkdir(exist_ok=True)
    if not (backup/status.name).exists():shutil.copy2(status,backup/status.name)
    old=status.read_text(encoding='utf-8');marker='\n## 2026-11-05 多风场联合训练对照\n'
    if marker in old:old=old.split(marker)[0]
    status.write_text(old+marker+'\n已完成同数据集内GBM/MLP/QRF单场与联合训练比较，完整结果见[联合训练报告](out_gefcom_pooling_20261105/RESULTS.md)。\n\n'+chr(10).join(decisions)+'\n\n采用相同时间切分、逐场rolling84校准和固定参数；不跨数据集混合，不代表新场泛化。\n',encoding='utf-8')
    write(OUT/'completion.json',dict(status='complete',verification='passed',families=FAMILIES,years=[2014,2012],
        report=str(OUT/'RESULTS.md'),scope='within-dataset known-farm retrospective comparison'))
    print('POOLING REPORT COMPLETE',OUT/'RESULTS.md',flush=True)


if __name__=='__main__':main()
