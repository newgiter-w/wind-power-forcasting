"""Mechanism diagnosis of the frozen Kelmarsh q90 score; no model selection."""
import joblib
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits

from run_kelmarsh_gfs_q90_expand import OUT as EXPANDED,restore,read_months,exact_daily,paired
import run_kelmarsh_gfs_q90 as old
from run_gefcom2012_local_increment import score,threshold,summarize
from revision_common import write

OUT=EXPANDED/'mechanism_diagnosis'
OUT.mkdir(exist_ok=True)


def main():
    forest,imp,model,frozen=restore()
    fit=old.record(read_months(('2023-11',)),forest,imp)
    d=read_months(tuple(f'2024-{m:02}' for m in range(2,13)))
    with threadpool_limits(limits=2):
        original=old.record(d,forest,imp)
        bounded=score(model,original,1.)
        raw_train=model.predict(fit[0]['features'][fit[0]['gate']])
        r=original[0]
        raw=model.predict(r['features'][r['gate']])
    gate=r['gate']
    y=r['actual'][gate]
    base=r['base'][gate]
    candidate=bounded[0]['candidate'][gate]
    change=candidate-base
    train_y=fit[0]['actual'][fit[0]['gate']]
    groups={'all':np.ones(len(y),dtype=bool),'true_ramp':y>.1,'quiet':np.abs(y)<=.05,'other':(y<=.1)&(np.abs(y)>.05)}
    rows=[]
    for name,use in groups.items():
        rows.append(dict(group=name,hours=int(use.sum()),raw_q90_mean=float(raw[use].mean()),
            correction_mean=float(change[use].mean()),correction_std=float(change[use].std()),
            cap_share=float((raw[use]>=.10).mean()),negative_share=float((raw[use]<0).mean()),
            base_mean=float(base[use].mean()),candidate_mean=float(candidate[use].mean()),actual_mean=float(y[use].mean())))
    pd.DataFrame(rows).to_csv(OUT/'score_groups.csv',index=False)
    subset=(y>.1)|(np.abs(y)<=.05)
    outcome=y[subset]>.1
    ranking=dict(train_gated_hours=len(train_y),train_ramps=int((train_y>.1).sum()),
        train_quiet=int((np.abs(train_y)<=.05).sum()),train_correction_cap_share=float((raw_train>=.1).mean()),
        test_spearman=float(spearmanr(base,candidate).statistic),
        base_auc=float(roc_auc_score(outcome,base[subset])),candidate_auc=float(roc_auc_score(outcome,candidate[subset])),
        base_gap=float(base[y>.1].mean()-base[np.abs(y)<=.05].mean()),
        candidate_gap=float(candidate[y>.1].mean()-candidate[np.abs(y)<=.05].mean()),
        constant_training_median=float(np.median(np.clip(raw_train,-.1,.1))))
    write(OUT/'ranking.json',ranking)
    alternatives={'q90_bounded':bounded}
    for name,value in [('constant_training_median',ranking['constant_training_median']),('q90_no_correction_cap',None)]:
        rec=[]
        for a in original:
            p=a['base'].copy()
            delta=raw if value is None else value
            p[a['gate']]=np.clip(p[a['gate']]+delta,-a['before'][a['gate']],1-a['before'][a['gate']])
            rec.append(dict(**a,candidate=p))
        alternatives[name]=rec
    frames=[]
    for name,records in alternatives.items():
        folder=OUT/name
        folder.mkdir(exist_ok=True)
        f=exact_daily(records,threshold(records),folder)
        f.to_csv(folder/'daily.csv',index=False)
        paired(f).to_csv(folder/'paired_blocks.csv',index=False)
        m=summarize(f)
        m.to_csv(folder/'summary.csv')
        m=m.xs('gated',level='scope').reset_index()
        m['ablation']=name
        frames.append(m)
    table=pd.concat(frames,ignore_index=True)
    table.to_csv(OUT/'ablations.csv',index=False)
    leaves=[int(tree.nodes['is_leaf'].sum()) for stage in model._predictors for tree in stage]
    write(OUT/'model_capacity.json',dict(trees=len(leaves),minimum_leaves=min(leaves),maximum_leaves=max(leaves),mean_leaves=float(np.mean(leaves)),min_samples_leaf=model.min_samples_leaf))
    bounded_frame=pd.read_csv(OUT/'q90_bounded'/'daily.csv',parse_dates=['origin'])
    unbounded_frame=pd.read_csv(OUT/'q90_no_correction_cap'/'daily.csv',parse_dates=['origin'])
    pair=pd.concat([bounded_frame[bounded_frame.model.eq('corrected')].assign(model='original'),unbounded_frame[unbounded_frame.model.eq('corrected')]])
    paired(pair).to_csv(OUT/'uncapped_vs_capped_paired.csv',index=False)
    print(pd.DataFrame(rows).round(6).to_string(index=False))
    print(ranking)
    print(table[['ablation','model','hits','events','false','recall','bias','mae','quiet_fpr','all_mae']].round(6).to_string(index=False))


if __name__=='__main__':
    main()

