"""Write the bounded-run conclusion from completed, verified artifacts."""
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).parent
OUT=ROOT/'out_v3'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    verification=read(OUT/'repair'/'artifact_verification.json')
    assert verification['status']=='PASS' and verification['new_model_tasks']==8
    phases={phase:{'analysis':read(OUT/phase/'analysis.json'),
                   'results':read(OUT/phase/'results.json')} for phase in ('repair','x01')}
    assert phases['x01']['analysis']['decision']=='insufficient_evidence'
    lines=['# 修正与唯一 X01 回测：最终结论','',
           '日期：2026-11-01（Asia/Shanghai）；实验切分按UTC。', '',
           '**证据结论：仍不足以支持检索条件化有稳定增益。执行决定：按预定预算停止追加检索条件化实验，暂不将其作为论文主线。**', '',
           '这不是统计证明所有检索无效，也不是两个方法等价；2020/2021两个fold分开报告，不合并日期制造更窄区间。X01额度已使用，不再增加回测、搜索或attention。F/144点确认未触发，未读取2023性能。','',
           '## 实际完成','',
           '- 修复匹配随机的参数包（H0→冻结R对应的H1），实际补训3个种子。',
           '- direct analog改回q05/q95；RD的q10/q90输入定义保持。重算raw/CQR，不重训旧12个主模型。',
           '- 改为配对移动日历块，保留完整预定季度的缺测日；修正阈值、覆盖和随机证据的决策代码。',
           '- 执行X01的NH_H0、R0_dtw_H1与匹配随机H1三种子，共5个任务；没有重新选型。',
           '- 保存新模型、scaler、输入、逐步分位数、signed校准量、日期、上下界、邻居、逐原点损失及运行配置。', '',
           '新增科研训练任务共8个（修正3+X01 5），每任务48个单输出分位数估计器，共384个。另有小型环境/回归检查，不计入科研任务。', '',
           '## 主结果（24个小时平均目标，90%名义水平）','',
           '| 历史fold | B：无检索IS | R：相似检索IS | 匹配随机H1三种子均值 | G(R,B) | 7天块95%区间 |',
           '|---|---:|---:|---:|---:|---:|']
    summary={}
    for phase,label in (('repair','2021 Q2验证，83原点'),('x01','2020 Q2回测，79原点')):
        a=phases[phase]['analysis'];r=phases[phase]['results']
        comp=a['R_vs_B']['7'];lo,hi=comp['gain_ci95']
        random_mean=float(np.mean([r['tasks'][k]['cqr']['score'] for k in a['random_names']]))
        lines.append(f"| {label} | {a['B_metrics']['score']:.6f} | {a['R_metrics']['score']:.6f} | {random_mean:.6f} | {comp['gain']:.2%} | [{lo:.2%}, {hi:.2%}] |")
        summary[phase]={'B_IS':a['B_metrics']['score'],'R_IS':a['R_metrics']['score'],
                        'random_mean_IS':random_mean,'R_vs_B':a['R_vs_B'],
                        'R_vs_random':a['R_vs_random_seed_mean'],'decision':a['decision'],
                        'checks':a['checks'],'B_coverage':a['B_metrics']['coverage'],
                        'R_coverage':a['R_metrics']['coverage']}
    a=phases['x01']['analysis']
    x14=a['R_vs_B']['14'];rand=a['R_vs_random_seed_mean']['7']
    lines += ['',f"X01的14天块区间为[{x14['gain_ci95'][0]:.2%}, {x14['gain_ci95'][1]:.2%}]，仍跨零。",
              f"X01中R相对匹配随机均值的改善为{rand['gain']:.2%}，7天区间[{rand['gain_ci95'][0]:.2%}, {rand['gain_ci95'][1]:.2%}]；没有明确的邻居身份优势。",'',
              f"X01覆盖：B={a['B_metrics']['coverage']:.2%}、R={a['R_metrics']['coverage']:.2%}，都高于预定88%–92%容忍区间。不能把过覆盖算作继续条件已通过，也未根据评分标签临时收窄区间。",'',
              'X01的正点估计可以如实保留，但区间、随机控制和覆盖三项均未通过继续门槛。它不推翻2021验证的负点估计。', '',
              '## 修正后的直接 analog','',
              '| fold | DTW analog raw IS | DTW analog CQR IS | 相对B改善及7天区间 |',
              '|---|---:|---:|---:|']
    for phase in ('repair','x01'):
        result=phases[phase]['results']['baselines']['analog_dtw']
        comp=phases[phase]['analysis']['analog_vs_B']['analog_dtw']['7']
        lines.append(f"| {phase} | {result['raw']['score']:.6f} | {result['cqr']['score']:.6f} | {comp['gain']:.2%} [{comp['gain_ci95'][0]:.2%}, {comp['gain_ci95'][1]:.2%}] |")
    lines += ['',
              '直接analog在2021验证上有较好点估计，在X01却更差，两个区间均较宽；没有达到±2%实际等价区间要求，不能宣布稳定最优或低成本等价。它仍可保留为基线。', '',
              'X01粗略组件计时：DTW analog仅校准/评分查询的独立成本约11.25秒；B的拟合与预测/持久化约6.43秒（均不含共同数据准备）。这不是独立完整吞吐基准，已不足以支持预定的总时间降低50%主张。', '',
              '## 验证与执行账目','',
              '- 6项针对性检查全部通过：名义analog分位数、全候选选择、缺日移动块、决策阈值、区间/校准公式、CPU模型保存重载。',
              '- 新增8个模型任务全部重载预测一致；包含3个analog基线在内，11组新产物均通过独立pinball形式重算IS、覆盖/宽度、校准次序统计量和原点身份检查。',
              '- 2021与X01内部校准样本各83，90%次序统计量rank=76；保留负signed修正。修正DTW analog有1个负修正lead，验证其非空有序，并未错误裁零。',
              '- X01样本M/T/Cal/Score=331/351/83/79；边界断言通过。',
              '- 本次完整科研执行约110秒，含约59秒邻居缓存；不含代码修改、小例子测试和执行后复核。',
              '- 原out_v3的b12_results.json、VALIDATION_RESULTS.md、DECISION.md仍为历史记录；应以repair/x01与本报告为修正后的结论入口。',
              '- 原12个模型只有历史逐原点损失，未伪造其逐步预测；其统计日期按当前相同分段重建。这一限制与新任务完整保存的日期身份已分别标注。', '',
              '## 下一方向','',
              '暂不继续扩展检索条件化，不启动F或attention。以强无检索模型为固定预测器，下一项可研究时间漂移下global/rolling/ACI校准；direct analog+CQR保留对照。该方向需另行冻结在线反馈与选型协议，不能把既有CQR的工程复现直接写成新贡献。本次没有执行新的校准搜索。', '',
              '证据路径：repair/analysis.json、x01/analysis.json、repair/artifact_verification.json；各目录tasks与baselines保存实际模型/预测。']
    (OUT/'FINAL_DECISION_AFTER_X01.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (OUT/'FINAL_DECISION_AFTER_X01.json').write_text(json.dumps(
        {'evidence_conclusion':'insufficient_evidence','resource_decision':'stop_expanding_current_conditioned_retrieval',
         'x01_used':1,'new_training_tasks':8,'confirmation_triggered':False,
         'verification':'PASS','folds':summary},ensure_ascii=False,indent=2),encoding='utf-8')
    print(OUT/'FINAL_DECISION_AFTER_X01.md')


if __name__=='__main__':
    main()
