"""B1/B2 experiment harness: strong baselines (N0/NH) + retrieval representations
(R0 mean+top1 / RD distribution) x {Euclidean, DTW} x {H0, H1}, scored on V_score.

Pre-registered protocol (see out_v3/protocol.json). One predictor per (rep,
distance, package); raw and CQR both reported. No per-candidate hyperparameter
search beyond the two packages.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import joblib

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

import evaluate as ev
import intervals as iv
import models as md
import baselines as bm
from config import default_config
from data import build_situations, load_dataframe
from run import segment_split, assert_time_boundaries
from retrieval import Retriever

PACKAGES = {
    "H0": dict(max_iter=50, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0),
    "H1": dict(max_iter=100, max_leaf_nodes=15, min_samples_leaf=40, l2_regularization=1.0),
}


def retrieve_all(ret, cond, feat, top_k):
    L, D = [], []
    for i in range(len(cond)):
        local, dist, _ = ret.query(cond[i], feat[i], exclude_local=-1, top_k=top_k)
        L.append(local)
        D.append(dist)
    return np.asarray(L), np.asarray(D)


def neighbor_stats(tgt, dist):
    """tgt (N,k,H), dist (N,k) -> weighted mean/top1/std and equal-weight q10/q90."""
    w = 1.0 / (dist + 1e-6)
    w = w / w.sum(axis=1, keepdims=True)
    mean = (w[:, :, None] * tgt).sum(axis=1)
    top1 = tgt[:, 0, :]
    var = (w[:, :, None] * (tgt - mean[:, None, :]) ** 2).sum(axis=1)
    std = np.sqrt(var)
    q10 = np.quantile(tgt, 0.1, axis=1)
    q90 = np.quantile(tgt, 0.9, axis=1)
    return mean, top1, std, q10, q90


def analog_quantiles(tgt, conf):
    """The nominal central interval, distinct from q10/q90 representation features."""
    alpha = 1.0 - conf
    return (np.quantile(tgt, alpha / 2.0, axis=1, method="linear"),
            np.quantile(tgt, 1.0 - alpha / 2.0, axis=1, method="linear"))


def select_candidates(tasks):
    no_ret = {k: v for k, v in tasks.items() if k.startswith(("N0_", "NH_"))}
    retr = {k: v for k, v in tasks.items()
            if k.startswith(("R0_", "RD_")) and "random" not in k}
    return (min(no_ret, key=lambda k: no_ret[k]["cqr"]["score"]),
            min(retr, key=lambda k: retr[k]["cqr"]["score"]))


def build_features(rep, feat, cond, neighbors):
    """neighbors = dict with mean/top1/std/q10/q90 (or None for N0/NH)."""
    if rep == "N0":
        return feat
    if rep == "NH":
        return np.hstack([feat, cond])
    if rep == "R0":
        return np.hstack([feat, neighbors["mean"], neighbors["top1"]])
    if rep == "RD":
        return np.hstack([feat, neighbors["mean"], neighbors["std"], neighbors["q10"], neighbors["q90"]])
    raise ValueError(rep)


def score_interval(y, lo, hi, capacity, alpha):
    return {
        "coverage": ev.coverage(y, lo, hi),
        "width": ev.mean_width(lo, hi, capacity),
        "score": ev.interval_score(y, lo, hi, alpha) / capacity,
    }


def run_task(X_T, y_T, X_Vcal, y_Vcal, X_Vscore, y_Vscore, capacity, conf, pkg, seed,
             artifact_dir=None):
    alpha = 1.0 - conf
    q_lo, q_hi = alpha / 2.0, 1.0 - alpha / 2.0
    cfg = default_config(seed=seed)
    started = time.perf_counter()
    qm_lo = md.fit_quantile(X_T, y_T, q_lo, cfg, pkg)
    qm_hi = md.fit_quantile(X_T, y_T, q_hi, cfg, pkg)
    fit_seconds = time.perf_counter() - started
    started = time.perf_counter()
    lo_raw_s = md.predict(qm_lo, X_Vscore); hi_raw_s = md.predict(qm_hi, X_Vscore)
    lo_raw_c = md.predict(qm_lo, X_Vcal); hi_raw_c = md.predict(qm_hi, X_Vcal)
    # ordered quantiles
    lo_s = np.minimum(lo_raw_s, hi_raw_s); hi_s = np.maximum(lo_raw_s, hi_raw_s)
    lo_c = np.minimum(lo_raw_c, hi_raw_c); hi_c = np.maximum(lo_raw_c, hi_raw_c)
    cross_rate = float((lo_raw_s > hi_raw_s).mean())
    # CQR
    q_h = iv.fit_cqr(y_Vcal, lo_c, hi_c, conf)
    lo_cqr = lo_s - q_h[None, :]
    hi_cqr = hi_s + q_h[None, :]
    empty_rate = float((lo_cqr > hi_cqr).mean())
    if artifact_dir is not None:
        artifact_dir = Path(artifact_dir)
        artifact_dir.mkdir(parents=True, exist_ok=True)
        joblib.dump({"lower": qm_lo, "upper": qm_hi}, artifact_dir / "models.joblib")
        np.savez_compressed(artifact_dir / "predictions.npz", y_cal=y_Vcal, y_score=y_Vscore,
                            lo_raw_cal=lo_raw_c, hi_raw_cal=hi_raw_c,
                            lo_raw_score=lo_raw_s, hi_raw_score=hi_raw_s,
                            lo_cal=lo_c, hi_cal=hi_c, lo_score=lo_s, hi_score=hi_s,
                            q_signed=q_h, lo_cqr=lo_cqr, hi_cqr=hi_cqr)
    if empty_rate:
        raise ValueError("Signed CQR produced an empty interval; apply the predeclared common fallback before ranking")
    result = {
        "raw": score_interval(y_Vscore, lo_s, hi_s, capacity, alpha),
        "cqr": score_interval(y_Vscore, lo_cqr, hi_cqr, capacity, alpha),
        "raw_per_origin": ev.per_origin_score(y_Vscore, lo_s, hi_s, alpha, capacity).tolist(),
        "cqr_per_origin": ev.per_origin_score(y_Vscore, lo_cqr, hi_cqr, alpha, capacity).tolist(),
        "crossing_rate": cross_rate,
        "empty_rate": empty_rate,
        "calibration_crossing_rate": float((lo_raw_c > hi_raw_c).mean()),
        "q_signed": q_h.tolist(),
        "negative_correction_steps": int((q_h < 0).sum()),
        "package": dict(pkg), "model_seed": seed,
        "feature_count": int(X_T.shape[1]), "fit_seconds": fit_seconds,
        "predict_calibrate_persist_seconds": time.perf_counter() - started,
        "postprocessing": "ordered_quantiles_signed_cqr",
    }
    return result


def main():
    t0 = time.time()
    cfg = default_config(
        points_per_day=144, stride_points=144, horizon_days=1, condition_days=1,
        horizon_bins=24, analog_bins=24, top_k=20, nn_candidates=40, dtw_band=12,
        kelmarsh_root=r"D:\Study\wind_datasets\kelmarsh",
        kelmarsh_cache=r"D:\Study\wind_datasets\kelmarsh\farm_cache_2018_2022.csv",
        weather_cols=["wind_speed", "wind_dir_sin", "wind_dir_cos", "temperature"],
        capacity=12300.0,
    )
    conf = 0.90
    alpha = 1.0 - conf
    OUT = "out_v3"
    os.makedirs(OUT, exist_ok=True)

    df = load_dataframe(cfg)
    d = build_situations(df, cfg)
    seg = segment_split(d["origin_ts"])
    assert_time_boundaries(d, seg)
    tvalid = d["target_valid"]
    cond, target, feat = d["cond"], d["target"], d["feat"]
    capacity = d["capacity"]

    M_idx = np.where(seg["M"] & tvalid)[0]
    T_idx = np.where(seg["T"] & tvalid)[0]
    Vcal_idx = np.where(seg["V_cal"] & tvalid)[0]
    Vscore_idx = np.where(seg["V_score"] & tvalid)[0]

    # ---- retrievers (Euclidean and DTW) ----
    cfg_e = default_config(**{**cfg.as_dict(), "use_dtw": False})
    cfg_d = default_config(**{**cfg.as_dict(), "use_dtw": True})
    ret_e = Retriever(cond[M_idx], feat[M_idx], target[M_idx], M_idx, cfg_e)
    ret_d = Retriever(cond[M_idx], feat[M_idx], target[M_idx], M_idx, cfg_d)

    # retrieve neighbors for T/Vcal/Vscore under both distances
    neighbors = {}  # neighbors[dist][split] = dict(mean,top1,std,q10,q90)
    for dist, ret in [("euclid", ret_e), ("dtw", ret_d)]:
        neighbors[dist] = {}
        for split, idx in [("T", T_idx), ("Vcal", Vcal_idx), ("Vscore", Vscore_idx)]:
            L, D = retrieve_all(ret, cond[idx], feat[idx], cfg.top_k)
            tgt = ret.target[L]
            mean, top1, std, q10, q90 = neighbor_stats(tgt, D)
            neighbors[dist][split] = dict(mean=mean, top1=top1, std=std, q10=q10, q90=q90, L=L, D=D)
        print(f"[retrieve] {dist} done ({time.time()-t0:.0f}s)")

    y_T, y_Vcal, y_Vscore = target[T_idx], target[Vcal_idx], target[Vscore_idx]

    # ---- baselines (climatology, persistence, analog AE/AD) ----
    base = {}
    lo, hi = bm.climatology(y_T, len(Vscore_idx), conf)
    base["climatology"] = score_interval(y_Vscore, lo, hi, capacity, alpha)
    lo, hi = bm.persistence(cond[Vscore_idx], y_Vscore.shape[1], conf, y_Vcal, cond[Vcal_idx])
    base["persistence"] = score_interval(y_Vscore, lo, hi, capacity, alpha)
    for dist, ret in [("euclid", ret_e), ("dtw", ret_d)]:
        nbr = neighbors[dist]["Vscore"]
        lo, hi = analog_quantiles(ret.target[nbr["L"]], conf)
        base[f"analog_{dist}"] = score_interval(y_Vscore, lo, hi, capacity, alpha)
        # analog + CQR from the same nominal quantiles on Vcal.
        nbr_c = neighbors[dist]["Vcal"]
        lo_c, hi_c = analog_quantiles(ret.target[nbr_c["L"]], conf)
        q_h = iv.fit_cqr(y_Vcal, lo_c, hi_c, conf)
        lo_cqr = lo - q_h[None, :]; hi_cqr = hi + q_h[None, :]
        base[f"analog_{dist}_cqr"] = score_interval(y_Vscore, lo_cqr, hi_cqr, capacity, alpha)

    # ---- B1/B2 model tasks ----
    results = {"baselines": base, "tasks": {}}
    specs = []
    for rep in ["N0", "NH"]:
        for pkg in ["H0", "H1"]:
            specs.append(dict(rep=rep, dist=None, pkg=pkg))
    for rep in ["R0", "RD"]:
        for dist in ["euclid", "dtw"]:
            for pkg in ["H0", "H1"]:
                specs.append(dict(rep=rep, dist=dist, pkg=pkg))

    for spec in specs:
        rep, dist, pkg = spec["rep"], spec["dist"], spec["pkg"]
        name = f"{rep}" + (f"_{dist}" if dist else "") + f"_{pkg}"
        # build X for T/Vcal/Vscore
        if rep in ("N0", "NH"):
            X_T = build_features(rep, feat[T_idx], cond[T_idx], None)
            X_Vcal = build_features(rep, feat[Vcal_idx], cond[Vcal_idx], None)
            X_Vscore = build_features(rep, feat[Vscore_idx], cond[Vscore_idx], None)
        else:
            X_T = build_features(rep, feat[T_idx], cond[T_idx], neighbors[dist]["T"])
            X_Vcal = build_features(rep, feat[Vcal_idx], cond[Vcal_idx], neighbors[dist]["Vcal"])
            X_Vscore = build_features(rep, feat[Vscore_idx], cond[Vscore_idx], neighbors[dist]["Vscore"])
        scaler = StandardScaler().fit(X_T)
        X_T = scaler.transform(X_T); X_Vcal = scaler.transform(X_Vcal); X_Vscore = scaler.transform(X_Vscore)
        r = run_task(X_T, y_T, X_Vcal, y_Vcal, X_Vscore, y_Vscore, capacity, conf, PACKAGES[pkg], seed=0)
        results["tasks"][name] = r
        print(f"[task] {name}: raw IS={r['raw']['score']:.4f} cov={r['raw']['coverage']*100:.1f}% | "
              f"cqr IS={r['cqr']['score']:.4f} cov={r['cqr']['coverage']*100:.1f}% "
              f"(cross {r['crossing_rate']*100:.1f}%, empty {r['empty_rate']*100:.1f}%)")

    # ---- B3: match the actually selected candidate, including its parameter package ----
    # matched weights = the DTW similar retrieval's normalized inverse-distance weights,
    # reassigned to random M continuations (isolates neighbor identity vs weighting).
    _, selected_r = select_candidates(results["tasks"])
    selected_rep, selected_dist, selected_pkg = selected_r.split("_")
    selected_ret = ret_d if selected_dist == "dtw" else ret_e
    w = {}
    for split in ["T", "Vcal", "Vscore"]:
        D = neighbors[selected_dist][split]["D"]
        ww = 1.0 / (D + 1e-6)
        ww = ww / ww.sum(axis=1, keepdims=True)
        w[split] = ww
    for seed in [0, 1, 2]:
        rng = np.random.default_rng(seed)
        name = f"{selected_rep}_{selected_dist}_random{seed}_{selected_pkg}"
        Xs = {}
        for split, idx in [("T", T_idx), ("Vcal", Vcal_idx), ("Vscore", Vscore_idx)]:
            L_rand = np.array([rng.choice(len(M_idx), size=cfg.top_k, replace=False) for _ in range(len(idx))])
            tgt_rand = selected_ret.target[L_rand]
            mean = (w[split][:, :, None] * tgt_rand).sum(axis=1)
            top1 = tgt_rand[:, 0, :]
            var = (w[split][:, :, None] * (tgt_rand - mean[:, None, :]) ** 2).sum(axis=1)
            nr = dict(mean=mean, top1=top1, std=np.sqrt(var),
                      q10=np.quantile(tgt_rand, .1, axis=1), q90=np.quantile(tgt_rand, .9, axis=1))
            Xs[split] = build_features(selected_rep, feat[idx], cond[idx], nr)
        scaler = StandardScaler().fit(Xs["T"])
        X_T = scaler.transform(Xs["T"]); X_Vcal = scaler.transform(Xs["Vcal"]); X_Vscore = scaler.transform(Xs["Vscore"])
        r = run_task(X_T, y_T, X_Vcal, y_Vcal, X_Vscore, y_Vscore, capacity, conf, PACKAGES[selected_pkg], seed=0)
        results["tasks"][name] = r
        print(f"[task] {name}: raw IS={r['raw']['score']:.4f} cov={r['raw']['coverage']*100:.1f}% | "
              f"cqr IS={r['cqr']['score']:.4f} cov={r['cqr']['coverage']*100:.1f}%")

    with open(os.path.join(OUT, "b12_results.json"), "w") as f:
        json.dump({"config": cfg.as_dict(), "results": results}, f, indent=2, default=str)
    print(f"\n[done] {len(specs) + 3} tasks + baselines in {time.time()-t0:.0f}s -> out_v3/b12_results.json")


if __name__ == "__main__":
    main()
