"""Point and quantile forecasting models (multi-output, retrieval-conditioned).

`pkg` is a parameter-package dict (max_iter / max_leaf_nodes / min_samples_leaf /
l2_regularization) so each candidate gets the SAME two pre-registered settings
(H0 / H1), not a per-candidate search.
"""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.multioutput import MultiOutputRegressor

from config import Config


def _point_estimator(cfg: Config, pkg: dict = None):
    p = pkg or {}
    return HistGradientBoostingRegressor(
        loss="squared_error",
        max_iter=p.get("max_iter", cfg.n_estimators),
        max_depth=p.get("max_depth", cfg.max_depth),
        max_leaf_nodes=p.get("max_leaf_nodes"),
        min_samples_leaf=p.get("min_samples_leaf", 20),
        l2_regularization=p.get("l2_regularization", 0.0),
        random_state=cfg.seed,
    )


def _quantile_estimator(cfg: Config, q: float, pkg: dict = None):
    p = pkg or {}
    return HistGradientBoostingRegressor(
        loss="quantile",
        quantile=q,
        max_iter=p.get("max_iter", cfg.n_estimators),
        max_depth=p.get("max_depth", cfg.max_depth),
        max_leaf_nodes=p.get("max_leaf_nodes"),
        min_samples_leaf=p.get("min_samples_leaf", 20),
        l2_regularization=p.get("l2_regularization", 0.0),
        random_state=cfg.seed,
    )


def fit_point(X: np.ndarray, Y: np.ndarray, cfg: Config, pkg: dict = None):
    m = MultiOutputRegressor(_point_estimator(cfg, pkg))
    m.fit(X, Y)
    return m


def fit_quantile(X: np.ndarray, Y: np.ndarray, q: float, cfg: Config, pkg: dict = None):
    m = MultiOutputRegressor(_quantile_estimator(cfg, q, pkg))
    m.fit(X, Y)
    return m


def predict(model, X: np.ndarray) -> np.ndarray:
    return np.asarray(model.predict(X), dtype=float)
