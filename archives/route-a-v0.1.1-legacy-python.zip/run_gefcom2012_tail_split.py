"""Q95-score split contrast with unchanged QRF lower and median heads."""
from concurrent.futures import ProcessPoolExecutor
import json
import os

from diagnose_gefcom2012_ramp_amplitude import OUT, YEAR
from run_point_residual import OUT as BASE, cells, load_farms, index, feature_array
from revision_common import frozen_spec, write
from sparse_leaf_qrf import SparseLeafQRF, RandomForestRegressor
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits
import numpy as np

FOLDS = 4
SEED = 0


def pilot_scores(x,y):
    """Build cross-fitted pinball gradients inside proper training only."""
    day_ids = np.arange(len(y))
    scores = np.empty(y.shape)
    for valid in np.array_split(day_ids,FOLDS):
        train = np.setdiff1d(day_ids,valid)
        with threadpool_limits(limits=2):
            model = HistGradientBoostingRegressor(loss='quantile',quantile=.95,max_iter=50,
                max_leaf_nodes=15,min_samples_leaf=40,early_stopping=False,random_state=SEED)
            model.fit(x[cells(train)],y[train].ravel())
            pilot = model.predict(x[cells(valid)]).reshape(-1,24)
        scores[valid] = (y[valid]>pilot).astype(float)-.05
    return scores.ravel()


def fit(job):
    farm, stage = job
    folder = OUT/f'farm_{farm:02}'
    folder.mkdir(exist_ok=True)
    path = folder/f'{stage}.npz'
    if path.exists():
        return
    d = load_farms(YEAR)[farm]
    tr = index(d,'train',True)
    query = np.concatenate([index(d,s) for s in ('validation_seed','validation','evaluation')])
    assert d['ends'][tr].max()<=d['origins'][query].min()
    x = feature_array(YEAR,farm,'QRF')
    tx,y = x[cells(tr)],d['y'][tr]
    gradient = pilot_scores(tx,y)
    assert len(np.unique(gradient))==2
    model=SparseLeafQRF(500,10,SEED,n_jobs=2)
    model.forest = RandomForestRegressor(n_estimators=500,min_samples_leaf=10,max_features=1.,
        bootstrap=True,random_state=SEED,n_jobs=2).fit(tx,gradient)
    model.build_responses(tx,y.ravel())
    head = model.predict(x[cells(query)],(.95,)).reshape(-1,24)
    assert np.isfinite(head).all() and (head>=0).all() and (head<=1).all()
    tmp=folder/'pending.npz'
    np.savez_compressed(tmp,ids=query,origins=d['origins'][query],upper=head,
        train=tr,positive_fraction=(gradient>0).mean())
    os.replace(tmp,path)
    print('HEADS',farm,flush=True)


def main():
    assert json.loads((OUT/'diagnostic_decision.json').read_text())['advance_tail_split']
    frozen_spec(OUT/'model_protocol.json',dict(model='500 bootstrap trees, leaf10, all features, seed0; split on .95-quantile pinball negative gradient proxy from a fixed pilot',
        pilot='four contiguous proper-training day folds, leave-one-fold-out HistGBR q95; only proper training, not a sequential backtest within training',
        output='original full weighted response quantile q95 from gradient-split leaves; hold raw original q05 and q50; floor new q95 at available original median (or q05 in seed archive)',
        calibration='same per-farm per-lead signed rolling84 CQR; raw q05 fixed, calibrated q05 can move',
        dev_gate='raw q95 pinball not worse AND ramp upper miss lower AND ramp mean exceedance not worse; report same-hour signal subgroup',
        evaluation='stop before scoring evaluation if raw gate fails; if pass, compare nominal and exact/frozen-width replay with usual gates'))
    with ProcessPoolExecutor(max_workers=7) as pool:
        list(pool.map(fit,[(farm,'heads') for farm in load_farms(YEAR)]))
    write(OUT/'training_complete.json',dict(farms=7))


if __name__=='__main__':
    main()
