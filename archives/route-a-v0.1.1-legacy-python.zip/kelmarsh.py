"""Kelmarsh wind-farm loader.

The Greenbyte SCADA export has a `#`-prefixed comment block AND a `#`-prefixed
header row. Missing values are the literal string "NaN". Data is per-turbine
(`Turbine_Data_Kelmarsh_{1..6}_...csv`); this module reads the 7 signals we need
and aggregates them to farm level.

Output columns (farm level):
    timestamp          datetime (UTC), 10-min grid
    power              farm active power (kW)  = sum over turbines
    wind_speed         mean over turbines (m/s)
    wind_dir_sin       mean of sin(wind_dir)   (circular, for retrieval/features)
    wind_dir_cos       mean of cos(wind_dir)
    temperature        mean nacelle ambient temperature (degC)
    setpoint           farm power setpoint (kW) = sum over turbines
    availability       fraction of turbines with valid power in that step
"""
from __future__ import annotations

import csv
import glob
import io
import os

import numpy as np
import pandas as pd

# exact Greenbyte column name -> internal short name
KEY_COLS = {
    "Date and time": "timestamp",
    "Power (kW)": "power",
    "Wind speed (m/s)": "wind_speed",
    "Wind direction (°)": "wind_dir",
    "Nacelle ambient temperature (°C)": "temperature",
    "Data Availability": "availability",
    "Turbine Power setpoint (kW)": "setpoint",
}


def _parse_header(header_line: str) -> list:
    # csv.reader handles quoted fields (some names contain commas)
    return next(csv.reader([header_line]))


def read_turbine(path: str) -> pd.DataFrame:
    """Read one Turbine_Data_*.csv into a slim (timestamp + 7 cols) frame.

    Uses positional usecols + streaming read (no full-file readlines), because
    each file has 200+ columns over ~52k rows.
    """
    header_idx = None
    cols = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for i, ln in enumerate(f):
            s = ln.rstrip("\r\n")
            if s.startswith("#") and "Date and time" in s:
                header_idx = i
                cols = _parse_header(s[1:].strip())  # drop leading '#'
                break
    if header_idx is None:
        raise ValueError(f"no header line found in {path}")

    key_names = list(KEY_COLS.keys())
    try:
        pos = [cols.index(k) for k in key_names]
    except ValueError:
        def _norm(s):
            return s.replace("°", "DEG").replace("º", "DEG")
        ncols = [_norm(c) for c in cols]
        pos = [ncols.index(_norm(k)) for k in key_names]

    # pandas SORTS integer usecols, so read by sorted positions then re-map + reorder.
    pos_to_short = {p: KEY_COLS[k] for p, k in zip(pos, key_names)}
    sorted_pos = sorted(pos)
    df = pd.read_csv(
        path, skiprows=header_idx + 1, header=None,
        na_values=["NaN"], usecols=sorted_pos, low_memory=False,
    )
    df.columns = [pos_to_short[p] for p in sorted_pos]
    df = df[list(KEY_COLS.values())]  # canonical column order

    df["timestamp"] = pd.to_datetime(df["timestamp"], format="%Y-%m-%d %H:%M:%S")
    for c in ["power", "wind_speed", "wind_dir", "temperature", "setpoint"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["availability"] = pd.to_numeric(df["availability"], errors="coerce")
    return df[["timestamp", "power", "wind_speed", "wind_dir", "temperature", "setpoint", "availability"]]


def load_kelmarsh(root: str, years=None, turbines=(1, 2, 3, 4, 5, 6)) -> pd.DataFrame:
    """Aggregate 6 turbines to farm level over the requested years."""
    frames = []
    for y in years if years else _available_years(root):
        for t in turbines:
            pat = os.path.join(root, "extracted", f"Kelmarsh_SCADA_{y}_*",
                               f"Turbine_Data_Kelmarsh_{t}_*.csv")
            hits = glob.glob(pat)
            for h in hits:
                frames.append(read_turbine(h))
    if not frames:
        raise FileNotFoundError(f"no turbine files under {root}")

    all_t = pd.concat(frames, ignore_index=True)
    all_t["wind_dir_rad"] = np.deg2rad(all_t["wind_dir"])
    all_t["wind_dir_sin"] = np.sin(all_t["wind_dir_rad"])
    all_t["wind_dir_cos"] = np.cos(all_t["wind_dir_rad"])

    g = all_t.groupby("timestamp")
    farm = pd.DataFrame({
        "power": g["power"].sum(min_count=1),   # raw sum (undercounts if a turbine is missing)
        "n_valid": g["power"].count(),          # turbines with valid power in this step
        "wind_speed": g["wind_speed"].mean(),
        "wind_dir_sin": g["wind_dir_sin"].mean(),
        "wind_dir_cos": g["wind_dir_cos"].mean(),
        "temperature": g["temperature"].mean(),
        "setpoint": g["setpoint"].sum(min_count=1),
    }).reset_index()
    farm["availability"] = farm["n_valid"] / len(turbines)
    return farm.sort_values("timestamp").reset_index(drop=True)


def _available_years(root: str):
    dirs = glob.glob(os.path.join(root, "extracted", "Kelmarsh_SCADA_*"))
    years = []
    for d in dirs:
        base = os.path.basename(d)  # e.g. Kelmarsh_SCADA_2016_3082
        try:
            years.append(int(base.split("_")[2]))
        except (IndexError, ValueError):
            pass
    return sorted(set(years))


def prepare_farm(farm: pd.DataFrame, freq: str = "10min") -> pd.DataFrame:
    """Reindex to a full 10-min grid and SEPARATE history (filled) from target (raw).

    Columns added/changed:
        power         valid farm power (NaN unless ALL turbines measured) -> TARGET
        power_valid   bool mask: all 6 turbines had valid power in this step
        power_filled  causal forward-fill of `power` -> HISTORY / condition window
    Weather is causally forward-filled (history features only). No row dropping:
    target NaN is meaningful and kept, so the time grid is never compressed.
    """
    farm = farm.set_index("timestamp").sort_index()
    full = pd.date_range(farm.index.min(), farm.index.max(), freq=freq)
    farm = farm.reindex(full)
    n_turbines = 6
    farm["power_valid"] = (farm["n_valid"] >= n_turbines).fillna(False)
    farm["power"] = farm["power"].where(farm["power_valid"])   # NaN unless fully observed
    farm["power_filled"] = farm["power"].ffill()               # causal, for history only
    for c in ["wind_speed", "wind_dir_sin", "wind_dir_cos", "temperature", "setpoint"]:
        farm[c] = farm[c].ffill()
    farm = farm.reset_index().rename(columns={"index": "timestamp"})
    return farm


def build_farm_cache(root: str, cache_path: str, years=None,
                     turbines=(1, 2, 3, 4, 5, 6)) -> pd.DataFrame:
    """Read raw SCADA once (slow) and write a slim farm-level cache (fast reload)."""
    farm = load_kelmarsh(root, years=years, turbines=turbines)
    farm = prepare_farm(farm)
    os.makedirs(os.path.dirname(cache_path) or ".", exist_ok=True)
    farm.to_csv(cache_path, index=False)
    return farm


def load_farm_cache(cache_path: str) -> pd.DataFrame:
    farm = pd.read_csv(cache_path, parse_dates=["timestamp"])
    farm["power_valid"] = farm["power_valid"].astype(bool)
    return farm


def diagnostic(farm: pd.DataFrame) -> dict:
    """Per-year quality summary for choosing the admissible window."""
    farm = farm.copy()
    farm["year"] = farm["timestamp"].dt.year
    out = {}
    for y, grp in farm.groupby("year"):
        n = len(grp)
        out[y] = {
            "rows": n,
            "power_valid": float(grp["power"].notna().mean()),
            "wind_valid": float(grp["wind_speed"].notna().mean()),
            "avail>=0.9": float((grp["availability"] >= 0.9).mean()),
            "mean_power": float(grp["power"].mean()) if grp["power"].notna().any() else None,
        }
    return out


if __name__ == "__main__":
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else r"D:\Study\wind_datasets\kelmarsh"
    farm = load_kelmarsh(root)
    print(f"total rows: {len(farm)}, span {farm.timestamp.min()} .. {farm.timestamp.max()}")
    diag = diagnostic(farm)
    for y, d in diag.items():
        print(f"{y}: rows={d['rows']:>6} power_valid={d['power_valid']*100:5.1f}% "
              f"wind_valid={d['wind_valid']*100:5.1f}% avail>=0.9={d['avail>=0.9']*100:5.1f}% "
              f"mean_power={d['mean_power']:.0f} kW")
