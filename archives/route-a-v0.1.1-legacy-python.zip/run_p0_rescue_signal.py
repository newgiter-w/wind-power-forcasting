"""P0-followup: what separates rescuable from non-rescuable down-ramp lower misses.

Read-only. For each down-ramp hour where R15 misses below (y < L_R15), label it
rescuable (L_O <= y) vs non-rescuable (y < L_O), and profile the issuance-time
signals: gap=L_R15-L_O, wind_drop (1h same-issue NWP speed drop), median_drop
(1h QRF median drop), and the frozen down-ramp classifier probability. Reports
recall of simple thresholds on the rescuable set (target: beat wind_drop's 8).
"""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SAMPLES = ROOT / 'out_gefcom_pooling_20261105' / 'inputs'
GUARD = ROOT / 'out_gefcom_qrf_down_guard_20261106'
POINT = ROOT / 'out_gefcom_point_residual_20261106'
OUT = ROOT / 'out_gefcom_p0_rescue_20261106'


def cells(days):
    return (days[:, None] * 24 + np.arange(24)).ravel()


def increments(power, history):
    return np.diff(np.c_[history[:, -1], power], axis=1)


def added_features(x):
    speed = x[:, -12].reshape(-1, 24)
    cols = []
    for lag in (1, 2, 3):
        difference = np.full_like(speed, np.nan)
        difference[:, lag:] = speed[:, lag:] - speed[:, :-lag]
        cols.append(difference.ravel())
    return np.column_stack(cols)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for year in (2014, 2012):
        nfarms = 10 if year == 2014 else 7
        for farm in range(1, nfarms + 1):
            with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'samples.npz') as z:
                d = {k: z[k] for k in z.files}
            with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'features.npz') as z:
                fqrf = z['QRF']
                fgbm = z['GBM']
            with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'R15.npz') as z:
                ids = z['ids']; lo_r = z['lo']; hi_r = z['hi']
            with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'original.npz') as z:
                np.testing.assert_array_equal(z['ids'], ids); lo_o = z['lo']
            with np.load(POINT / f'gefcom{year}' / f'farm_{farm:02d}' / 'heads.npz') as z:
                qrf_med = z['qrf']
            model = joblib.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'classifier.joblib')

            y = d['y'][ids]
            valid = d['valid'][ids]
            hist = d['history'][ids]
            valid2 = np.broadcast_to(valid[:, None], y.shape)
            delta = np.diff(y, axis=1, prepend=hist[:, -1][:, None])

            gap = lo_r - lo_o
            wind_drop = -added_features(fgbm)[cells(ids), 0].reshape(y.shape)
            median_drop = -increments(qrf_med[ids], hist)
            clf_prob = model.predict_proba(fqrf[cells(ids)])[:, 1].reshape(y.shape)

            dlm = (y < lo_r) & (delta < -0.10) & valid2
            rescuable = dlm & (y >= lo_o)
            nonrescuable = dlm & (y < lo_o)

            for label, m in [('rescuable', rescuable), ('non_rescuable', nonrescuable)]:
                if not m.any():
                    continue
                for name, arr in [('gap', gap), ('wind_drop', wind_drop),
                                  ('median_drop', median_drop), ('clf_prob', clf_prob),
                                  ('delta', delta)]:
                    v = arr[m]
                    rows.append(dict(year=year, farm=farm, label=label, signal=name,
                                     n=int(v.size), mean=float(np.nanmean(v)),
                                     median=float(np.nanmedian(v)),
                                     p25=float(np.nanpercentile(v, 25)),
                                     p75=float(np.nanpercentile(v, 75))))

            # recall of threshold rules on the rescuable set
            if rescuable.any():
                n_resc = int(rescuable.sum())
                for name, arr in [('wind_drop', wind_drop), ('median_drop', median_drop),
                                  ('clf_prob', clf_prob), ('gap', gap)]:
                    threshs = [0.25, 0.50, 0.75] if name == 'wind_drop' else \
                              [0.025, 0.05, 0.10] if name == 'median_drop' else \
                              [0.10, 0.20, 0.30] if name == 'clf_prob' else \
                              [0.02, 0.05, 0.10]
                    for t in threshs:
                        flagged = arr >= t
                        rescued = int((flagged & rescuable).sum())
                        # precision: rescued / flagged among down-ramp lower-miss (resc + nonresc)
                        flagged_dlm = int((flagged & dlm).sum())
                        prec = rescued / flagged_dlm if flagged_dlm else float('nan')
                        rows.append(dict(year=year, farm=farm, label='threshold', signal=f'{name}>={t}',
                                         n=n_resc, mean=rescued / n_resc,
                                         median=prec, p25=float('nan'), p75=float('nan')))

    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / 'rescuable_signal_profile.csv', index=False)

    # summary: mean recall across farms per threshold
    th = frame[frame.label == 'threshold'].copy()
    th['recall'] = th['mean']
    th['precision'] = th['median']
    recall = th.groupby(['year', 'signal']).agg(recall=('recall', 'mean'),
                                                precision=('precision', 'mean'),
                                                n_farms=('recall', 'size')).reset_index()
    recall.to_csv(OUT / 'rescuable_signal_recall.csv', index=False)

    prof = frame[frame.label.isin(['rescuable', 'non_rescuable'])].copy()
    prof_pivot = prof.groupby(['year', 'label', 'signal'])[['mean', 'median', 'p25', 'p75']].mean().reset_index()
    prof_pivot.to_csv(OUT / 'rescuable_signal_profile_summary.csv', index=False)

    print('=== threshold recall on rescuable set (macro across farms) ===')
    print(recall.round(3).to_string(index=False))
    print()
    print('=== signal profile: rescuable vs non_rescuable (macro mean) ===')
    print(prof_pivot.round(4).to_string(index=False))
    print()
    print('COMPLETE')


if __name__ == '__main__':
    main()
