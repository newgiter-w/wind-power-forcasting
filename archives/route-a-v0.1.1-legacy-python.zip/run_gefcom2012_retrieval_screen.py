"""Equal-width, chronological analogue calibration for frozen GEFCom2012 QRF."""
import numpy as np
import pandas as pd

from run_point_residual import ROOT, OUT as BASE, load_farms, feature_array, index
from pooling_common import local_heads
from revision_common import calibration, collect, frozen_spec, write, METRIC_COLS
from run_qrf_regime_bounds import GROUPS, bootstrap
from gefcom2014_experiment import masks

OUT = ROOT/'out_gefcom2012_retrieval_screen'
K = 24
SEEDS = (11, 23, 37, 49, 61)
STRENGTHS = (.25, .50)
LIMIT = .05
YEAR = 2012


def representation(d, farm):
    canonical = feature_array(YEAR, farm, 'GBM')
    wind = canonical[:, -14:-12].reshape(-1, 24, 2)
    speed = np.linalg.norm(wind, axis=-1)
    tr = index(d, 'train', True)
    blocks = (wind.reshape(-1, 48), np.diff(speed, axis=1), d['history'][:, -1:])
    features = []
    for block in blocks:
        scale = block[tr].std(axis=0).clip(min=1e-8)
        features.append((block-block[tr].mean(axis=0))/scale/np.sqrt(block.shape[1]))
    x = np.column_stack(features)
    assert np.isfinite(x).all()
    distances = np.linalg.norm(x[:, None]-x[None, :], axis=-1)
    # Training-only reference for the distance to the Kth usable neighbour.
    typical = []
    for i in tr:
        pool = tr[(d['ends'][tr] <= d['origins'][i]) &
                  (d['ends'][tr] > d['origins'][i]-np.timedelta64(84, 'D')) & (tr < i)]
        if len(pool) >= K:
            typical.append(np.partition(distances[i, pool], K-1)[K-1])
    return distances, float(np.quantile(typical, .90))


def ranked_quantile(scores):
    rank = min(len(scores), int(np.ceil(.90*(len(scores)+1))))-1
    return np.partition(scores, rank, axis=0)[rank]


def retrieve(d, farm, ids, stage, distance, threshold, raw_upper):
    seed_phase = 'validation_seed' if stage == 'validation' else 'validation'
    seed = index(d, seed_phase)
    history = np.r_[seed, ids]
    errors = d['y']-raw_upper
    rngs = [np.random.default_rng(s+100*farm) for s in SEEDS]
    neighbors = np.full((len(ids), 1+len(SEEDS), K), -1, dtype=int)
    proposals = np.zeros((len(ids), 1+len(SEEDS), 24))
    pool_counts, kth, reasons = [], [], []
    for j, i in enumerate(ids):
        now = d['origins'][i]
        past = history[:len(seed)+j]
        age = (now-d['ends'][past])/np.timedelta64(1,'D')
        eligible = (age >= 0) & (age < 84) & d['valid'][past]
        pool, age = past[eligible], age[eligible]
        pool_counts.append(len(pool))
        assert (d['ends'][pool] <= now).all() and i not in pool
        if len(pool) < K:
            kth.append(np.nan)
            reasons.append('few')
            continue
        positions = np.argsort(distance[i, pool], kind='stable')[:K]
        radius = distance[i, pool[positions[-1]]]
        kth.append(radius)
        if radius > threshold:
            reasons.append('distance')
            continue
        reasons.append('used')
        bins = (age//21).astype(int)
        neighbors[j, 0] = pool[positions]
        for arm, rng in enumerate(rngs, 1):
            picked = [rng.choice(np.flatnonzero(bins == b), size=(bins[positions] == b).sum(), replace=False)
                      for b in np.unique(bins[positions])]
            draw = np.concatenate(picked)
            np.testing.assert_array_equal(np.sort(bins[draw]), np.sort(bins[positions]))
            neighbors[j, arm] = pool[draw]
        assert (d['ends'][neighbors[j]] <= now).all()
        reference = ranked_quantile(errors[pool])
        for arm in range(neighbors.shape[1]):
            proposals[j, arm] = ranked_quantile(errors[neighbors[j, arm]])-reference
    return proposals, neighbors, pd.DataFrame(dict(farm=farm,stage=stage,origin=d['origins'][ids],
        pool=pool_counts,kth_distance=kth,threshold=threshold,status=reasons))


def redistribute(lo, hi, proposal, strength):
    """Project proposed upper endpoints onto the original daily width budget."""
    target = hi[:, None, :]
    wanted = target+strength*proposal
    floor = np.maximum(lo[:, None, :], target-LIMIT)
    ceil = np.minimum(1, target+LIMIT)
    left = np.min(floor-wanted, axis=-1, keepdims=True)
    right = np.max(ceil-wanted, axis=-1, keepdims=True)
    total = target.sum(axis=-1)
    for _ in range(44):
        mid = (left+right)/2
        below = np.clip(wanted+mid, floor, ceil).sum(axis=-1) < total
        left = np.where(below[..., None], mid, left)
        right = np.where(below[..., None], right, mid)
    upper = np.where(np.any(proposal != 0,axis=-1,keepdims=True),
                     np.clip(wanted+(left+right)/2, floor, ceil), target)
    assert (upper >= lo[:, None, :]).all() and (upper <= 1).all()
    assert np.max(np.abs(upper.sum(axis=-1)-total)) < 1e-10
    return upper


def evaluate(stage, farms, rows, selected=None):
    daily, audit = {}, []
    for farm, d in farms.items():
        raw_lo, raw_hi = local_heads(YEAR, farm, 'QRF', 0)
        ids, res = calibration(d, raw_lo, raw_hi, stage)
        lo, hi = np.clip([res['lo'], res['hi']], 0, 1)
        with np.load(BASE/f'gefcom2012/farm_{farm:02}/{stage}_direct_qrf.npz') as z:
            for a,b in ((ids,z['ids']), (lo,z['lo']), (hi,z['hi'])):
                np.testing.assert_array_equal(a,b)
        dist, cutoff = representation(d, farm)
        proposals, neighbors, info = retrieve(d, farm, ids, stage, dist, cutoff, raw_hi)
        audit.append(info)
        y = d['y'][ids]
        groups = masks(y,d['history'][ids,-1])
        masks_valid = {g: groups[g]&d['valid'][ids,None] for g in GROUPS}
        path = OUT/f'farm_{farm:02}'
        path.mkdir(exist_ok=True)
        results = {}
        for s in (STRENGTHS if selected is None else (selected,)):
            upper = redistribute(lo, hi, proposals, s)
            np.testing.assert_array_equal(upper[info.status.ne('used')], np.broadcast_to(
                hi[:,None,:], upper.shape)[info.status.ne('used')])
            for name,u in [('base',hi), ('similar',upper[:,0]), *[
                    (f'random_{seed}',upper[:,j+1]) for j,seed in enumerate(SEEDS)]]:
                collect(rows,d,ids,lo,u,farm=farm,stage=stage,strength=s,model=name)
                if stage == 'evaluation':
                    w=u-lo
                    stats = [w, (y>=lo)&(y<=u), w+20*np.maximum(lo-y,0)+20*np.maximum(y-u,0), y>u]
                    for g, keep in masks_valid.items():
                        daily[name,farm,g]=(d['origins'][ids], np.column_stack(
                            [keep.sum(axis=1)]+[np.where(keep,v,0).sum(axis=1) for v in stats]))
            results[f'upper_{s}'] = upper
        np.savez_compressed(path/f'{stage}.npz',ids=ids,origins=d['origins'][ids],lower=lo,
            baseline_upper=hi,neighbors=neighbors, **results)
    pd.concat(audit,ignore_index=True).to_csv(OUT/f'{stage}_retrieval_audit.csv',index=False)
    return daily


def macro_table(rows):
    frame = pd.DataFrame(rows)
    macro = frame.groupby(['stage','strength','model','group'])[METRIC_COLS].mean()
    random = macro.loc[macro.index.get_level_values('model').str.startswith('random_')]
    random_mean = random.groupby(['stage','strength','group']).mean().assign(model='random_mean').set_index('model',append=True)
    return pd.concat([macro, random_mean.reorder_levels(macro.index.names)]).sort_index()


def decision(macro, stage, s):
    a,b,r = (macro.loc[(stage,s,k)] for k in ('base','similar','random_mean'))
    return dict(up_vs_base=float(b.loc['up_ramp','upper_miss']-a.loc['up_ramp','upper_miss']),
        up_vs_random=float(b.loc['up_ramp','upper_miss']-r.loc['up_ramp','upper_miss']),
        coverage=bool(b.loc['all','coverage']>=.90),
        IS=bool(b.loc['all','IS']<=a.loc['all','IS']),
        near_zero=bool(b.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
        down_ramp=bool(b.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01))


def qualifies(g):
    return g['up_vs_base'] <= -.01 and g['up_vs_random'] <= -.01 and all(
        g[k] for k in ('coverage','IS','near_zero','down_ramp'))


def paired_intervals(daily):
    rows=[]
    for ref in ('base','random_mean'):
        pair={}
        for farm in range(1,8):
            for g in GROUPS:
                pair['similar',farm,g] = daily['similar',farm,g]
                if ref == 'base':
                    pair[ref,farm,g] = daily[ref,farm,g]
                else:
                    groups = [daily[f'random_{seed}',farm,g] for seed in SEEDS]
                    pair[ref,farm,g] = (groups[0][0],np.mean([v[1] for v in groups],axis=0))
        rows.extend(dict(reference=ref,**r) for r in bootstrap(YEAR,pair,'similar'))
    return pd.DataFrame(rows)


def main():
    frozen_spec(OUT/'protocol.json',dict(farms=list(range(1,8)), base='frozen seed0 QRF + signed rolling84',
        split='2011 Q2 development; original held-out-in-fit historical evaluation',
        inputs='same farm, forecast U/V trajectory, hourly changes in forecast speed, last observed power; equally weighted blocks, training-only standardization',
        neighbors=K, support='84 days of arrived valid forecast errors in the existing phase-specific calibration history; reject if kth distance exceeds training-only rolling q90 threshold',
        random='same query, eligibility, fallback and counts per 21-day age bin; five fixed seeds',
        mechanism='per-lead local minus pooled q90 of raw upper errors; freeze lower endpoint and each issued daily total width, upper adjustment capped at .05',
        strengths=list(STRENGTHS), seeds=list(SEEDS),
        gate='at least 1pp less upper miss against both comparators; coverage >=90%; IS no worse than base; near-zero and down-ramp within 1pp of base',
        selection='among passing strengths minimize worst upper-miss contrast; if none pass, freeze least-bad strength for diagnostic evaluation only',
        inference='synchronized across farms 14-day moving block 2000 reps'))
    farms = load_farms(YEAR)
    assert list(farms) == list(range(1,8))
    rows = []
    evaluate('validation',farms,rows)
    m = macro_table(rows)
    gates = {s:decision(m,'validation',s) for s in STRENGTHS}
    passing = [s for s,g in gates.items() if qualifies(g)]
    best = min(passing or STRENGTHS,key=lambda s:max(gates[s]['up_vs_base'],gates[s]['up_vs_random']))
    frozen_spec(OUT/'selection.json',dict(strength=best,dev_pass=bool(passing),checks={str(s):g for s,g in gates.items()}))
    print('FROZEN',best,gates,flush=True)
    daily = evaluate('evaluation',farms,rows,best)
    macro = macro_table(rows)
    pd.DataFrame(rows).to_csv(OUT/'per_farm.csv',index=False)
    macro.to_csv(OUT/'macro.csv')
    ci = paired_intervals(daily)
    ci.to_csv(OUT/'paired_blocks.csv',index=False)
    g = decision(macro,'evaluation',best)
    clear = (ci.query("group == 'up_ramp' and metric == 'upper_miss'").high<0).all()
    write(OUT/'completion.json',dict(status='complete',farms=7,eval=g,
        conference_candidate=bool(passing and qualifies(g) and clear)))
    print('EVALUATION',g,flush=True)


if __name__ == '__main__':
    main()
