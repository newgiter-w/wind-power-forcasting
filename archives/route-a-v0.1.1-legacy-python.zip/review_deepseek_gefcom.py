"""Reproduce DeepSeek December backtest into a separate review directory.

Keeps original code/results unchanged; captures arrays for metric and time checks.
"""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
from pathlib import Path
import hashlib,json,time,sys,zipfile
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
# Replay the reviewed source snapshot, even after the working implementation is fixed.
_root=Path(__file__).resolve().parent
_snapshot=_root/'out_gefcom_protocol_v2/source_before_changes.zip'
if _snapshot.exists():
    _replay=_root/'review_deepseek_gefcom_20261102/original_sources'
    _replay.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(_snapshot) as _z:
        for _name in _z.namelist():
            if Path(_name).name!=_name:raise ValueError(_name)
            (_replay/_name).write_bytes(_z.read(_name))
    sys.path.insert(0,str(_replay))
import gefcom_data as gd
import run_gefcom_confirm as confirm
from run_gefcom_abc import build_X
from gefcom2014_experiment import metrics as correct_metrics

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'review_deepseek_gefcom_20261102'
OUT.mkdir(exist_ok=True)

def write(name,x):
    (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def main():
    originals=json.loads((ROOT/'out_gefcom_confirm/results.json').read_text(encoding='utf-8'))
    simulator=confirm.simulate;results={};checks=[];corrected=[];captured=[];clock=time.perf_counter()
    for zone in range(1,11):
        s=gd.build_samples(confirm.load_full(zone));md=pd.DatetimeIndex(s['origin_ts'])
        tr=((md.year==2012)|((md.year==2013)&(md.month<=8))) & s['target_valid']
        seed=(md.year==2013)&md.month.isin([9,10,11])&s['target_valid']
        te=(md.year==2013)&(md.month==12)&s['target_valid']
        raw=confirm.load_full(zone)
        dt=pd.DatetimeIndex(raw.TIMESTAMP)
        assert dt.equals(pd.date_range(dt.min(),dt.max(),freq='h'))
        assert not dt.duplicated().any()
        assert np.isfinite(s['future_nwp']).all()
        assert (s['origin_ts'][tr]+np.timedelta64(24,'h')).max()<=s['origin_ts'][seed].min()
        assert (s['origin_ts'][seed]+np.timedelta64(24,'h')).max()<=s['origin_ts'][te].min()
        order=[]
        def spy(*args,**kwargs):
            res=simulator(*args,**kwargs)
            method='ABC'[len(order)];order.append(method)
            origins,ends,y,lo,hi,valid,seed_i,test_i=args[:8]
            assert (res['max_label_end_used']<=origins[test_i]).all()
            # Match each target hour to raw released observations independently.
            indexed=raw.set_index('TIMESTAMP')
            for i in test_i:
                ts=pd.date_range(pd.Timestamp(origins[i])+pd.Timedelta(hours=1),periods=24,freq='h')
                assert np.array_equal(indexed.TARGETVAR.reindex(ts).to_numpy(),y[i])
                hs=pd.date_range(pd.Timestamp(origins[i])-pd.Timedelta(hours=23),periods=24,freq='h')
                assert np.array_equal(indexed.TARGETVAR.reindex(hs).to_numpy(),s['history'][i],equal_nan=True)
            fixed=correct_metrics(y[test_i],res['lo'],res['hi'],valid[test_i],s['history'][test_i,-1])
            for group,m in fixed.items():corrected.append(dict(farm=zone,method=method,group=group,**m))
            X=build_X(s,method)
            checks.append(dict(farm=zone,method=method,n_train=int(tr.sum()),n_seed=int(seed.sum()),n_test=int(te.sum()),
                        n_input_features=X.shape[1],history_missing_days=int((~np.isfinite(s['history']).all(axis=1)).sum()),
                        train_history_missing_days=int((tr & ~np.isfinite(s['history']).all(axis=1)).sum()),
                        seed_history_missing_days=int((seed & ~np.isfinite(s['history']).all(axis=1)).sum()),
                        test_history_missing_days=int((te & ~np.isfinite(s['history']).all(axis=1)).sum()),
                        seed_label_arrival=True,all_feedback_arrival=True,target_alignment=True,history_alignment=True,
                        empty_cqr_cells=int(res['midpoint_expansion_count'])))
            np.savez_compressed(OUT/f'zone{zone:02d}_{method}.npz',origins=origins[test_i],
                       y=y[test_i],last_power=s['history'][test_i,-1],lo=res['lo'],hi=res['hi'],
                       raw_lo=lo[test_i],raw_hi=hi[test_i],n_cal=res['n_cal'],max_label_end=res['max_label_end_used'])
            return res
        confirm.simulate=spy
        with threadpool_limits(limits=2):result=confirm.run_zone(zone)
        results[f'Zone{zone}']=result
        for m in 'ABC':
            for g in ['all','up_ramp','down_ramp','near_zero']:
                for metric in ['coverage','width','IS','cells']:
                    a=result[m]['rolling'][g][metric];b=originals[f'Zone{zone}'][m]['rolling'][g][metric]
                    assert np.isclose(a,b,rtol=1e-9,atol=1e-10),(zone,m,g,metric,a,b)
        print(f'Zone{zone} reproduced, matched all reported metrics; elapsed={time.perf_counter()-clock:.1f}s',flush=True)
        write('reproduced_confirm.json',results);write('checks.json',checks)
        pd.DataFrame(corrected).to_csv(OUT/'corrected_ramp_metrics_per_farm.csv',index=False)
    c=pd.DataFrame(corrected)
    c.groupby(['method','group'])[['coverage','width','IS']].mean().reset_index().to_csv(OUT/'corrected_metrics_macro.csv',index=False)
    write('completion.json',dict(status='complete',zones=10,methods=3,original_results_matched=True,elapsed=time.perf_counter()-clock))
    print('REPRODUCTION COMPLETE',flush=True)

if __name__=='__main__':main()
