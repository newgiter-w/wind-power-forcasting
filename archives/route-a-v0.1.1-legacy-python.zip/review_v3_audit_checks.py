"""Audit saved V3 losses; no training and no edits to experiment outputs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from config import default_config
from data import load_dataframe, build_situations
from run import segment_split

root=Path(__file__).parent
result=json.loads((root/'out_v3'/'b12_results.json').read_text())
tasks=result['results']['tasks']
cfg=default_config(points_per_day=144,stride_points=144,horizon_days=1,condition_days=1,horizon_bins=24,analog_bins=24,kelmarsh_root=r'D:\Study\wind_datasets\kelmarsh',kelmarsh_cache=r'D:\Study\wind_datasets\kelmarsh\farm_cache_2018_2022.csv',weather_cols=['wind_speed','wind_dir_sin','wind_dir_cos','temperature'],capacity=12300.)
d=build_situations(load_dataframe(cfg),cfg)
mask=segment_split(d['origin_ts'])['V_score'] & d['target_valid']
dates=d['origin_ts'][mask].reset_index(drop=True).dt.floor('D')
full=pd.date_range(dates.min(),dates.max(),freq='D')
locations=full.get_indexer(dates)
assert len(dates)==83 and all(len(t['cqr_per_origin'])==len(dates) for t in tasks.values())
no_ret={k:v for k,v in tasks.items() if k.startswith(('N0_','NH_'))}
retr={k:v for k,v in tasks.items() if k.startswith(('R0_','RD_')) and 'random' not in k}
B=min(no_ret,key=lambda k:no_ret[k]['cqr']['score'])
R=min(retr,key=lambda k:retr[k]['cqr']['score'])
losses={k:np.array(v['cqr_per_origin']) for k,v in tasks.items()}
random_keys=[k for k in tasks if 'random' in k]
losses['random_H0_seed_mean']=np.mean([losses[k] for k in random_keys],axis=0)

def check_bootstrap(r,b,length,moving=True):
    rgrid=np.full(len(full),np.nan);bgrid=np.full(len(full),np.nan)
    rgrid[locations]=r;bgrid[locations]=b
    rng=np.random.default_rng(0)
    estimates=[]
    if not moving:
        blocks=[locations[(locations>=i)&(locations<i+length)] for i in range(0,len(full),length)]
        blocks=[v for v in blocks if len(v)]
    for _ in range(5000):
        if moving:
            starts=rng.integers(0,len(full)-length+1,size=int(np.ceil(len(full)/length)))
            grid=np.concatenate([np.arange(i,i+length) for i in starts])[:len(full)]
        else:
            selected=rng.integers(0,len(blocks),size=len(blocks))
            grid=np.concatenate([blocks[i] for i in selected])
        estimates.append(1-np.nanmean(rgrid[grid])/np.nanmean(bgrid[grid]))
    ci=np.quantile(estimates,[.025,.975])
    return {'gain':float(1-np.mean(r)/np.mean(b)),'ci95':ci.tolist(),'calendar_days':len(full),'valid_origins':len(r),'method':'moving_calendar_blocks' if moving else 'nonoverlapping_calendar_blocks'}

out={'B':B,'R':R,'dates_first_last':[str(dates.min()),str(dates.max())],'task_count':len(tasks),'original_nonoverlap_reproduction':{},'moving_calendar_reanalysis':{},'matched_H0_comparison':{},'coverage':{'B':tasks[B]['cqr']['coverage'],'R':tasks[R]['cqr']['coverage']},'random_control_task_names':random_keys,'mean_consistency_max_error':float(max(abs(np.mean(v['cqr_per_origin'])-v['cqr']['score']) for v in tasks.values()))}
for length in (7,14):
    out['original_nonoverlap_reproduction'][str(length)]=check_bootstrap(losses[R],losses[B],length,False)
    out['moving_calendar_reanalysis'][str(length)]=check_bootstrap(losses[R],losses[B],length,True)
    out['matched_H0_comparison'][str(length)]=check_bootstrap(losses['R0_dtw_H0'],losses['random_H0_seed_mean'],length,True)
out['limitations']=['Origin identity reconstructed from current data order; saved loss arrays contain no origin IDs.', 'Selected R=H1 has no matching H1 random retraining in saved data.', 'No selected-forecast uncertainty correction; validation conclusions are exploratory.', 'No tree models or direct-analog forecasts recomputed.']
path=root/'out_v3'/'review_audit_checks.json'
path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
