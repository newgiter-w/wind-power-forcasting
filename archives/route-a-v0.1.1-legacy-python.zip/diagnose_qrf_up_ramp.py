"""Align observed power, same-issue NWP and saved QRF predictions."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gefcom_protocol_v2 import prepare, index
from pooling_common import feature_array
from run_point_residual import OUT as SOURCE

OUT = SOURCE.parent / 'out_gefcom_up_ramp_diagnosis_20261106'


def align():
    frames = []
    for year in (2014, 2012):
        farms, _ = prepare(year)
        for farm, d in farms.items():
            folder = SOURCE / f'gefcom{year}/farm_{farm:02}'
            ids = index(d, 'evaluation')
            with np.load(folder/'heads.npz') as z:
                np.testing.assert_array_equal(d['origins'], z['origins'])
                point = z['qrf'][ids]
            with np.load(folder/'evaluation_direct_qrf.npz') as z:
                np.testing.assert_array_equal(ids, z['ids'])
                upper, lower = z['hi'], z['lo']
                assert (z['max_label_end'] <= d['origins'][ids]).all()
            wind = np.hypot(d['nwp'][:,:,-2], d['nwp'][:,:,-1])
            x = feature_array(year, farm, 'GBM')
            np.testing.assert_allclose(x[:,-12].reshape(wind.shape), wind, atol=1e-12)
            w = wind[ids]
            y = d['y'][ids]
            last = d['history'][ids,-1,None]
            dy = np.diff(np.c_[last,y],axis=1)
            dp = np.diff(np.c_[last,point],axis=1)
            dw = np.diff(w,axis=1,prepend=np.nan)
            adjacent = pd.DataFrame(dw.T).rolling(5,center=True,min_periods=1).max().to_numpy().T
            flat = dict(year=year, farm=farm, origin=np.repeat(d['origins'][ids],24),
                        lead=np.tile(np.arange(1,25),len(ids)), valid=np.repeat(d['valid'][ids],24),
                        observed=y.ravel(), qrf=point.ravel(), lower90=lower.ravel(), upper90=upper.ravel(),
                        nwp_speed=w.ravel(), delta_wind=dw.ravel(), max_delta_wind_pm2=adjacent.ravel(),
                        delta_observed=dy.ravel(), delta_qrf=dp.ravel(),
                        upper_miss=(y>upper).ravel(), lower_miss=(y<lower).ravel(),
                        up_ramp=(dy>.10).ravel())
            frame = pd.DataFrame(flat)
            frame['target_time'] = frame.origin + pd.to_timedelta(frame.lead,unit='h')
            frames.append(frame)
    return pd.concat(frames,ignore_index=True)


def summarize(all_hours):
    events = all_hours[all_hours.valid & all_hours.up_ramp]
    rows = []
    for year, data in events.groupby('year'):
        eligible = data[data.lead>1]
        for threshold in [.25,.5,1.]:
            now = eligible.delta_wind>=threshold
            nearby = eligible.max_delta_wind_pm2>=threshold
            for label, mask in [('same_hour',now),('nearby_only',~now & nearby),('none_nearby',~nearby)]:
                part=eligible[mask]
                missed=part[part.upper_miss]
                rows.append(dict(year=year,threshold=threshold,signal=label,n=len(part),
                                 upper_misses=len(missed),total_upper_misses=len(eligible[eligible.upper_miss]),
                                 upper_miss_rate=part.upper_miss.mean(), qrf_ramp_rate=(part.delta_qrf>.1).mean(),
                                 qrf_ramp_rate_in_misses=(missed.delta_qrf>.1).mean(),
                                 observed_delta_mean=part.delta_observed.mean(),
                                 qrf_delta_mean=part.delta_qrf.mean(),
                                 median_bias=(part.qrf-part.observed).mean()))
        for farm, part in data.groupby('farm'):
            covered=(~part.upper_miss & ~part.lower_miss).mean()
            previous=pd.read_csv(SOURCE/'interval_per_farm.csv')
            row=previous.query("year == @year and farm == @farm and stage == 'evaluation' and method == 'direct_qrf' and variant == 'signed' and group == 'up_ramp'")
            np.testing.assert_allclose([covered,part.upper_miss.mean()],row[['coverage','upper_miss']].iloc[0],atol=1e-12)
        print(year,'events',len(data),'upper misses',data.upper_miss.sum(),'lead1 events',sum(data.lead==1),
              'lead1 upper misses',sum((data.lead==1)&data.upper_miss),flush=True)
    return pd.DataFrame(rows)


def plot_cases(hours):
    cases = hours[(hours.year==2012)&(hours.farm==1)&hours.origin.isin(pd.to_datetime(['2012-03-02','2011-09-02']))].copy()
    assert len(cases)==48 and cases.valid.all()
    cases.to_csv(OUT/'cases_hourly.csv',index=False)
    fig,axes=plt.subplots(2,2,figsize=(11,6),sharex=True,layout='constrained')
    for col,(date,d) in enumerate(cases.groupby('origin',sort=False)):
        ax=axes[0,col]
        for key,label,color,ls in [('observed','Observed','#b52c2c','-'),('qrf','QRF median','#102d63','-'),('upper90','90% upper bound','#555555','--')]:
            ax.plot(d.lead,d[key],label=label,color=color,ls=ls)
        misses=d[d.upper_miss]
        ax.scatter(misses.lead,misses.observed,facecolors='none',edgecolors='#b52c2c',label='Upper miss',zorder=5)
        ax.set_title(str(date.date()))
        ax.set_ylim(0,.75)
        ax.set_ylabel('Power / capacity')
        ax.legend(fontsize=8,loc='upper left')
        wind=axes[1,col]
        wind.plot(d.lead,d.nwp_speed,color='#218268',marker='.',label='Same-issue NWP speed')
        for h in d.loc[d.up_ramp,'lead']:
            ax.axvline(h,color='#b52c2c',alpha=.22)
            wind.axvline(h,color='#b52c2c',alpha=.22)
        wind.set_ylabel('NWP wind speed (m/s)')
        wind.set_xlabel('Forecast lead (h)')
        wind.set_xticks([1,6,12,18,24])
        wind.legend(fontsize=8)
    fig.savefig(OUT/'aligned_cases.png',dpi=170)
    return cases


if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    data=align()
    stats=summarize(data)
    data.to_csv(OUT/'aligned_hours.csv',index=False)
    stats.to_csv(OUT/'wind_signal_summary.csv',index=False)
    cases=plot_cases(data)
    print(stats.to_string(index=False))
    print(cases.loc[cases.up_ramp|cases.upper_miss,['origin','lead','observed','qrf','upper90','delta_observed','delta_qrf','nwp_speed','delta_wind','up_ramp','upper_miss']].to_string(index=False))
