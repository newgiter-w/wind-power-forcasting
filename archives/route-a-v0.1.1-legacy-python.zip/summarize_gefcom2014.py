"""Recompute paired metrics and summarize the frozen experiment from saved arrays."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gefcom2014_experiment import metrics,masks,METHODS,write_json

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_gefcom2014_nwp_v1'
GROUPS=['all','ramp','up_ramp','down_ramp','near_zero']
LABELS=['History','+ 100m NWP','+ 10/100m NWP']

def main():
    assert json.loads((OUT/'completion.json').read_text())['status']=='complete'
    manifest=pd.read_csv(OUT/'split_manifest.csv')
    dates=pd.date_range('2013-07-01','2013-12-31',freq='D')
    # Stats by method,farm,calendar day,group: count, hit, width sum, IS sum.
    daily=np.zeros((3,10,len(dates),5,4));recomputed=[];leads=[]
    integrity=[]
    for farm in range(1,11):
        md=manifest[manifest.farm.eq(farm)].reset_index(drop=True)
        for j,m in enumerate(METHODS):
            folder=OUT/f'farm_{farm:02d}'/m
            with np.load(folder/'predictions.npz') as z:
                yall=z['y'];validall=z['valid'];origins=z['origins'];lastall=z['last_power'];loall=z['raw_lo'];hiall=z['raw_hi']
            with np.load(folder/'calibrated.npz') as z:
                idx=z['indices'];lo=z['lo'];hi=z['hi'];ends=z['max_label_end_used']
            assert np.array_equal(pd.to_datetime(md.origin).to_numpy(),origins)
            assert np.array_equal(idx,np.flatnonzero(md.phase.eq('test')))
            assert (ends<=origins[idx]).all()
            assert np.isfinite(lo).all() and np.isfinite(hi).all() and (lo<=hi).all()
            if j==0:reference=(yall.copy(),validall.copy(),origins.copy())
            else:
                assert np.array_equal(yall,reference[0],equal_nan=True)
                assert np.array_equal(validall,reference[1]) and np.array_equal(origins,reference[2])
            y=yall[idx];v=validall[idx];last=lastall[idx]
            for stage,L,U in [('test_raw',loall[idx],hiall[idx]),('test_cqr',lo,hi)]:
                for g,s in metrics(y,L,U,v,last).items():recomputed.append(dict(farm=farm,method=m,stage=stage,group=g,**s))
            for h in range(24):
                r=metrics(y[:,h:h+1],lo[:,h:h+1],hi[:,h:h+1],v,last)['all']
                leads.append(dict(farm=farm,method=m,lead=h+1,**r))
            hit=(y>=lo)&(y<=hi);width=hi-lo
            score=width+20*np.maximum(lo-y,0)+20*np.maximum(y-hi,0)
            gs=masks(y,last)
            for k,origin in enumerate(origins[idx]):
                pos=dates.get_indexer([pd.Timestamp(origin)])[0];assert pos>=0
                for g,group in enumerate(GROUPS):
                    mask=gs[group][k]&v[k]
                    daily[j,farm-1,pos,g]=[mask.sum(),hit[k,mask].sum(),width[k,mask].sum(),score[k,mask].sum()]
            integrity.append(dict(farm=farm,method=m,paired_origins=True,label_arrival=True,
                                  all_issued=int(len(idx)),valid_days=int(v.sum()),
                                  negative_lower_cells=int((lo[v]<0).sum()),upper_above_one_cells=int((hi[v]>1).sum())))
    rec=pd.DataFrame(recomputed)
    stored=pd.read_csv(OUT/'metrics_per_farm.csv');stored=stored[stored.stage.str.startswith('test')]
    merged=rec.merge(stored,on=['farm','method','stage','group'],suffixes=('_new','_saved'),validate='one_to_one')
    for c in ['coverage','width','IS','cells','origins','lower_miss','upper_miss']:
        assert np.allclose(merged[c+'_new'],merged[c+'_saved'],equal_nan=True)
    # Independently recompute IS using piecewise penalties on one real set of arrays.
    manual=[]
    for r in range(len(y)):
        if not v[r]:continue
        for h in range(24):
            val=hi[r,h]-lo[r,h]
            if y[r,h]<lo[r,h]:val+=20*(lo[r,h]-y[r,h])
            elif y[r,h]>hi[r,h]:val+=20*(y[r,h]-hi[r,h])
            manual.append(val)
    assert np.isclose(np.mean(manual),metrics(y,lo,hi,v,last)['all']['IS'])
    write_json(OUT/'verification.json',dict(stored_metrics_recomputed=True,paired_methods=True,
               independent_piecewise_IS_check=True,calibration_label_time_checks=True,checks=integrity))
    # Paired moving block bootstrap: same date draw for all methods AND all farms.
    # Interval describes within-period time variation, not multi-year or seed uncertainty.
    def aggregate(a):
        total=a.sum(axis=2) # method,farm,group,stat
        return np.nanmean(np.divide(total[:,:,:,1:],total[:,:,:,0,None],
                          out=np.full(total[:,:,:,1:].shape,np.nan),where=total[:,:,:,0,None]>0),axis=1)
    point=aggregate(daily)
    rng=np.random.default_rng(20261102);boots=[];block=14
    for _ in range(1000):
        starts=rng.integers(0,len(dates)-block+1,size=int(np.ceil(len(dates)/block)))
        draw=np.concatenate([np.arange(s,s+block) for s in starts])[:len(dates)]
        boots.append(aggregate(daily[:,:,draw]))
    boots=np.array(boots);deltas=[]
    for j in [1,2]:
        for g,group in enumerate(GROUPS):
            for k,metric in enumerate(['coverage','width','IS']):
                b=boots[:,j,g,k]-boots[:,0,g,k]
                deltas.append(dict(method=METHODS[j],baseline=METHODS[0],group=group,metric=metric,
                                   delta=float(point[j,g,k]-point[0,g,k]),
                                   lower95=float(np.quantile(b,.025)),upper95=float(np.quantile(b,.975)),
                                   bootstrap='paired common-calendar 14-day moving blocks, 1000 resamples, seed20261102'))
    pd.DataFrame(deltas).to_csv(OUT/'paired_bootstrap_deltas.csv',index=False)
    perlead=pd.DataFrame(leads).groupby(['method','lead'])[['coverage','width','IS']].mean().reset_index()
    fig,axes=plt.subplots(1,3,figsize=(12,3.5))
    for m,label in zip(METHODS,LABELS):
        t=perlead[perlead.method.eq(m)]
        for ax,col in zip(axes,['coverage','width','IS']):ax.plot(t.lead,t[col]*(100 if col!='IS' else 1),label=label)
    axes[0].axhline(90,color='gray',ls='--',lw=1)
    for ax,title in zip(axes,['Coverage (%)','Width (% capacity)','Interval score']):
        ax.set_title(title);ax.set_xlabel('Forecast hour');ax.grid(alpha=.2)
    axes[-1].legend(fontsize=8);fig.suptitle('GEFCom2014: test July-Dec 2013, rolling CQR, macro over 10 farms')
    fig.tight_layout();fig.savefig(OUT/'per_lead.png',dpi=180);fig.savefig(OUT/'per_lead.pdf');plt.close(fig)
    macro=pd.read_csv(OUT/'metrics_macro.csv')
    table=macro[macro.stage.eq('test_cqr')].copy()
    lines=['# GEFCom2014 NWP 首轮实验结果','',
           '日期：2026-11-02。10 风场，3 输入对照，固定种子 0；2012 训练，2013Q1 验证、Q2 初始校准、H2 测试。每场分别训练 q05/q95 的 24 个 HistGBR 输出头，rolling-84 日 CQR。没有基于测试结果调参。','',
           '## 校准后结果（10 场宏平均）','',
           '| 工况 | 历史功率：覆盖/宽度/IS | +100m NWP | +两层 NWP |','|---|---|---|---|']
    names=dict(all='总体',ramp='爬坡',up_ramp='上升爬坡',down_ramp='下降爬坡',near_zero='近零')
    for group in GROUPS:
        vals=[]
        for m in METHODS:
            r=table[(table.method==m)&(table.group==group)].iloc[0]
            vals.append(f'{r.coverage*100:.2f}% / {r.width*100:.2f}% / {r.IS:.4f}')
        lines.append('| '+names[group]+' | '+' | '.join(vals)+' |')
    lines+=['','覆盖率为点级经验覆盖，不是整个 24h 路径同时覆盖；宽度按已归一化容量 1 计。先逐场求均值再宏平均，单元格加权汇总另见 metrics_pooled.csv。',
            '', '## 校准前总体结果','', '| 输入 | 覆盖率 | 宽度 | IS |','|---|---:|---:|---:|']
    for m in METHODS:
        r=macro[(macro.method==m)&(macro.stage=='test_raw')&(macro.group=='all')].iloc[0]
        lines.append(f'| {m} | {r.coverage*100:.2f}% | {r.width*100:.2f}% | {r.IS:.4f} |')
    lines+=['','## 配对差异（校准后，对历史功率基线）','',
            '14 日移动区块 bootstrap 同步抽取全部风场和方法的日期，1,000 次；保留跨场与短期时间依赖，仅描述本测试期的不确定性。非多年份、非多随机种子稳健性保证。','',
            '| 输入 | 工况 | 指标 | 差值 | 95% 区间 |','|---|---|---|---:|---|']
    for d in deltas:
        if d['group'] not in ['all','up_ramp','near_zero']:continue
        factor=100 if d['metric']!='IS' else 1;unit='pp' if factor==100 else ''
        lines.append(f"| {d['method']} | {names[d['group']]} | {d['metric']} | {d['delta']*factor:+.3f}{unit} | [{d['lower95']*factor:+.3f}, {d['upper95']*factor:+.3f}] |")
    lines+=['','## 逐场总体结果（校准后）','', '| 风场 | 输入 | 有效测试日 | 覆盖率 | 宽度 | IS |','|---|---|---:|---:|---:|---:|']
    for _,r in rec[(rec.stage=='test_cqr')&(rec.group=='all')].sort_values(['farm','method']).iterrows():
        lines.append(f'| {r.farm} | {r.method} | {r.origins} | {r.coverage*100:.2f}% | {r.width*100:.2f}% | {r.IS:.4f} |')
    lines+=['','## 解释边界与数据纪律','',
            '- 原始功率与天气来自期刊附件，未使用模拟真值；来源与 SHA-256 在 protocol.json。测试答案用于事后评估、标签到达后的滚动校准，以及后续原点已观测的历史功率输入；假设整点功率报告无额外延迟，未使用未来标签构造历史。',
            '- 三组均采用相同的有效原点和工况掩码；输入缺失时不发预测，已发预测不会因为目标未来缺失而提前删除，评价和反馈时才检查完整标签。完整日策略会排除缺失小时所在的整天。',
            '- 纯历史 35 维，100m 为 107 维，两层为 179 维；NWP 曲线直接进入分位数模型。按样本的过去功率统计量与日历特征相同。',
            '- NWP 为竞赛每日协议提供的未来有效时间序列，文件无原生起报时间与发布延迟；不把它宣称为 ECMWF 新鲜 1–24h 起报。数据时区保留文件时钟。',
            '- 主结果使用未裁剪区间，与现有 rolling CQR 路线一致；允许负下界或大于 1 的上界，数量见 verification.json。不能把容量边界裁剪的收益归功于 NWP。',
            '- 工况：小时功率变化绝对值 >0.10 为爬坡，第一步对比最后已观测功率；|功率|<=0.01 为近零。三组工况由相同真实标签事后定义。',
            '- 仅一个数据集、一个时间切分、固定参数与种子；各场历史训练原点为 365 个。不能宣称普适最优，也不能把跨数据集结果称为 Kelmarsh 得到直接改善。',
            '- Zone4/5、Zone7/8 的 NWP 输入相同，风场不是独立重复；bootstrap 同步抽取日期。时序 CQR 报告经验覆盖，不宣称严格分布无关保证。',
            '', '## 产物','',
            '- protocol.json：冻结参数、版本、原始文件散列；split_manifest.csv / sample_counts.csv / input_exclusions.csv：样本与划分。',
            '- metrics_per_farm.csv / metrics_macro.csv / metrics_pooled.csv / metrics_per_lead.csv：全部数值。',
            '- farm_XX/：模型、原始预测、校准区间与反馈流水；verification.json：从保存数组重算结果与时间断言。',
            '- paired_bootstrap_deltas.csv：配对差异与区间；per_lead.png / .pdf：逐时效图。','']
    (OUT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print(table[['method','group','coverage','width','IS']].to_string(index=False))

if __name__=='__main__':main()
