"""Synthetic wind-power series generator (smoke-test data).

Produces a realistic-enough power curve with:
  * diurnal wind-speed cycle,
  * a cubic wind->power transfer (cut-in / cut-out),
  * occasional ramp events,
  * additive noise,
coupled to wind_speed / temperature / pressure so retrieval has signal to find.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def generate_synthetic(
    n_days: int = 365,
    points_per_day: int = 96,
    capacity: float = 100.0,
    seed: int = 0,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    n = n_days * points_per_day
    step_min = int(1440 / points_per_day)
    t = np.arange(n)
    hour = (t % points_per_day) / points_per_day * 24.0
    day = t / points_per_day

    # diurnal + synoptic wind speed
    wind = (
        6.0
        + 2.5 * np.sin(2 * np.pi * (hour - 3.0) / 24.0)
        + 1.5 * np.sin(2 * np.pi * day / 7.0)
        + 0.9 * rng.standard_normal(n)
    )
    wind = np.clip(wind, 0.0, 25.0)

    temperature = 15.0 + 9.0 * np.sin(2 * np.pi * (hour - 14.0) / 24.0) + 0.4 * rng.standard_normal(n)
    pressure = 1013.0 + 4.0 * np.sin(2 * np.pi * day / 30.0) + 0.6 * rng.standard_normal(n)

    # cubic transfer function
    v = wind
    rated = 20.0
    cut_in = 3.0
    power = np.where(v < cut_in, 0.0, np.where(v > rated, capacity, capacity * ((v - cut_in) / (rated - cut_in)) ** 3))

    # ramp events (fronts)
    n_ramps = int(n_days * 1.2)
    ramp = np.zeros(n)
    for _ in range(n_ramps):
        i = int(rng.integers(0, max(1, n - 40)))
        length = int(rng.integers(8, 32))
        sign = rng.choice([-1.0, 1.0])
        mag = rng.uniform(0.15, 0.45) * capacity
        envelope = np.sin(np.linspace(0, np.pi, length))
        ramp[i:i + length] += sign * mag * envelope

    power = power + ramp
    power = np.clip(power, 0.0, capacity)
    power += 0.02 * capacity * rng.standard_normal(n)
    power = np.clip(power, 0.0, capacity)

    ts = pd.date_range("2022-01-01", periods=n, freq=f"{step_min}min")
    df = pd.DataFrame(
        {
            "timestamp": ts,
            "power": power,
            "wind_speed": wind,
            "temperature": temperature,
            "pressure": pressure,
        }
    )
    return df
