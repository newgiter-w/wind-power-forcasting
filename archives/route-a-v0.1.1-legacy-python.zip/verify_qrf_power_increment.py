"""Replay the saved increment forests and draw the two fixed ramp examples."""
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from run_qrf_power_increment import OUT, cells, feature_array, load_farms, index, increments, write

def main():
    checks=[]
    for year in (2014,2012):
        for farm,d in load_farms(year).items():
            folder=OUT/f'gefcom{year}/farm_{farm:02}'
            model=joblib.load(folder/'model.joblib')
            with np.load(folder/'increments.npz') as z:
                train=index(d,'train',True)
                np.testing.assert_array_equal(z['train_days'],train)
                labels=increments(d['y'][train],d['history'][train])
                np.testing.assert_array_equal(model.sorted_y,np.sort(labels.ravel()))
                for stage in ('validation','evaluation'):
                    days=index(d,stage)[:2]
                    pos=np.searchsorted(z['days'],days)
                    np.testing.assert_array_equal(z['days'][pos],days)
                    replay=model.predict(feature_array(year,farm,'QRF')[cells(days)],(.5,)).reshape(-1,24)
                    np.testing.assert_allclose(replay,z['forecast'][pos],atol=1e-12,rtol=1e-12)
                    checks.append(dict(year=year,farm=farm,stage=stage,max_error=float(abs(replay-z['forecast'][pos]).max())))
    cases=pd.read_csv(OUT/'paired_examples_hourly.csv')
    fig,axes=plt.subplots(2,1,figsize=(10,6),sharex=True,sharey=True,layout='constrained')
    for ax,(date,d) in zip(axes,cases.groupby('date')):
        ax.axhline(10,ls='--',lw=1,color='#666666',label='Up-ramp threshold')
        for key,color,label in [('actual','#b52c2c','Observed'),('baseline','#4c5967','Original QRF'),('increment_model','#138574','Increment QRF')]:
            ax.plot(d.lead,100*d[key],marker='.',label=label,color=color)
        ax.set_title(date)
        ax.set_ylabel('Power change (capacity pp)')
        ax.grid(alpha=.2)
    axes[0].legend(ncol=2,fontsize=8,loc='upper left')
    axes[1].set_xlabel('Forecast lead (h)')
    axes[1].set_xticks([1,6,12,18,24])
    fig.savefig(OUT/'paired_examples.png',dpi=170)
    plt.close(fig)
    write(OUT/'verification.json',dict(status='passed',checks=checks))

if __name__=='__main__':
    main()
