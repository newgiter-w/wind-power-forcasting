"""Render the saved factorial evidence as a Chinese handoff report."""
import json
import pandas as pd
from run_gefcom_factorial import OUT, METHODS

LABELS=dict(zip(METHODS,['独立头＋基础 NWP','独立头＋显式气象特征','共享时效＋基础 NWP','共享时效＋显式气象特征']))
CN={'all':'总体','ramp':'全部爬坡','up_ramp':'上升爬坡','down_ramp':'下降爬坡','near_zero':'近零'}
PAIRS={
    'sharing_without_extra':('基础输入下改为共享',METHODS[2],METHODS[0]),
    'extra_with_independent':('独立头下加入显式特征',METHODS[1],METHODS[0]),
    'extra_with_shared':('共享模型下加入显式特征',METHODS[3],METHODS[2]),
    'sharing_with_extra':('显式特征下改为共享',METHODS[3],METHODS[1]),
    'combined':('共享＋特征的组合总变化',METHODS[3],METHODS[0]),
}

def main():
    macro=pd.read_csv(OUT/'evaluation_macro.csv')
    boots=pd.read_csv(OUT/'paired_bootstrap.csv')
    b=boots[boots.block_days==14]
    ver=json.loads((OUT/'verification.json').read_text())
    spec=json.loads((OUT/'protocol.json').read_text())
    done=json.loads((OUT/'completion.json').read_text())
    def m(y,method,g='all'):
        return macro[(macro.year==y)&(macro.method==method)&(macro.group==g)].iloc[0]
    def c(y,name,metric='IS',g='all',block=14):
        return boots[(boots.year==y)&(boots.contrast==name)&(boots.metric==metric)&(boots.group==g)&(boots.block_days==block)].iloc[0]
    lines=['# 分位数排序修复与共享时效 × 显式气象特征交叉消融',
        '', '日期：2026-11-03（Asia/Shanghai）。状态：两套数据、17 个风场、四组共 68 个场/方法组合已完成训练、验证与评价。',
        '', '## 结论', '',
        '当前固定配置下，显式气象特征的收益主要发生在共享模型中。独立头已为每个时效固定访问对应的整条 NWP 曲线列；共享模型加入当前时效的气象量后，更容易利用它们。这个机制解释与交互效应一致，但不是因果机制已经被单独证明。',
        '', '不能把总收益简单分成“共享贡献多少百分比、气象贡献多少百分比”：共享效果随是否有显式特征而改变。下面报告四个条件效应、交互项，以及一种明确约定的平均分解。',
        '', '1. 独立头下加入显式特征：2014/2012 总体 IS 分别变化 +0.087%/+0.164%，均无稳定收益（配对区间跨零）。基础输入下单独改为共享，IS 反而变差 6.643%/4.165%，对应差值的 95% 区间均高于零。',
        '2. 共享模型下加入显式特征，IS 改善 9.868%/8.301%；在已有显式特征时改为共享，IS 改善 3.964%/4.638%。总体 IS 的负交互项在 7/14 日块下均稳定，支持当前配置的组合收益。',
        '3. 共享＋显式特征相对基础独立头，总体 IS 改善 3.881%/4.481%，宽度相对减少约 1.951%/2.048%；配对区间支持总体 IS 与宽度改善，但均未达到原先“IS 与宽度各至少改善 5%”的研究目标。',
        '4. 上升爬坡覆盖由 82.378%→86.076%、72.847%→78.721%，仍不足 90%；该工况宽度分别增加 2.794pp/2.204pp，不能称作各工况都收窄。',
        '5. 2012 近零覆盖由 97.799%→96.703%，下降 1.096pp，按点估计已超过原定 1pp 容忍线；相应 IS 差值区间跨零。结论仍是“有条件权衡”，不能晋升为全面改进。',
        '6. 总体 IS 的风场差异不能忽略：2014 为 7/10 场改善，6、7、10 场变差；2012 为 7/7 场改善。宏平均收益不等于所有风场受益。',
        '', '## 修复及公平对照', '',
        '- 修复 `strong_baselines.py`、`run_p2_evaluation.py`、`run_p2_2012.py` 的顺序覆盖问题。新辅助函数同时从原始 q05/q95 取 min/max，交叉时交换端点，保留两个原始预测值。新增交叉样例测试，并通过原有三项时间协议回归检查，共 4 项。',
        '- 所有四组均重新拟合，保存在新目录；旧实验、DeepSeek 结果和此前复核产物保留。分位数原始输出、排序后校准结果、模型和反馈日志均可追溯。',
        '- 四组都包含 B_speed：历史功率、统计、日历、完整的 24 小时 U/V/风速曲线；2012 还包含当时已知的 NWP 批次年龄。这里“加气象特征”不是“从无 NWP 到有 NWP”，而是加入同一条已知曲线的 14 个显式派生特征。',
        '- 两种结构使用完全相同的 14 个显式特征：当前 U、V、风速、风速三次方、两个归一化方向分量、目标小时 sin/cos、U 的 ±1/±2h 值和前后差分。相邻值取自同一个预测原点已知的 NWP 曲线，边缘为 NaN，不访问未来功率。',
        '- 采用 protocol_v2 的统一基础列顺序。DeepSeek 原共享模型的整条曲线列采用交错顺序；列重排未改变信息，但树的并列候选分裂可能受影响，因此不混用旧 R1/R2 数字。新 R0 的评价区间与旧 B_speed 逐元素核验一致。',
        '- 一致性核验还发现：初版逐头布尔列切片改变了内存布局，Scaler 的均值归约出现约 1e−14 的舍入差，少量边界样本落入不同树箱。已统一为 C 连续数组并在新的 `_v2` 目录重跑全部四格；旧初版目录仅保留追溯，不能与本文数字混用。该修正依据基线逐元素复现检查，不依据方法优劣选结果。',
        '- 独立头在固定时效上删除仅在训练段判断为全 NaN 的边缘列；没有有效训练信息被删除。每头 Scaler 仅拟合训练段。共享头额外输入 h=1…24，独立头的时效由头编号给定。',
        '', '## 冻结协议', '',
        '- q05/q95，名义逐小时覆盖 90%；每场单独训练。HistGBR 固定 50 轮、31 叶、最小叶样本 20、L2=0、seed=0，无 early stopping、无调参。',
        '- 2014：2012 训练，2013Q1 验证种子、Q2 验证；Q2 为评价校准种子，2013H2 评价。2012：2009H2+2010 训练，2011Q1 种子、Q2 验证，2011H2—2012-06-27 评价。',
        '- 每时效 signed rolling CQR，84 日历日窗；仅 `target_end <= origin` 的完整标签反馈，未来目标完整性不参与发预测资格。CQR 后裁剪至 [0,1]；本文主表均为该口径，未裁剪结果另存。',
        '- 同一数据集四组使用相同发报原点、标签与工况掩码。上升/下降爬坡为相邻小时变化 >0.1/<−0.1，首小时以前一已观测小时为基准；近零为 |y|≤0.01。这些未来真实工况仅用于评价。',
        '- 表内按风场宏平均；覆盖和宽度为 %，差值以百分点 pp 表示。IS 为 90% interval score，`宽度 + 20×下越界距离 + 20×上越界距离`，越低越好。归一化容量 C=1。',
        '', '## 四组总体结果', '',
        '| 数据集 | 模型 | 覆盖率 % | 宽度 % | IS | 相对基础独立头的 IS 降幅 % |',
        '|---|---|---:|---:|---:|---:|']
    for y in [2014,2012]:
        ref=m(y,METHODS[0]).IS
        for method in METHODS:
            r=m(y,method)
            lines.append(f'| {y} | {LABELS[method]} | {100*r.coverage:.3f} | {100*r.width:.3f} | {r.IS:.6f} | {100*(ref-r.IS)/ref:+.3f} |')
    lines+=['', '## 条件效应：共享和显式特征各改变了什么', '',
        '以下均为“后者 − 对照”，IS/宽度负值表示改善；覆盖正值只表示覆盖增加，不等同于校准更好。置信区间为同步跨场、跨方法的配对 14 日历日移动块 bootstrap，2000 次；7 日块敏感性分析见 CSV。', '',
        '| 数据集 | 对照 | Δ覆盖 pp | Δ宽度 pp | ΔIS [95% CI] | 相对该对照的 IS 降幅 % |',
        '|---|---|---:|---:|---|---:|']
    for y in [2014,2012]:
        for name,(label,a,base) in PAIRS.items():
            r=c(y,name);cov=c(y,name,'coverage');w=c(y,name,'width')
            lines.append(f'| {y} | {label} | {100*cov.delta:+.3f} | {100*w.delta:+.3f} | {r.delta:+.6f} [{r.low95:+.6f}, {r.high95:+.6f}] | {-100*r.delta/m(y,base).IS:+.3f} |')
    lines+=['', '### 交互与平均分解', '',
        '交互项 =（共享模型加特征的变化）−（独立头加特征的变化）。负的 IS 交互意味着显式特征在共享结构下更有用。它本身不等于组合相对 R0 的净收益。', '',
        '| 数据集 | IS 交互项 [95% CI] | 平均共享效应 ΔIS | 平均特征效应 ΔIS | 两项之和 ΔIS |',
        '|---|---|---:|---:|---:|']
    for y in [2014,2012]:
        r=c(y,'interaction');a=c(y,'average_sharing');e=c(y,'average_extra')
        lines.append(f'| {y} | {r.delta:+.6f} [{r.low95:+.6f}, {r.high95:+.6f}] | {a.delta:+.6f} | {e.delta:+.6f} | {a.delta+e.delta:+.6f} |')
    lines+=['', '平均共享效应 = ½[(共享基础−独立基础)+(共享增强−独立增强)]；平均特征效应 = ½[(独立增强−独立基础)+(共享增强−共享基础)]。这是对两条加入路径等权的分解约定，不是唯一归因；不能转换成不带限定的“贡献率”。',
        '', '## 爬坡与近零工况', '',
        '| 数据集 | 工况 | 模型 | 覆盖率 % | 宽度 % | IS |',
        '|---|---|---|---:|---:|---:|']
    for y in [2014,2012]:
        for group in ['ramp','up_ramp','down_ramp','near_zero']:
            for method in METHODS:
                r=m(y,method,group)
                lines.append(f'| {y} | {CN[group]} | {LABELS[method]} | {100*r.coverage:.3f} | {100*r.width:.3f} | {r.IS:.6f} |')
    lines+=['', '共享＋显式特征相对基础独立头的关键条件变化：', '',
        '| 数据集 | 工况 | Δ覆盖 pp [95% CI] | Δ宽度 pp [95% CI] | ΔIS [95% CI] |',
        '|---|---|---|---|---|']
    for y in [2014,2012]:
        for group in ['up_ramp','near_zero']:
            cells=[]
            for metric,scale in [('coverage',100),('width',100),('IS',1)]:
                r=c(y,'combined',metric,group)
                cells.append(f'{scale*r.delta:+.4f} [{scale*r.low95:+.4f}, {scale*r.high95:+.4f}]')
            lines.append(f'| {y} | {CN[group]} | '+' | '.join(cells)+' |')
    lines+=['', '### 实际分位数交叉计数', '',
        '下表为排序前 q05>q95 的单元数。全期包含训练与种子段，评价列只统计完整标签的评价小时；交叉均在进入校准前用修复后的同一函数排序。', '',
        '| 数据集 | 模型 | 全期交叉小时 | 评价交叉小时 |',
        '|---|---|---:|---:|']
    ck=pd.DataFrame(ver['checks'])
    for y in [2014,2012]:
        for method in METHODS:
            r=ck[(ck.year==y)&(ck.method==method)]
            lines.append(f'| {y} | {LABELS[method]} | {r.crossing_all.sum()} | {r.crossing_eval.sum()} |')
    lines+=['', '## 统计与完整性边界', '',
        f'- 运行耗时 {done["elapsed_seconds"]:.1f} 秒；68 组的评价指标已从保存数组独立重算，四组原点一致、两个阶段反馈时间检查通过。17 场 R0 与旧 B_speed 评价区间最大差 <1e−10。',
        '- bootstrap 在统一完整日历上同步抽块，保留跨风场/跨方法的配对关系；缺发报日保留为空日。每次先逐场按有效小时求指标，再对风场等权平均。',
        '- 置信区间是未作多重比较校正的探索性区间；只反映本批固定风场、固定种子和历史时期的时间波动，不包含新风场、重新训练种子或模型选择的不确定性。',
        '- 所有评价日期此前已被查看，本轮是预先固定四格的回溯消融，不能称为新的未触碰测试，也不据评价结果继续调参。验证指标保存在 metrics_macro.csv，未用于这轮选型。',
        '- 结构对比固定每模型 H0，不固定总参数量：独立模型每分位数 24×50 轮，共享模型每分位数 1×50 轮。结论属于当前共享方式及容量配置，不能单独证明“共享机制”的纯因果效应。',
        '- 2014 缺原生 NWP 起报/发布时间，沿用竞赛可用性假设；2012 仅一个可用高度。没有新增外部天气信息，没有消除数据的这些限制。',
        '- 本地运行和数组核验不等于独立外部审计通过。',
        '', '## 下一步建议', '',
        '1. 保留完整四格结果。根据条件效应和交互解释收益，不把 R2 总收益全部归给共享结构，也不把显式特征当成新增 NWP 信息。',
        '2. 上升爬坡覆盖仍低于名义 90%；同时检查该工况宽度增加与上下尾漏点，不能仅凭总体 IS 下降称问题已解决。',
        '3. 2012 近零覆盖相对基础下降 1.096pp，超过原定 1pp 点估计容忍线，继续标记为“有条件权衡”；即使绝对覆盖仍高于 90%，也不改写原门槛。',
        '4. 如需继续研究结构机制，另冻结一轮容量/复杂度对照及新的时间外验证；不要在当前评价段反复选树轮数。当前用户授权的四格实验已完成，不自动启动下一轮调参。',
        '', '## 复现与产物', '',
        '- 训练：`python -u run_gefcom_factorial.py`；数组核验与统计：`python analyze_gefcom_factorial.py`；报告：`python write_gefcom_factorial_report.py`。',
        '- `protocol.json` 保存运行前协议、依赖版本与源码 SHA256；两套数据子目录各有原始文件 SHA256、日历、逐场样本、模型、原始分位数输出、验证/评价区间与反馈日志。',
        '- `evaluation_macro.csv` / `recomputed_metrics_per_farm.csv`：主口径指标；`metrics_macro.csv` / `metrics_per_farm.csv`：含验证、raw/CQR、裁剪/未裁剪的完整口径。',
        '- `paired_bootstrap.csv`：全部 8 个预设对照、5 个工况、3 个指标、7/14 日块的点估计及区间；`evaluation_per_lead.csv`：逐场逐时效。',
        '- `verification.json`：68 组核验与交叉计数；`checks.json`：训练和时序检查；`gefcom2014_daily_stats.npz` / `gefcom2012_daily_stats.npz`：用于 bootstrap 的逐日充分统计。',
        '- 最新区间图及选日说明：[四组区间预测图](figures/README.md)，分别提供两套数据的 PNG、矢量 PDF、逐小时 CSV 和复现脚本。每图四行方法、两列固定日期，含漏覆盖点；例图不代替总体统计。',
        f'- 运行环境：Python {spec["versions"]["python"]}、NumPy {spec["versions"]["numpy"]}、pandas {spec["versions"]["pandas"]}、sklearn {spec["versions"]["sklearn"]}；复用项目既有运行时，未安装依赖。',
        '']
    (OUT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':main()
