"""Direct event probability versus frozen annual q90, development gate first."""
from pathlib import Path
import hashlib
import json
import sys

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score
from threadpoolctl import threadpool_limits

import run_kelmarsh_gfs_q90 as prior
from run_kelmarsh_gfs_q90_expand import read_months
from run_q90_training_coverage import apply,subset
from run_uncapped_alarm_new_site import models,calibrate,alarm
from diagnose_gefcom2012_data_attribution import match_truth
from prepare_q90_training_coverage import TRAIN,OUT as COVERAGE
from revision_common import frozen_spec,write

OUT=Path(__file__).resolve().parent/'out_kelmarsh_ramp_probability'
MODELS=('qrf','annual_q90','ramp_probability')
FIELDS={'annual_q90':'uncapped','ramp_probability':'probability'}
FEATURES=('qrf_increment','qrf_previous_level','qrf_median','nwp_speed','nwp_speed_change',
          'nwp_direction_change','nwp_u_unit','nwp_v_unit','forecast_lead')
CONFIG=dict(loss='log_loss',max_iter=40,max_leaf_nodes=7,min_samples_leaf=50,
            l2_regularization=1,early_stopping=False,random_state=0)
PERIODS=tuple(f'2024-{m:02}' for m in range(2,13))
QUARTERS={'feb_mar':(2,3),'apr_jun':(4,5,6),'jul_sep':(7,8,9),'oct_dec':(10,11,12)}
SEASONS={'winter_partial_DF':(2,12),'spring_MAM':(3,4,5),'summer_JJA':(6,7,8),'autumn_SON':(9,10,11)}
COUNTS=('events','hits','quiet','false','nonramps','false_nonramps','hours','alarms','exact_hits')
METRICS=('recall','quiet_fpr','nonramp_fpr','alarm_rate','exact_recall','exact_precision')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def protocol():
    frozen_spec(OUT/'protocol.json',dict(
        train=list(TRAIN),train_selection='exact same annual q90 rows and gate; no resampling or class weighting',
        target='actual hourly increment >0.10 capacity, same-hour event, not ±1h-expanded labels',
        features=list(FEATURES),model=CONFIG,
        qrf='frozen original checkpoint, input builder, imputation and normalizer',
        annual_q90='load out_q90_training_coverage/annual.joblib unchanged; fully uncapped alarm score',
        off_gate='original QRF increment >0.10 for every method; first lead never gated',
        event_matching='same day ±1h one-to-one; group according to true event gate; quiet abs(actual_increment)<=0.05',
        comparison='per-development-group exact quiet false count equal to original QRF; deterministic per-date ties seed20261107+epoch_day',
        december_development=['2023-12'],expanded_development=list(PERIODS),
        status='2024 Kelmarsh already inspected in prior experiments; reused development/retrospective only',
        quarterly_stability={k:list(v) for k,v in QUARTERS.items()},
        meteorological_seasons={k:list(v) for k,v in SEASONS.items()},
        season_scope='quarters reproduce earlier work; meteorological seasons also reported, winter missing January and contains separated February/December',
        shared_workpoint='also apply pooled expanded-development diagnostic cutoff unchanged across seasonal groups; not deployable validation',
        inference='2000 paired calendar moving blocks,14d primary,7/28d sensitivity; conditional on fitted scores and diagnostic cutoffs, not recalibrated inside bootstrap',
        development_gate=dict(primary='pooled gated recall gain CI lower>0 against BOTH annual q90 and QRF at14d',
            quarterly='at least3 of4 nonnegative gains vs q90; no quarter point decline beyond5pp; no quarter CI upper<0',
            seasonal='at least2 of3 observed full meteorological seasons nonnegative vs q90; no point decline beyond5pp or CI upper<0; incomplete winter described separately',
            overall='all-hour recall point not lower than q90',december='same-FPR gated recall point not lower than q90'),
        threshold_order='only after development gate passes, freeze thresholds using Kelmarsh December2023 quiet labels; no holdout threshold matching for deployment',
        independent='do not score or acquire new target series unless gate passes; old Kelmarsh/Penmanshiel scored dates cannot be relabeled independent; lock new cohort/site and dates first',
        intervention='probability alarm only; no point correction or interval endpoint changes; no coverage/width/IS claim',
        execution='existing project CPU runtime,2threads,no environment changes or GPU'))


def add_probability(base,q90,classifier):
    r=apply(base,q90)[0]
    r['probability']=np.full(r['base'].shape,np.nan)
    with threadpool_limits(limits=2):
        r['probability'][r['gate']]=classifier.predict_proba(r['features'][r['gate']])[:,1]
    return r


def rates(v):
    events,hits,quiet,false,negative,fp,hours,alerts,exact=np.moveaxis(v,-1,0)
    with np.errstate(divide='ignore',invalid='ignore'):
        return np.stack([hits/events,false/quiet,fp/negative,alerts/hours,exact/events,exact/alerts],axis=-1)


def daily(r,cutoffs,operation):
    y=r['actual'];u=y>.1;q=np.abs(y)<=.05
    rows=[]
    for name in MODELS:
        al=r['base']>.1 if name=='qrf' else alarm(r,FIELDS[name],cutoffs[name])
        hit=match_truth(u,al)
        for scope,keep in [('gated',r['gate']),('all',np.ones_like(r['gate']))]:
            arrays=[u&keep,u&keep&hit,q&keep,q&keep&al,~u&keep,~u&keep&al,keep,al&keep,u&al&keep]
            vals=np.column_stack([a.sum(axis=1) for a in arrays])
            rows.append(pd.DataFrame(vals,columns=COUNTS).assign(origin=r['origins'],
                model=name,scope=scope,operation=operation))
    return pd.concat(rows,ignore_index=True)


def summarize(frame):
    s=frame.groupby(['operation','scope','model'])[list(COUNTS)].sum()
    return s.join(pd.DataFrame(rates(s.to_numpy()),index=s.index,columns=METRICS))


def paired(frame,block):
    dates=pd.date_range(frame.origin.min(),frame.origin.max())
    n=len(dates)
    assert block<=n
    rng=np.random.default_rng(20120516)
    starts=rng.integers(0,n-block+1,size=(2000,int(np.ceil(n/block))))
    take=(starts[:,:,None]+np.arange(block)).reshape(2000,-1)[:,:n]
    rows=[]
    for (op,scope),g in frame.groupby(['operation','scope']):
        for ref in ('qrf','annual_q90'):
            v=np.stack([g[g.model.eq(m)].set_index('origin')[list(COUNTS)]
                .reindex(dates,fill_value=0).to_numpy() for m in (ref,'ramp_probability')])
            draws=rates(v[:,take].sum(axis=2))
            delta=draws[1]-draws[0]
            point=rates(v.sum(axis=1))
            low,high=np.nanquantile(delta,[.025,.975],axis=0)
            rows.extend(dict(operation=op,scope=scope,reference=ref,block=block,metric=k,
                delta=float(d),low=float(lo),high=float(hi),valid_draws=int(np.isfinite(delta[:,i]).sum()))
                for i,(k,d,lo,hi) in enumerate(zip(METRICS,point[1]-point[0],low,high)))
    return pd.DataFrame(rows)


def ranking(r,train_prevalence):
    use=r['gate'];y=(r['actual'][use]>.1).astype(int)
    a=r['probability'][use]
    return dict(hours=int(use.sum()),events=int(y.sum()),prevalence=float(y.mean()),
        probability_mean=float(a.mean()),Brier=float(brier_score_loss(y,a)),
        Brier_training_constant=float(brier_score_loss(y,np.full(len(y),train_prevalence))),
        logloss=float(log_loss(y,a,labels=[0,1])),
        probability_AUC=float(roc_auc_score(y,a)),probability_AP=float(average_precision_score(y,a)),
        q90_AUC=float(roc_auc_score(y,r['uncapped'][use])),q90_AP=float(average_precision_score(y,r['uncapped'][use])),
        qrf_AUC=float(roc_auc_score(y,r['base'][use])),qrf_AP=float(average_precision_score(y,r['base'][use])))


def evaluate(name,base,q90,classifier,prevalence,pooled=None):
    folder=OUT/name;folder.mkdir(exist_ok=True)
    r=add_probability(base,q90,classifier)
    cutoffs={m:calibrate([r],field) for m,field in FIELDS.items()}
    d=daily(r,cutoffs,'same_fpr_development')
    if pooled is not None:
        d=pd.concat([d,daily(r,pooled,'pooled_development_cutoff')],ignore_index=True)
    m=summarize(d)
    d.to_csv(folder/'daily.csv',index=False);m.to_csv(folder/'summary.csv')
    span=len(pd.date_range(d.origin.min(),d.origin.max()))
    ci=pd.concat([paired(d,b) for b in (7,14,28) if b<=span],ignore_index=True)
    ci.to_csv(folder/'paired_blocks.csv',index=False)
    write(folder/'diagnostic_cutoffs.json',cutoffs)
    write(folder/'ranking.json',ranking(r,prevalence))
    np.savez_compressed(folder/'scores.npz',origins=r['origins'],actual=r['actual'],gate=r['gate'],
        qrf=r['base'],q90=r['uncapped'],probability=r['probability'],tie=r['tie'])
    a=m.xs(('same_fpr_development','gated'))
    assert a['false'].nunique()==1
    print(name,'events',int(a.events.iloc[0]),'hits',a.hits.astype(int).to_dict(),
        'false',int(a['false'].iloc[0]),flush=True)
    return d,m,ci,cutoffs


def cirow(result,reference='annual_q90',scope='gated',block=14,metric='recall'):
    ci=result[2]
    return ci[(ci.operation=='same_fpr_development')&(ci.scope==scope)&
              (ci.reference==reference)&(ci.block==block)&(ci.metric==metric)].iloc[0]


def stability(results,names,minimum):
    c=[cirow(results[n]) for n in names]
    return dict(nonnegative=int(sum(r.delta>=0 for r in c)),required=minimum,
        no_point_decline_beyond_5pp=all(r.delta>=-.05 for r in c),
        no_significant_negative=all(r.high>=0 for r in c),
        pass_gate=bool(sum(r.delta>=0 for r in c)>=minimum and all(r.delta>=-.05 and r.high>=0 for r in c)))


def main():
    protocol()
    (OUT/'source_executed.py').write_bytes(Path(__file__).read_bytes())
    forest,imp,_=models()
    q90=joblib.load(COVERAGE/'annual.joblib')
    frozen_spec(OUT/'weights.json',dict(qrf_sha256=sha(prior.OUT/'q90_expanded_holdout'/'frozen_baseline.joblib'),
        annual_q90_sha256=sha(COVERAGE/'annual.joblib')))
    train=read_months(TRAIN)
    with threadpool_limits(limits=2):
        base=prior.record(train,forest,imp)[0]
    use=base['gate'];target=(base['actual'][use]>.1).astype(int)
    assert use.sum()==1387 and target.sum()==231 and len(base['origins'])==297
    assert base['ends'].max()<=np.datetime64('2023-08-01')
    with threadpool_limits(limits=2):
        classifier=HistGradientBoostingClassifier(**CONFIG).fit(base['features'][use],target)
    joblib.dump(classifier,OUT/'classifier.joblib')
    counts=dict(days=297,gated_hours=int(use.sum()),events=int(target.sum()),negatives=int((target==0).sum()),
        feature_sha256=hashlib.sha256(base['features'][use].tobytes()).hexdigest(),
        target_sha256=hashlib.sha256(target.tobytes()).hexdigest(),
        mean_leaves=float(np.mean([t.nodes['is_leaf'].sum() for row in classifier._predictors for t in row])))
    write(OUT/'training_counts.json',counts)
    with threadpool_limits(limits=2):
        witness=prior.record({**train,'y':np.zeros_like(train['y'])},forest,imp)[0]
    np.testing.assert_array_equal(base['features'],witness['features'])
    np.testing.assert_array_equal(base['base'],witness['base'])
    write(OUT/'training_ranking.json',ranking(add_probability(base,q90,classifier),float(target.mean())))
    print('TRAINED',counts,flush=True)
    results={}
    dec=read_months(('2023-12',));year=read_months(PERIODS)
    with threadpool_limits(limits=2):
        dec_base=prior.record(dec,forest,imp)[0];year_base=prior.record(year,forest,imp)[0]
    results['december2023_development']=evaluate('december2023_development',dec_base,q90,classifier,float(target.mean()))
    results['expanded_development']=evaluate('expanded_development',year_base,q90,classifier,float(target.mean()))
    pooled=results['expanded_development'][3]
    for label,months in {**QUARTERS,**SEASONS}.items():
        results[label]=evaluate(label,subset(year_base,months),q90,classifier,float(target.mean()),pooled)
    quarter=stability(results,list(QUARTERS),3)
    season=stability(results,['spring_MAM','summer_JJA','autumn_SON'],2)
    checks=dict(pooled_recall_ci_above_q90=bool(cirow(results['expanded_development']).low>0),
        pooled_recall_ci_above_qrf=bool(cirow(results['expanded_development'],'qrf').low>0),
        quarterly_stability=quarter['pass_gate'],meteorological_stability=season['pass_gate'],
        all_hour_recall_not_lower=bool(cirow(results['expanded_development'],scope='all').delta>=0),
        december_recall_not_lower=bool(cirow(results['december2023_development']).delta>=0))
    passed=all(checks.values())
    decision=dict(checks=checks,quarterly=quarter,seasonal=season,development_passed=passed,
        independent_status='pending: identify and lock genuinely unused cohort/site before target acquisition' if passed else 'not run: development gate failed; preserve new holdout',
        interval_status='original QRF endpoints unchanged')
    write(OUT/'decision.json',decision)
    if passed:
        frozen_spec(OUT/'thresholds.json',dict(source='Kelmarsh December2023 ONLY',cutoffs=results['december2023_development'][3],
            status='frozen after development gate; independent target series not scored'))
    # Verify frozen q90 and QRF development counts against the preceding run.
    current=results['expanded_development'][1].xs(('same_fpr_development','gated'))
    old=pd.read_csv(COVERAGE/'retrospective_kelmarsh_year'/'annual'/'summary.csv')
    old=old[(old.operation=='exact_fpr')&(old.scope=='gated')].set_index('model')
    for name,key in [('qrf','original'),('annual_q90','corrected')]:
        for c in ('events','hits','quiet','false','hours'):
            assert current.loc[name,c]==old.loc[key,c]
    assert sha(prior.OUT/'q90_expanded_holdout'/'frozen_baseline.joblib')==json.loads((OUT/'weights.json').read_text())['qrf_sha256']
    assert sha(COVERAGE/'annual.joblib')==json.loads((OUT/'weights.json').read_text())['annual_q90_sha256']
    common=classifier.get_params().keys() & q90.get_params().keys()-{'loss'}
    assert all(classifier.get_params()[k]==q90.get_params()[k] for k in common)
    write(OUT/'verification.json',dict(status='pass',same_annual_counts=True,same_shared_hyperparameters=True,
        features_independent_of_future_targets=True,baseline_yearly_counts_reproduce_previous_results=True,
        qrf_and_q90_hashes_unchanged=True,
        interpreter=sys.executable,sklearn=sklearn.__version__,numpy=np.__version__,pandas=pd.__version__,
        independent_data_scored=False))
    write(OUT/'sample_counts.json',dict(training=counts,december_development=dict(days=len(dec['origins']),issued=dec['total_origins']),
        expanded_development=dict(days=len(year['origins']),issued=year['total_origins'])))
    write(OUT/'completion.json',dict(status='development_complete' if passed else 'complete',development_passed=passed,
        independent_run=False,reason=decision['independent_status']))
    print('DECISION',json.dumps(decision),flush=True)


if __name__=='__main__':
    main()
