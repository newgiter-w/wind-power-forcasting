"""Read-only diagnostics of saved predictions; no model fitting or test selection."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'out_calibration_v1/diagnostics'
CAP=12300.

def metrics(f):
    if not len(f):return {'cells':0,'origins':0}
    lo,hi,y=(f[k].to_numpy() for k in ('lo','hi','y'))
    w=hi-lo;rw=f.raw_hi-f.raw_lo
    inside=(y>=lo)&(y<=hi)
    assert (w>=0).all()
    assert np.isclose(inside.mean()+(y<lo).mean()+(y>hi).mean(),1)
    score=w+20*np.maximum(lo-y,0)+20*np.maximum(y-hi,0)
    # Counterfactual only. Net SCADA targets are not constrained to [0, capacity].
    cl=np.maximum(lo,0);cu=np.minimum(hi,CAP)
    return dict(cells=len(f),origins=f.origin.nunique(),coverage=float(inside.mean()),
                below_rate=float((y<lo).mean()),above_rate=float((y>hi).mean()),
                width_kw=float(w.mean()),raw_width_kw=float(rw.mean()),
                calibration_added_kw=float((w-rw).mean()),
                raw_width_share=float(rw.mean()/w.mean()),score=float(score.mean()/CAP),
                mean_upper_kw=float(hi.mean()),negative_targets=int((y<0).sum()),
                above_capacity_targets=int((y>CAP).sum()),
                clipped_coverage=float(((y>=cl)&(y<=cu)).mean()),
                clipped_width_kw=float(np.maximum(cu-cl,0).mean()),
                upper_exceedance_kw=float(np.maximum(y-hi,0).mean()),
                lower_exceedance_kw=float(np.maximum(lo-y,0).mean()))

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    # Read cache directly, retaining the original regular time grid and quality flags.
    df=pd.read_csv(r'D:\Study\wind_datasets\kelmarsh\farm_cache_2018_2022.csv',parse_dates=['timestamp'])
    assert df.timestamp.diff().dropna().eq(pd.Timedelta(minutes=10)).all()
    with np.load(ROOT/'out_calibration_v1/raw_predictions.npz') as p:
        origins=pd.to_datetime(p['origins']);last=p['last_hour'].copy()
    features=[]
    index=pd.DatetimeIndex(df.timestamp).get_indexer(origins)
    assert (index>=143).all()
    for t,i,lh in zip(origins,index,last):
        hist=df.iloc[i-143:i+1];six=hist.iloc[-36:]
        hp=six.power_filled.to_numpy().reshape(6,6).mean(axis=1)
        np.testing.assert_allclose(lh,hp[-1],atol=1e-8,rtol=0)
        features.append(dict(origin=t,last_hour_kw=lh,historical_6h_valid=bool(six.power_valid.all()),
            last_6h_max_abs_kw=float(np.abs(hp).max()),last_6h_max_change_kw=float(np.abs(np.diff(hp)).max()),
            past_wind_6h=float(six.wind_speed.mean()),last_wind=float(hist.wind_speed.iloc[-1]),
            past_6h_mean_kw=float(hp.mean())))
    features=pd.DataFrame(features)
    features['predict_low']=features.last_hour_kw.abs().le(.05*CAP)&features.historical_6h_valid
    features['predict_stable_low']=features.predict_low&features.last_6h_max_abs_kw.le(.05*CAP)&features.last_6h_max_change_kw.le(.05*CAP)
    features.to_csv(OUT/'historical_features.csv',index=False)
    rows=[];tails=[];horizons=[];cases=[];case_context=[]
    for year in (2021,2022):
        for method in ('global_cqr','rolling_cqr','aci_projected'):
            f=pd.read_csv(ROOT/f'out_calibration_v1/{year}/{method}/forecasts.csv',parse_dates=['origin'])
            f=f.merge(features,on='origin',validate='many_to_one')
            f=f[f.target_valid].copy()
            previous=f.groupby('origin',sort=False).y.shift(1).fillna(f.last_hour_kw)
            delta=f.y-previous
            np.testing.assert_array_equal(delta.abs().gt(.1*CAP),f.ramp)
            assert np.isfinite(f[['y','lo','hi','raw_lo','raw_hi']]).all().all()
            np.testing.assert_allclose(f.hi-f.lo-(f.raw_hi-f.raw_lo),2*f.q_used,atol=1e-8)
            groups={'all':np.ones(len(f),bool),'actual_near_zero':f.y.abs().le(.01*CAP),
                    'actual_ramp':f.ramp,'actual_non_ramp':~f.ramp,
                    'actual_up_ramp':delta.gt(.1*CAP),'actual_down_ramp':delta.lt(-.1*CAP),
                    'predict_low':f.predict_low,'predict_stable_low':f.predict_stable_low}
            for name,mask in groups.items():rows.append(dict(year=year,method=method,group=name,**metrics(f[mask])))
            for a,b in ((1,3),(4,6),(7,12),(13,24)):
                h=f[f.lead_block.between(a,b)]
                horizons.append(dict(year=year,method=method,lead=f'{a}-{b}',**metrics(h)))
                if method=='rolling_cqr':
                    for g in ('predict_low','predict_stable_low'):
                        z=h[h[g]]
                        tails.append(dict(year=year,group=g,lead=f'{a}-{b}',cells=len(z),origins=z.origin.nunique(),
                            future_above_20pct_rate=float(z.y.gt(.2*CAP).mean()) if len(z) else None))
            if year==2022:
                for date in ('2022-08-08 23:50:00','2022-05-05 23:50:00'):
                    day=f[f.origin.eq(pd.Timestamp(date))]
                    cases.append(dict(origin=date,method=method,group='whole_day',**metrics(day)))
                    cases.append(dict(origin=date,method=method,group='actual_near_zero',**metrics(day[day.y.abs().le(.01*CAP)])))
                    day.assign(method=method).to_csv(OUT/f'{date[:10]}_{method}_decomposition.csv',index=False)
                    if method=='rolling_cqr':
                        i=int(index[origins==pd.Timestamp(date)][0]);future=df.iloc[i+1:i+145]
                        case_context.append(dict(origin=date,**features[features.origin.eq(pd.Timestamp(date))].drop(columns='origin').iloc[0].to_dict(),
                            future_wind_mean_RETROSPECTIVE=float(future.wind_speed.mean()),
                            future_wind_min_RETROSPECTIVE=float(future.wind_speed.min()),
                            future_wind_max_RETROSPECTIVE=float(future.wind_speed.max()),
                            future_availability_min_RETROSPECTIVE=float(future.availability.min()),
                            future_setpoint_nonmissing=int(future.setpoint.notna().sum())))
    pd.DataFrame(rows).to_csv(OUT/'group_metrics.csv',index=False)
    pd.DataFrame(horizons).to_csv(OUT/'horizon_metrics.csv',index=False)
    pd.DataFrame(tails).to_csv(OUT/'predict_low_future_takeoff.csv',index=False)
    pd.DataFrame(cases).to_csv(OUT/'example_metrics.csv',index=False)
    pd.DataFrame(case_context).to_csv(OUT/'example_context.csv',index=False)
    (OUT/'audit.json').write_text(json.dumps(dict(model_fits=0,new_prediction_calls=0,
        evaluation_years=[2021,2022],unseen_years_read=[],capacity_kw=CAP,
        actual_near_zero='abs(y)<=123 kW: retrospective diagnostic only',
        predict_low='abs(last observed hour)<=615 kW, preceding 6h fully valid',
        predict_stable_low='predict_low and all preceding 6 hourly abs means<=615 kW and max hourly change<=615 kW',
        target_validity='same complete-day mask as existing evaluation',
        assertions=['10-minute regular grid','last-hour feature matches frozen cache','width equals raw width plus 2q','all evaluated bounds ordered/finite']),indent=2),encoding='utf-8')
    print(pd.DataFrame(rows).query("group=='all' or group=='actual_near_zero'").to_string(index=False))
    print('\nCASE CONTEXT\n',pd.DataFrame(case_context).to_string(index=False))
    print('\nCASE METRICS\n',pd.DataFrame(cases).to_string(index=False))
    print('\nLOW POWER TAKEOFF\n',pd.DataFrame(tails).to_string(index=False))

if __name__=='__main__':main()
