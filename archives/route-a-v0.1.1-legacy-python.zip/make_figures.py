"""Generate final paper figures from out_final/results.json."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

OUT = 'out_final'
d = json.load(open(f'{OUT}/results.json'))
leads = [str(h + 1) for h in range(24)]
x = np.arange(1, 25)

fig, axes = plt.subplots(2, 2, figsize=(13, 7))
for i, year in enumerate(('2021', '2022')):
    c0c = [d[year]['C0']['per_lead'][l]['coverage'] * 100 for l in leads]
    fnc = [d[year]['Final']['per_lead'][l]['coverage'] * 100 for l in leads]
    c0w = [d[year]['C0']['per_lead'][l]['width'] * 100 for l in leads]
    fnw = [d[year]['Final']['per_lead'][l]['width'] * 100 for l in leads]
    axes[0, i].plot(x, c0c, 'o-', ms=3, label='C0 (symmetric CQR)')
    axes[0, i].plot(x, fnc, 's-', ms=3, label='Final (L01+Hybrid)')
    axes[0, i].axhline(90, ls='--', color='gray', lw=0.8)
    axes[0, i].set_title(f'{year}: per-lead coverage (%)')
    axes[0, i].set_xlabel('lead time (h)'); axes[0, i].set_ylim(50, 105)
    axes[0, i].grid(alpha=0.3)
    axes[1, i].plot(x, c0w, 'o-', ms=3, label='C0')
    axes[1, i].plot(x, fnw, 's-', ms=3, label='Final')
    axes[1, i].set_title(f'{year}: per-lead width (% capacity)')
    axes[1, i].set_xlabel('lead time (h)'); axes[1, i].set_ylim(0, 110)
    axes[1, i].grid(alpha=0.3)
axes[0, 0].legend(fontsize=8); axes[1, 0].legend(fontsize=8)
plt.tight_layout()
plt.savefig(f'{OUT}/per_lead.png', dpi=110)
plt.close(fig)

# group comparison bar chart
groups = ['all', 'ramp', 'up_ramp', 'down_ramp', 'near_zero']
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
for i, year in enumerate(('2021', '2022')):
    c0 = [d[year]['C0'][g]['coverage'] * 100 for g in groups]
    fn = [d[year]['Final'][g]['coverage'] * 100 for g in groups]
    w = 0.35
    xx = np.arange(len(groups))
    axes[i].bar(xx - w/2, c0, w, label='C0')
    axes[i].bar(xx + w/2, fn, w, label='Final')
    axes[i].axhline(90, ls='--', color='gray', lw=0.8)
    axes[i].set_xticks(xx); axes[i].set_xticklabels(groups, rotation=20, fontsize=8)
    axes[i].set_title(f'{year}: coverage by condition (%)')
    axes[i].set_ylim(70, 100)
    axes[i].grid(alpha=0.3, axis='y')
axes[0].legend(fontsize=8)
plt.tight_layout()
plt.savefig(f'{OUT}/group_coverage.png', dpi=110)
plt.close(fig)
print('figures written: per_lead.png, group_coverage.png')
