"""Exploratory cross-family transfer of the already frozen MLP risk guard.

No QRF-specific tuning. Baseline H2 was inspected before this transfer was added;
this does not create new held-out evidence and is not an automatic promotion.
"""
import json
import numpy as np
from gefcom_protocol_v2 import prepare
from revision_common import OUT,write,frozen_spec,collect,save_metrics


def main():
    assert json.loads((OUT/'qrf/completion.json').read_text())['status']=='complete'
    assert json.loads((OUT/'mlp/completion.json').read_text())['status']=='complete'
    leaf=json.loads((OUT/'qrf/selection.json').read_text())['selected_leaf']
    threshold=json.loads((OUT/'mlp/selection.json').read_text())['0.05']['threshold']
    dest=OUT/'qrf_protection';dest.mkdir(exist_ok=True)
    frozen_spec(dest/'protocol.json',dict(threshold=threshold,source='MLP q=.05 2014Q2 frozen threshold; unchanged',
        classifier='reuse same per-farm proper-training prefix-OOF classifier',
        selection='none; no QRF-specific threshold tuning',
        status='exploratory transfer added after QRF seed0 H2 inspection; no new held-out evidence or promotion'))
    rows=[]
    for year in [2014,2012]:
        farms,_=prepare(year)
        for farm,d in farms.items():
            p=np.load(OUT/f'mlp/gefcom{year}/farm_{farm:02d}/risk_probabilities.npz')['probability']
            for seed in [0,1,2]:
                folder=dest/f'gefcom{year}/farm_{farm:02d}/seed_{seed}';folder.mkdir(parents=True,exist_ok=True)
                for stage in ['validation','evaluation']:
                    with np.load(OUT/f'qrf/gefcom{year}/farm_{farm:02d}/leaf_{leaf}/seed_{seed}/{stage}.npz') as z:
                        ids=z['indices'];lo=z['clipped_lo'];hi=z['clipped_hi'];ends=z['max_label_end']
                    protected=np.where(p[ids]>=threshold,0.,lo)
                    assert np.all(protected<=lo)
                    np.savez_compressed(folder/f'{stage}.npz',indices=ids,lo=protected,hi=hi,
                        max_label_end=ends,probability=p[ids],threshold=threshold)
                    collect(rows,d,ids,protected,hi,year=year,farm=farm,seed=seed,stage=stage,method='QRF_protected')
    save_metrics(dest,rows)
    write(dest/'completion.json',dict(status='complete',threshold=threshold,new_models_trained=0,
        interpretation='exploratory unchanged guard transfer; no promotion'))
    print('QRF protection transfer complete; no model trained or threshold reselected')


if __name__=='__main__':main()
