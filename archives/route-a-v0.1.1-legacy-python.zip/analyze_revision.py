"""Recompute saved intervals and synchronous seed-mean time-block comparisons."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from revision_common import OUT,REFERENCE,METRIC_COLS,evaluate,paired_daily_arrays,write

GROUPS=['all','ramp','up_ramp','down_ramp','near_zero']


def verify_diffusion():
    import torch
    from retrieval_diffusion import ResidualDenoiser
    checks=[]
    for name,dimension in [('conditional',160),('unconditional',1)]:
        folder=OUT/'diffusion'/name
        with np.load(folder/'fixed_validation_batch.npz') as z:
            values={k:z[k] for k in z.files}
        net=ResidualDenoiser(context=dimension,width=192,blocks=4,dropout=.1)
        net.load_state_dict(torch.load(folder/'model.pt',weights_only=True));net.eval()
        with torch.no_grad():
            pred=net(torch.tensor(values['z']),torch.tensor(values['steps']),torch.tensor(values['context'])).numpy()
        loss=float(((pred-values['target'])**2).mean());zero=float((values['target']**2).mean())
        saved=json.loads((folder/'diagnostics.json').read_text())
        assert abs(loss-saved['model_mse'])<1e-6 and abs(zero-saved['zero_mse'])<1e-6
        checks.append(dict(method=name,model_mse=loss,actual_zero_mse=zero,skill=1-loss/zero))
    with np.load(OUT/'diffusion/anchor_residuals.npz') as z:
        a={k:z[k] for k in z.files}
    with np.load(REFERENCE/'gefcom2014/farm_01/samples.npz') as z:
        np.testing.assert_equal(a['origins'],z['origins'])
    with np.load(REFERENCE.parents[0]/'out_gefcom_protocol_v2/gefcom2014/farm_01/samples.npz') as z:
        wind=np.hypot(z['nwp'][:,:,2],z['nwp'][:,:,3])
    dates=a['origins'];train=dates<np.datetime64('2013-01-01')
    predictors={'predicted_mean':a['mu']*a['ys']+a['ym'],'wind_speed':wind}
    bins=[]
    for name,x in predictors.items():
        edges=np.quantile(x[train],[.2,.4,.6,.8])
        for stage,days in [('train',train),('Q1',(dates>=np.datetime64('2013-01-01'))&(dates<np.datetime64('2013-04-01'))),
                           ('Q2',(dates>=np.datetime64('2013-04-01'))&(dates<np.datetime64('2013-07-01'))),
                           ('evaluation',dates>=np.datetime64('2013-07-01'))]:
            for b in range(5):
                mask=(np.searchsorted(edges,x)==b)&days[:,None]&a['valid'][:,None]
                if mask.any():
                    r=a['residual'][mask]
                    bins.append(dict(predictor=name,stage=stage,bin=b,cells=int(mask.sum()),
                        residual_mean=float(r.mean()),residual_std=float(r.std()),residual_second_moment=float((r*r).mean())))
    pd.DataFrame(bins).to_csv(OUT/'diffusion/residual_condition_bins.csv',index=False)
    write(OUT/'diffusion/recomputed_diagnostics.json',dict(status='passed',checks=checks))
    return checks


def verify_saved_models():
    import sys
    import torch
    import joblib
    from gefcom_protocol_v2 import prepare,index
    from strong_baselines import build_shared
    from run_p2_2012 import build_shared_2012
    from run_dl_baseline import QuantileMLP
    from run_gefcom_tail_dynamic import base_matrix
    sys.path.insert(0,str(OUT.parent/'.aris/qrf-packages'))
    torch.set_num_threads(2)
    checks=[]
    leaf=json.loads((OUT/'qrf/selection.json').read_text())['selected_leaf']
    for year in [2014,2012]:
        farms,_=prepare(year)
        for farm,d in farms.items():
            root=OUT/f'mlp/gefcom{year}/farm_{farm:02d}'
            X,_,_=(build_shared if year==2014 else build_shared_2012)(d,'R2')
            scaler=joblib.load(root/'scaler.joblib');xz=np.nan_to_num(X,nan=0.)
            tm=np.repeat(np.isin(np.arange(len(d['y'])),index(d,'train',True)),24)
            np.testing.assert_allclose(scaler.mean_,xz[tm].mean(axis=0),atol=1e-12)
            # Deterministically chosen validation+evaluation cells, independent of errors.
            days=np.r_[index(d,'validation')[:2],index(d,'evaluation')[:2]]
            cells=(days[:,None]*24+np.arange(24)).ravel()
            xx=torch.tensor(scaler.transform(xz[cells]),dtype=torch.float32)
            for seed in [0,1,2]:
                for q in [.02,.05,.95]:
                    model=QuantileMLP(X.shape[1]);model.load_state_dict(torch.load(root/f'seed_{seed}/q{q:.2f}.pt',weights_only=True));model.eval()
                    with torch.no_grad():pred=model(xx).numpy()
                    saved=np.load(root/f'seed_{seed}/q{q:.2f}.npz')['prediction'].ravel()[cells]
                    np.testing.assert_allclose(pred,saved,atol=2e-6,rtol=2e-6)
            risk=joblib.load(root/'risk_model.joblib')
            p=risk['calibrator'].predict(risk['classifier'].predict_proba(X[cells])[:,1])
            np.testing.assert_allclose(p,np.load(root/'risk_probabilities.npz')['probability'].ravel()[cells],atol=1e-12)
            qx=base_matrix(d,year)
            for seed in [0,1,2]:
                qfolder=OUT/f'qrf/gefcom{year}/farm_{farm:02d}/leaf_{leaf}/seed_{seed}'
                bundle=joblib.load(qfolder/'model.joblib')
                pred=bundle['model'].predict(bundle['imputer'].transform(qx[cells]),quantiles=[.05,.95],
                    weighted_quantile=True,weighted_leaves=True,aggregate_leaves_first=True)
                with np.load(qfolder/'heads.npz') as z:
                    saved=np.c_[z['lo'].ravel()[cells],z['hi'].ravel()[cells]]
                np.testing.assert_allclose(pred,saved,atol=1e-10,rtol=1e-10)
            checks.append(dict(year=year,farm=farm,MLP_weights_replayed=9,QRF_weights_replayed=3,
                scaler_train_only=True,risk_probability_replayed=True,selection='first2 validation and evaluation origins'))
            print('model replay',year,farm,flush=True)
    write(OUT/'saved_model_replay.json',dict(status='passed',checks=checks))
    return checks


def verify_low_power():
    from gefcom_protocol_v2 import prepare
    from revision_common import calibration
    frame=pd.read_csv(OUT/'low_power_corrected/eval_per_farm.csv').set_index(['farm','method','group'])
    checks=[]
    for farm,d in prepare(2014)[0].items():
        for method in ['GBM_base','GBM_aug','DL_base','DL_aug']:
            folder=OUT/f'low_power_corrected/farm_{farm:02d}'/method
            with np.load(folder/'heads.npz') as z:
                lo=np.minimum(z['q05'],z['q95']);hi=np.maximum(z['q05'],z['q95'])
                np.testing.assert_equal(z['origins'],d['origins'])
            ids,res=calibration(d,lo,hi,'evaluation')
            lo,hi=np.clip(res['lo'],0,1),np.clip(res['hi'],0,1)
            with np.load(folder/'evaluation.npz') as z:
                np.testing.assert_equal(z['indices'],ids)
                np.testing.assert_equal(z['lo'],lo);np.testing.assert_equal(z['hi'],hi)
            for group,values in evaluate(d,ids,lo,hi).items():
                if group not in GROUPS:continue
                for metric in METRIC_COLS:
                    assert abs(values[metric]-frame.loc[(farm,method,group),metric])<1e-10
            checks.append(dict(farm=farm,method=method,head_to_calibration_replayed=True))
    write(OUT/'low_power_corrected/verification.json',dict(status='passed',checks=checks))
    return checks


def load_interval(year,farm,label,seed):
    if label=='R2':
        path=REFERENCE/f'gefcom{year}/farm_{farm:02d}/R2_shared_aug/evaluation.npz'
        with np.load(path) as z:return z['indices'],np.clip(z['lo'],0,1),np.clip(z['hi'],0,1)
    if label=='QRF_protected':
        path=OUT/f'qrf_protection/gefcom{year}/farm_{farm:02d}/seed_{seed}/evaluation.npz'
        with np.load(path) as z:ids,lo,hi=z['indices'],z['lo'],z['hi']
        leaf=json.loads((OUT/'qrf/selection.json').read_text())['selected_leaf']
        threshold=json.loads((OUT/'mlp/selection.json').read_text())['0.05']['threshold']
        p=np.load(OUT/f'mlp/gefcom{year}/farm_{farm:02d}/risk_probabilities.npz')['probability'][ids]
        with np.load(OUT/f'qrf/gefcom{year}/farm_{farm:02d}/leaf_{leaf}/seed_{seed}/evaluation.npz') as z:
            np.testing.assert_equal(lo,np.where(p>=threshold,0.,z['clipped_lo']))
            np.testing.assert_equal(hi,z['clipped_hi'])
        return ids,lo,hi
    if label.startswith('QRF'):
        leaf=json.loads((OUT/'qrf/selection.json').read_text())['selected_leaf']
        path=OUT/f'qrf/gefcom{year}/farm_{farm:02d}/leaf_{leaf}/seed_{seed}/evaluation.npz'
        with np.load(path) as z:return z['indices'],z['clipped_lo'],z['clipped_hi']
    q=.02 if 'q02' in label else .05
    folder=OUT/f'mlp/gefcom{year}/farm_{farm:02d}/seed_{seed}/lower_{q:.2f}'
    name='evaluation_protected.npz' if 'protected' in label else 'evaluation.npz'
    with np.load(folder/name) as z:
        ids=z['indices']
        if 'protected' in label:return ids,z['lo'],z['hi']
        if 'nonshrinking' in label:
            qv=np.maximum(z['q_signed'],0)
            return ids,np.clip(z['raw_lo']-qv,0,1),np.clip(z['raw_hi']+qv,0,1)
        return ids,z['clipped_lo'],z['clipped_hi']


def main():
    for task in ['mlp','qrf','diffusion','qrf_protection']:
        assert json.loads((OUT/task/'completion.json').read_text())['status']=='complete',task+' incomplete'
    diffusion_checks=verify_diffusion()
    saved_model_checks=verify_saved_models()
    low_power_checks=verify_low_power()
    labels=['R2','MLP_q05','MLP_q02','MLP_q05_nonshrinking','MLP_q05_protected','MLP_q02_protected','QRF','QRF_protected']
    allrows=[];checks=[];boot=[]
    for year,nfarm in [(2014,10),(2012,7)]:
        start='2013-07-01' if year==2014 else '2011-07-01'
        end='2013-12-31' if year==2014 else '2012-06-27'
        dates=pd.date_range(start,end,freq='D').to_numpy();n=len(dates)
        # method, farm, calendar-day, group, [count,IS,coverage,width]
        daily=np.zeros((len(labels),nfarm,n,5,4))
        for farm in range(1,nfarm+1):
            with np.load(OUT/f'mlp/gefcom{year}/farm_{farm:02d}/samples.npz') as z:
                d={k:z[k] for k in z.files}
            common=None
            for m,label in enumerate(labels):
                seeds=[-1] if label=='R2' else [0,1,2]
                for seed in seeds:
                    ids,lo,hi=load_interval(year,farm,label,seed)
                    if common is None:common=ids
                    np.testing.assert_equal(common,ids)
                    assert np.isfinite(lo).all() and np.isfinite(hi).all() and (lo<=hi).all()
                    assert (lo>=0).all() and (hi<=1).all()
                    if label!='R2':
                        # Explicit arrival checks on the base calibration archive.
                        if label.startswith('QRF'):
                            leaf=json.loads((OUT/'qrf/selection.json').read_text())['selected_leaf']
                            cp=OUT/f'qrf/gefcom{year}/farm_{farm:02d}/leaf_{leaf}/seed_{seed}/evaluation.npz'
                        else:
                            q=.02 if 'q02' in label else .05
                            cp=OUT/f'mlp/gefcom{year}/farm_{farm:02d}/seed_{seed}/lower_{q:.2f}/evaluation.npz'
                        with np.load(cp) as z:assert (z['max_label_end']<=d['origins'][ids]).all()
                    metrics=evaluate(d,ids,lo,hi)
                    for group,values in metrics.items():allrows.append(dict(year=year,farm=farm,method=label,seed=seed,group=group,**values))
                    stats=paired_daily_arrays(d,ids,lo,hi)
                    pos=np.searchsorted(dates,d['origins'][ids]);np.testing.assert_equal(dates[pos],d['origins'][ids])
                    for g,group in enumerate(GROUPS):
                        values=np.stack([stats[group+'_n'],stats[group+'_IS'],stats[group+'_coverage'],stats[group+'_width']],axis=1)
                        daily[m,farm-1,pos,g,:]+=values/len(seeds)
                checks.append(dict(year=year,farm=farm,method=label,seeds=seeds,paired_origins=True,finite_ordered_support=True,causal_feedback=True))
        np.savez_compressed(OUT/f'{year}_paired_daily.npz',daily=daily,dates=dates,methods=labels,groups=GROUPS)
        rng=np.random.default_rng(20261104+year)
        for block in [7,14]:
            draws=[]
            for _ in range(2000):
                starts=rng.integers(0,n-block+1,size=int(np.ceil(n/block)))
                draws.append((starts[:,None]+np.arange(block)).ravel()[:n])
            def macro(x):
                total=x.sum(axis=2)
                return np.nanmean(np.divide(total[:,:,:,1:],total[:,:,:,0,None],
                    out=np.full(total[:,:,:,1:].shape,np.nan),where=total[:,:,:,0,None]>0),axis=1)
            point=macro(daily)
            samples=np.stack([macro(daily[:,:,ids,:,:]) for ids in draws])
            for m,label in enumerate(labels[1:],1):
                for g,group in enumerate(GROUPS):
                    for k,metric in enumerate(['IS','coverage','width']):
                        delta=samples[:,m,g,k]-samples[:,0,g,k]
                        lo,hi=np.quantile(delta,[.025,.975])
                        boot.append(dict(year=year,method=label,reference='R2',group=group,metric=metric,block_days=block,
                            difference=float(point[m,g,k]-point[0,g,k]),low=float(lo),high=float(hi),
                            interpretation='conditional on fitted models, seeds averaged; retrospective descriptive CI'))
            for target,reference in [('MLP_q05_protected','MLP_q05'),('MLP_q02','MLP_q05'),('QRF_protected','QRF')]:
                m,r=labels.index(target),labels.index(reference)
                for g,group in enumerate(GROUPS):
                    for k,metric in enumerate(['IS','coverage','width']):
                        delta=samples[:,m,g,k]-samples[:,r,g,k];lo,hi=np.quantile(delta,[.025,.975])
                        boot.append(dict(year=year,method=target,reference=reference,group=group,metric=metric,block_days=block,
                            difference=float(point[m,g,k]-point[r,g,k]),low=float(lo),high=float(hi),
                            interpretation='conditional on fitted models, seeds averaged; retrospective descriptive CI'))
    frame=pd.DataFrame(allrows);frame.to_csv(OUT/'recomputed_metrics_per_farm.csv',index=False)
    frame.groupby(['year','method','seed','group'])[METRIC_COLS].mean().reset_index().to_csv(OUT/'recomputed_macro_per_seed.csv',index=False)
    # First average across seeds within each farm, then macro average farms.
    macro=frame.groupby(['year','method','farm','group'])[METRIC_COLS].mean().groupby(['year','method','group']).mean().reset_index()
    macro.to_csv(OUT/'evaluation_macro.csv',index=False)
    pd.DataFrame(boot).to_csv(OUT/'paired_bootstrap.csv',index=False)
    # Report the OLD full promotion gates separately from the narrower guard-selection gates.
    ref=pd.read_csv(REFERENCE/'evaluation_macro.csv').set_index(['year','method','group'])
    gates=[]
    for year in [2014,2012]:
        r2=macro[(macro.year==year)&(macro.method=='R2')].set_index('group')
        r0near=float(ref.loc[(year,'R0_ind_base','near_zero'),'coverage'])
        def gate_values(candidate):
            return {
                'overall_coverage':candidate.loc['all','coverage']>=max(.9,r2.loc['all','coverage']-.005),
                'width_minus5pct':candidate.loc['all','width']<=.95*r2.loc['all','width'],
                'IS_minus5pct':candidate.loc['all','IS']<=.95*r2.loc['all','IS'],
                'up_coverage_plus3pp':candidate.loc['up_ramp','coverage']>=r2.loc['up_ramp','coverage']+.03,
                'up_IS_not_worse':candidate.loc['up_ramp','IS']<=r2.loc['up_ramp','IS'],
                'up_width_plus2pp_max':candidate.loc['up_ramp','width']<=r2.loc['up_ramp','width']+.02,
                'near_zero_old_gate':candidate.loc['near_zero','coverage']>=max(r0near-.01,r2.loc['near_zero','coverage']-.005)}
        for method in labels[1:]:
            candidate=macro[(macro.year==year)&(macro.method==method)].set_index('group')
            checks_old=gate_values(candidate)
            passing=[]
            for seed in [0,1,2]:
                per_seed=frame[(frame.year==year)&(frame.method==method)&(frame.seed==seed)].groupby('group')[METRIC_COLS].mean()
                if all(gate_values(per_seed).values()):passing.append(seed)
            gates.append(dict(year=year,method=method,all_old_gates_pass=all(checks_old.values()),
                seeds_passing=len(passing),passing_seeds=','.join(map(str,passing)),
                failures=';'.join(k for k,v in checks_old.items() if not v),**checks_old,
                note='descriptive evaluation gate check, not reselection or independent promotion'))
    pd.DataFrame(gates).to_csv(OUT/'old_promotion_gates.csv',index=False)
    # Independent recomputation must match the runners' persisted CSVs.
    deltas=[]
    for year in [2014,2012]:
        for method,label in [('MLP_q0.05_signed','MLP_q05'),('MLP_q0.02_signed','MLP_q02'),
                             ('MLP_q0.05_protected','MLP_q05_protected')]:
            original=pd.read_csv(OUT/'mlp/metrics_macro.csv')
            original=original[(original.year==year)&(original.stage=='evaluation')&(original.method==method)].groupby('group')[METRIC_COLS].mean()
            rec=macro[(macro.year==year)&(macro.method==label)].set_index('group')[METRIC_COLS]
            common=original.index.intersection(rec.index)
            delta=float(np.abs(original.loc[common].to_numpy()-rec.loc[common].to_numpy()).max())
            assert delta<1e-10;deltas.append(dict(year=year,method=method,max_abs_diff=delta))
    write(OUT/'verification.json',dict(status='passed',checks=checks,macro_recomputations=deltas,
        diffusion_recomputation=diffusion_checks,
        saved_model_replay=saved_model_checks,
        low_power_recomputation=low_power_checks,
        uncertainty='7/14-day synchronous calendar blocks, 2000 draws; no independent-site assumption',
        limitations='previously inspected evaluation; no independent external experiment-integrity review'))
    print('verified',len(checks),'method/farm combinations')


if __name__=='__main__':main()
