"""Audit native GEFCom2012 NWP vintages and fit the fixed dual-batch QRF arm."""
from concurrent.futures import ProcessPoolExecutor
import hashlib
import os

from run_point_residual import ROOT, OUT as BASE, cells, load_farms, feature_array, index
from pooling_common import local_heads
from revision_common import frozen_spec, write
from sparse_leaf_qrf import SparseLeafQRF
from gefcom_protocol_v2 import DATA
import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer

OUT = ROOT / 'out_gefcom2012_dual_batch_nwp'
PHASES = ('train', 'validation_seed', 'validation', 'evaluation')


def folder(farm):
    return OUT / f'farm_{farm:02}'


def audit(farm, d):
    source = DATA / f'gefcom2012_wind/data/windforecasts_wf{farm}.csv'
    weather = pd.read_csv(source)
    issue = pd.to_datetime(weather.date.astype(str), format='%Y%m%d%H')
    assert set(issue.dt.hour) <= {0, 12}
    assert weather.hors.between(1, 48).all()
    lookup = weather.set_index([issue, 'hors'], verify_integrity=True)[['u', 'v']]
    origins = d['origins']
    selected = pd.to_datetime(d['meta'].nwp_issue).to_numpy()
    old = selected - np.timedelta64(12, 'h')
    ages = (origins - selected) / np.timedelta64(1, 'h')
    assert np.isin(ages, [0, 12, 24]).all()
    lead = np.arange(1, 25)
    targets = origins[:, None] + lead * np.timedelta64(1, 'h')

    def align(batch):
        native = (targets - batch[:, None]) / np.timedelta64(1, 'h')
        assert np.equal(native, native.astype(int)).all()
        key = pd.MultiIndex.from_arrays([np.repeat(batch, 24), native.ravel().astype(int)])
        values = lookup.reindex(key).to_numpy().reshape(-1, 24, 2)
        np.testing.assert_array_equal(batch[:, None] + native.astype(int)*np.timedelta64(1, 'h'), targets)
        assert np.all(batch <= origins)
        return values, native.astype(int)

    latest, native_latest = align(selected)
    canonical = feature_array(2012, farm, 'GBM')
    np.testing.assert_array_equal(latest, canonical[:, -14:-12].reshape(-1, 24, 2))
    assert np.isfinite(latest).all()
    for age in (0, 12):
        candidate, _ = align(origins - np.timedelta64(age, 'h'))
        assert not (np.isfinite(candidate).all(axis=(1, 2)) & (age < ages)).any()
    previous, native_old = align(old)
    np.testing.assert_array_equal(native_old, native_latest + 12)
    available = np.isfinite(previous).all(axis=2)
    paired = available.all(axis=1)
    old_speed = np.hypot(previous[..., 0], previous[..., 1])
    new_speed = np.hypot(latest[..., 0], latest[..., 1])
    features = np.dstack([previous, old_speed, latest-previous, new_speed-old_speed]).reshape(-1, 6)
    folder(farm).mkdir(parents=True, exist_ok=True)
    np.savez_compressed(folder(farm)/'weather.npz', origins=origins, paired=paired, features=features)
    detail = pd.DataFrame(dict(farm=farm, phase=d['meta'].phase, origin=origins, latest_issue=selected,
        older_issue=old, latest_age_hours=ages, old_lead_first=native_old[:, 0],
        old_lead_last=native_old[:, -1], old_hours_available=available.sum(axis=1),
        complete_pair=paired, valid_target=d['valid'], latest_at_origin=selected == origins,
        old_issue_exists=np.isin(old, issue.unique())))
    write(folder(farm)/'weather_source.json', dict(path=str(source), sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
    return detail


def fit(farm):
    dest = folder(farm)
    d = load_farms(2012)[farm]
    tr = index(d, 'train', True)
    query = np.flatnonzero(~d['meta'].phase.eq('train').to_numpy())
    assert d['ends'][tr].max() <= d['origins'][query].min()
    with np.load(dest/'weather.npz') as z:
        np.testing.assert_array_equal(z['origins'], d['origins'])
        paired, extra = z['paired'], z['features']
    assert np.isfinite(extra[cells(tr[paired[tr]])]).all()
    if (dest/'heads.npz').exists() and (dest/'fit.json').exists():
        print('REUSE', farm, flush=True)
        return
    imputer = SimpleImputer(strategy='median', add_indicator=True, keep_empty_features=True).fit(extra[cells(tr)])
    X = np.column_stack([feature_array(2012, farm, 'QRF'), imputer.transform(extra)]).astype('float32')
    model = SparseLeafQRF(500, 10, 0, n_jobs=2).fit(X[cells(tr)], d['y'][tr].ravel())
    print('TREES', farm, flush=True)
    paired_query = query[paired[query]]
    pred = model.predict(X[cells(paired_query)], (.05, .5, .95)).reshape(-1, 24, 3)
    assert np.isfinite(pred).all() and (np.diff(pred, axis=2) >= 0).all()
    lo, hi = local_heads(2012, farm, 'QRF', 0)
    with np.load(BASE/f'gefcom2012/farm_{farm:02}/heads.npz') as z:
        np.testing.assert_array_equal(z['origins'], d['origins'])
        np.testing.assert_array_equal(z['direct_qrf'], [lo, hi])
        hybrid = np.stack([lo, z['qrf'], hi], axis=-1)
    hybrid[paired_query] = pred
    assert np.isfinite(hybrid[query][:, :, [0, 2]]).all()
    scored = np.r_[index(d, 'validation'), index(d, 'evaluation')]
    assert np.isfinite(hybrid[scored, :, 1]).all()
    tmp = dest/'heads_tmp.npz'
    np.savez_compressed(tmp, origins=d['origins'], heads=hybrid, train_days=tr, paired=paired)
    os.replace(tmp, dest/'heads.npz')
    joblib.dump(imputer, dest/'older_imputer.joblib')
    write(dest/'fit.json', dict(farm=farm, train_days=len(tr), train_paired=int(paired[tr].sum()),
                                paired_predictions=len(paired_query), input_columns=X.shape[1]))
    print('FIT', farm, 'paired forecasts', len(paired_query), flush=True)


def main():
    frozen_spec(OUT/'protocol.json', dict(
        farms=list(range(1, 8)), model='QRF500 leaf10 max_features=1 seed0',
        split='existing 2012 protocol, identical proper-training rows; 2011 Q2 development, 2011 H2–2012 H1 retrospective evaluation',
        input='A existing canonical R2; B add older U/V/speed and latest minus older U/V/speed for identical valid hour',
        availability='latest complete native batch at or before origin; older exactly 12h before latest; assume zero release delay, no publication timestamps',
        missing='B trained on same rows as A with training-only older medians and indicators; use A exactly when old 24-hour trajectory incomplete',
        calibration='same signed84 rolling CQR per farm per lead, complete labels only on arrival; B uses hybrid raw forecasts and exact A calibrated endpoints on fallback dates',
        matching='nominal plus 2011Q2 offset frozen separately for each analysis scope; primary operational offset from full sample; adjust only complete days, symmetric half-width shift, preserve a touched boundary when shrinking; same-width evaluation match is retrospective',
        gates='at matched width lower up-ramp upper miss, macro coverage >=90%, IS <=A, near-zero and down-ramp coverage >= A-1pp',
        inference='farm equal weight, synchronous 14-day paired date-block CI for nominal and Q2-frozen policies'))
    farms = load_farms(2012)
    assert list(farms) == list(range(1, 8))
    audit_rows = pd.concat([audit(farm, d) for farm, d in farms.items()], ignore_index=True)
    audit_rows.to_csv(OUT/'batch_availability.csv', index=False)
    summary = audit_rows.assign(valid_pair=audit_rows.valid_target & audit_rows.complete_pair).groupby(
        ['farm','phase']).agg(issued=('origin','size'), valid=('valid_target','sum'),
        paired=('complete_pair','sum'), valid_paired=('valid_pair','sum'),
        latest_at_origin=('latest_at_origin','sum'), old_hours=('old_hours_available','sum'))
    summary.to_csv(OUT/'batch_coverage_per_farm.csv')
    print(summary.groupby('phase').sum().to_string(), flush=True)
    with ProcessPoolExecutor(max_workers=7) as pool:
        list(pool.map(fit, farms))
    print('TRAINING COMPLETE', flush=True)


if __name__ == '__main__':
    main()

