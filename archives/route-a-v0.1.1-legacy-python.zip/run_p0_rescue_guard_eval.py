"""P0-followup: evaluate candidate rescue guards on evaluation (frozen transfer).

For each candidate trigger rule, the guard lowers the bound to min(R15, O) on
flagged hours and keeps R15's upper bound. Reports macro coverage/width/IS and
down-ramp / near-zero coverage, and checks the down_guard gates. Read-only; the
down-ramp classifier is trained on proper training only (no leakage).
"""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SAMPLES = ROOT / 'out_gefcom_pooling_20261105' / 'inputs'
GUARD = ROOT / 'out_gefcom_qrf_down_guard_20261106'
POINT = ROOT / 'out_gefcom_point_residual_20261106'
OUT = ROOT / 'out_gefcom_p0_rescue_20261106'


def cells(days):
    return (days[:, None] * 24 + np.arange(24)).ravel()


def increments(power, history):
    return np.diff(np.c_[history[:, -1], power], axis=1)


def added_features(x):
    speed = x[:, -12].reshape(-1, 24)
    cols = []
    for lag in (1, 2, 3):
        difference = np.full_like(speed, np.nan)
        difference[:, lag:] = speed[:, lag:] - speed[:, :-lag]
        cols.append(difference.ravel())
    return np.column_stack(cols)


def metrics(y, lo, hi, valid2, delta):
    inside = (y >= lo) & (y <= hi)
    width = hi - lo
    score = width + 20 * np.maximum(lo - y, 0) + 20 * np.maximum(y - hi, 0)
    down = (delta < -0.10) & valid2
    nz = (np.abs(y) <= 0.01) & valid2
    out = dict(
        coverage=float(inside[valid2].mean()),
        width=float(width[valid2].mean()),
        IS=float(score[valid2].mean()),
        down_cov=float(inside[down].mean()),
        down_width=float(width[down].mean()),
        nz_cov=float(inside[nz].mean()),
    )
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rules = [
        ('R15', lambda **s: np.zeros_like(s['lo_r'], dtype=bool)),
        ('O', None),  # handled separately
        ('wind_drop>=0.75', lambda **s: s['wind_drop'] >= 0.75),
        ('clf>=0.10', lambda **s: s['clf'] >= 0.10),
        ('clf>=0.15', lambda **s: s['clf'] >= 0.15),
        ('clf>=0.20', lambda **s: s['clf'] >= 0.20),
        ('gap>=0.02', lambda **s: s['gap'] >= 0.02),
        ('gap>=0.05', lambda **s: s['gap'] >= 0.05),
        ('clf>=0.10 & gap>=0.02', lambda **s: (s['clf'] >= 0.10) & (s['gap'] >= 0.02)),
        ('clf>=0.15 & gap>=0.02', lambda **s: (s['clf'] >= 0.15) & (s['gap'] >= 0.02)),
    ]
    rows = []
    for year in (2014, 2012):
        nfarms = 10 if year == 2014 else 7
        for farm in range(1, nfarms + 1):
            with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'samples.npz') as z:
                d = {k: z[k] for k in z.files}
            with np.load(SAMPLES / f'gefcom{year}' / f'farm_{farm:02d}' / 'features.npz') as z:
                fqrf = z['QRF']; fgbm = z['GBM']
            with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'R15.npz') as z:
                ids = z['ids']; lo_r = z['lo']; hi_r = z['hi']
            with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'original.npz') as z:
                lo_o = z['lo']; hi_o = z['hi']
            with np.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'wind_drop_0.750.npz') as z:
                lo_g = z['lo']
            model = joblib.load(GUARD / f'gefcom{year}' / f'farm_{farm:02d}' / 'classifier.joblib')

            y = d['y'][ids]
            valid = d['valid'][ids]
            hist = d['history'][ids]
            valid2 = np.broadcast_to(valid[:, None], y.shape)
            delta = np.diff(y, axis=1, prepend=hist[:, -1][:, None])

            gap = lo_r - lo_o
            wind_drop = -added_features(fgbm)[cells(ids), 0].reshape(y.shape)
            clf = model.predict_proba(fqrf[cells(ids)])[:, 1].reshape(y.shape)
            L_restore = np.minimum(lo_r, lo_o)
            rescuable_down = valid2 & (L_restore <= y) & (y < lo_r) & (y <= hi_r) & (delta < -0.10)

            # baselines
            for name, lo, hi in [('O', lo_o, hi_o), ('R15', lo_r, hi_r),
                                 ('G(wind_drop_0.750)', lo_g, hi_r)]:
                m = metrics(y, lo, hi, valid2, delta)
                rows.append(dict(year=year, farm=farm, method=name, **m))

            # oracle (post-hoc; reference only)
            lo_oracle = np.where(rescuable_down, L_restore, lo_r)
            m = metrics(y, lo_oracle, hi_r, valid2, delta)
            rows.append(dict(year=year, farm=farm, method='oracle', **m))

            # candidate rules
            sig = dict(lo_r=lo_r, hi_r=hi_r, lo_o=lo_o, gap=gap, wind_drop=wind_drop, clf=clf)
            for name, rule in rules:
                if rule is None:
                    continue
                flagged = rule(**sig)
                lo = np.where(flagged, L_restore, lo_r)
                m = metrics(y, lo, hi_r, valid2, delta)
                rows.append(dict(year=year, farm=farm, method=name, **m))

    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / 'guard_candidates_per_farm.csv', index=False)
    macro = frame.groupby(['year', 'method'])[['coverage', 'width', 'IS', 'down_cov', 'down_width', 'nz_cov']].mean().reset_index()
    macro.to_csv(OUT / 'guard_candidates_macro.csv', index=False)

    # gates vs O and R15 per year
    gate_rows = []
    for year, g in macro.groupby('year'):
        o = g.set_index('method').loc['O']
        r15 = g.set_index('method').loc['R15']
        for method in ['G(wind_drop_0.750)', 'clf>=0.10', 'clf>=0.15', 'clf>=0.20',
                       'gap>=0.02', 'gap>=0.05', 'clf>=0.10 & gap>=0.02', 'clf>=0.15 & gap>=0.02', 'oracle']:
            c = g.set_index('method').loc[method]
            gate_rows.append(dict(
                year=year, method=method,
                coverage=bool(c.coverage >= .9),
                width=bool(c.width < o.width and c.width <= r15.width + 0.5 * (o.width - r15.width)),
                near_zero=bool(c.nz_cov >= o.nz_cov - .01),
                down_ramp=bool(c.down_cov >= o.down_cov - .01),
                rescue=bool(c.down_cov > r15.down_cov),
                IS=bool(c.IS <= o.IS),
            ))
    gates = pd.DataFrame(gate_rows)
    gates.to_csv(OUT / 'guard_candidates_gates.csv', index=False)

    pd.set_option('display.width', 200)
    print('=== macro metrics ===')
    print(macro.round(4).to_string(index=False))
    print()
    print('=== gates (vs O / R15) ===')
    print(gates.to_string(index=False))
    print()
    print('COMPLETE')


if __name__ == '__main__':
    main()
