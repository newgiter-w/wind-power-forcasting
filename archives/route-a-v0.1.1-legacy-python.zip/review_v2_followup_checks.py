"""Second audit of REVIEW_V2: shortlist invariance and evaluation population."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from config import Config
from data import load_dataframe, build_situations
from run import segment_split
from retrieval import Retriever
from evaluate import ramp_mask, interval_score, pinball_loss

root=Path(__file__).parent
saved=json.loads((root/'out'/'ablation.json').read_text())
cfg=Config(**saved['config'])
df=load_dataframe(cfg)
d=build_situations(df,cfg)
seg=segment_split(d['origin_ts'])
ids={k:np.flatnonzero(v & d['target_valid']) for k,v in seg.items()}
cfg.use_dtw=False
ret=Retriever(d['cond'][ids['M']],d['feat'][ids['M']],d['target'][ids['M']],ids['M'],cfg)
queries=np.concatenate([ids[k] for k in ['T','V','C','E']])
scaled=ret.scaler.transform(d['feat'][queries])
_,n40=ret.nn.kneighbors(scaled,n_neighbors=40)
_,n100=ret.nn.kneighbors(scaled,n_neighbors=100)
out={'euclidean_shortlist_invariance':{'query_count':len(queries),'top20_equal':bool(np.array_equal(n40[:,:20],n100[:,:20])),'top30_equal':bool(np.array_equal(n40[:,:30],n100[:,:30]))},'evaluation_population':{}}
for name in seg:
    mask=np.asarray(seg[name]); idx=ids[name]
    dates=d['origin_ts'].iloc[idx]
    out['evaluation_population'][name]={'before_quality_filter':int(mask.sum()),'after_quality_filter':len(idx),'excluded':int(mask.sum())-len(idx),'calendar_gap_count':int((dates.diff().dropna()>pd.Timedelta(days=1)).sum()),'max_origin_gap_days':float(dates.diff().dt.total_seconds().max()/86400)}
e=ids['E']
target=d['target'][e]
rm=ramp_mask(target,cfg.capacity,cfg.ramp_threshold_frac)
# For hourly-average targets, use the last observed hour's mean at the boundary.
last_hour=np.array([df.power_filled.iloc[o-5:o+1].mean() for o in d['origin_idx'][e]])
boundary_ramp=np.abs(target[:,0]-last_hour)>.1*cfg.capacity
out['ramp_first_block']={'existing_first_block_count':int(rm[:,0].sum()),'boundary_ramps_vs_last_observed_hour':int(boundary_ramp.sum()),'current_total_ramp_cells':int(rm.sum()),'total_evaluation_cells':int(target.size)}
rng=np.random.default_rng(8)
y=rng.normal(size=(10,24));lo=rng.normal(size=y.shape);hi=lo+np.abs(rng.normal(size=y.shape))
is_value=interval_score(y,lo,hi,.1)
pin_value=20*(pinball_loss(y,lo,.05)+pinball_loss(y,hi,.95))
out['ordered_interval_score_identity_abs_error']=abs(is_value-pin_value)
# Dates are origin/last-observed timestamps, not target dates.
out['quality_by_e_origin_month']={}
for month in range(1,13):
    mask=np.asarray(seg['E'] & (d['origin_ts'].dt.month==month))
    out['quality_by_e_origin_month'][str(month)]={'origins':int(mask.sum()),'excluded':int((mask & ~d['target_valid']).sum())}
path=root/'review_v2_followup_checks.json'
path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
