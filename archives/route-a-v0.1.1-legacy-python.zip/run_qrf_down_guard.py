"""Protect the lower side of R15 on forecast down-ramp risk."""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from gefcom_protocol_v2 import PKG
from run_qrf_power_increment import cells, increments
from run_qrf_regime_bounds import (OUT as PRIOR, BASE, ROOT, GROUPS, REVISION, load_farms,
    feature_array, index, local_heads, calibration, variants, collect, masks, added_features,
    frozen_spec, write, bootstrap, METRIC_COLS)
from report_qrf_speed_delta import table

OUT=ROOT/'out_gefcom_qrf_down_guard_20261106'
RULES={f'{key}_{value:.3f}':(key,value) for key,values in
       [('classifier',(.10,.15,.20,.30)),('median_drop',(.025,.05,.10)),
        ('wind_drop',(.25,.50,.75))] for value in values}


def replay(year,stage,rules):
    rows,daily,guard_stats=[],{},[]
    for farm,d in load_farms(year).items():
        ids=index(d,stage)
        folder=OUT/f'gefcom{year}/farm_{farm:02}'
        folder.mkdir(parents=True,exist_ok=True)
        old=BASE/f'gefcom{year}/farm_{farm:02}'
        with np.load(old/f'{stage}_direct_qrf.npz') as z:
            np.testing.assert_equal(z['ids'],ids)
            orig_lo,orig_hi=z['lo'],z['hi']
            assert (z['max_label_end']<=d['origins'][ids]).all()
        if stage=='evaluation':
            with np.load(PRIOR/f'gefcom{year}/farm_{farm:02}/R15.npz') as z:
                np.testing.assert_equal(z['ids'],ids)
                rlo,rhi=z['lo'],z['hi']
                assert (z['max_calibration_end']<=d['origins'][ids]).all()
        else:
            lo,hi=local_heads(year,farm,'QRF',0)
            _,base=calibration(d,lo,hi,stage)
            wind=added_features(feature_array(year,farm,'GBM'))[:,0].reshape(-1,24)
            risk=np.load(REVISION/f'mlp/gefcom{year}/farm_{farm:02}/risk_probabilities.npz')['probability']
            rlo,rhi=next((l,u) for name,l,u,_ in variants(d,ids,index(d,'validation_seed'),
                            lo,hi,orig_lo,orig_hi,base['q_signed'],wind,risk) if name=='R15')
        x=feature_array(year,farm,'QRF')
        tr=index(d,'train',True)
        y=d['y'][ids]
        actual=increments(y,d['history'][ids])
        assert d['ends'][tr].max()<=d['origins'][ids].min()
        model_path=folder/'classifier.joblib'
        if model_path.exists():
            model=joblib.load(model_path)
        else:
            event=increments(d['y'][tr],d['history'][tr])<-.10
            model=HistGradientBoostingClassifier(**PKG).fit(x[cells(tr)],event.ravel())
            joblib.dump(model,model_path,compress=1)
        probability=model.predict_proba(x[cells(ids)])[:,1].reshape(y.shape)
        np.testing.assert_equal(probability,joblib.load(model_path).predict_proba(x[cells(ids)])[:,1].reshape(y.shape))
        with np.load(old/'heads.npz') as z:
            np.testing.assert_equal(z['origins'],d['origins'])
            median_drop=-increments(z['qrf'][ids],d['history'][ids])
        wind_drop=-added_features(feature_array(year,farm,'GBM'))[cells(ids),0].reshape(y.shape)
        scores=dict(classifier=probability,median_drop=median_drop,wind_drop=wind_drop)
        methods=[('original',orig_lo,orig_hi),('R15',rlo,rhi)]
        valid=np.broadcast_to(d['valid'][ids,None],y.shape)
        for name in rules:
            key,cutoff=RULES[name]
            flagged=scores[key]>=cutoff
            lower=np.where(flagged,np.minimum(rlo,orig_lo),rlo)
            assert (lower<=rlo).all()
            changed=lower<rlo
            methods.append((name,lower,rhi))
            guard_stats.append(dict(year=year,stage=stage,farm=farm,method=name,hours=int(valid.sum()),
                flagged=int((flagged&valid).sum()),changed=int((changed&valid).sum()),
                down_events=int(((actual<-.10)&valid).sum()),
                rescued_down=int(((actual<-.10)&valid&(y<rlo)&(y>=lower)&(y<=rhi)).sum())))
        groups=masks(y,d['history'][ids,-1])
        for method,l,u in methods:
            assert np.isfinite(l).all() and np.isfinite(u).all() and (l<=u).all()
            collect(rows,d,ids,l,u,year=year,farm=farm,stage=stage,method=method)
            if stage=='evaluation':
                np.savez_compressed(folder/f'{method}.npz',ids=ids,lo=l,hi=u)
                vals=[u-l,(y>=l)&(y<=u),u-l+20*np.maximum(l-y,0)+20*np.maximum(y-u,0),y>u]
                for g in GROUPS:
                    keep=groups[g]&valid
                    daily[method,farm,g]=(d['origins'][ids],np.column_stack(
                        [keep.sum(axis=1)]+[np.where(keep,v,0).sum(axis=1) for v in vals]))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{year}_{stage}_per_farm.csv',index=False)
    pd.DataFrame(guard_stats).to_csv(OUT/f'{year}_{stage}_guards.csv',index=False)
    m=frame.groupby(['method','group'])[METRIC_COLS].mean()
    m.to_csv(OUT/f'{year}_{stage}_macro.csv')
    return m,daily


def gates(m,name):
    a,b,c=(m.loc[k] for k in ('original','R15',name))
    width0,width15,width=a.loc['all','width'],b.loc['all','width'],c.loc['all','width']
    return dict(coverage=bool(c.loc['all','coverage']>=.9),
      width=bool(width<width0 and width<=width15+.5*(width0-width15)),
      up_upper=bool(c.loc['up_ramp','upper_miss']<a.loc['up_ramp','upper_miss'] and
                    c.loc['up_ramp','upper_miss']==b.loc['up_ramp','upper_miss']),
      near_zero=bool(c.loc['near_zero','coverage']>=a.loc['near_zero','coverage']-.01),
      down_ramp=bool(c.loc['down_ramp','coverage']>=a.loc['down_ramp','coverage']-.01),
      rescue=bool(c.loc['down_ramp','coverage']>b.loc['down_ramp','coverage']),
      IS=bool(c.loc['all','IS']<=a.loc['all','IS']))


def main():
    assert json.loads((PRIOR/'selection.json').read_text())['selected']=='R15'
    frozen_spec(OUT/'protocol.json',dict(seed=0,rules={k:list(v) for k,v in RULES.items()},
        score='down classifier on proper-training label delta<-0.10, original R2 QRF inputs, 50 rounds; original QRF median drop; same-issue NWP speed drop',
        guard='on flagged hours min(R15 lower, original lower); R15 upper',
        choice='2014Q2 only; lowest IS among passing rules, ties prefer narrower; diagnostic lowest IS among fewest failed gates if none pass',
        gates='coverage >=90%; retain >=half R15 shrinkage and all upper-miss gain; down and near coverage lose <=1pp vs original; down coverage improves vs R15; IS <= original',
        evaluation='same frozen rule on both previously inspected evaluation windows',
        bootstrap='2000 paired synchronous 14-day moving blocks'))
    dev,_=replay(2014,'validation',RULES)
    checks={k:gates(dev,k) for k in RULES}
    passed=[k for k in RULES if all(checks[k].values())]
    chosen=min(RULES,key=lambda k:(sum(not v for v in checks[k].values()),dev.loc[(k,'all'),'IS'],dev.loc[(k,'all'),'width']))
    frozen_spec(OUT/'selection.json',dict(chosen=chosen,passing=passed,checks=checks))
    print('FROZEN',chosen,len(passed),flush=True)
    rows,blocks,judgment=[],[],{}
    for year,stage in [(2014,'validation'),(2014,'evaluation'),(2012,'evaluation')]:
        if stage=='validation':
            m=dev
        else:
            m,daily=replay(year,stage,[chosen])
            judgment[str(year)]=gates(m,chosen)
            for base in ('original','R15'):
                pair={('original' if k==base else chosen,f,g):v
                      for (k,f,g),v in daily.items() if k in (base,chosen)}
                blocks.extend(dict(reference=base,**r) for r in bootstrap(year,pair,chosen))
        for k in ('original','R15',chosen):
            a=m.loc[k]
            rows.append([year,stage,k,f"{100*a.loc['all','coverage']:.2f}",
                         f"{100*a.loc['all','width']:.2f}",f"{100*a.loc['up_ramp','upper_miss']:.2f}",
                         f"{100*a.loc['near_zero','coverage']:.2f}",f"{100*a.loc['down_ramp','coverage']:.2f}",
                         f"{a.loc['all','IS']:.4f}"])
    pd.DataFrame(blocks).to_csv(OUT/'paired_blocks.csv',index=False)
    checks_rows=[[year,', '.join(k for k,v in check.items() if not v) or '无'] for year,check in judgment.items()]
    paired=[]
    for a in blocks:
        if (a['group'],a['metric']) not in [('all','width'),('all','IS'),('up_ramp','upper_miss'),('down_ramp','coverage'),('near_zero','coverage'),('all','coverage')]:
            continue
        scale=1 if a['metric']=='IS' else 100
        paired.append([a['year'],a['reference'],a['group'],a['metric'],f"{a['delta']*scale:+.4f}",
                        f"[{a['low']*scale:+.4f}, {a['high']*scale:+.4f}]"])
    text=f"""# R15 下爬坡下界保护

在 2014 Q2 比较 10 个固定候选。信号来自逐场下爬坡分类器、原 QRF 中位数下降和同次 NWP 风速下降。分类器使用原 QRF 输入及原训练段，目标为小时功率下降超过装机容量 10%。命中保护时取原 QRF 和 R15 中更低的下界，以保留已有近零保护。上界逐小时取 R15 的值。

开发期通过 {len(passed)} 个规则，冻结 **{chosen}**。门槛为总体覆盖至少 90%，相对原 QRF 至少保留 R15 一半的缩宽、全部上侧漏点改善，近零及下爬坡覆盖下降各不超过 1 个百分点，IS 不升，且下爬坡覆盖优于 R15。用最小 IS 选规则。评价期只运行冻结规则。

{table(['数据','阶段','规则','总体覆盖%','宽度%容量','上爬坡上漏%','近零覆盖%','下爬坡覆盖%','IS'],rows)}

{table(['评价数据','未通过的门槛'],checks_rows)}

{table(['数据','对照','工况','指标','保护后差值','95%配对区间'],paired)}

除 IS 外，差值单位为百分点。按风场等权宏平均。配对区间用 2000 次同步跨场 14 日移动块抽样，条件于固定模型。评价为已使用过的单种子回溯。逐场保护触发、实际下界变化和补回的下爬坡数量见 guards.csv 系列。
"""
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')
    write(OUT/'completion.json',dict(chosen=chosen,development_passing=passed,evaluation=judgment,
        eligible=bool(passed and all(all(v.values()) for v in judgment.values()))))
    print('COMPLETE',judgment,flush=True)

if __name__=='__main__':
    main()
