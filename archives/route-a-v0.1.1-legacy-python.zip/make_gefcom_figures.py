"""GEFCom2014 NWP figures: A/B/C bar chart + December interval example."""
from __future__ import annotations

import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from threadpoolctl import threadpool_limits

from run_gefcom_confirm import load_full
import gefcom_data as gd
from run_gefcom_abc import build_X, fit_q
from online_calibration import simulate
from sklearn.preprocessing import StandardScaler
import pandas as pd

OUT = 'out_gefcom_confirm_corrected'


def bar_chart():
    results = json.load(open(f'{OUT}/results.json'))
    groups = ['all', 'up_ramp', 'near_zero']
    contrasts = ['A', 'B', 'C']
    macro = {}
    for g in groups:
        macro[g] = {}
        for c in contrasts:
            vals = [results[f'Zone{z}'][c]['rolling'][g] for z in range(1, 11)]
            macro[g][c] = {
                'coverage': np.mean([v['coverage'] for v in vals if v]),
                'width': np.mean([v['width'] for v in vals if v]),
                'IS': np.mean([v['IS'] for v in vals if v]),
            }
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    labels = ['A (no NWP)', 'B (+100m)', 'C (+10m/100m)']
    colors = ['#d62728', '#2ca02c', '#1f77b4']
    for i, (metric, title) in enumerate([('coverage', 'coverage'), ('width', 'width (%cap)'), ('IS', 'interval score')]):
        ax = axes[i]
        for g, mk in zip(groups, ['o', 's', '^']):
            vals = [macro[g][c][metric] * (100 if metric == 'width' else 1) for c in contrasts]
            ax.plot([0, 1, 2], vals, marker=mk, label=g, lw=1.2)
        ax.set_xticks([0, 1, 2]); ax.set_xticklabels(labels, fontsize=8, rotation=15)
        ax.set_title(title); ax.grid(alpha=0.3, axis='y')
        if metric == 'coverage':
            ax.set_ylim(0.75, 1.0); ax.axhline(0.9, ls='--', color='gray', lw=0.8)
    axes[0].legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(f'{OUT}/abc_comparison.png', dpi=110)
    plt.close(fig)
    return macro


def interval_example():
    s = gd.build_samples(load_full(1))
    origins = s['origin_ts']; t = pd.DatetimeIndex(origins)
    train = (t.year == 2012) | ((t.year == 2013) & (t.month <= 8))
    seed = (t.year == 2013) & (t.month.isin([9, 10, 11]))
    test = (t.year == 2013) & (t.month == 12)
    tv = s['target_valid']
    inputs = s['history_valid'] & s['nwp_valid']
    train = train & tv & inputs; seed = seed & tv & inputs; test = test & inputs
    target_end = origins + np.timedelta64(24, 'h')
    y = s['target']; valid = s['target_valid']
    intervals = {}
    for c in ('A', 'B'):
        X = build_X(s, c)
        sc = StandardScaler().fit(X[train]); Xs = sc.transform(X)
        lo_m = fit_q(Xs[train], y[train], 0.05); hi_m = fit_q(Xs[train], y[train], 0.95)
        lo_raw = lo_m.predict(Xs); hi_raw = hi_m.predict(Xs)
        lo = np.minimum(lo_raw, hi_raw); hi = np.maximum(lo_raw, hi_raw)
        res = simulate(origins, target_end, y, lo, hi, valid,
                       np.where(seed)[0], np.where(test)[0], 'rolling', 84)
        intervals[c] = res
    # pick a December day with a notable ramp
    test_pos = np.where(test)[0]
    y_te = y[test_pos]
    chg = np.abs(np.diff(y_te, axis=1, prepend=s['history'][test_pos, -1, None]))
    totals = np.where(tv[test_pos], np.nansum(chg, axis=1), -np.inf)
    rampday = int(np.argmax(totals))
    fig, ax = plt.subplots(figsize=(9, 4))
    x = np.arange(1, 25)
    ax.fill_between(x, intervals['A']['lo'][rampday], intervals['A']['hi'][rampday],
                    color='#d62728', alpha=0.25, label='A (no NWP)')
    ax.fill_between(x, intervals['B']['lo'][rampday], intervals['B']['hi'][rampday],
                    color='#2ca02c', alpha=0.30, label='B (+100m)')
    ax.plot(x, y_te[rampday], color='k', lw=1.5, label='actual')
    ax.set_xlabel('hour of day'); ax.set_ylabel('normalized power')
    actual_date = pd.Timestamp(origins[test_pos[rampday]]).strftime('%Y-%m-%d')
    ax.set_title(f'Zone1 · {actual_date} (retrospective high-variation example)')
    ax.grid(alpha=0.3); ax.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(f'{OUT}/interval_example.png', dpi=110)
    plt.close(fig)


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        bar_chart()
        interval_example()
        print('figures: abc_comparison.png, interval_example.png')
