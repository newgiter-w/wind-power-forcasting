"""GEFCom2014-Wind A/B/C contrast: does future NWP tighten 24h intervals?

A = history + calendar; B = A + 100m wind field (U100/V100); C = A + 10m+100m.
Same q=.05/.95 HistGBR (24 outputs), fixed CQR on 2013 Q2, score July-November.
Reports raw + calibrated coverage/width/IS and ramp/near-zero per zone + macro.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

import evaluate as ev
import gefcom_data as gd

ROOT = Path(__file__).parent
OUT = ROOT / 'out_gefcom_abc_corrected'
H0 = dict(max_iter=50, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, random_state=0)
CAP = 1.0
RAMP = 0.10
NEARZERO = 0.01


def build_X(s, contrast):
    S = len(s['history'])
    base = np.array([gd.base_features(s['history'][i], s['origin_ts'][i]) for i in range(S)])
    Xa = np.hstack([s['history'], base])
    if contrast == 'A':
        return Xa
    nwp = s['future_nwp']                     # (S, 24, 4) = U10,V10,U100,V100
    u10 = nwp[:, :, 0].reshape(S, -1); v10 = nwp[:, :, 1].reshape(S, -1)
    u100 = nwp[:, :, 2].reshape(S, -1); v100 = nwp[:, :, 3].reshape(S, -1)
    if contrast == 'B':
        return np.hstack([Xa, u100, v100])
    return np.hstack([Xa, u10, v10, u100, v100])


def split(s):
    import pandas as _pd
    t = _pd.DatetimeIndex(s['origin_ts'])
    train = (t.year == 2012)
    cal = (t.year == 2013) & (t.month.isin([4, 5, 6]))
    test = (t.year == 2013) & (t.month.isin([7, 8, 9, 10, 11, 12]))
    return np.asarray(train), np.asarray(cal), np.asarray(test)


def fit_q(X, y, q):
    m = MultiOutputRegressor(HistGradientBoostingRegressor(loss='quantile', quantile=q, **H0))
    m.fit(X, y)
    return m


def conformal_quantile(scores, conf):
    n = len(scores)
    k = int(np.ceil((n + 1) * conf)); k = min(k, n)
    return np.sort(scores)[k - 1]


def metrics(y, lo, hi, conf=0.9, *, last_power, target_valid=None):
    alpha = 1 - conf
    inside = (y >= lo) & (y <= hi)
    width = np.maximum(hi - lo, 0)
    is_cell = (width + (2/alpha)*np.where(y < lo, lo - y, 0) + (2/alpha)*np.where(y > hi, y - hi, 0)) / CAP
    # Include the transition from the last observed hour to forecast hour one.
    delta = np.diff(y, axis=1, prepend=np.asarray(last_power)[:, None])
    chg = np.abs(delta)
    up = delta > RAMP
    down = delta < -RAMP
    nz = np.abs(y) <= NEARZERO
    valid = np.isfinite(y).all(axis=1) if target_valid is None else np.asarray(target_valid)
    def g(m):
        m = m & valid[:, None]
        if not m.any():
            return None
        return {'coverage': float(inside[m].mean()), 'width': float(width[m].mean()),
                'IS': float(is_cell[m].mean()), 'cells': int(m.sum())}
    return {'all': g(np.ones_like(y, bool)), 'ramp': g(chg > RAMP), 'up_ramp': g(up), 'down_ramp': g(down),
            'near_zero': g(nz)}


def run_zone(zone):
    s = gd.build_samples(gd.load_zone(zone))
    train, cal, test = split(s)
    # keep fully-valid target days
    tv = s['target_valid']
    inputs = s['history_valid'] & s['nwp_valid']
    train = train & tv & inputs; cal = cal & tv & inputs; test = test & inputs
    y_tr = s['target'][train]; y_cal = s['target'][cal]; y_te = s['target'][test]
    out = {}
    for c in ('A', 'B', 'C'):
        X = build_X(s, c)
        sc = StandardScaler().fit(X[train])
        Xtr = sc.transform(X[train]); Xcal = sc.transform(X[cal]); Xte = sc.transform(X[test])
        lo_m = fit_q(Xtr, y_tr, 0.05); hi_m = fit_q(Xtr, y_tr, 0.95)
        lo_raw = lo_m.predict(Xte); hi_raw = hi_m.predict(Xte)
        lo_cal = lo_m.predict(Xcal); hi_cal = hi_m.predict(Xcal)
        lo_te = np.minimum(lo_raw, hi_raw); hi_te = np.maximum(lo_raw, hi_raw)
        lo_c = np.minimum(lo_cal, hi_cal); hi_c = np.maximum(lo_cal, hi_cal)
        q = np.array([conformal_quantile(np.maximum(lo_c[:, h] - y_cal[:, h], y_cal[:, h] - hi_c[:, h]), 0.9)
                      for h in range(24)])
        lo_cqr = lo_te - q[None, :]; hi_cqr = hi_te + q[None, :]
        args = dict(last_power=s['history'][test, -1], target_valid=tv[test])
        out[c] = {'raw': metrics(y_te, lo_te, hi_te, **args), 'cqr': metrics(y_te, lo_cqr, hi_cqr, **args),
                  'n_train': int(train.sum()), 'n_cal': int(cal.sum()), 'n_test': int(test.sum()),
                  'n_scored': int((test & tv).sum())}
    return out


def main():
    OUT.mkdir(exist_ok=True)
    began = time.perf_counter()
    results = {}
    for z in gd.ZONES:
        results[f'Zone{z}'] = run_zone(z)
        print(f'[done] Zone{z} ({time.perf_counter()-began:.1f}s)', flush=True)
    # macro-average of CQR coverage/width/IS
    print('\n===== CQR macro-average (across 10 zones) =====')
    for g in ('all', 'up_ramp', 'near_zero'):
        line = f'  {g:9s}'
        for c in ('A', 'B', 'C'):
            vals = [results[f'Zone{z}'][c]['cqr'][g] for z in range(1, 11)]
            cov = np.mean([v['coverage'] for v in vals if v])
            w = np.mean([v['width'] for v in vals if v])
            is_ = np.mean([v['IS'] for v in vals if v])
            line += f"  {c}: cov={cov*100:5.1f}% w={w*100:5.1f}% IS={is_:.3f}"
        print(line)
    (OUT / 'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2, default=str),
                                      encoding='utf-8')
    print(f'\n[done] -> {OUT / "results.json"} ({time.perf_counter()-began:.1f}s)')


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        main()
