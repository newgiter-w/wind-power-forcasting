"""Summarize paired hourly increment forecasts and time-block uncertainty."""
import json
import numpy as np
import pandas as pd
from run_qrf_power_increment import (OUT, BASE, cells, feature_array, load_farms,
                                     index, increments, frozen_spec, write)
from run_qrf_speed_delta import added_features
from report_qrf_speed_delta import table

METHODS = ('level_qrf', 'increment_qrf')
METRICS = ('MAE', 'bias', 'miss', 'false_alarm', 'alert_rate')
FOCUS = ('signal_all', 'signal_up', 'signal_no_up', 'up_all', 'quiet_nwp', 'quiet_actual')


def compare(year, stage):
    rows, daily, cases = [], [], []
    for farm, d in load_farms(year).items():
        ids = index(d,stage)
        valid = d['valid'][ids,None]
        actual = increments(d['y'][ids],d['history'][ids])
        dw = added_features(feature_array(year,farm,'GBM'))[cells(ids),0].reshape(-1,24)
        up = actual>.10
        signal = dw>=.50
        groups = dict(all=np.ones_like(up), signal_all=signal, signal_up=signal&up,
                      signal_no_up=signal&~up, up_all=up, quiet_nwp=abs(dw)<.25,
                      quiet_actual=abs(actual)<=.05)
        with np.load(BASE/f'gefcom{year}/farm_{farm:02}/heads.npz') as old:
            np.testing.assert_array_equal(old['origins'],d['origins'])
            baseline = increments(old['qrf'][ids],d['history'][ids])
        with np.load(OUT/f'gefcom{year}/farm_{farm:02}/increments.npz') as new:
            pos=np.searchsorted(new['days'],ids)
            np.testing.assert_array_equal(new['days'][pos],ids)
            np.testing.assert_array_equal(new['origins'][pos],d['origins'][ids])
            np.testing.assert_array_equal(new['train_days'],index(d,'train',True))
            candidate=new['forecast'][pos]
        for method, pred in zip(METHODS,(baseline,candidate)):
            assert np.isfinite(pred).all()
            error = pred-actual
            alert = pred>.10
            metrics=dict(MAE=abs(error),bias=error,miss=up&~alert,
                         false_alarm=~up&alert,alert_rate=alert)
            for group,mask in groups.items():
                keep=mask&valid
                if keep.any():
                    rows.append(dict(year=year,stage=stage,farm=farm,method=method,group=group,
                                     n=int(keep.sum()),miss_n=int((keep&metrics['miss']).sum()),
                                     false_alarm_n=int((keep&metrics['false_alarm']).sum()),
                                     **{k:float(v[keep].mean()) for k,v in metrics.items()}))
                if stage=='evaluation' and group in FOCUS:
                    sums = [keep.sum(axis=1)]+[np.where(keep,metrics[k],0).sum(axis=1) for k in METRICS]
                    daily.append((method,farm,group,d['origins'][ids],np.column_stack(sums)))
        if stage=='evaluation' and year==2012 and farm==1:
            for date in ('2011-09-02','2012-03-02'):
                ix=int(np.flatnonzero(d['origins'][ids]==np.datetime64(date))[0])
                for h in range(24):
                    cases.append(dict(date=date,lead=h+1,actual=actual[ix,h],baseline=baseline[ix,h],
                                      increment_model=candidate[ix,h],wind_delta=dw[ix,h]))
    frame=pd.DataFrame(rows)
    frame.to_csv(OUT/f'{year}_{stage}_per_farm.csv',index=False)
    macro=frame.groupby(['method','group'])[list(METRICS)].mean()
    macro.to_csv(OUT/f'{year}_{stage}_macro.csv')
    if cases:
        pd.DataFrame(cases).to_csv(OUT/'paired_examples_hourly.csv',index=False)
    return macro,frame,daily


def select(macro):
    base,model=(macro.loc[m] for m in METHODS)
    checks=dict(signal_up_mae=bool(model.loc['signal_up','MAE']<base.loc['signal_up','MAE']),
                signal_all_mae=bool(model.loc['signal_all','MAE']<base.loc['signal_all','MAE']),
                signal_up_miss=bool(model.loc['signal_up','miss']<base.loc['signal_up','miss']),
                all_up_miss=bool(model.loc['up_all','miss']<=base.loc['up_all','miss']),
                quiet_nwp_false_alarm=bool(model.loc['quiet_nwp','false_alarm']<=base.loc['quiet_nwp','false_alarm']+.005),
                quiet_actual_false_alarm=bool(model.loc['quiet_actual','false_alarm']<=base.loc['quiet_actual','false_alarm']+.005))
    frozen_spec(OUT/'selection.json',dict(pass_q2=all(checks.values()),checks=checks))
    print('Q2 gate',checks,flush=True)


def paired_blocks(year,daily):
    dates=pd.date_range(min(r[3][0] for r in daily),max(r[3][-1] for r in daily)).to_numpy()
    farms=sorted({r[1] for r in daily})
    data=np.zeros((2,len(farms),len(FOCUS),len(dates),1+len(METRICS)))
    for method,farm,group,origin,values in daily:
        i=np.searchsorted(dates,origin)
        np.testing.assert_equal(dates[i],origin)
        data[METHODS.index(method),farms.index(farm),FOCUS.index(group),i,:]=values
    def delta(a):
        totals=a.sum(axis=3)
        counts=totals[...,:1]
        rates=np.divide(totals[...,1:],counts,out=np.full_like(totals[...,1:],np.nan),where=counts>0)
        macro=np.nanmean(rates,axis=1)
        return macro[1]-macro[0]
    rng=np.random.default_rng(20261106+year)
    samples=[]
    n=len(dates)
    for _ in range(2000):
        starts=rng.integers(0,n-13,size=int(np.ceil(n/14)))
        selection=(starts[:,None]+np.arange(14)).ravel()[:n]
        samples.append(delta(data[:,:,:,selection,:]))
    point=delta(data)
    lo,hi=np.quantile(samples,[.025,.975],axis=0)
    return pd.DataFrame([dict(year=year,group=g,metric=k,delta=point[i,j],low=lo[i,j],high=hi[i,j])
                         for i,g in enumerate(FOCUS) for j,k in enumerate(METRICS)])


def report():
    output,counts,intervals=[],[],[]
    for year in (2014,2012):
        compare(year,'validation')
        macro,frame,daily=compare(year,'evaluation')
        boot=paired_blocks(year,daily)
        boot.to_csv(OUT/f'{year}_paired_blocks.csv',index=False)
        for method in METHODS:
            for group in FOCUS:
                a=macro.loc[(method,group)]
                total=frame[(frame.method==method)&(frame.group==group)]
                counts.append([year,method,group,int(total.n.sum()),int(total.miss_n.sum()),int(total.false_alarm_n.sum())])
                output.append([year,method,group,f'{100*a.MAE:.2f}',f'{100*a.bias:+.2f}',
                               f'{100*a.miss:.2f}' if group in ('signal_up','up_all') else '—',
                               f'{100*a.false_alarm:.2f}' if group in ('signal_no_up','quiet_nwp','quiet_actual') else '—'])
        for group,metric in [('signal_all','MAE'),('signal_up','MAE'),('signal_up','miss'),
                             ('up_all','miss'),('quiet_nwp','false_alarm'),('quiet_actual','false_alarm')]:
            a=boot[(boot.group==group)&(boot.metric==metric)].iloc[0]
            intervals.append([year,group,metric,f'{100*a.delta:+.3f}',f'[{100*a.low:+.3f}, {100*a.high:+.3f}]'])
    decision=json.loads((OUT/'selection.json').read_text())
    text=f"""# 小时功率增量 QRF 配对对照

两套 GEFCom 共 17 个风场。两种模型使用相同的逐场 R2 输入、时间切分、500 树及叶大小 10，固定种子 0。原方案由相邻两个功率中位数求差，新增方案直接训练并输出增量的中位数。第 1 小时均以发报时最后一个实测功率为前值。第 2–24 小时的新增方案使用同一发报时刻的输入直接出结果。中位数之差和增量的中位数是不同的统计量。

实测和预测的上爬坡阈值均为单小时增幅严格大于装机容量的 10%。signal_all 包含所有同批 NWP 同小时风速差至少 +0.5 m/s 的时点。signal_up 与 signal_no_up 分别是其中实测发生和未发生上爬坡的子集。quiet_nwp 指同小时预报风速变化绝对值小于 0.25 m/s，quiet_actual 指实测功率变化绝对值不超过容量的 5%。quiet_nwp 的误报分母是该组全部有效小时。第 1 小时纳入总体和实测分组。

2014 Q2 预设门槛是否通过 **{decision['pass_q2']}**。每项门槛见 selection.json，所有评价结果照常报告。本轮仅验证增量预测，未改变原区间模型。

{table(['数据','方法','工况','增量 MAE（容量pp）','增量偏差（容量pp）','漏报率%','误报率%'],output)}

{table(['数据','方法','工况','事件数','漏报数','误报数'],counts)}

{table(['数据','工况','指标','新增减原始（pp）','95%配对区间'],intervals)}

比例和误差表按风场等权宏平均，计数表直接汇总事件。配对区间使用 2000 次同步 14 日移动块抽样，条件于固定种子和已训练模型。评价期为既有的回溯窗口。
"""
    (OUT/'RESULTS.md').write_text(text,encoding='utf-8')
    write(OUT/'completion.json',dict(status='complete',farms=17,seed=0,selection=decision))
    print('REPORT COMPLETE',OUT/'RESULTS.md',flush=True)


if __name__=='__main__':
    report()
