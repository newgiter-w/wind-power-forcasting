"""Freeze the scope after an outcome-blind runtime pilot."""
import shutil
import platform
import sklearn
from retraining_common import OUT,ROOT,frozen_spec,write


def main():
    OUT.mkdir(exist_ok=True)
    frozen_spec(OUT/'protocol.json',dict(date='2026-11-05',datasets=[2014,2012],methods=['frozen','expanding','rolling365'],
        seeds=[0],workers=6,forest_workers=2,model='QRF500,leaf10,max_features1,bootstrap,full leaf responses,weighted-linear quantiles .05/.95',
        features='unchanged canonical factorial-v2 R2; train-only median plus missing indicators, refitted at each model version',
        training='per-farm; refit first calendar day monthly; use complete arrived target days ending <= issue minus84 calendar days',
        expanding='all eligible earlier training days',rolling365='target_end in (issue-84days-365days,issue-84days]',
        heldout='target_end in (issue-84days,issue], input and complete target valid, no fitting on this buffer',
        calibration='model-specific out-of-training buffer, then within-month complete arrived feedback; signed per-lead rolling84, clip[0,1]',
        transitions='recompute held-out buffer predictions with new weights; never rescore new-model fitting rows as calibration',
        frozen='reuse original seed0 per-farm QRF models and all raw heads; monthly rolling reset must equal old continuous arrays',
        validation='2014Apr-Jun, all arms retained, descriptive gate fixed, no parameter search',
        evaluation='2014Jul-Dec;2011Jul-2012Jun27 for GEFCom2012; same eligible calendar and labels as prior work',
        gate='2014Q2 macro cov>=max(.90,frozen-.005), width<=.97frozen, IS<=frozen; near_zero/up/down coverage each>=frozen-.01',
        uncertainty='synchronous calendar7/14-day paired moving blocks2000 each, all farms together; fixed seed/model conditional',
        pilot='single2014farm1 July expanding fit for walltime before protocol; no outcome metrics viewed; model reused, not a new independent test',
        limitations=['retrospective dates already inspected','seed0 screening only, no training-seed uncertainty',
            '365-day window may contain fewer valid origins','84-day holdout delays base-model learning intentionally',
            'no new risk protection or pooling arms','later observed labels may enter next monthly fits only after calibration exclusion',
            'daily marginal coverage, no24h simultaneous guarantee'],
        environment=dict(python=platform.python_version(),sklearn=sklearn.__version__,device='CPU',source='existing .aris/compute/local.md and qrf.md')))
    dest=OUT/'source_snapshot';dest.mkdir(exist_ok=True)
    for name in ['retraining_common.py','run_retraining.py','prepare_retraining.py','analyze_retraining.py','test_retraining.py','sparse_leaf_qrf.py','online_calibration.py']:
        shutil.copy2(ROOT/name,dest/name)
    write(OUT/'launch.json',dict(status='prepared',scope='348 new500-tree fits +174 frozen-month reconstructions, seed0',
        resource='6 isolated processes,2 forest threads each; existing verified CPU environment; no installation'))


if __name__=='__main__':main()
