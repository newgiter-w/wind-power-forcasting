"""Small residual diffusion. No forecast-time targets enter the condition."""
import math
import numpy as np
import torch
from torch import nn


class HistoryAnchor(nn.Module):
    def __init__(self, inputs):
        super().__init__()
        self.encoder=nn.Sequential(nn.Linear(inputs,128),nn.SiLU(),nn.Linear(128,64),nn.SiLU())
        self.mean=nn.Linear(64,24)

    def forward(self,x):
        h=self.encoder(x)
        return self.mean(h),h


class ResidualDenoiser(nn.Module):
    def __init__(self,context=137,width=96,blocks=3,dropout=0.0):
        super().__init__()
        self.input=nn.Linear(24,width)
        self.norm=nn.ModuleList([nn.LayerNorm(width) for _ in range(blocks)])
        self.mod=nn.ModuleList([nn.Linear(context+32,2*width) for _ in range(blocks)])
        self.layers=nn.ModuleList([nn.Sequential(nn.Linear(width,width),nn.SiLU(),nn.Dropout(dropout),nn.Linear(width,width)) for _ in range(blocks)])
        self.output=nn.Sequential(nn.LayerNorm(width),nn.SiLU(),nn.Linear(width,24))
        for m in self.mod:nn.init.zeros_(m.weight);nn.init.zeros_(m.bias)

    def forward(self,z,steps,context):
        freq=torch.exp(-math.log(10000)*torch.arange(16,device=z.device)/15)
        angles=steps[:,None]*freq[None]
        c=torch.cat([context,angles.sin(),angles.cos()],dim=1)
        h=self.input(z)
        for norm,mod,layer in zip(self.norm,self.mod,self.layers):
            scale,shift=mod(c).chunk(2,dim=1)
            h=h+layer(norm(h)*(1+scale)+shift)
        return self.output(h)


class VelocityDiffusion:
    def __init__(self):
        self.beta=torch.linspace(1e-4,.02,1000,dtype=torch.float64)
        self.abar=torch.cumprod(1-self.beta,dim=0).float()

    def noisy(self,clean,steps,noise):
        a=self.abar[steps,None].sqrt();b=(1-self.abar[steps,None]).sqrt()
        return a*clean+b*noise,a*noise-b*clean

    def loss(self,net,clean,context,generator=None):
        steps=torch.randint(1000,(len(clean),),generator=generator)
        noise=torch.randn(clean.shape,generator=generator)
        z,v=self.noisy(clean,steps,noise)
        return (net(z,steps,context)-v).square().mean()

    @torch.no_grad()
    def sample(self,net,context,samples=200,steps=40,seed=8101):
        # Each origin receives the same pre-fixed noise pool across methods/seeds.
        generator=torch.Generator().manual_seed(seed)
        initial=torch.randn((samples,24),generator=generator)
        times=torch.linspace(999,0,steps).round().long()
        output=[]
        for c in context:
            z=initial.clone();ctx=c[None].expand(samples,-1)
            for j,s in enumerate(times):
                prev=times[j+1] if j+1<len(times) else -1
                a=self.abar[s].sqrt();b=(1-self.abar[s]).sqrt()
                v=net(z,torch.full((samples,),int(s),dtype=torch.long),ctx)
                clean=a*z-b*v;noise=b*z+a*v
                ap=self.abar[prev] if prev>=0 else torch.tensor(1.)
                z=ap.sqrt()*clean+(1-ap).sqrt()*noise
            output.append(z.numpy())
        return np.stack(output)
